<center>
<a href="{register_href}">Register new account</a><br />
{loginformstart}
<div style="color:red;font-weight:bold">{loginform_info}</div>
<table border="0" cellpadding="5" width="500">
<tr><td width="250" align="right">Login</td><td>{loginform_login}</td></tr>
<tr><td align="right">Password</td><td>{loginform_password}</td></tr>
<tr>
  <td align="right"></td>
  <td align="left">{loginform_submit}&nbsp;&nbsp;&nbsp;&nbsp; {loginform_remember}&nbsp;Remember me?</td></tr>
<tr>
  <td colspan="2" align="center"></td></tr>
</table>
{loginformend}
</center>
