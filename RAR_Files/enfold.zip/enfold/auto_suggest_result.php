{agentresult}
<h3 class="primary-background">Real Estate Agent Team</h3>
<ul>
{searchresults}
	<li class="row_{row_num_even_odd}">
      <div style="max-width:680px;">  
		<div class="image">
			<a href="./agents/{agent_link}"><img src="{agent_thumbnail rank='0'}" width="120" alt="{agent fieldvalue='title'}"></a>
		</div>
		<div class="info">
			<strong>{agent fieldvalue='title'}</strong><br>
			{agent fieldvalue='agent_first_name'} {agent fieldvalue='agent_last_name'} <br>
			Cell: {agent fieldvalue='agent_cellphone'} <br>
			<a class="fullview" href="./agents/{agent_link}"><strong>View Full Details &raquo;</strong></a>
		</div>
          </div>  
	</li>
{/searchresults}
</ul>
{/agentresult}

{listingresult}
<h3 class="footer_color">Real Estate Listings</h3>
<ul style="z-index:1 !important;position:relative;">
{searchresults}
	<li class="row_{row_num_even_odd}">
    <div style="max-width:680px;">
		<div class="image">
			<a href="{full_link_to_listing}" title="{listing field='title'}"><img src="{listing_image_thumb_url}" style="width:120px; height:90px;" alt="{listing field='title'}"></a>
		</div>
		<div class="info">
        <b>Address:</b> {listing field='address'}, {listing field='city'}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>MLS:</b> {listing field='MLS'}<br />
			<b>Price:</b> {listing field='Price'}&nbsp;&nbsp;&nbsp;&nbsp;{if {!listing field='Bedrooms'}}<b>Beds:</b> {listing field='Bedrooms'}{endif}&nbsp;&nbsp;&nbsp;&nbsp;{if {!listing field='Bathrooms'}}<b>Baths:</b> {listing field='Bathrooms'}{endif}&nbsp;&nbsp;&nbsp;&nbsp;{if {!listing field='EstSqFt'}}<b>EstSqFt:</b> {listing field='EstSqFt'}{endif}<br />
{listing field='remarks' limit='60'}<a href="{full_link_to_listing}" class="main_color"><i>...read more</i></a>
		</div>
      </div>  
	</li>
{/searchresults}
</ul>
{/listingresult}