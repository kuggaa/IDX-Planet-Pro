<div class="flex_column av_three_fourth  flex_column_div first">
<div class="flex_column av_one_full  flex_column_div first  avia-builder-el-0  el_before_av_one_full  avia-builder-el-first  ">
<div id="carousel-listing" class="carousel slide post-carusel" data-ride="carousel" data-interval="false">
<div class="slider-property-status ribbon-wrapper- "></div>
<div id="slider_enable_map"><i class="fa fa-map-marker"></i></div>
<div id="slider_enable_street"><i class="fa fa-location-arrow"></i></div>
<div id="slider_enable_slider"><i class="fa fa-picture-o"></i></div>
<div id="gmapzoomplus" class="smallslidecontrol"><i class="fa fa-plus"></i> </div>
<div id="gmapzoomminus" class="smallslidecontrol"><i class="fa fa-minus"></i></div>
<div id="googleMapSlider" data-post_id="{listing field='listingsdb_id'}" data-cur_lat="{listing field='latitude'}" data-cur_long="{listing field='longitude'}" style="overflow: hidden; transform: translateZ(0px) translateZ(0px); display: none; background-color: rgb(229, 227, 223);">
</div>
<!-- Wrapper for slides -->
<script type="text/javascript">
function showIt() {document.getElementById("ld-photos").style.visibility = "visible";}
setTimeout("showIt()", 1500); // after 1.5 sec
</script>
<div class="carousel-inner">
<div id="ld-photos" style="visibility: hidden;">{image_gallery}</div>
</div>
</div>
</div>
<div class="flex_column av_one_half first avia-builder-el-7 el_before_av_one_half avia-builder-el-first">
<div class="property">
<h3 class="wpr-title">Property Details</h3>
{headline}</div>
<div class="interior">
<h3 class="wpr-title">Interior Features</h3>
{interior}</div>
</div>
<div class="flex_column av_one_half avia-builder-el-8 el_after_av_one_half el_before_av_one_full">
<div class="exterior">
<h3 class="wpr-title">Exterior Features</h3>
{exterior}</div>

<div>
<h3 class="wpr-title">Financial Information</h3>
{financial}</div>
</div>
    <div class="mylistings">
      <h3 class="agent_listings_title_similar">Similar Listings</h3>
[//shortcode fields="City|Bedrooms|TotalBaths|ComplexSubdivision|Type|PropertyType" values="{listing field='City'}|{listing field='Bedrooms'}|{listing field='TotalBaths'}|{listing field='ComplexSubdivision'}|{listing field='Type'}|{listing field='PropertyType'}"  template="similar_listings.php"  sort_type="LOCAL" count="3"]
    </div>
  <div id="disclaimer"> This Listing is Courtesy of: {listing field='ListOfficeName'}. This information is deemed reliable, but not guaranteed. The buyer is responsible for verifying all information. This information is provided for use by its members and is not intended for any other purpose. This information is provided exclusively for consumers' personal, non-commercial use and may not be used for any purpose other than to identify prospective properties consumers may be interested in purchasing.
    <p>This data is updated on a daily basis. Some properties which appear for sale on this web site may subsequently have sold and may no longer be available.</p>
  </div>
  [inbound_forms id="5582" name="Listing Information"]
</div>


<div class="flex_column av_one_fourth  flex_column_div  avia-builder-el-1  el_after_av_one_full ">
<div class="agent_contanct_form_sidebar">

<div class="agent_unit">
<div class="agent-unit-img-wrapper">
<img width="265" height="163" src="http://newpresales.com/wp-content/uploads/2015/10/DeniseMai.png" class="img-responsive wp-post-image" alt="Denise Mai" >
</div>    
<div class="">
<h4>Denise Mai</h4>
<div class="agent_position">buying agent</div><div class="agent_detail"><i class="fa fa-phone"></i>604.439.2266</div><div class="agent_detail"><i class="fa fa-mobile"></i>778.858.0996</div><div class="agent_detail"><i class="fa fa-envelope-o"></i>denisemai@remax.net</div><div class="agent_detail"><i class="fa fa-skype"></i>Denise Mai.wp</div><div class="agent_detail"><i class="fa fa-desktop"></i></div>        </div> 
<div class="agent_unit_social">
<div class="social-wrapper"> 
<a href="http://wpresidence.net/"><i class="fa fa-facebook"></i></a> <a href="http://wpresidence.net/"><i class="fa fa-twitter"></i></a> <a href="http://wpresidence.net/"><i class="fa fa-linkedin"></i></a> <a href="http://wpresidence.net/"><i class="fa fa-pinterest"></i></a>              
</div>
</div>
</div>
<div class="clearfix"></div>
<h3 class="wpr-title">Listing Information</h3>
<div class="contactform-box">
<?php gravity_form(1, $display_title=false, $display_description=true, false, '', false); ?>
</div>
<div id="mini-calc">
<h3 class="wpr-title">Mortgage Calculator</h3>
<div id="calc-container" style="font-family:Arial, Helvetica, sans-serif; font-size:12px;">
<form action="POST" name="myform">
<script type="text/javascript">
function Morgcal() {
form = document.myform;
LoanAmount= form.LoanAmount.value;
//take out
LoanAmount= form.LoanAmount.value.substr(1,form.LoanAmount.value.length);
//take out
LoanAmount=LoanAmount.replace(/,/,"");
LoanAmount=LoanAmount.replace(/,/,"");
LoanAmount=LoanAmount.replace(/,/,"");
DownPayment= "0";
AnnualInterestRate=form.InterestRate.value/100;
Years= form.NumberOfYears.value;
MonthRate=AnnualInterestRate/12;
NumPayments=Years*12;
Prin=LoanAmount-DownPayment;
MonthPayment=Math.floor((Prin*MonthRate)/(1-Math.pow((1+MonthRate),(-1*NumPayments)))*100)/100;
form.NumberOfPayments.value=NumPayments;
form.MonthlyPayment.value=MonthPayment;
}
</script>
<div id="calculator" style="background:#fcfcfc; border:#efefef thin solid; width:100%; margin-bottom:20px;">
<div class="calculator">Loan Amount $
<input type="text" size="10" name="LoanAmount" value="{listing field='price'}" onBlur="Morgcal()" onChange="Morgcal()">
</div>
<div class="calculator">Annual Interest Rate %
<input type="text" size="2" name="InterestRate" value="3.0" onBlur="Morgcal()" onChange="Morgcal()">
</div>
<div class="calculator">Term of Loan x/Years
<input type="text" size="2" name="NumberOfYears" value="30" onBlur="Morgcal()" onChange="Morgcal()">
</div>
<div style="margin: 0px; height:26px; float: right; padding-right:20px; clear: both;">
<input style="height:26px !important;" type="button" name="morgcal" value="Calculate" language="JavaScript" onClick="Morgcal()" />
</div>
<div id="payments" style="clear: both;">
<div class="calculator">Number of Payments
<input type="text" size="7" name="NumberOfPayments">
</div>
<div class="calculator">Monthly Payment $
<input type="text" size="7" name="MonthlyPayment">
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>


<script type='text/javascript'>
/* <![CDATA[ */
var googlecode_property_vars = {"general_latitude":"{listing field='latitude'}","general_longitude":"{listing field='longitude'}","path":"http:\/\/vancouver.mlsplugin.com\/wp-content\/themes\/wpresidence\/css\/css-images","markers":"[[\"{listing field='title'}\",{listing field='latitude'},{listing field='longitude'},1,\"%3Cimg%20width%3D%22400%22%20height%3D%22180%22%20src%3D%22{listing_image_thumb_url}%22%20class%3D%22attachment-property_map1%20wp-post-image%22%20alt%3D%22A%20palace%20to%20call%20your%20home.%22%20%2F%3E\",\"{listing field='Price'}%3Cspan%20class%3D%22infocur%22%3E%3C%2Fspan%3E\",\"{listing field='remarks' limit='50'}\",\"\",\"\",\"\",{listing field='listingsdb_id'},\"\",\"\",\"\",\"{listing field='bedrooms'}\",\"{listing field='totalbaths'}\",\"{listing field='EstSqFt'}\",\"\",\"\"]]","camera_angle":"0","idx_status":"0","page_custom_zoom":"16","current_id":"{listing field='listingsdb_id'}","generated_pins":"0","small_map":"1","type":"ROADMAP"};
/* ]]> */
</script>