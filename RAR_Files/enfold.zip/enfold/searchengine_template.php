<h3>Search Listings:</h3>
<table border="0" style='border:1px black;' align="left" cellpadding="10">
<tr align="left" valign="top">
<td><strong>{searchenginefield_caption field_name='listing_class'}</strong></td><td>{searchenginefield_generate field_name='listing_class'}</td>
</tr> 
<tr align="left">
<td><strong>{searchenginefield_caption field_name='listing_name'}</strong></td><td>{searchenginefield_generate field_name='listing_name'}</td>
</tr>
<tr align="left">
<td><strong>{searchenginefield_caption field_name='listing_price_min'}</strong></td><td>{searchenginefield_generate field_name='listing_price_min'} to {searchenginefield_generate field_name='listing_price_max'}</td>
</tr>
<tr>
<td colspan="2">{searchengine submit}</td>
</tr>
</table>