<?php
/**
 * Loads the WordPress environment and template.
 *
 * @package WordPress
 */
 
if ( !isset($wp_did_header) ) {
$wp_did_header = true;
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
wp();
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-includes/template-loader.php' );
}
?>
<?php while ( have_posts() ) : the_post(); ?>
<?php get_template_part( 'content', 'page' ); ?>
[form_1]
<?php endwhile; // end of the loop. ?>
