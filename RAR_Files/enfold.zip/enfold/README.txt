We are in the process of updating all our core "Default" templates to "HTML-5" and "Responsive".

The files included here are for general use purposes and are going to need to be modified to suit your own design. 

These template files are not even close to "perfect" and are going to go through a lot of changes over the next few months as we will be adding in multiple "Pre-Styled" template options for you to choose from.

I have also included a new quick search template that can be modified then copied and pasted into a "Wordpress Text Widget" - as seen on most of our demo sites.

And on a final *note - I will be including a new examples template in the next release that will include all of our conditional code snippets to help you to do all of the "advanced custom" options.
