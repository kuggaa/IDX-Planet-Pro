<div id="wprmeta">
<p>The custom code you inject into the head and foot sections are <strong><em>page-specific</em></strong>, this means that only <strong><em>this page</em></strong> will be affected by the code you add below.<br>To Reset Default {wp-realty tag} head/footer Code: <select onchange="document.getElementById('value1').value = this.value;
document.getElementById('value2').value = this.options[this.selectedIndex].getAttribute('altvalue');">
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>"; ?>" altvalue="">Select {wp-realty tag}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/prism.css'."' type='text/css' media='all'>
<script src='".$config['baseurl'].$config['template_dir'].'/js/jquery.min.js'."' type='text/javascript'></script>"; ?>" altvalue="<?php echo "<script src='".$config['baseurl'].$config['template_dir'].'/js/chosen.jquery.js'."' type='text/javascript'></script>
<script src='".$config['baseurl'].$config['template_dir'].'/js/prism.js'."' type='text/javascript' charset='utf-8'>
</script>
<script type='text/javascript'>
var config = {
'.chosen-select'           : {width:'100%'},
'.chosen-select-deselect'  : {allow_single_deselect:true},
'.chosen-select-no-single' : {disable_search_threshold:20, width:'100%'},
'.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
'.chosen-select-width'     : {width:'100%'}
}
for (var selector in config) {
$(selector).chosen(config[selector]);
}
</script>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/prism.css'."' type='text/css' media='all'>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/chosen2.css'."' type='text/css' media='all'>
<script src='".$config['baseurl'].$config['template_dir'].'/js/jquery.min.js'."' type='text/javascript'></script>"; ?>">{wp-realty searchpage}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/prism.css'."' type='text/css' media='all'>
<script src='".$config['baseurl'].$config['template_dir'].'/js/jquery.min.js'."' type='text/javascript'></script>"; ?>" altvalue="<?php echo "<script src='".$config['baseurl'].$config['template_dir'].'/js/chosen.jquery.js'."' type='text/javascript'></script>
<script src='".$config['baseurl'].$config['template_dir'].'/js/prism.js'."' type='text/javascript' charset='utf-8'>
</script>
</script>
<script type='text/javascript'>
var config = {
'.chosen-select'           : {width:'100%'},
'.chosen-select-deselect'  : {allow_single_deselect:true},
'.chosen-select-no-single' : {disable_search_threshold:20, width:'100%'},
'.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
'.chosen-select-width'     : {width:'100%'}
}
for (var selector in config) {
$(selector).chosen(config[selector]);
}
</script>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/prism.css'."' type='text/css' media='all'>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/chosen2.css'."' type='text/css' media='all'>
<script src='".$config['baseurl'].$config['template_dir'].'/js/jquery.min.js'."' type='text/javascript'></script>"; ?>">{wp-realty searchresults}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/layout.css'."' type='text/css' media='all'>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/css/skeleton.css'."' type='text/css' media='all'>
<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/lib/galleria/themes/classic/galleria.classic.css?ver=2.2'."' type='text/css' media='screen'>
<script src='".$config['baseurl'].$config['template_dir'].'/lib/galleria/galleria-1.2.7.min.js?ver=2.2'."' type='text/javascript'></script>
<script src='".$config['baseurl'].$config['template_dir'].'/lib/galleria/themes/classic/galleria.classic.min.js?ver=2.2'."' type='text/javascript'></script>
<script src='http://maps.google.com/maps/api/js?sensor=false' type='text/javascript'></script>"; ?>" altvalue="">{wp-realty listingdetails}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>"; ?>" altvalue="">{wp-realty register}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>"; ?>" altvalue="">{wp-realty myaccount}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>"; ?>" altvalue="">{wp-realty agentroster}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>"; ?>" altvalue="">{wp-realty officeroster}</option>
<option value="<?php echo "<link rel='stylesheet' href='".$config['baseurl'].$config['template_dir'].'/style.css'."' type='text/css' media='all'>"; ?>" altvalue="">{wp-realty myaccount}</option>
</select></p>
  <p><strong>Head Injection</strong></p>
  <p>
    <textarea id="value1" value="" name="wpr_head" style="width:99%;"><?php echo $wpr_head; ?></textarea>
    <label>Insert code into the head section of this page, just before <a href="http://www.w3schools.com/tags/tag_head.asp" target="_blank">&lt;/head&gt;</a></label>
  </p>
  <p><strong>Foot Injection</strong></p>
  <p>
    <textarea id="value2" value="" name="wpr_foot" style="width:99%;"><?php echo $wpr_foot; ?></textarea>
    <label>Insert code into the footer area of this page, just before <a href="http://www.w3schools.com/tags/tag_body.asp" target="_blank">&lt;/body&gt;</a></label>
  </p>
</div>