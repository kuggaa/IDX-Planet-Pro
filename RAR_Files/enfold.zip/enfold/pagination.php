<ul id="agentdirectory2">
  <li><a href="{firstpage}" class="first">First</a></li>
  <li><a href="{prevpage}" class="previous">&lt;&lt;</a></li>
  {numberpagination}
  <li><a href="{url}" class="{hasresult} {current}" title="Page {number}">{number}</a></li>
  {/numberpagination}
  <li><a href="{nextpage}" class="next">&gt;&gt;</a></li>
  <li><a href="{lastpage}" class="last">Last</a></li>
</ul>
<!--<a href="{prev10page}" >Prev 10</a> <a href="{next10page}">Next 10</a>-->