<style type="text/css">
.agentwrapper { 
  overflow:hidden;
}
.agentwrapper div {
   min-height: 170px;
   margin: 10px;
}
.agentimage {
  float:left; 
  margin-right:20px;
  max-width:300px;
  max-height: 270px;
}
.agentimage a{
overflow:inherit !important; position:inherit !important;display: inline !important;
}
.agentpost { 
  overflow:hidden;
  margin:10px;
  min-height:170px;
  padding: 5px;
}
@media screen and (max-width: 400px) {
.agentimage { 
    width:100% !important;
    float: none;
    margin: auto;
	max-width:100% !important;
    max-height:100% !important;
	padding-right: 10px;
  }
}
</style>
<div class="agentwrapper">
<div class="agentimage"><img title="{agent fieldvalue='name'}, {agent fieldvalue='title'}" alt="{agent fieldvalue='name'}" class="agentimage" src="{agent_photo rank='0'}">
</div>
<div class="agentpost">
<h1>{agent fieldvalue='name'}</h1>
{agent fieldvalue='title'}<br />
<a href="mailto:{agent fieldvalue='emailaddress'}" target="_blank">E-Mail {agent fieldvalue='first_name'}</a><br />
{if {!agent fieldvalue='cellphone'}}
phone: {agent fieldvalue='cellphone'}<br />
{endif}
{if {!agent fieldvalue='officephone'}}
office: {agent fieldvalue='officephone'}<br />
{endif}
<a href="{agent fieldvalue='url'}" target="_blank">{agent fieldvalue='url'}</a><br />
</div>
{agent fieldvalue='comments'}
</div>