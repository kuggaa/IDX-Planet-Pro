<style type="text/css"> 
<!-- This is default CSS that should be moved to your Wordpress Theme Style.css
ul.shortcode-pagination li {
    background: none repeat scroll 0 0 transparent !important;
    list-style: none outside none !important;
    padding-left: 0 !important;
}
ul.shortcode-pagination li a {
    background: -moz-linear-gradient(center top , #FFFFFF 1px, #F3F3F3 1px, #E6E6E6) repeat scroll 0 0 transparent !important;
    border: 1px solid #B6B6B6 !important;
    border-radius: 3px 3px 3px 3px !important;
    color: #474747 !important;
    padding: 4px 7px !important;
}
ul.shortcode-pagination li a:hover, ul.shortcode-pagination li a.current {
    background: none repeat scroll 0 0 #FFFFFF !important;
}
ul.shortcode-pagination {
    font: 12px 'Tahoma' !important;
    height: 100% !important;
    list-style-type: none !important;
    margin: 0 auto !important;
    overflow: hidden !important;
    padding: 0 !important;
}
ul.shortcode-pagination li {
    float: left !important;
    margin: 0 0 0 5px !important;
    padding: 0 !important;
}
ul.shortcode-pagination li:first-child {
    margin-left: 0 !important;
}
ul.shortcode-pagination li a {
    color: black !important;
    display: block !important;
    padding: 4px 7px !important;
    text-decoration: none !important;
}
ul.shortcode-pagination li a img {
    border: medium none !important;
}
.row_0{background:#f5f5f5 !important;}
.row_1{background:#e2eaf6 !important;}

--> 
</style>
<div id="nextprevwrapper" style="margin-bottom: 20px;">
<ul class="shortcode-pagination">
<li><a href="{firstpage}" class="first">First</a></li>
<li><a href="{prevpage}" class="previous">&lt;&lt;</a></li>
{numberpagination}
<li><a href="{url}" class="{hasresult} {current}" title="Page {number}">{number}</a></li>
{/numberpagination}
<li><a href="{nextpage}" class="next">&gt;&gt;</a></li>
<li><a href="{lastpage}" class="last">Last</a></li>
</ul>
</div>