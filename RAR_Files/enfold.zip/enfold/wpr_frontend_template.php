<div id="content">
    
  <div id="homepage">
    <div class="postarea">
        <div id="" style="margin:0px;text-align:left">
        {content}
        </div>
    </div>
  </div>


<div id="sidebar_t">
	<div id="sidebar_top"> 	
	<ul id="sidebarwidgeted">
        <li id="quicksearch" class="widget">
			<div  class='quicksearch' style="padding-bottom:10px;text-align:left">
                                <h4>Example listings</h4>
                                {!shortcode fields="City" values="{listing field='city'}" sort_type="LOCAL" count="3" template="sidebar.html"}    
            </div>
        </li>
	</ul>
	</div>
</div>



<div class="clear"></div>

    <div id="footer">
        <p align="center">Copyright &copy; 2010 &middot; All Rights Reserved &middot; <a href="http://www.wprealty.org">Real Estate Websites</a> by <a href="http://www.wprealty.org" >WP Realty</a>    
        </p>
    </div>
</div>
{jqueryend_scripts}
