<div class="something">There are currently&nbsp;<strong>{active_agent_rows}&nbsp;</strong> active agents found.</div>

<ul id="agentdirectory">
{agentroster_pagination}
<li><a href="#" class="{hasagents} {current}" title="Agents A">A</a></li>
{/agentroster_pagination}
</ul>