<center>
<form method="post">
<h3>Modify Account</h3>
<table border="0" cellpadding="5" width="500">
<tr><td width="250" align="right">Username</td><td><input type="text" value="{user field='user_username'}" name="" disabled="true" /></td></tr>
<tr><td align="right">First Name</td><td><input type="text" value="{user field='user_firstname'}" name="firstname" /></td></tr>
<tr><td align="right">Last Name</td><td><input type="text" value="{user field='user_lastname'}" name="lastname" /></td></tr>
<tr><td align="right">Email</td><td><input type="text" value="{user field='user_email'}" name="email" /></td></tr>
<tr><td align="right">Phone</td><td><input type="text" value="{user field='user_phone'}" name="phone" /></td></tr>
<tr><td align="right">Mobile</td><td><input type="text" value="{user field='user_mobile'}" name="mobile" /></td></tr>
<tr><td align="right">Fax</td><td><input type="text" value="{user field='user_fax'}" name="fax" /></td></tr>
<tr><td align="right">Homepage</td><td><input type="text" value="{user field='user_homepage'}" name="homepage" /></td></tr>
<tr><td align="right">Info</td><td><textarea name="info">{user field='user_info'}</textarea></td></tr>
<tr><td colspan="2" align="center"><input type="submit" name="modify_account" value="Save!" /></td></tr>
</table>
</form>
<h3>Change Password</h3>
<table border="0" cellpadding="5" width="500">
<form method="post">
<tr><td align="right">Old Password</td><td><input type="password" name="oldpassword" /></td></tr>
<tr><td align="right">New Password</td><td><input type="password" name="newpassword" /></td></tr>
<tr><td align="right">Password (again)</td><td><input type="password" name="newpassword_reply" /></td></tr>
<tr><td align="right" colspan="2"><input type="submit" name="changepass" value="Change!" /></td></tr>
</form>
</table>


</center>
