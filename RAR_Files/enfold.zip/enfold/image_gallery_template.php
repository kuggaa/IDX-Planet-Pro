<?php //var_dump($config); ?>
<!--javascript for Galleria - Options List @ http://galleria.io/docs/options/ -->
<script type="text/javascript">
//setup galleria
	Galleria.loadTheme('<?php echo $config['wpr_baseurl'].$config['template_dir']; ?>/lib/galleria/themes/classic/galleria.classic.min.js');
	Galleria.configure({
	preload: '0',
	lightbox: true,
	responsive: true,
    transition: 'fade',
    imageCrop: true
});
	Galleria.run('.galleria', {
    autoplay: 3000 // will move forward every 3 seconds
});
</script>
<style type="text/css">
.post-carusel {background:none !important;}

.galleria {width: 100%; height: 520px; z-index:0;position: relative;}
@media screen and (max-width: 997px) {
  .galleria {width:100%; height:480px;}
}
@media screen and (max-width: 858px) {
  .galleria {width:100%; height:460px;}
}
@media screen and (max-width: 767px) {
  .galleria {width:100%; height:420px;}
}
@media screen and (max-width: 479px) {
  .galleria {width:100%; height:300px;}
}
@media screen and (max-width: 380px) {
  .galleria {width:100%; height:220px;}
}
</style>

<!--default divs for Galleria-->
<div class="galleria">
	{repeat_image_row}
	<a href="{image_url}"><img src="{image_url}"></a>
	{/repeat_image_row}
</div>

