<div id="officeid_{office fieldvalue='id'}" class="agent_roster clearfix">
    <div class="agentphoto"><a title="{office fieldvalue='name'}" href="{office_link}"> 
    <img width="150" height="150" title="{office fieldvalue='name'}" alt="{office fieldvalue='name'}" class="attachment-thumbnail wp-post-image" src="{office_thumbnail rank='0'}"></a></div>
    <div class="agentsummary">
<h3>{office fieldvalue='name'}</h3>
<p>{office field='adress'}: {office fieldvalue='adress'}<br>
   {office field='url'}: <a href="{office fieldvalue='url'}">{office fieldvalue='url'}</a></p>

<div class="clear"></div>
	</div>
</div>
<?php
error_reporting(E_ALL);
echo substr('abcdefghijklmnop', 0, 4);
echo "Hello World";
?>