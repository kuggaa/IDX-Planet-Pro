<div class="something">There are currently&nbsp;<strong>{active_office_rows}&nbsp;</strong> active offices found.</div>
{office_letter_pagination}
{office_number_pagination}
{offices}
<div id="officeid_{office fieldvalue='id'}" class="agent_roster clearfix agents_row_{row_even_odd} {featuredoffice}">
    <div class="agentphoto"><a title="{office fieldvalue='name'}" href="{office_link}"> 
    <img width="150" height="150" title="{office fieldvalue='name'}" alt="{office fieldvalue='name'}" class="attachment-thumbnail wp-post-image" src="{office_thumbnail rank='0'}"></a></div>
    <div class="agentsummary">
<h3>{office fieldvalue='name'}</h3>
<p>{office field='adress'}: {office fieldvalue='adress'}<br>
   {office field='url'}: <a href="{office fieldvalue='url'}">{office fieldvalue='url'}</a></p>
<a title="{office fieldvalue='name'}" href="{office_link}"> Learn More ? </a>
<div class="clear"></div>
	</div>
</div>
{/offices}
<?php
error_reporting(E_ALL);
echo substr('abcdefghijklmnop', 0, 4);
echo "Hello World";
?>