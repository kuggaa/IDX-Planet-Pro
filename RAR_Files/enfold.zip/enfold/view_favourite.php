<table border="0" width="100%" style="font-size: 12px;">
<tr style="font-weight: bold;font-size:15px;text-align:center">
    <td></td>
    <td><a href="{searchresultsort field_name='title'}">Title</a></td>
    <td><a href="{searchresultsort field_name='city'}">City</a></td>
    <td><a href="{searchresultsort field_name='zip'}">Zip</a></td>
    <td><a href="{searchresultsort field_name='state'}">State</a></td>
    <td><a href="{searchresultsort field_name='price'}">Price</a></td>
</tr>
{favorites}
<tr>
    <td><div style=''>
            <img src="{listing_image_url}" style='width:120px;height:80px' />
        </div>
    </td>
    <td><a href="{full_link_to_listing}">{listing field='title'}</a></td>
    <td>{listing field='city'}</td>
    <td>{listing field='zip'}</td>
    <td>{listing field='state'}</td>
    <td>{listing field="price'}</td>
<td><a href="{delfavoriteshref}" onclick='return false' class='alertinfo' name="Delete this listing?">Delete from favorites</a></td>
</tr>
{/favorites}
</table>