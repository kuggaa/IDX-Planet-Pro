<style type="text/css">
#agentdirectory li:before {
	visibility: hidden;
}
#agentdirectory {
	padding:0px;
}
#agentnumber {
	visibility:hidden;
}
#agentroster {
	font-size:15px;
	display: none;
}
#agentletter {
	display: none;
}

.hasagents {
	background:#82c112 !important;
	color:#fff !important;
}
.hasagents:hover {
	background:#82c112 !important;
	color:#333 !important;
}
ul.searchresults li a.current {
	background: #A4FF00 !important;
	color:#333 !important;
}


.agentwrapper { 
  border : 2px solid #000; 
  overflow:hidden;
}

.agentwrapper div {
   min-height: 170px;
   margin: 10px;
}
.agentimage {
  float:left; 
  margin-right:20px;
  width:150px;
  max-width:200px;
  max-height: 170px;
}
.agentimage a{
overflow:inherit !important; position:inherit !important;display: inline !important;
}
.agentpost { 
  overflow:hidden;
  margin:10px;
  border:2px dashed #ccc;
  min-height:170px;
  padding: 5px;
}

@media screen and (max-width: 400px) {
.agentimage { 
    width:100% !important;
    float: none;
    margin: auto;
	max-width:100% !important;
    max-height:100% !important;
	padding-right: 10px;
  }
}
</style>
<div id="agentroster">There are currently <strong>{active_agent_rows}</strong> active agents found.</div>
<div id="agentletter">
  <ul class="searchresults">
    <li>{agent_letter_pagination}</li>
  </ul>
</div>
<div id="agentnumber">
  <ul class="searchresults">
    <li>{agent_number_pagination}</li>
  </ul>
</div>
<ul>
  {agents}
  <li class="row_{row_num_even_odd}">
    <div class="agentwrapper">
<div class="agentimage"><a title="{agent fieldvalue='name'}, {agent fieldvalue='title'}" href="{agent_link}"><img title="{agent fieldvalue='name'}, {agent fieldvalue='title'}" alt="{agent fieldvalue='name'}" class="agentimage" src="{agent_photo rank='0'}"></a></div>
<div class="agentpost"><h5>{agent fieldvalue='name'}</h5>
        <span>{agent fieldvalue='title'}</span><br />
        <span><strong>Cell:</strong> {agent fieldvalue='cellphone'}</span><br />
        <span><strong>Email:</strong> {agent fieldvalue='emailaddress'}</span><br />
        </div>
    </div>
  </li>
  {/agents}
</ul>