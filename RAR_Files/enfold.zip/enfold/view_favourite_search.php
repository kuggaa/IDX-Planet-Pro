<table border="0" width="100%" style="font-size: 12px;">

{favorites}
<tr>
    <td><a href="{favorite_search_link}">{favorite_search_name}</a></td>
    <td><a href="{favorite_search_delete}" onclick='return false' class='alertinfo' name="Delete this search?">Delete from favorites</a></td>
    
</tr>
{/favorites}
</table>