<script>
jQuery(document).ready(function ($) {

/* jQuery activation and setting options for the third tabs*/
$("#tabbed-nav3").zozoTabs({
position: "top-left",
theme: "crystal",
rounded: false,
shadows: true,
size: "large",
orientation: "horizontal",
responsive: true,
animation: {
easing: "easeInOutExpo",
duration: 400,
effects: "slideH"
}
});
});
</script>