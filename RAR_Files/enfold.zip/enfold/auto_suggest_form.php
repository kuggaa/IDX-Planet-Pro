<div class="auto_suggest">
<input type="text" placeholder="SEARCH by ADDRESS, MLS#, CITY, ZIP, NEIGHBORHOOD…" data-attr="{attr}" name="wpr_auto_suggest" />
<div id="post" class="suggestions"></div>
</div>

