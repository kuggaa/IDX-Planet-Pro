[raw]<style type=\"text/css\">
<!--
.style1 {color: #FF0000}
-->
</style>
{wprcontactform_css}
<form method=\'post\' action=\'\' id=\'form_3\'>
  {wprcontactform_3_validate}
  <table id=\"table1\" width=\"95%\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\">
    <tbody>
      <tr>
        <td colspan=\"3\" style=\"background-color:#e9e9e9\"><strong>Contact Information</strong></td>
      </tr>
      <tr>
        <td>First Name <span class=\"style1\">*</span></td>
        <td> </td>
        <td colspan=\"2\">Last Name <span class=\"style1\">*</span></td>
      </tr>
      <tr>
        <td>{wprcontactform_field_first_name} </td>
        <td> </td>
        <td colspan=\"2\">{wprcontactform_field_last_name} </td>
      </tr>
      <tr>
        <td>Email Address <span class=\"style1\">*</span> </td>
        <td> </td>
        <td colspan=\"2\">Email Confirmation <span class=\"style1\">*</span> </td>
      </tr>
      <tr>
        <td>{wprcontactform_field_email} </td>
        <td> </td>
        <td colspan=\"2\">{wprcontactform_field_email_confirmation} </td>
      </tr>
      <tr>
        <td>Phone </td>
        <td> </td>
        <td>How do you prefer to be contacted? <span class=\"style1\">*</span></td>
        <td> </td>
      </tr>
      <tr>
        <td>{wprcontactform_field_phone} </td>
        <td> </td>
        <td class=\"no_br\" colspan=\"2\">{wprcontactform_field_how_do_you_prefer_to_be_contacted}</td>
      </tr>
      <tr>
        <td colspan=\"3\">Your Present Street Address <span class=\"style1\">*</span></td>
      </tr>
      <tr>
        <td colspan=\"3\">{wprcontactform_field_your_present_street_address}</td>
      </tr>
      <tr>
        <td colspan=\"3\"><table id=\"table2\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">
            <tbody>
              <tr>
                <td>City <span class=\"style1\">*</span></td>
                <td>State <span class=\"style1\">*</span></td>
                <td>Zip Code <span class=\"style1\">*</span></td>
              </tr>
              <tr>
                <td>{wprcontactform_field_city}</td>
                <td>{wprcontactform_field_state}</td>
                <td>{wprcontactform_field_zip_code}</td>
              </tr>
            </tbody>
          </table></td>
      </tr>
      <tr>
        <td colspan=\"3\" style=\"background-color:#e9e9e9\"><strong>Property Type</strong></td>
      </tr>
      <tr>
        <td colspan=\"3\"><table id=\"table3\" width=\"100%\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">
            <tbody>
              <tr>
                <td>Property Type</td>
                <td>Overall condition of home</td>
              </tr>
              <tr>
                <td>{wprcontactform_field_property_type}</td>
                <td>{wprcontactform_field_overall_condition_of_home}</td>
              </tr>
              <tr>
                <td>[Optional] Acreage/Lot size:</td>
                <td>Beds</td>
              </tr>
              <tr>
                <td>{wprcontactform_field_optional_acreage_lot_size}</td>
                <td>{wprcontactform_field_beds}</td>
              </tr>
              <tr>
                <td>Approx. Square footage:</td>
                <td>Baths:</td>
              </tr>
              <tr>
                <td>{wprcontactform_field_approx_square_footage}</td>
                <td>{wprcontactform_field_baths}</td>
              </tr>
            </tbody>
          </table></td>
      </tr>
      <tr>
        <td colspan=\"3\" style=\"background-color:#e9e9e9\"><strong>Property Information</strong></td>
      </tr>
      <tr>
        <td colspan=\"2\" nowrap=\"nowrap\">Purpose of home value request?</td>
        <td colspan=\"2\" nowrap=\"nowrap\">Is this property currently listed?</td>
      </tr>
      <tr>
        <td colspan=\"2\" nowrap=\"nowrap\">{wprcontactform_field_purpose_of_home_value_request}</td>
        <td class=\"no_br\" colspan=\"2\" nowrap=\"nowrap\">{wprcontactform_field_is_this_property_currently_listed}</td>
      </tr>
      <tr>
        <td colspan=\"2\" nowrap=\"nowrap\">What is your relationship to the property?</td>
        <td colspan=\"2\" nowrap=\"nowrap\">Timeframe for selling or refinancing?</td>
      </tr>
      <tr>
        <td colspan=\"2\" valign=\"top\" nowrap=\"nowrap\">{wprcontactform_field_what_is_your_relationship_to_the_property}</td>
        <td colspan=\"2\" nowrap=\"nowrap\">{wprcontactform_field_time_frame_for_selling_or_refinancing}</td>
      </tr>
      <tr>
        <td colspan=\"2\" nowrap=\"nowrap\">Are you also interested in a home purchase?   </td>
        <td colspan=\"2\" nowrap=\"nowrap\">[Optional] Desired selling price?   </td>
      </tr>
      <tr>
        <td class=\"no_br\" colspan=\"2\" nowrap=\"nowrap\">{wprcontactform_field_are_you_also_interested_in_a_home_purchase}</td>
        <td colspan=\"2\" nowrap=\"nowrap\">{wprcontactform_field_optional_desired_selling_price} </td>
      </tr>
      <tr>
        <td colspan=\"3\">[Optional] Other information about the home, e.g., exterior condition, upgrades, garage (for a more accurate home valuation):<br>
          <table id=\"table4\" border=\"0\">
            <tbody>
              <tr>
                <td>{wprcontactform_message} 
                  </td>
                <td valign=\"bottom\" align=\"right\">{wprcontactform_field_captcha}<br>{wprcontactform_submit}</td>
              </tr>
            </tbody>
          </table></td>
      </tr>
      <tr>
        <td colspan=\"3\" align=\"center\"> </td>
      </tr>
    </tbody>
  </table>
</form>
[/raw]