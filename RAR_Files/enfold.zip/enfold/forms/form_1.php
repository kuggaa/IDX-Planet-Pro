{wprcontactform_css}
<form method=\'post\' action=\'\' id=\'form_1\'>
{wprcontactform_1_validate}<table>
<tr><td colspan=\'2\'>{wprcontactform_submit}</td></tr>
</table></form>
