<style type=\"text/css\">
<!--
.style1 {color: #FF0000}
-->
</style>
{wprcontactform_css}
<form method=\'post\' action=\'\' id=\'form_6\'>
  {wprcontactform_6_validate}
  <table id=\"table1\" width=\"95%\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\">
    <tbody>
      <tr>
        <td colspan=\"3\" style=\"background-color:#e9e9e9\"><strong>Contact Information</strong></td>
      </tr>
      <tr>
        <td>First Name <span class=\"style1\">*</span></td>
        <td> </td>
        <td colspan=\"2\">Last Name <span class=\"style1\">*</span></td>
      </tr>
      <tr>
        <td>{wprcontactform_field_first_name} </td>
        <td> </td>
        <td colspan=\"2\">{wprcontactform_field_last_name} </td>
      </tr>
      <tr>
        <td>Email Address <span class=\"style1\">*</span> </td>
        <td> </td>
        <td colspan=\"2\">Email Confirmation <span class=\"style1\">*</span> </td>
      </tr>
      <tr>
        <td>{wprcontactform_field_email} </td>
        <td> </td>
        <td colspan=\"2\">{wprcontactform_field_email_confirmation} </td>
      </tr>
      <tr>
        <td>Phone </td>
        <td> </td>
        <td>How do you prefer to be contacted? <span class=\"style1\">*</span></td>
      </tr>
      <tr>
        <td>{wprcontactform_field_phone} </td>
        <td> </td>
        <td class=\"no_br\" colspan=\"2\">{wprcontactform_field_how_do_you_prefer_to_be_contacted}</td>
      </tr>
      <tr>
        <td>Timeframe for moving is?</td>
        <td></td>
        <td class=\"no_br\" colspan=\"2\">Are you currently with an agent? <span class=\"style1\">*</span></td>
      </tr>
      <tr>
        <td>{wprcontactform_field_timeframe_for_moving_is}</td>
        <td></td>
        <td class=\"no_br\" colspan=\"2\">{wprcontactform_field_are_you_currently_working_with_an_agent}</td>
      </tr>
      <tr>
        <td colspan=\"3\" style=\"background-color:#e9e9e9\"><strong>Property Type</strong></td>
      </tr>
      <tr>
        <td colspan=\"3\"><table id=\"table3\" width=\"100%\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">
            <tbody>
              <tr>
                <td>Property Type</td>
                <td>View Type</td>
              </tr>
              <tr>
                <td>{wprcontactform_field_property_type} </td>
                <td>{wprcontactform_field_view_type} </td>
              </tr>
              <tr>
                <td>[Optional] Acreage/Lot size:</td>
                <td>Beds</td>
              </tr>
              <tr>
                <td>{wprcontactform_field_optional_acreage_lot_size} </td>
                <td>{wprcontactform_field_beds} </td>
              </tr>
              <tr>
                <td>Approx. Square footage:</td>
                <td>Baths:</td>
              </tr>
              <tr>
                <td>{wprcontactform_field_approx_square_footage} </td>
                <td>{wprcontactform_field_baths} </td>
              </tr>
              <tr>
                <td>Desired price range? </td>
                <td>How long have you been looking?</td>
              </tr>
              <tr>
                <td>{wprcontactform_field_desired_price_range}</td>
                <td>{wprcontactform_field_how_long_have_you_been_looking}</td>
              </tr>
            </tbody>
          </table></td>
      </tr>
      <tr>
        <td colspan=\"3\">[Optional] Other information about the neighborhood/home, e.g., swimming pool, garage, near beach, etc. (for a more accurate property match):<br>
          <table id=\"table4\" border=\"0\">
            <tbody>
              <tr>
                <td>{wprcontactform_message}</td>
                <td valign=\"bottom\" align=\"right\">{wprcontactform_field_captcha}<br>{wprcontactform_submit}</td>
              </tr>
            </tbody>
          </table></td>
      </tr>
      <tr>
        <td colspan=\"3\" align=\"center\"> </td>
      </tr>
    </tbody>
  </table>
</form>
