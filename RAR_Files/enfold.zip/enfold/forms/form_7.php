{wprcontactform_css}
<form method=\'post\' action=\'\' id=\'form_7\'>
{wprcontactform_7_validate}<table>
<tr><td>First Name</td><td>{wprcontactform_field_first_name}</td></tr>
<tr><td>Last Name</td><td>{wprcontactform_field_last_name}</td></tr>
<tr><td>Email</td><td>{wprcontactform_field_email}</td></tr>
<tr><td>Phone</td><td>{wprcontactform_field_phone}</td></tr>
<tr><td>Are you currently working with an agent</td><td>{wprcontactform_field_are_you_currently_working_with_an_agent}</td></tr>
<tr><td>Message</td><td>{wprcontactform_message}</td></tr>
<tr><td>Captcha</td><td>{wprcontactform_field_captcha}</td></tr>
<tr><td colspan=\'2\'>{wprcontactform_submit}</td></tr>
</table></form>
