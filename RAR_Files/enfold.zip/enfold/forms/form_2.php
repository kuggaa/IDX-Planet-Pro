{wprcontactform_css}
<form method=\'post\' action=\'\' id=\'form_2\'>
{wprcontactform_2_validate}<table>
<tr><td>Name</td><td>{wprcontactform_field_name}</td></tr>
<tr><td>E-mail</td><td>{wprcontactform_field_e-mail}</td></tr>
<tr><td>Phone</td><td>{wprcontactform_field_phone}</td></tr>
<tr><td>Subject</td><td>{wprcontactform_subject}</td></tr>
<tr><td>Message</td><td>{wprcontactform_message}</td></tr>
<tr><td>Captcha</td><td>{wprcontactform_field_captcha}</td></tr>
<tr><td colspan=\'2\'>{wprcontactform_submit}</td></tr>
</table></form>
