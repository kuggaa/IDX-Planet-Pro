{wprcontactform_css}<form method=\'post\' action=\'\' id=\'form_4\'>
{wprcontactform_4_validate}<table>
<tr><td>Name *</td><td>{wprcontactform_field_name}</td></tr>
<tr><td>E-mail *</td><td>{wprcontactform_field_email}</td></tr>
<tr><td>Phone</td><td>{wprcontactform_field_phone}</td></tr>
<tr><td>Price Range</td><td>{wprcontactform_field_price_range}</td></tr>
<tr><td>Preferred Communities</td><td>{wprcontactform_field_preferred_communities}</td></tr>
<tr><td>Type of Property</td><td>{wprcontactform_field_type_of_property}</td></tr>
<tr><td>Number of Bedrooms</td><td>{wprcontactform_field_number_of_bedrooms}</td></tr>
<tr><td>Numbers of Bathrooms</td><td>{wprcontactform_field_numbers_of_bathrooms}</td></tr>
<tr><td>Square Footage</td><td>{wprcontactform_field_square_footage}</td></tr>
<tr><td>Currently working with an agent? *</td><td>{wprcontactform_field_currently_working_with_an_agent}</td></tr>
<tr><td>Message</td><td>{wprcontactform_message}</td></tr>
<tr><td>Captcha</td><td>{wprcontactform_field_captcha}</td></tr>
<tr><td colspan=\'2\'>{wprcontactform_submit}</td></tr></table></form>