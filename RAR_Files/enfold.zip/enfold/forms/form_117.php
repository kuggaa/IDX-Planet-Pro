{wprcontactform_css}
<form method='post' action='' id='form_117'>
{wprcontactform_117_validate}<table>
<tr><td colspan='2'>{wprcontactform_submit}</td></tr>
</table></form>
