{wprcontactform_css}
<form method=\'post\' action=\'\' id=\'form_5\'>
{wprcontactform_5_validate}<table>
<tr><td>First Name</td><td>{wprcontactform_field_first_name}</td></tr>
<tr><td>Last Name</td><td>{wprcontactform_field_last_name}</td></tr>
<tr><td>Email</td><td>{wprcontactform_field_email}</td></tr>
<tr><td>Email Confirmation</td><td>{wprcontactform_field_email_confirmation}</td></tr>
<tr><td>Phone</td><td>{wprcontactform_field_phone}</td></tr>
<tr><td>How do you prefer to be contacted?</td><td>{wprcontactform_field_how_do_you_prefer_to_be_contacted?}</td></tr>
<tr><td>Your Present Street Address </td><td>{wprcontactform_field_your_present_street_address_}</td></tr>
<tr><td>City</td><td>{wprcontactform_field_city}</td></tr>
<tr><td>State</td><td>{wprcontactform_field_state}</td></tr>
<tr><td>Zip Code</td><td>{wprcontactform_field_zip_code}</td></tr>
<tr><td>Property Type</td><td>{wprcontactform_field_property_type}</td></tr>
<tr><td>View Type</td><td>{wprcontactform_field_view_type}</td></tr>
<tr><td>[Optional] Acreage/Lot size</td><td>{wprcontactform_field_[optional]_acreage/lot_size}</td></tr>
<tr><td>Approx. Square footage</td><td>{wprcontactform_field_approx._square_footage}</td></tr>
<tr><td>Beds</td><td>{wprcontactform_field_beds}</td></tr>
<tr><td>Baths</td><td>{wprcontactform_field_baths}</td></tr>
<tr><td>Desired price range?</td><td>{wprcontactform_field_desired_price_range?}</td></tr>
<tr><td>Timeframe for moving is?</td><td>{wprcontactform_field_timeframe_for_moving_is?}</td></tr>
<tr><td>Message</td><td>{wprcontactform_message}</td></tr>
<tr><td>Captcha</td><td>{wprcontactform_field_captcha}</td></tr>
<tr><td colspan=\'2\'>{wprcontactform_submit}</td></tr>
</table></form>
