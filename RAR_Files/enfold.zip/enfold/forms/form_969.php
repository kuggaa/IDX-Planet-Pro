{wprcontactform_css}
<form method='post' action='' id='form_969'>
{wprcontactform_969_validate}<table>
<tr><td colspan='2'>{wprcontactform_submit}</td></tr>
</table></form>
