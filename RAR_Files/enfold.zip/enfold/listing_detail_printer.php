<h3>{listing field='title'}</h3>
<table>

    <tr valign="top">
        <td>{wprcontactform name='testowy'}</td>
        <td align="right">
            <a href="{link_printer_friendly_href}">Printer Friendly Version of This Page</a><br />        
            <a href="{mortgage_calculator_href}" onclick="window.open(this.href,'_blank','location=0,status=0,scrollbars=1,toolbar=0,menubar=0,width=500,height=520');return false;">Mortgage Calculator</a><br />     
            <a href="{adddel_favorite_href}">{adddel_favorite_caption}</a>
            <br />
            <br />
            <a href="{rss_last_modified_href}">Last Modified Listing Feed</a><br />
            <a href="{rss_featured_href}">Featured Listings RSS</a><br />
        </td>
        
    </tr>
<tr>    
    <td width="300" valign="top" align="left">      

        
        <ul>
            <li>MLS: {listing field='mls'}</li>
            <li>Class: {listing field='class_name'}</li>
            {!if "{listing field='address'}"!=""}
                <li>Address: {listing field='address'}</li>
            {!else}
                <li>No address</li>
            {!endif}
            
            
            <li>City: {listing field='city'}</li>
            <li>State: {listing field='state'}</li>
            <li>Zip: {listing field='zip'}</li>
        </ul>
        <ul>            
            <li>{listing field='price'}</li>
            <li>Baths: {listing field='baths'}</li>
        </ul>
            



        
        {!!if(strlen('{listing field='home_features'}')>0)}
        <ul>
        {!explode field='{listing field='home_features'}' template='<li>explode_value</li>'}
        </ul>
        {!!endif}
    </td>
    <td  align="right">
        <div id="slideshow_c" style="">
        </div>
        <img src="{listing_image_url}" />
    </td>
</tr>
</table>   
{agent_section} 
<h3>Offered by</h3>
<div id="agentid_{agent fieldvalue='id'}" class="agent_roster clearfix {featuredagent}">
    <div class="agentphoto"><a title="{agent fieldvalue='name'}, {agent fieldvalue='title'}" href="{agent_link}"> 
    <img width="150" height="150" title="{agent fieldvalue='name'}, {agent fieldvalue='title'}" alt="{agent fieldvalue='name'}" class="attachment-thumbnail wp-post-image" src="{agent_thumbnail rank='0'}"></a></div>
    <div class="agentsummary">
<h3>{agent fieldvalue='name'}, {agent fieldvalue='title'}</h3>
<p>{agent field='cellphone'}<br>
   {agent field='officephone'}<br>
   {agent field='emailaddress'}: <a href="{agent fieldvalue='emailaddress'}">{agent fieldvalue='emailaddress'}</a><br>
   {agent field='url'}: <a href="{agent fieldvalue='url'}">{agent fieldvalue='url'}</a></p>
   <a title="{agent fieldvalue='name'}, {agent fieldvalue='title'}" href="{agent_link}"> Learn More ? </a>

<div class="clear"></div>
	</div>
</div>
{/agent_section}



    <div id="walkscore">{walkscore width='500'}</div>
    <div id="googlemaps">{googlemaps width='500' height='400'}</div>
    

