{users}

<a href="{user_link}">{user_name}</a><br/>
{/users}