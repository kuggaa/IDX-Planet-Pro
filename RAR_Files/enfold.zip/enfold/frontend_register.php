<center>
{registerformstart}
<div style="color:red;font-weight:bold">{registerform_inforegister}</div>
<table border="0" cellpadding="5" width="500">
<tr><td width="250" align="right">Username</td><td>{registerform_login}</td></tr>
<tr><td align="right">Password</td><td>{registerform_password}</td></tr>
<tr><td align="right">Password (again)</td><td>{registerform_password_again}</td></tr>
<tr><td align="right">First Name</td><td>{registerform_firstname}</td></tr>
<tr><td align="right">Last Name</td><td>{registerform_lastname}</td></tr>
<tr><td align="right">Email</td><td>{registerform_email}</td></tr>
<tr><td align="right">Phone</td><td>{registerform_phone}</td></tr>
<tr><td align="right">Mobile</td><td>{registerform_mobile}</td></tr>
<tr><td align="right">Fax</td><td>{registerform_fax}</td></tr>
<tr><td align="right">Homepage</td><td>{registerform_homepage}</td></tr>
<tr><td align="right">Info</td><td>{registerform_info}</td></tr>
<tr><td align="right">Captcha</td><td>{registerform_captcha}</td></tr>
<tr><td colspan="2" align="center">{registerform_submit}</td></tr>
</table>
{registerformend}
</center>
