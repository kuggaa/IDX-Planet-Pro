<h3>{user field='username'}</h3>

<b>Name:</b> {user field='firstname'} {user field='lastname'}