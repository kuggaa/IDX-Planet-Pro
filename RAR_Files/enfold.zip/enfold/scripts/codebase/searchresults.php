<center>
<!--  <form method='post'>
    Save as:
    <input type='text' value='{favorite_name}' name='favorite_name' />
    <input type='submit' value='Add to favorite' name='addfavorite'>
  </form>  -->
</center>
<div style="width:380px; float:left; font-weight:bold; font-size:18px; padding-bottom: 5px;">Your Search Returned <span style=" color:#FF0000;">{searchresultsnav_searchcount}</span> Properties.</br><input type="button" value="Back to Search" onclick="history.go(-1);return true;" />
</div>

<div style="float:right;">
<strong>Sort Search Results:</strong>
  <ul class="searchresults">
    <li><a href="{searchresultsort field_name='Price'}">Price</a></li>
    <li><a href="{searchresultsort field_name='Beds'}">Beds</a></li>
    <li><a href="{searchresultsort field_name='Bathrooms'}">Baths</a></li>
    <li><a href="{searchresultsort field_name='NetSQFT'}">SqFt</a></li>
  </ul>
</div>
<div class="clear"></div>
{searchresults}
<div class="row_{row_num_even_odd}" style="float:left; width:100%;">
  <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td class="stl"></td>
      <td class="stm"></td>
      <td class="str"></td>
    </tr>
    <tr>
      <td class="sml"></td>
      <td class="smc"><span style="float:left; font-size:16px; font-weight:bold;"><a href="{full_link_to_listing}" class="fancy_link">
        <?php $titleString = "{listing field='title'}";  $lowercaseTitle = strtolower($titleString); $ucTitleString = ucwords($lowercaseTitle); echo "$ucTitleString"; ?>
        </a></span> <span style=" float:right;font-size:16px; font-weight:bold;">{listing field='Price'} {priceflag field='Price|OriginalPrice'}</span></td>
      <td class="smr"></td>
    </tr>
    <tr>
      <td class="sbl"></td>
      <td class="sbm"></td>
      <td class="sbr"></td>
    </tr>
  </table>
  <div style="padding:5px;">
    <div style="float:left; width:210px; margin-top:6px; clear:both;"> <a href="{full_link_to_listing}" title="{listing field='address'} {listing field='city'}, {listing field='state'} {listing field='PostalCode'}" style="overflow:inherit !important; position:inherit !important;display: inline !important;"><img src="{listing_image_thumb_url}" width="200" height="150" alt="{listing field='title'}"></a><br />
    </div>
    <strong>MLS#:</strong> {listing field='mls'}&nbsp;&nbsp;&nbsp;{if {!listing field='Beds'}}<b>Beds:</b> {listing field='Beds'}{endif}&nbsp;&nbsp;&nbsp;{if {!listing field='BathsFull'}}<b>Baths:</b> {listing field='BathsFull'}{endif}&nbsp;{if {!listing field='BathsHalf'}}<b>/</b> {listing field='BathsHalf'}{endif}&nbsp;&nbsp;&nbsp;{if {!listing field='NetSQFT'}}<b>SqFt:</b> {listing field='NetSQFT'}{endif}&nbsp;&nbsp;&nbsp;{if {!listing field='LotAreaAcre'}}<b>Acre(s):</b> {listing field='LotAreaAcre'}{endif}<br />
    {listing field='remarks' limit='150'}<a href="{full_link_to_listing}"><i>....read more</i></a><br />
    <img src="/hmsre/wpradmin/template/custom/images/brlogosm.gif" width="25" height="20" /> <font style="font-size: .72em;"> {listing field='ListOfficeFullOfficeName'}</font>&nbsp;&nbsp;</div>
  <div style=" float:left;overflow: hidden;">
    <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="stl"></td>
        <td class="stm"></td>
        <td class="str"></td>
      </tr>
      <tr>
        <td class="sml"></td>
        <td class="smc" style="padding:0px !important;"><span style="float:left;line-height: 32px;padding-left: 20px;">({listing field='TotalPhotos'})</span> <a class="resultsNav1" href="{full_link_to_listing}"><span class="hide" >Photo Count</span></a><a class="resultsNav4" href="{adddel_favorite_href}" target="_blank" title="Add this listing to your favorites" rel="nofollow"><span class="hide">Save Property</span></a> <a class="resultsNav5" href="http://maps.google.com/maps?q={listing field='address'} {listing field='city'}, {listing field='state'} {listing field='PostalCode'}&output=embed" onClick="window.open(this.href,'_map','location=0,status=0, scrollbars=1,toolbar=0,menubar=0,width=800,height= 600');return false" rel="nofollow"><span class="hide">Map Property</span></a>
          <!-- AddToAny BEGIN -->
          <a class="resultsNav6 a2a_dd" href="http://www.addtoany.com/share_save"><span class="hide">Share</span></a>
          <script type="text/javascript" src="http://static.addtoany.com/menu/page.js"></script>
          <!-- AddToAny END --></td>
        <td class="smr"></td>
      </tr>
      <tr>
        <td class="sbl"></td>
        <td class="sbm"></td>
        <td class="sbr"></td>
      </tr>
    </table>
  </div>
</div>
<div style="clear:both;"></div>
{/searchresults}
</br>
<div style="float:right;">
Viewing&nbsp;{searchrestultsnav_range}&nbsp;of <strong>{searchresultsnav_searchcount}</strong> Properties &nbsp;
  <ul class="searchresults">
    <li>{searchresultsnav_prev_button}</li>
    {searchresultsnav_pages length=10}
    <li>{searchresultsnav_next_button}</li>
  </ul>
</div>
<div class="clear"></div>
</br>
<div id="disclaimer"><p>The data relating to real estate for sale on this website appears in part through the TREND Internet Data Exchange program, a voluntary cooperative exchange of property listing data between licensed real estate brokerage firms in which Home Marketsite participates, and is provided by TREND through a licensing agreement. The information provided by this website is for the personal, non-commercial use of consumers and may not be used for any purpose other than to identify prospective properties consumers may be interested in purchasing. Some properties which appear for sale on this website may no longer be available because they are under contract, have sold or are no longer being offered for sale. </br>©2015 TREND, all rights reserved. Information deemed reliable, but not guaranteed.</p>
<p>This data is updated throughout the day. Some properties which appear for sale on this web site may subsequently have sold and may no longer be available.</p>
<hr />
PUBLISHER'S NOTICE: All real estate advertised herein is subject to the Federal Fair Housing Act, which Acts make it illegal to make or publish any advertisement that indicates any preference, limitation, or discrimination based on race, color, religion, sex, handicap, family status, or national origin.
  </div>