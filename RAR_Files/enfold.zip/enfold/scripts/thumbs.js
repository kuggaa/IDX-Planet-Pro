(function($){
$(document).ready(function(){
$(".thumb").hover(function() {
	$(this).css({'z-index' : '10'});
	$(this).find('img').addClass("hover").stop()
		.animate({
			marginTop: '-74px', 
			marginLeft: '-106px', 
			top: '50%', 
			left: '50%', 
			width: '512px', 
			height: '400px',
			padding: '0px' 
		}, 400);
	} , function() {
	$(this).css({'z-index' : '0'});
	$(this).find('img').removeClass("hover").stop()
		.animate({
			marginTop: '0', 
			marginLeft: '0',
			top: '0', 
			left: '0', 
			width: '200px', 
			height: '150px', 
			padding: '0px'
		}, 400);
});
});
})(jQuery);