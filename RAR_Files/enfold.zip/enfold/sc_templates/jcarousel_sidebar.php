<div class="mysite_jcarousel" style="width: 260px;">
  <script type="text/javascript">jQuery(document).ready(function() {jQuery("#mysite_custom_jcarousel_1").jcarousel({vertical: false,visible: 1,scroll: 1,animation: 700,auto: 3,wrap: "both",itemFallbackDimension: 400,buttonNextHTML: null, buttonPrevHTML: null,initCallback: mysite_custom_jcarousel_1_callback,setupCallback: mysite_custom_jcarousel_1_setup,buttonNextCallback: mysite_custom_jcarousel_1_next_event,});});function mysite_custom_jcarousel_1_next_event(c) {if( c.buttonNextState === true ) { jQuery("#mysite_custom_jcarousel_1_next").addClass("jcarousel_next_disabled"); }if( c.buttonNextState === false ){ jQuery("#mysite_custom_jcarousel_1_next").removeClass("jcarousel_next_disabled"); }}function mysite_custom_jcarousel_1_prev_event(c) {if( c.buttonPrevState === true || c.buttonPrevState === null ) { jQuery("#mysite_custom_jcarousel_1_prev").addClass("jcarousel_prev_disabled"); }if( c.buttonPrevState === false ){ jQuery("#mysite_custom_jcarousel_1_prev").removeClass("jcarousel_prev_disabled"); }}function mysite_custom_jcarousel_1_callback(c) {jQuery("#mysite_custom_jcarousel_1_next").live("click touchstart", function(){ c.next(); Cufon.refresh(); return false; });jQuery("#mysite_custom_jcarousel_1_prev").live("click touchstart", function(){ c.prev(); Cufon.refresh(); return false; });}function mysite_custom_jcarousel_1_setup(c) {c.clip.parent().parent().parent().parent().removeClass('noscript');}</script>
  <div class="mysite_jcarousel_nav"><span id="mysite_custom_jcarousel_1_prev" class="mysite_jcarousel_prev"></span><span id="mysite_custom_jcarousel_1_next" class="mysite_jcarousel_next"></span></div>
  <div id="mysite_custom_jcarousel_1_wrapper" class="jcarousel_wrapper jcarousel_grid">
    <div class=" jcarousel-skin-mysite">
      <div class="jcarousel-container jcarousel-container-horizontal" style="position: relative; display: block;">
        <div class="jcarousel-clip jcarousel-clip-horizontal" style="position: relative;">
          <ul id="mysite_custom_jcarousel_1" class="jcarousel-list jcarousel-list-horizontal" style="overflow: hidden; position: relative; top: 0px; margin: 0px; padding: 0px; left: -206px; width: 618px;">
            {repeat_row}
            <li style="float: left; list-style: none; width: 260px;" class="jcarousel-item jcarousel-item-horizontal">
              <div> <a href="{full_link_to_listing}"><img src="{listing_image_thumb_url}" width="260" height="200" alt="{listing field='title'}" /><br />
                <b>{listing field='title'}, {listing field='city'}</b><br />
                </a> <b>Price:</b> {listing field='Price'}&nbsp;&nbsp;&nbsp;&nbsp; {if {!listing field='Bedrooms'}}<b>Beds:</b> {listing field='Bedrooms'}{endif} &nbsp;&nbsp;&nbsp;&nbsp; {if {!listing field='FullBaths'}}<b>Baths:</b> {listing field='FullBaths'}{endif}<br />
                {listing field='remarks' limit='150'}<a href="{full_link_to_listing}"><i>....read more</i></a><br />
                <hr />
              </div>
            </li>
            {/repeat_row}
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="clearboth"></div>
</div>
<script type="text/javascript" src="/wpradmin/template/custom/scripts/jquery.jcarousel.min.js?ver=2.2"></script>
