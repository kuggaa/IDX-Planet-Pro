<!-- Shared assets -->
<!-- Example assets -->
<link rel="stylesheet" type="text/css" href="<?php echo site_url(); ?>/wpradmin/template/enfold/css/jcarousel.responsive.css">
<script type="text/javascript" src="<?php echo site_url(); ?>/wpradmin/template/enfold/scripts/jquery.js"></script>
<script type="text/javascript" src="<?php echo site_url(); ?>/wpradmin/template/enfold/scripts/jquery.jcarousel.min.js?ver=2.2"></script>
<script type="text/javascript" src="<?php echo site_url(); ?>/wpradmin/template/enfold/scripts/jcarousel.responsive.js"></script>
<div class="jcarousel-wrapper">
  <div class="jcarousel">
    <ul>
      {repeat_row}
      <li>
        <div> <a href="{full_link_to_listing}"><img src="{listing_image_thumb_url}" alt="{listing field='title'}" />
          <b>{listing field='title'}, {listing field='city'}</b><br />
          </a> <b>Price:</b> {listing field='Price'}&nbsp;{if {!listing field='Bedrooms'}} <b>Beds:</b>&nbsp;{listing field='Bedrooms'}{endif}&nbsp;{if {!listing field='FullBaths'}} <b>Baths:</b> {listing field='FullBaths'}{endif}<br />
        </div>
      </li>
      {/repeat_row}
    </ul>
  </div>
  <a href="#" class="jcarousel-control-prev"><</a><a href="#" class="jcarousel-control-next">></a>
</div>
