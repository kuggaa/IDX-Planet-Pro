{repeat_row}
  <div class="col-md-4 shortcode-col listing_wrapper" data-org="4">
    <div class="property_listing" data-link="{full_link_to_listing}">
      <div class="listing-unit-img-wrapper"><a href="{full_link_to_listing}"><img src="{listing_image_thumb_url}" title="{listing field='title'}, {listing field='city'}" alt="{listing field='title'}, {listing field='city'}" class="responsive-thumbs"/></a>
        <div class="listing-cover"></div>
        <a href="{full_link_to_listing}"> <span class="listing-cover-plus">+</span></a></div>
      <h4><a href="{full_link_to_listing}" style="line-height: 13px;">{listing field='title'}</a></h4>
      <div class="property_location"> {if {!listing field='Bedrooms'}}<span class="inforoom">{listing field='Bedrooms'}</span>{endif}{if {!listing field='TotalBaths'}}<span class="infobath">{listing field='TotalBaths'}</span>{endif}{if {!listing field='EstSqFt'}}<span class="infosize">{listing field='EstSqFt'}<sup>2</sup></span>{endif}</div>
      <div class="listing_details the_grid_view">{listing field='remarks' limit='70'}</div>
      <div class="listing_details the_list_view">{listing field='remarks' limit='70'}</div>
      <div class="listing_prop_details"> </div>
      <div class="listing_unit_price_wrapper">{listing field='Price'}<span class="price_label"></span>
        <div class="listing_actions">
          <div class="share_unit"> <a href="http://www.facebook.com/sharer.php?u={full_link_to_listing}&amp;t={listing field='title'}" target="_blank" class="social_facebook"></a> <a href="http://twitter.com/home?status={listing field='title'}+{full_link_to_listing}" class="social_tweet" target="_blank"></a> <a href="https://plus.google.com/share?url={full_link_to_listing}" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" class="social_google"></a> <a href="http://pinterest.com/pin/create/button/?url={full_link_to_listing}&amp;media=<?php if (isset( $pinterest[0])){ echo $pinterest[0]; }?>&amp;description={listing field='title'}" target="_blank" class="social_pinterest"></a> </div>
          <span class="share_list" data-original-title="share"></span> <span class="icon-fav icon-fav-off" data-original-title="add to favorites" data-postid="{full_link_to_listing}"></span> </div>
      </div>
    </div>
  </div>
{/repeat_row}