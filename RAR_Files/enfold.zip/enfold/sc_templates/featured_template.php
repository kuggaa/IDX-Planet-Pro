<style type="text/css">
.wpr-rss {text-decoration: none;float: left;clear: both;margin-top: 5px;}
#nextprevwrapper {margin-bottom:0px !important; float:left;}
ul.searchresults li {background: none repeat scroll 0 0 transparent !important; list-style: none outside none; padding-left: 0 !important;}
ul.searchresults li a {background: -moz-linear-gradient(center top, #FFFFFF 1px, #F3F3F3 1px, #E6E6E6) repeat scroll 0 0 transparent; border: 1px solid #B6B6B6; border-radius: 3px 3px 3px 3px; color: #474747; padding: 2px 5px;}
ul.searchresults li a:hover, ul.searchresults li a.current {background: none repeat scroll 0 0 #FFFFFF !important;}
ul.searchresults {font: 12px 'Tahoma'; height: 100%; list-style-type: none; margin: 0 auto !important; overflow: hidden; padding: 0 !important;}
ul.searchresults li {float: left; margin: 0 0 0 3px; padding: 0; list-style-type: none;}
ul.searchresults li a {color: black; display: block; padding: 2px 5px; text-decoration: none;}
ul.searchresults li a img {border: medium none;}
.row_0 {background:#f5f5f5;}
.row_1 {background:#e2eaf6;}
</style>
<!--<div style="float:right;"><strong>Sort Search Results:</strong>
  <ul class="searchresults">
    <li><a href="{sc_sort sortedby='Price' init_dir='DESC'}">Price</a></li>
    <li><a href="{sc_sort sortedby='Bedroom' init_dir='ASC'}">Beds</a></li>
    <li><a href="{sc_sort sortedby='Full_Bath'}">Baths</a></li>
  </ul>
</div>-->
<div class="clear"></div>
<link rel="stylesheet" href="/wpradmin/template/custom/style.css" type="text/css" media="screen" />
{repeat_row}
<div class="row_{row_num_even_odd}" style="float:left; width:100%;">
  <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td class="stl"></td>
      <td class="stm"></td>
      <td class="str"></td>
    </tr>
    <tr>
      <td class="sml"></td>
      <td class="smc"><span style="float:left; font-size:16px; font-weight:bold;"><a href="{full_link_to_listing}" class="fancy_link">
        <?php $titleString = "{listing field='address'}, {listing field='city'}";  $lowercaseTitle = strtolower($titleString); $ucTitleString = ucwords($lowercaseTitle); echo "$ucTitleString"; ?>
        </a></span> <span style=" float:right;"><b>MLS#:</b> {listing field='MLS'}</span></td>
      <td class="smr"></td>
    </tr>
    <tr>
      <td class="sbl"></td>
      <td class="sbm"></td>
      <td class="sbr"></td>
    </tr>
  </table>
   <div style="padding:5px;">
    <div style="float:left; width:210px; margin-top:6px; clear:both;"> <a href="{full_link_to_listing}" title="{listing field='title'}" style="overflow:inherit !important; position:inherit !important;display: inline !important;"><img src="{listing_image_thumb_url}" width="200" height="150" alt="{listing field='title'}"></a><br />
    </div>
    <b>Price:</b> {listing field='Price'} {priceflag field='Price|OriginalPrice'}&nbsp;&nbsp;&nbsp;{if {!listing field='Bedrooms'}}<b>Beds:</b> {listing field='Bedrooms'}{endif}&nbsp;&nbsp;&nbsp;{if {!listing field='TotalBaths'}}<b>Baths:</b> {listing field='TotalBaths'}{endif}&nbsp;&nbsp;&nbsp;{if {!listing field='EstHeatSqFt'}}<b>SqFt:</b> {listing field='EstHeatSqFt'}{endif}<br />
    {listing field='remarks' limit='150'}<a href="{full_link_to_listing}"><i>....read more</i></a><br />
    <img id="bricon"></img><font style="font-size: .72em;">Listing information provided by: {office fieldvalue='name'}</font>&nbsp;&nbsp;<img src="/wpradmin/template/custom/images/icon-idx-property-lg.png" width="65" height="25" /> </div>
  <div style=" float:left;overflow: hidden;">
  <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td class="stl"></td>
      <td class="stm"></td>
      <td class="str"></td>
    </tr>
    <tr>
      <td class="sml"></td>
      <td class="smc" style="padding:0px !important;"><span style="float:left;line-height: 26px;padding-left: 20px;">({listing field='PhotoCount'})</span> <a class="resultsNav1" href="{full_link_to_listing}"><span class="hide" >Photo Count</span></a><a class="resultsNav4" href="{adddel_favorite_href}" target="_blank" title="Add this listing to your favorites" rel="nofollow"><span class="hide">Save Property</span></a> <a class="resultsNav5" href="http://maps.google.com/maps?q={listing field='title'}, {listing field='city'}, {listing field='state'},{listing field='zip'}&output=embed" onClick="window.open(this.href,'_map','location=0,status=0, scrollbars=1,toolbar=0,menubar=0,width=800,height= 600');return false" rel="nofollow"><span class="hide">Map Property</span></a>
      <!-- AddToAny BEGIN -->
      <a class="resultsNav6 a2a_dd" href="http://www.addtoany.com/share_save"><span class="hide">Share</span></a>
<script type="text/javascript">
a2a_config = {
    linkname: '{listing field='title'} {listing field='city'}, {listing field='state'}. {listing field='zip'}',
    linkurl: '{full_link_to_listing}'
};
</script>
      <script type="text/javascript" src="http://static.addtoany.com/menu/page.js"></script>
      <!-- AddToAny END --></td>
      <td class="smr"></td>
    </tr>
    <tr>
      <td class="sbl"></td>
      <td class="sbm"></td>
      <td class="sbr"></td>
    </tr>
  </table>
  </div>
</div>
<div style="clear:both;"></div>
{/repeat_row}