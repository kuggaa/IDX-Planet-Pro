<?xml version="1.0" encoding="UTF-8" ?>
<?xml-stylesheet type="text/css" href="/wp-content/plugins/wp-realty/template/default/sc_templates/rss.css" ?>
<rss version="2.0">
  <channel>
    <title>{rss_title}{listing field='Address'} {listing field='City'}</title>
    <link>{rss_webroot}</link>
    <description></description>
    <generator></generator>
    {rss_listing_block}
    <item>
      <title>{listing field='Address'} {listing field='City'}</title>
      <link>{full_link_to_listing}</link>
      <guid isPermaLink="false">{rss_listing_guid}</guid>
      <pubDate></pubDate>
      <description>
        <![CDATA[<div style="width:280px;">
          <a href="{full_link_to_listing}"><img src="{listing_image_thumb_url}" width="260" height="200" alt="{listing field='title'}" /></a><br />
          <b>Price:</b> {listing field='Price'}&nbsp;&nbsp;{if {!listing field='Bedrooms'}}<b>Beds:</b> {listing field='Bedrooms'}{endif}&nbsp;&nbsp;{if {!listing field='FullBaths'}}<b>Baths:</b> {listing field='FullBaths'}{endif}<br />{listing field='remarks' limit='150'}...<a href="{full_link_to_listing}"><i>read more</i></a><br />
          <hr /> 
          </div>
          <div style="clear:both;"><hr /></div>]]>
      </description>
    </item>
    {/rss_listing_block}</channel>
</rss>
