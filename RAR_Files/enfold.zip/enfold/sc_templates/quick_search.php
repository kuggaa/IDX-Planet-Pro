<style type="text/css"> 
<!--
#qsearch {width: 100%; margin-top: 10px;}
input, textarea {
padding: 0px;
max-width: 298px;
line-height:30px;
}
select {
padding: 8px 12px;
}
--> 
</style>
<script src="<?php echo site_url(); ?>/wpradmin/template/custom/scripts/placeholdertext.js"></script>
<form id="wprform" method="get" action="<?php echo site_url(); ?>/search-page/" onsubmit="readySearchForm(this);">
  <input type="hidden" value="searchresults" name="page" />
    <div id="quicksearch">
    <input type="text"  placeholder="    Search By MLS #" value="" name="MLS" id="se_MLS" style="width:100%;"/>
<input type="text"  placeholder="    Search By Street Address" value="" name="Address" id="se_Address" style="width:100%;"/>
<input type="text"  placeholder="    Search By Zip Code" value="" name="Zip" id="se_Zip" style="width:100%;"/>
<select class="qsselect" name="PropertyType[]" id="se_PropertyType" style="width:100%;">
              <option value="">Property Type</option>
<option value="Residential">Residential</option>
<option value="Lots and Land">Lot/Land</option>
<option value="Multi-Family">Multi-Family</option>
<option value="Commercial">Commercial</option>
            </select>
<select class="qsselect" name="City[]" id="se_City" style="width:100%;">
              <option value="">City</option>
<option value="Allenville">Allenville</option>
<option value="Altamont">Altamont</option>
<option value="Arcola">Arcola</option>
<option value="Arthur">Arthur</option>
<option value="Assumption">Assumption</option>
<option value="Beecher City">Beecher City</option>
<option value="Bethany">Bethany</option>
<option value="Brownstown">Brownstown</option>
<option value="Carlinville">Carlinville</option>
<option value="Cerro Gordo">Cerro Gordo</option>
<option value="Charleston">Charleston</option>
<option value="Clarksburg">Clarksburg</option>
<option value="Cooks Mills">Cooks Mills</option>
<option value="Cowden">Cowden</option>
<option value="Dalton City">Dalton City</option>
<option value="Dieterich">Dieterich</option>
<option value="Effingham">Effingham</option>
<option value="Farina">Farina</option>
<option value="Findlay">Findlay</option>
<option value="Gays">Gays</option>
<option value="Greenup">Greenup</option>
<option value="Henton">Henton</option>
<option value="Herborn">Herborn</option>
<option value="Herrick">Herrick</option>
<option value="Lakewood">Lakewood</option>
<option value="Lovington">Lovington</option>
<option value="Loxa">Loxa</option>
<option value="Mattoon">Mattoon</option>
<option value="Middlesworth">Middlesworth</option>
<option value="Mode">Mode</option>
<option value="Moweaqua">Moweaqua</option>
<option value="Neoga">Neoga</option>
<option value="Oakland">Oakland</option>
<option value="Oconee">Oconee</option>
<option value="Other">Other</option>
<option value="Pana">Pana</option>
<option value="Ramsey">Ramsey</option>
<option value="Shelbyville">Shelbyville</option>
<option value="Shumway">Shumway</option>
<option value="Sigel">Sigel</option>
<option value="Stewardson">Stewardson</option>
<option value="Strasburg">Strasburg</option>
<option value="Sullivan">Sullivan</option>
<option value="Taylorville">Taylorville</option>
<option value="Teutopolis">Teutopolis</option>
<option value="Toledo">Toledo</option>
<option value="Tower Hill">Tower Hill</option>
<option value="Trowbridge">Trowbridge</option>
<option value="Vandalia">Vandalia</option>
<option value="Watson">Watson</option>
<option value="Wheeler">Wheeler</option>
<option value="Westervelt">Westervelt</option>
<option value="Windsor">Windsor</option>
<option value="Yantisville">Yantisville</option>
            </select>
<select class="qsselect" id="Price-min" tabindex="1" name="Price_from" style="width:100%;">
              <option value="">Min Price</option>
<option value="10000">$10,000</option>
<option value="20000">$20,000</option>
<option value="30000">$30,000</option>
<option value="40000">$40,000</option>
<option value="50000">$50,000</option>
<option value="60000">$60,000</option>
<option value="70000">$70,000</option>
<option value="80000">$80,000</option>
<option value="90000">$90,000</option>
<option value="100000">$100,000</option>
<option value="125000">$125,000</option>
<option value="150000">$150,000</option>
<option value="175000">$175,000</option>
<option value="200000">$200,000</option>
<option value="225000">$225,000</option>
<option value="250000">$250,000</option>
<option value="275000">$275,000</option>
<option value="300000">$300,000</option>
<option value="325000">$325,000</option>
<option value="350000">$350,000</option>
<option value="375000">$375,000</option>
<option value="400000">$400,000</option>
<option value="425000">$425,000</option>
<option value="450000">$450,000</option>
<option value="475000">$475,000</option>
<option value="500000">$500,000</option>
<option value="550000">$550,000</option>
<option value="600000">$600,000</option>
<option value="650000">$650,000</option>
<option value="700000">$700,000</option>
<option value="750000">$750,000</option>
<option value="800000">$800,000</option>
<option value="850000">$850,000</option>
<option value="900000">$900,000</option>
<option value="950000">$950,000</option>
<option value="1000000">$1 mil</option>
<option value="1500000">$1.5 mil</option>
<option value="2000000">$2 mil</option>
<option value="2500000">$2.5 mil</option>
<option value="3000000">$3 mil</option>
<option value="3500000">$3.5 mil</option>
<option value="4000000">$4 mil</option>
<option value="4500000">$4.5 mil</option>
<option value="5000000">$5 mil</option>
<option value="5000001">$5 mil+</option>
</select>
<select class="qsselect" id="Price-max" tabindex="2" name="Price_to" style="width:100%;">
              <option value="">Max Price</option>
<option value="10000">$10,000</option>
<option value="20000">$20,000</option>
<option value="30000">$30,000</option>
<option value="40000">$40,000</option>
<option value="50000">$50,000</option>
<option value="60000">$60,000</option>
<option value="70000">$70,000</option>
<option value="80000">$80,000</option>
<option value="90000">$90,000</option>
<option value="100000">$100,000</option>
<option value="125000">$125,000</option>
<option value="150000">$150,000</option>
<option value="175000">$175,000</option>
<option value="200000">$200,000</option>
<option value="225000">$225,000</option>
<option value="250000">$250,000</option>
<option value="275000">$275,000</option>
<option value="300000">$300,000</option>
<option value="325000">$325,000</option>
<option value="350000">$350,000</option>
<option value="375000">$375,000</option>
<option value="400000">$400,000</option>
<option value="425000">$425,000</option>
<option value="450000">$450,000</option>
<option value="475000">$475,000</option>
<option value="500000">$500,000</option>
<option value="550000">$550,000</option>
<option value="600000">$600,000</option>
<option value="650000">$650,000</option>
<option value="700000">$700,000</option>
<option value="750000">$750,000</option>
<option value="800000">$800,000</option>
<option value="850000">$850,000</option>
<option value="900000">$900,000</option>
<option value="950000">$950,000</option>
<option value="1000000">$1 mil</option>
<option value="1500000">$1.5 mil</option>
<option value="2000000">$2 mil</option>
<option value="2500000">$2.5 mil</option>
<option value="3000000">$3 mil</option>
<option value="3500000">$3.5 mil</option>
<option value="4000000">$4 mil</option>
<option value="4500000">$4.5 mil</option>
<option value="5000000">$5 mil</option>
<option value="5000001">$5 mil+</option>
            </select>
<select class="qsselect" id="Bedrooms" tabindex="3" name="Bedrooms_from" style="width:100%;">
              <option value="">Bedrooms</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8+</option>
            </select>
            <input name="Bedrooms_to" type="hidden" value="" />
 <select class="qsselect" id="TotalBathrooms" tabindex="4" name="TotalBathrooms_from" style="width:100%;">
              <option value="">Baths</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8+</option>
            </select>
            <input name="TotalBathrooms_to" type="hidden" value="" />
<input type="hidden" value="yes" name="searchengine2_validate">
<input type="hidden" name="sortby" value="Price" />
<input type="hidden" name="sortorder" value="DESC" />
<input type="submit" id="qsearch" class="button_link hover_fade" value="Search"></td>
  </div>
</form>