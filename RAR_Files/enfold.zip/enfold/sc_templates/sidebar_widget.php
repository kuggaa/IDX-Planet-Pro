{repeat_row}
<div>
<a href="{full_link_to_listing}"><img src="{listing_image_thumb_url}" width="260" height="200" alt="{listing field='title'}" /><br /><b>{listing field='title'}, {listing field='city'}</b><br /></a>   
<b>Price:</b> {listing field='Price'}     {if {!listing field='Bedrooms'}}<b>Beds:</b> {listing field='Bedrooms'}{endif}      {if {!listing field='FullBaths'}}<b>Baths:</b> {listing field='FullBaths'}{endif}<br />{listing field='remarks' limit='150'}...<a href="{full_link_to_listing}"><i>read more</i></a><br />
<hr /> 
</div>
{/repeat_row}