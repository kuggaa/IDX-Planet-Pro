<style type="text/css">
.wpr-rss {text-decoration: none;float: left;clear: both;margin-top: 5px;}
#nextprevwrapper {margin-bottom:0px !important; float:left;}
ul.searchresults li {background: none repeat scroll 0 0 transparent !important; list-style: none outside none; padding-left: 0 !important;}
ul.searchresults li a {background: -moz-linear-gradient(center top, #FFFFFF 1px, #F3F3F3 1px, #E6E6E6) repeat scroll 0 0 transparent; border: 1px solid #B6B6B6; border-radius: 3px 3px 3px 3px; color: #474747; padding: 2px 5px;}
ul.searchresults li a:hover, ul.searchresults li a.current {background: none repeat scroll 0 0 #FFFFFF !important;}
ul.searchresults {font: 12px 'Tahoma'; height: 100%; list-style-type: none; margin: 0 auto !important; overflow: hidden; padding: 0 !important;}
ul.searchresults li {float: left; margin: 0 0 0 3px; padding: 0; list-style-type: none;}
ul.searchresults li a {color: black; display: block; padding: 2px 5px; text-decoration: none;}
ul.searchresults li a img {border: medium none;}
.row_0 {background:#f5f5f5;}
.row_1 {background:#e2eaf6;}
</style>
    <table class="footable">
      <thead>
        <tr>
          <th data-class="expand" data-sort-initial="false">
            Address
          </th>
          <th data-hide="phone">
          City
          </th>
          <th data-hide="default" data-type="numeric">
          Date
          </th>
	     <th data-hide="phone" data-sort-ignore="true">
          BD/BA
          </th>
          <th data-hide="default" data-type="numeric" data-sort-initial="true">
            <span title="table sorted by this column on load">Price</span>
          </th>
        </tr>
      </thead>{repeat_row}
<tr><td><a href="{full_link_to_listing}" alt="{listing field='title'}"/>{listing field='address'}</a>&nbsp;({listing field='TotalPhotos'})</td><td>{listing field='city'}</td><td data-value="{listing field='ListDate'}">{listing field='ListDate'}</td><td>{listing field='Beds'}/{listing field='BathsFull'}</td><td>{listing field='Price'}&nbsp;&nbsp;<span style="float:right;"><img src="/wpradmin/template/custom/images/brlogosm.gif" width="20" height="16" title={listing field='ListOfficeFullOfficeName'}/></span></td></tr>
      {/repeat_row}
    </table>