<style type="text/css">
div div div div div div div div div + .blog-side .responsive-thumbs {width:100%; height:226px;}
.responsive-thumbs {width:100%; height:267px;}
@media screen and (max-width: 74em) {
.responsive-thumbs {width:100%; height:226px;}
}
@media screen and (max-width: 62em) {
.responsive-thumbs {width:100%; height:auto;}
}
</style>
<div class="pricing-box post_grid_image">
{repeat_in_row repeat='3'}
  <div class="row" style="margin-bottom: 30px;">
  {repeat_row}
    <div class="col-md-4">
      <ul class="pricing-table">
        <li style="background-color: #fff; padding: 0px;border: 1px solid #dbdbdb; border-bottom:none;"><a href="{full_link_to_listing}" style="padding: 0px;margin: 0px;"> <img src="{listing_image_thumb_url}" title="{listing field='title'}, {listing field='city'}" alt="{listing field='title'}, {listing field='city'}" class="responsive-thumbs"/></a></li>
        <li><a href="{full_link_to_listing}" style="line-height: 13px;">{listing field='title'}<br /><span style="font-style:italic; font-size:10px; font-weight: normal;">{listing field='city'}</span></a><br />
      <b>Price:</b> {listing field='Price'}&nbsp;&nbsp;&nbsp;&nbsp; <br />
      {if {!listing field='Bedrooms'}}<b>Beds:</b> {listing field='Bedrooms'}{endif} &nbsp;&nbsp;&nbsp;&nbsp; {if {!listing field='FullBaths'}}<b>Baths:</b> {listing field='FullBaths'}{endif}</li>
      </ul>
    </div>
    {/repeat_row}
  </div>
  {/repeat_in_row}
</div>