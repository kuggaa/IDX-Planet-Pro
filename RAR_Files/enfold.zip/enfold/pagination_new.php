<ul id="agentdirectory">
{letterpagination}
<li><a href="{url}" class="{hasresult} {current}" title="Agents {letter}">{letter}</a></li>
{/letterpagination}
</ul>