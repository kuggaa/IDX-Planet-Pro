
<!-- Content container -->
<div>
<!-- Advanced Search -->
<div>
<form id="MapSearchForm" action="/search-page/" method="get" onSubmit="readySearchForm(this);">
<!-- side-a -->
<div class="side-a">
<div class="size-a">
<h4 class="sflabel">Property Type</h4>
<select data-placeholder="Choose a Property Type..." class="chosen-select size-a" multiple name="PropertyType[]" id="se_class_name">
<option value="">Any</option>
<option value="Residential">Residential</option>
<option value="Lots and Land">Lot/Land</option>
<option value="Multi-Family">Multi-Family</option>
<option value="Commercial">Commercial</option>
</select>
</div>
<div class="side-ax">
<h4 class="sflabel">Min Price</h4>
<select data-placeholder="Min Price..." class="chosen-select-no-single size-b" input type="text" autocomplete="off" name="Price_from" id="se_Price">
<option value=""></option>
<option value="1000">$1,000</option>
<option value="10000">$10,000</option>
<option value="20000">$20,000</option>
<option value="30000">$30,000</option>
<option value="40000">$40,000</option>
<option value="50000">$50,000</option>
<option value="60000">$60,000</option>
<option value="70000">$70,000</option>
<option value="80000">$80,000</option>
<option value="90000">$90,000</option>
<option value="100000">$100,000</option>
<option value="125000">$125,000</option>
<option value="150000">$150,000</option>
<option value="175000">$175,000</option>
<option value="200000">$200,000</option>
<option value="225000">$225,000</option>
<option value="250000">$250,000</option>
<option value="275000">$275,000</option>
<option value="300000">$300,000</option>
<option value="325000">$325,000</option>
<option value="350000">$350,000</option>
<option value="375000">$375,000</option>
<option value="400000">$400,000</option>
<option value="425000">$425,000</option>
<option value="450000">$450,000</option>
<option value="475000">$475,000</option>
<option value="500000">$500,000</option>
<option value="550000">$550,000</option>
<option value="600000">$600,000</option>
<option value="650000">$650,000</option>
<option value="700000">$700,000</option>
<option value="750000">$750,000</option>
<option value="800000">$800,000</option>
<option value="850000">$850,000</option>
<option value="900000">$900,000</option>
<option value="950000">$950,000</option>
<option value="1000000">$1 mil</option>
<option value="1500000">$1.5 mil</option>
<option value="2000000">$2 mil</option>
<option value="2500000">$2.5 mil</option>
<option value="3000000">$3 mil</option>
<option value="3500000">$3.5 mil</option>
<option value="4000000">$4 mil</option>
<option value="4500000">$4.5 mil</option>
<option value="5000000">$5 mil</option>
<option value="5000001">$5 mil+</option>
</select>
</div>
<div class="side-bx">
<h4 class="sflabel">Max Price</h4>
<select data-placeholder="Max Price..." class="chosen-select-no-single size-b" input type="text" autocomplete="off" name="Price_to" id="se_Price">
<option value=""></option>
<option value="10000">$10,000</option>
<option value="20000">$20,000</option>
<option value="30000">$30,000</option>
<option value="40000">$40,000</option>
<option value="50000">$50,000</option>
<option value="60000">$60,000</option>
<option value="70000">$70,000</option>
<option value="80000">$80,000</option>
<option value="90000">$90,000</option>
<option value="100000">$100,000</option>
<option value="125000">$125,000</option>
<option value="150000">$150,000</option>
<option value="175000">$175,000</option>
<option value="200000">$200,000</option>
<option value="225000">$225,000</option>
<option value="250000">$250,000</option>
<option value="275000">$275,000</option>
<option value="300000">$300,000</option>
<option value="325000">$325,000</option>
<option value="350000">$350,000</option>
<option value="375000">$375,000</option>
<option value="400000">$400,000</option>
<option value="425000">$425,000</option>
<option value="450000">$450,000</option>
<option value="475000">$475,000</option>
<option value="500000">$500,000</option>
<option value="550000">$550,000</option>
<option value="600000">$600,000</option>
<option value="650000">$650,000</option>
<option value="700000">$700,000</option>
<option value="750000">$750,000</option>
<option value="800000">$800,000</option>
<option value="850000">$850,000</option>
<option value="900000">$900,000</option>
<option value="950000">$950,000</option>
<option value="1000000">$1 mil</option>
<option value="1500000">$1.5 mil</option>
<option value="2000000">$2 mil</option>
<option value="2500000">$2.5 mil</option>
<option value="3000000">$3 mil</option>
<option value="3500000">$3.5 mil</option>
<option value="4000000">$4 mil</option>
<option value="4500000">$4.5 mil</option>
<option value="5000000">$5 mil</option>
<option value="5000001">$5 mil+</option></select>
</div>
<div class="side-ax">
<h4 class="sflabel">Bedrooms</h4>
<select data-placeholder="Min Bedrooms..." class="chosen-select-no-single size-b" input type="text" autocomplete="off" name="Bedrooms_from" id="se_Beds">
<option value=""></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8+</option>
</select>
<input type="hidden" value="" name="Bedrooms_to" />
</div>
<div class="side-bx">
<h4 class="sflabel">Bathrooms</h4>
<select data-placeholder="Min Bathrooms..." class="chosen-select-no-single size-b" input type="text" autocomplete="off" name="TotalBathrooms_from" id="se_TotalBathrooms">
<option value=""></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8+</option>
</select>
<input type="hidden" value="" name="TotalBathrooms_to" />
</div>
<div class="side-ax">
<h4 class="sflabel">Square Feet</h4>
<select data-placeholder="Min SqFt..." class="chosen-select-no-single size-b" input type="text" autocomplete="off" name="EstSqFt_from" id="se_EstSqFt">
<option value=""></option>
<option value="1000">1000</option>
<option value="1250">1250</option>
<option value="1500">1500</option>
<option value="1750">1750</option>
<option value="2000">2000</option>
<option value="2250">2250</option>
<option value="2500">2500</option>
<option value="2750">2750</option>
<option value="3000">3000</option>
<option value="3500">3500</option>
<option value="4000">4000</option>
<option value="4500">4500</option>
<option value="5000">5000</option>
<option value="5500">5500</option>
<option value="6000">6000</option>
<option value="6500">6500</option>
<option value="7000">7000</option>
<option value="7500">7500</option>
<option value="8000">8000</option>
<option value="8500">8500</option>
<option value="9000">9000</option>
<option value="9500">9500</option>
<option value="10000">10000+</option>
</select>
<input type="hidden" value="" name="EstSqFt_to" />
</div>
<div class="side-bx">
  <h4 class="sflabel">Year Built</h4>
<select data-placeholder="Min Year Built..." class="chosen-select-no-single size-b" input type="text" autocomplete="off" name="YearBuilt_from" id="se_YearBuilt">
<option value=""></option>
<option value="1700">1700</option>
<option value="1710">1710</option>
<option value="1720">1722</option>
<option value="1730">1730</option>
<option value="1740">1740</option>
<option value="1750">1750</option>
<option value="1760">1760</option>
<option value="1780">1780</option>
<option value="1790">1790</option>
<option value="1810">1810</option>
<option value="1820">1820</option>
<option value="1830">1830</option>
<option value="1840">1840</option>
<option value="1850">1850</option>
<option value="1860">1860</option>
<option value="1870">1870</option>
<option value="1880">1880</option>
<option value="1890">1890</option>
<option value="1900">1900</option>
<option value="1910">1910</option>
<option value="1920">1920</option>
<option value="1930">1930</option>
<option value="1940">1940</option>
<option value="1950">1950</option>
<option value="1960">1960</option>
<option value="1970">1970</option>
<option value="1980">1980</option>
<option value="1990">1990</option>
<option value="2000">2000</option>
<option value="2005">2005</option>
<option value="2010">2010</option>
<option value="2011">2011</option>
<option value="2012">2012</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
</select>
</div>
<div class="size-a">
<h4 class="sflabel">Select City</h4>
<select data-placeholder="Choose a City..." class="chosen-select size-a" multiple name="City[]"  id="se_City">
<option value=""></option>
<option>Allenville</option>
<option>Altamont</option>
<option>Arcola</option>
<option>Arthur</option>
<option>Assumption</option>
<option>Beecher City</option>
<option>Bethany</option>
<option>Brownstown</option>
<option>Carlinville</option>
<option>Cerro Gordo</option>
<option>Charleston</option>
<option>Clarksburg</option>
<option>Cooks Mills</option>
<option>Cowden</option>
<option>Dalton City</option>
<option>Dieterich</option>
<option>Effingham</option>
<option>Farina</option>
<option>Findlay</option>
<option>Gays</option>
<option>Greenup</option>
<option>Henton</option>
<option>Herborn</option>
<option>Herrick</option>
<option>Lakewood</option>
<option>Lovington</option>
<option>Loxa</option>
<option>Mattoon</option>
<option>Middlesworth</option>
<option>Mode</option>
<option>Moweaqua</option>
<option>Neoga</option>
<option>Oakland</option>
<option>Oconee</option>
<option>Other</option>
<option>Pana</option>
<option>Ramsey</option>
<option>Shelbyville</option>
<option>Shumway</option>
<option>Sigel</option>
<option>Stewardson</option>
<option>Strasburg</option>
<option>Sullivan</option>
<option>Taylorville</option>
<option>Teutopolis</option>
<option>Toledo</option>
<option>Tower Hill</option>
<option>Trowbridge</option>
<option>Vandalia</option>
<option>Watson</option>
<option>Wheeler</option>
<option>Westervelt</option>
<option>Windsor</option>
<option>Yantisville</option>
</select>
</div>
<div class="size-a">
<h4 class="sflabel">Select County</h4>
<select data-placeholder="Choose County..." class="chosen-select size-a" multiple name="County[]"  id="se_County">
<option value=""></option>
<option value="Champaign">Champaign</option>
<option value="Christian">Christian</option>
<option value="Clark">Clark</option>
<option value="Clay">Clay</option>
<option value="Coles-E">Coles-E</option>
<option value="Coles-W">Coles-W</option>
<option value="Crawford">Crawford</option>
<option value="Cumberland">Cumberland</option>
<option value="Douglas">Douglas</option>
<option value="Edgar">Edgar</option>
<option value="Effingham">Effingham</option>
<option value="Fayette">Fayette</option>
<option value="Hancock">Hancock</option>
<option value="Jackson">Jackson</option>
<option value="Jasper">Jasper</option>
<option value="Macon">Macon</option>
<option value="Marion">Marion</option>
<option value="Massac">Massac</option>
<option value="Montgomery">Montgomery</option>
<option value="Moultrie">Moultrie</option>
<option value="Other">Other</option>
<option value="Piatt">Piatt</option>
<option value="Richland">Richland</option>
<option value="Saline">Saline</option>
<option value="Shelby">Shelby</option>
<option value="Wayne">Wayne</option>
<option value="White">White</option>
</select>
</div>
</div>
<!-- end-side-a -->
<!-- side-b -->
<div class="side-b">
<div class="size-a">
<h4 class="sflabel">Property Style</h4>
<select data-placeholder="Choose a Style..." class="chosen-select size-a" multiple name="Styles[]"  id="se_Styles">
<option value=""></option>
<option value="A Frame">A Frame</option>
<option value="Bungalow">Bungalow</option>
<option value="Cabin">Cabin</option>
<option value="Cape Cod">Cape Cod</option>
<option value="Condo">Condo</option>
<option value="Contemporary">Contemporary</option>
<option value="Duplex">Duplex</option>
<option value="Earth Home">Earth Home</option>
<option value="Farm House">Farm House</option>
<option value="Log Home">Log Home</option>
<option value="Manufactured">Manufactured</option>
<option value="Modular">Modular</option>
<option value="Other">Other</option>
<option value="Ranch">Ranch</option>
<option value="Townhouse">Townhouse</option>
<option value="Tudor">Tudor</option>
<option value="Victorian">Victorian</option></select>
</div>
<div class="size-b">
  <h4 class="sflabel">Interior Features</h4>
<select data-placeholder="Choose Interior Features..." class="chosen-select size-a" multiple name="InteriorFeatures[]"  id="se_InteriorFeatures">
  <option value=""></option>
<option value="Attic Fan">Attic Fan</option>
<option value="Breakfast Nook">Breakfast Nook</option>
<option value="Cable TV">Cable TV</option>
<option value="Carbon Monoxide Detector">Carbon Monoxide Detector</option>
<option value="Carpeted Floors">Carpeted Floors</option>
<option value="Cathedral Ceiling">Cathedral Ceiling</option>
<option value="Ceiling Fan">Ceiling Fan</option>
<option value="Central Vacuum">Central Vacuum</option>
<option value="Ceramic Tile Floor">Ceramic Tile Floor</option>
<option value="Drywall">Drywall</option>
<option value="Fireplace Gas">Fireplace Gas</option>
<option value="Fireplace Wood">Fireplace Wood</option>
<option value="Fireplace-Livingroom">Fireplace-Livingroom</option>
<option value="Hardwood Floors">Hardwood Floors</option>
<option value="Insul Glass Window">Insul Glass Window</option>
<option value="Jetted Tub">Jetted Tub</option>
<option value="Lake View">Lake View</option>
<option value="Laminate Flooring">Laminate Flooring</option>
<option value="Paneling">Paneling</option>
<option value="Pantry">Pantry</option>
<option value="Plaster">Plaster</option>
<option value="Replacement Windows">Replacement Windows</option>
<option value="Security System">Security System</option>
<option value="Sump Pump">Sump Pump</option>
<option value="Vinyl Floor">Vinyl Floor</option>
<option value="Walk-in Closet">Walk-in Closet</option>
<option value="Water Conditioner">Water Conditioner</option>
<option value="Water Softener">Water Softener</option>
<option value="Workshop Area">Workshop Area</option>
</select>
</div>
<div class="size-b">
  <h4 class="sflabel">Exterior Features</h4>
<select data-placeholder="Choose Amenities..." class="chosen-select size-a" multiple name="ExteriorFeatures[]"  id="se_ExteriorFeatures">
  <option value=""></option>
<option value="Above ground Pool">Above ground Pool</option>
<option value="Antenna">Antenna</option>
<option value="Asphalt Parking">Asphalt Parking</option>
<option value="Boat House">Boat House</option>
<option value="Brick Trim">Brick Trim</option>
<option value="Business District">Business District</option>
<option value="Circle Drive">Circle Drive</option>
<option value="Concrete Parking">Concrete Parking</option>
<option value="Courtyard">Courtyard</option>
<option value="Deck">Deck</option>
<option value="Fenced Yard">Fenced Yard</option>
<option value="Fencing">Fencing</option>
<option value="Fruit Trees">Fruit Trees</option>
<option value="Garage Opener">Garage Opener</option>
<option value="Garden">Garden</option>
<option value="Generator">Generator</option>
<option value="Greenhouse">Greenhouse</option>
<option value="Ground Lvl Access">Ground Lvl Access</option>
<option value="Guest House">Guest House</option>
<option value="Handicap Access">Handicap Access</option>
<option value="Horses Allowed">Horses Allowed</option>
<option value="Hot Tub">Hot Tub</option>
<option value="In-ground Pool">In-ground Pool</option>
<option value="Industrial Park">Industrial Park</option>
<option value="Interstate Access">Interstate Access</option>
<option value="Lake Access">Lake Access</option>
<option value="Lakeview">Lakeview</option>
<option value="Landscaped">Landscaped</option>
<option value="Large Trees">Large Trees</option>
<option value="Level">Level</option>
<option value="Office">Office</option>
<option value="Outbuildings">Outbuildings</option>
<option value="Outdoor Sign">Outdoor Sign</option>
<option value="Pasture">Pasture</option>
<option value="Patio">Patio</option>
<option value="Pond">Pond</option>
<option value="Porch">Porch</option>
<option value="Propane Tank - Leased">Propane Tank � Leased</option>
<option value="Propane Tank - Owned">Propane Tank � Owned</option>
<option value="Rolling,Sloping,Traffic Count Avail">Rolling,Sloping,Traffic Count Avail</option>
<option value="Satellite Dish">Satellite Dish</option>
<option value="Screened Porch">Screened Porch</option>
<option value="Security System">Security System</option>
<option value="Shed">Shed</option>
<option value="Sidewalks">Sidewalks</option>
<option value="Sloping">Sloping</option>
<option value="Tillable">Tillable</option>
<option value="Water Frontage">Water Frontage</option>
<option value="Wooded">Wooded</option>
<option value="Workshop Area">Workshop Area</option>
</select>
</div>
<div class="size-b">
  <h4 class="sflabel">Exterior Finish</h4>
<select data-placeholder="Choose Exterior Finish..." class="chosen-select size-b" multiple name="Exterior[]"  id="se_Exterior">
<option value=""></option>
<option value="Aluminum">Aluminum</option>
<option value="Asphalt Shingle">Asphalt Shingle</option>
<option value="Block">Block</option>
<option value="Brick">Brick</option>
<option value="Cement Siding">Cement Siding</option>
<option value="Limestone">Limestone</option>
<option value="Log Home">Log Home</option>
<option value="Masonite">Masonite</option>
<option value="Masonry">Masonry</option>
<option value="Shake">Shake</option>
<option value="Shingle">Shingle</option>
<option value="Slate">Slate</option>
<option value="Steel">Steel</option>
<option value="Stone">Stone</option>
<option value="Stucco">Stucco</option>
<option value="Vinyl">Vinyl</option>
<option value="Wood">Wood</option>
</select>
</div>
<div class="size-b">
  <h4 class="sflabel">School District</h4>
<select data-placeholder="Choose School District..." class="chosen-select size-b" multiple name="SchoolDistrict[]"  id="se_SchoolDistrict">
  <option value=""></option>
<option value="Altamont Dist. 10">Altamont Dist. 10</option>
<option value="Arcola Dist. 306">Arcola Dist. 306</option>
<option value="Arthur Dist. 305">Arthur Dist. 305</option>
<option value="Atwood Hammond Dist. 39">Atwood Hammond Dist. 39</option>
<option value="Beecher City Dist. 20">Beecher City Dist. 20</option>
<option value="Bond/Fayette/Effingham 410">Bond/Fayette/Effingham 410</option>
<option value="Brownstown Dist. 201">Brownstown Dist. 201</option>
<option value="Casey-Westfield Dist. 4C">Casey-Westfield Dist. 4C</option>
<option value="Central A &amp; M Dist. 21">Central A &amp; M Dist. 21</option>
<option value="Charleston Dist. 1">Charleston Dist. 1</option>
<option value="Clay/Jasper/Richland">Clay/Jasper/Richland</option>
<option value="Cowden-Herrick 3A">Cowden-Herrick 3A</option>
<option value="Cumberland Dist. 77">Cumberland Dist. 77</option>
<option value="Dieterich Dist. 30">Dieterich Dist. 30</option>
<option value="Edgar Dist. 6">Edgar Dist. 6</option>
<option value="Effingham Dist. 40">Effingham Dist. 40</option>
<option value="Flora Dist. 35">Flora Dist. 35</option>
<option value="Hutsonville Dist. 1">Hutsonville Dist. 1</option>
<option value="Jasper County Dist. 1">Jasper County Dist. 1</option>
<option value="Kansas Dist. 3">Kansas Dist. 3</option>
<option value="Marshall Dist. 2C">Marshall Dist. 2C</option>
<option value="Martinsville Dist. 3C">Martinsville Dist. 3C</option>
<option value="Mattoon Dist. 2">Mattoon Dist. 2</option>
<option value="Mt Zion Dist 3">Mt Zion Dist 3</option>
<option value="Neoga Dist. 3">Neoga Dist. 3</option>
<option value="Nokomis Dist. 22">Nokomis Dist. 22</option>
<option value="North Clay Dist. 25">North Clay Dist. 25</option>
<option value="Oakland Dist. 5">Oakland Dist. 5</option>
<option value="Oblong Dist. 4">Oblong Dist. 4</option>
<option value="Okaw Valley Dist. 302">Okaw Valley Dist. 302</option>
<option value="Other">Other</option>
<option value="Palestine Dist. 3">Palestine Dist. 3</option>
<option value="Pana Dist. 8">Pana Dist. 8</option>
<option value="Paris Dist. 4">Paris Dist. 4</option>
<option value="Paris-Union Dist. 95">Paris-Union Dist. 95</option>
<option value="Ramsey Dist. 204">Ramsey Dist. 204</option>
<option value="Riddle Elementary Dist. 2">Riddle Elementary Dist. 2</option>
<option value="Robinson Dist. 2">Robinson Dist. 2</option>
<option value="Shelbyville Dist. 4">Shelbyville Dist. 4</option>
<option value="Shiloh Dist. 1">Shiloh Dist. 1</option>
<option value="St. Elmo Dist. 202">St. Elmo Dist. 202</option>
<option value="Stewardson-Strasburg Dist. 5A">Stewardson-Strasburg Dist. 5A</option>
<option value="Sullivan Dist. 300">Sullivan Dist. 300</option>
<option value="Taylorville Dist. 3">Taylorville Dist. 3</option>
<option value="Teutopolis Dist. 50">Teutopolis Dist. 50</option>
<option value="Tuscola Dist. 301">Tuscola Dist. 301</option>
<option value="Vandalia Dist. 203">Vandalia Dist. 203</option>
<option value="Villa Grove Dist. 302">Villa Grove Dist. 302</option>
<option value="Windsor Dist. 1">Windsor Dist. 1</option>
</select>
</div>
<div class="size-b">
  <h4 class="sflabel">Zip Code</h4>
<div class="chosen-container chosen-container-multi" style="width: 100%;">
  <ul class="chosen-choices">
    <li class="search-field">
    <input placeholder="Search by Zip Code..." class="default" autocomplete="off" type="text" name="Zip"  id="se_Zip">
    </li>
  </ul>
</div>
</div>
</div>
<div style="padding-top:4px;">
<input type="hidden" name="sortby" value="Price" />
<input type="hidden" name="sortorder" value="DESC" />
<input type="hidden" value="yes" name="searchengine2_validate">
<input type="hidden" name="page" value="searchresults" />
<input type="submit" class="button_link hover_fade submit-button" value="Submit Query" />
</div>
</form>
<!-- end-side-b -->
</div>
<!-- end-Advanced Search -->
</div>
