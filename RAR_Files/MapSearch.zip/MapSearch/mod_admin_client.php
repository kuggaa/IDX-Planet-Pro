<?php
namespace MapSearch;

define('MAP_SEARCH_SCRIPT_URL', MBX_WPR_AJAX_URL.'Modules/MapSearch/scripts/');
define('MAP_SEARCH_AJAX_URL', MBX_WPR_AJAX_URL.'Modules/MapSearch/ajax/');
define('MAP_SEARCH_BASEPATH', WPR_MODULES_PATH.'MapSearch/');
//define('MAPSEARCH_RES_TPL_FILE', $config["basepath"].$config["template_dir"].'/Modules/MapSearch/SingleResult.html');
define('MAPSEARCH_OUTER_TPL_FILE', $config["basepath"].$config["template_dir"].'/Modules/MapSearch/MapSearch.html');
define('MAPSEARCH_MODAL_CSS_FILE', $config["baseurl"].$config["template_dir"].'/Modules/MapSearch/css/modal.css');

function SetDom(){
    //echo 'mapsearch admin';
}