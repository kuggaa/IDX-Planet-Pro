<?php
namespace MapSearch;

define('MAP_SEARCH_SCRIPT_URL', MBX_WPR_AJAX_URL.'Modules/MapSearch/scripts/');
define('MAP_SEARCH_AJAX_URL', MBX_WPR_AJAX_URL.'Modules/MapSearch/ajax/');
define('MAP_SEARCH_BASEPATH', WPR_MODULES_PATH.'MapSearch/');
//define('MAPSEARCH_RES_TPL_FILE', $config["basepath"].$config["template_dir"].'/Modules/MapSearch/SingleResult.html');
define('MAPSEARCH_OUTER_TPL_FILE', $config["basepath"].$config["template_dir"].'/Modules/MapSearch/MapSearch.html');
define('MAPSEARCH_MODAL_CSS_FILE', $config["baseurl"].$config["template_dir"].'/Modules/MapSearch/css/modal.css');
define('MAPSEARCH_UI_CSS_FILE', $config["baseurl"].$config["template_dir"].'/Modules/MapSearch/css/UI.css');

if(!defined('WPR_MARKERS_BASEURL'))
    define('WPR_MARKERS_BASEURL', WPR_ADMIN_SITE_ROOT.WPR_CURRENT_TPL.'/Modules/MapSearch/markers/');


$conf = \Mbx\System\GetModuleConfig('MapSearch');

wp_register_script('gmapi', 'http://maps.googleapis.com/maps/api/js?libraries=drawing&key='.$conf['gmap_key'], array('jquery'),FALSE, FALSE ); 
    wp_enqueue_script('gmapi');

    wp_register_script('markerclusterer', MAP_SEARCH_SCRIPT_URL.'markerclusterer.js', array('jquery', 'gmapi'), FALSE, TRUE ); 
    wp_enqueue_script('markerclusterer');
    
    wp_register_script('oms', MAP_SEARCH_SCRIPT_URL.'oms.js', array('jquery', 'gmapi'), FALSE, TRUE ); 
    wp_enqueue_script('oms');

if(strpos($_SERVER['REQUEST_URI'], 'listing-details') === FALSE){
    

    wp_register_script('remote-map', MAP_SEARCH_SCRIPT_URL.'remote-map.js', array('jquery'), FALSE, TRUE ); 
    wp_enqueue_script('remote-map');
}

//wp_register_script('mapSearch', MAP_SEARCH_SCRIPT_URL.'jquery.mbxSearch.js', array('jquery'), 1.0, TRUE ); 
        //wp_enqueue_script('mapSearch');

        //wp_register_script('MbxFw', MBX_WPR_AJAX_URL.'System/scripts/Framework.js', array('jquery', 'gmapi'), FALSE, TRUE ); 
        //wp_enqueue_script('MbxFw');

        //wp_register_script('all-pages-mapsearch', MAP_SEARCH_AJAX_URL.'allPages.js', array('mapSearch'), FALSE, TRUE ); 
        //wp_enqueue_script('all-pages-mapsearch');

        //wp_enqueue_style( 'mapsearch-modal', MAPSEARCH_MODAL_CSS_FILE);
        
        
function MapSearchMain($params){
    
    if(strpos($_SERVER['REQUEST_URI'], 'wp-admin') === FALSE){
        wp_register_script('mapSearch', MAP_SEARCH_SCRIPT_URL.'jquery.mbxSearch.js', array('jquery', 'gmapi') ); 
        wp_enqueue_script('mapSearch');

        wp_register_script('MbxFw', MBX_WPR_AJAX_URL.'System/scripts/Framework.js', array('jquery', 'gmapi') ); 
        wp_enqueue_script('MbxFw');

        wp_register_script('all-pages-mapsearch', MAP_SEARCH_AJAX_URL.'allPages.js', array('mapSearch') ); 
        wp_enqueue_script('all-pages-mapsearch');

        wp_enqueue_style( 'mapsearch-modal', MAPSEARCH_MODAL_CSS_FILE);
    }
    
    
        //wp_enqueue_style( 'mapsearch-UI', MAPSEARCH_UI_CSS_FILE);
    
    $tpl = file_get_contents(MAPSEARCH_OUTER_TPL_FILE);
    return $tpl;
}

add_shortcode('wpr_map_search', '\\MapSearch\\MapSearchMain');

function SetAppConfig(){
    $config = 'WPR.mbxSearch = {};WPR.mbxSearch.mapSettings = {};';
    $config .= 'WPR.mbxSearch.continuousScrollLoadBuffer = 400;';
    $config .= 'WPR.MapSearch = WPR.MapSearch || {};WPR.MapSearch.markerUrl = "'.WPR_ADMIN_SITE_ROOT.WPR_CURRENT_TPL.'/Modules/MapSearch/markers/";';
    
    return $config;
}

//function SetDom()