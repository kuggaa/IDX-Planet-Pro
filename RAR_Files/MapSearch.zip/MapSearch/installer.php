<?php
namespace MapSearch;

include_once 'config.php';
define('ASSETS_TPLS', dirname(__FILE__).'/assets/templates/');

function Install($keepCustom){
    $template_dirs = glob(TPL_ROOT . '*', GLOB_ONLYDIR);
    foreach ($template_dirs as $tpl){
        $tpldir = $tpl.'/Modules/MapSearch';
        $markersdir = $tpldir.'/markers';
        $clustersdir = $markersdir . '/clusters';
        if(!file_exists($clustersdir)) mkdir($clustersdir);
        copy(ASSETS_TPLS.'markers/clusters/m1.png', $clustersdir.'/m1.png');
        copy(ASSETS_TPLS.'markers/clusters/m2.png', $clustersdir.'/m2.png');
        copy(ASSETS_TPLS.'markers/clusters/m3.png', $clustersdir.'/m3.png');
        copy(ASSETS_TPLS.'markers/clusters/m4.png', $clustersdir.'/m4.png');
        copy(ASSETS_TPLS.'markers/clusters/m5.png', $clustersdir.'/m5.png');
    }
    
    if($keepCustom){
        return;
    }
    
    
    
    $db = \Mbx\DataStore\MbxGetDb();
    
    try {
        $drop = 'DROP TABLE IF EXISTS '.WPR_TABLE_PFX."mapsearch_settings";
        $db->TableOp($drop);
        
        // Just do this and catch the ex if table exists
        $create_settings_table = "CREATE TABLE `".WPR_TABLE_PFX."mapsearch_settings` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `configKey` varchar(64) NOT NULL,
            `value` varchar(128) NOT NULL,
            PRIMARY KEY (`id`)
          );";

        $db->TableOp($create_settings_table);
        
        $sql = 'INSERT INTO '.WPR_TABLE_PFX."mapsearch_settings SET configKey = 'ctr-lat', `value` = '39.809734'";
        
        $db->InsertSingleRow($sql, array());
        
        $sql = 'INSERT INTO '.WPR_TABLE_PFX."mapsearch_settings SET configKey = 'ctr-lng', `value` = '-98.56'";
        
        $db->InsertSingleRow($sql, array());

    //$db->InsertSingleRow('INSERT INTO '.WPR_TABLE_PFX."mapsearch_settings (`configKey`, `value`) VALUES ('ctr-lat', '39.809734')", array());


    //$db->InsertSingleRow('INSERT INTO '.WPR_TABLE_PFX."mapsearch_settings (`configKey`, `value`) VALUES ('ctr-lng', '-98.56')", array());

    //$db->InsertSingleRow('INSERT INTO '.WPR_TABLE_PFX."mapsearch_settings (`configKey`, `value`) VALUES ('zoom', '4')", array());

    //$db->InsertSingleRow('INSERT INTO '.WPR_TABLE_PFX."mapsearch_settings (`configKey`, `value`) VALUES ('map_type', 'hybrid')", array());

    }
    catch (\PDOException $ex) {
        echo $ex->getMessage();
    }
    
    
    
    foreach ($template_dirs as $tpl) {
        $tpldir = $tpl.'/Modules/MapSearch';

        if(!file_exists($tpldir)) mkdir($tpldir, 0777, TRUE);
        copy(ASSETS_TPLS.'InfoWindow.html', $tpldir.'/InfoWindow.html');
        copy(ASSETS_TPLS.'MapSearch.html', $tpldir.'/MapSearch.html');
        copy(ASSETS_TPLS.'MapSearchForm.html', $tpldir.'/MapSearchForm.html');
        copy(ASSETS_TPLS.'SingleResult.html', $tpldir.'/SingleResult.html');

        $cssdir = $tpldir.'/css';
        if(!file_exists($cssdir)) mkdir($cssdir);
        copy(ASSETS_TPLS.'css/UI.css', $tpldir.'/css/UI.css');
        copy(ASSETS_TPLS.'css/modal.css', $tpldir.'/css/modal.css');
        copy(ASSETS_TPLS.'css/admin-css.css', $tpldir.'/css/admin-css.css');

        /*$admindir = $tpldir.'/admin';
        if(!file_exists($admindir)) mkdir($admindir);
        copy(ASSETS_TPLS.'admin/AdvSettings.html', $tpldir.'/admin/AdvSettings.html');
        copy(ASSETS_TPLS.'admin/Settings.html', $tpldir.'/admin/Settings.html');*/

        $markersdir = $tpldir.'/markers';
        if(!file_exists($markersdir)) mkdir($markersdir);
        copy(ASSETS_TPLS.'markers/.htaccess', $tpldir.'/markers/.htaccess');
        
        
    }
}

