<?php
namespace MapSearch\Models;

class Listing{
    function GetListing($id){
        $sql = 'SELECT * FROM '.WPR_TABLE_PFX.'listingsdb WHERE listingsdb_id = :id';
        $paramsArr = array(':id' => $id);
        $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
        return $db->FetchSingleRow($sql, $paramsArr);
        
    }
}

class Listings{
    /* @var $listings Listing[] */
    public $listings;
    
    public static function GetInstance(){
        return new Listings();
    }
    
    public function GetListings(array $sql_frags, array $map_center, $start_at = 10){
        $limit = 25;
        //$start_at = 10;
        $param_arr = array();
        //$sql = 'SELECT listingsdb_id as id, class_id, listingsdb_title as title, Price, MLS, City, '.WPR_BEDS_COL.', '.WPR_BATHS_COL.', '.WPR_PROPTYPE_COL.' as classField, Remarks, PhotoCount, latitude, longitude ';
        $sql_having = '';
        $sql_select = 'SELECT listingsdb_id as id ';
        $sql_where .= 'FROM '.WPR_TABLE_PFX.'listingsdb WHERE ';
        $isCircle = FALSE;
        foreach ($sql_frags as $frag){
            if($frag[0] == 'circle'){
                $isCircle = TRUE;
                $sql_select .= ", ( 3959 * acos( cos( radians(".$frag[2][0].") ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(".$frag[2][1].") ) + sin( radians(".$frag[2][0].") ) * sin( radians( latitude ) ) ) ) AS distance ";
                $sql_having .= " HAVING distance < ".$frag[2][2]." ";
                
            }
            elseif($frag[0] == 'polygon'){ // needs expanded for other shapes
                $sql_where .= "ST_CONTAINS(ST_GEOMFROMTEXT('POLYGON((";
                foreach ($frag[2] as $polybound){ // 0 = lng
                    $sql_where .= $polybound[0].' '.$polybound[1].', ';
                }
                $sql_where .= $frag[2][0][0].' '.$frag[2][0][1]; // Close the poly
                //$sql = substr($sql, 0, -2);
                $sql_where .= "))'), point(longitude, latitude)) AND  ";
            }
            else{
                $sql_where .= $frag[0].' '.$frag[1].' :'.$frag[3].$frag[0].' AND  ';
                $param_arr[':'.$frag[3].$frag[0]] = $frag[2];
            }
            
        }
        $sql_where = substr($sql_where, 0, -6);
        $sql = $sql_select.$sql_where.$sql_having;
        //$sql .= ' ORDER BY abs(haversine(:ctr_lat, latitude, :ctr_lon, longitude, "KM")) DESC';
        if(!$isCircle){
            $sql .= ' ORDER BY ABS(ABS(latitude - :ctr_lat) + ABS(longitude - :ctr_lon)) ASC';
        }
        
        $param_arr[':ctr_lat'] = $map_center['lat'];
        $param_arr[':ctr_lon'] = $map_center['lon'];
        $sql .= ' LIMIT '.$limit;
        $sql .= ' OFFSET '.$start_at;
        //echo $sql;die();
        if(MAP_SEARCH_DEBUG)///////////////////////////////////////////// where i stopped - how to do offset $start_at
        {
            echo $sql.'<br><br>';
            var_dump($param_arr);
        }
        
        $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
        
        $return_listings = $db->GetRows($sql, $param_arr);
        
        if(MAP_SEARCH_DEBUG){
            foreach($db->GetRows($sql, $param_arr) as $row){
                echo '<br>MLS - '.$row['MLS'].' rem len: '. strlen($row['Remarks']);
            }
        }
        else{
            return $return_listings;
        }
    }
    
        private function GetAllMarkers(array $sql_frags, $limit = 200){
        $param_arr = array();
        $sql_select = 'SELECT listingsdb_id as id, listingsdb_title as title, MLS, latitude, longitude, '.WPR_PROPTYPE_COL. ' as classField ';
        //var_dump($sql_frags);
        //die();
        $sql_having = '';
        $sql_where = 'FROM '.WPR_TABLE_PFX.'listingsdb WHERE ';
        foreach ($sql_frags as $frag){
            if($frag[0] == 'circle'){
                $sql_select .= ", ( 3959 * acos( cos( radians(".$frag[2][0].") ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(".$frag[2][1].") ) + sin( radians(".$frag[2][0].") ) * sin( radians( latitude ) ) ) ) AS distance ";
                $sql_having .= " HAVING distance < ".$frag[2][2]." ";
            }
            elseif($frag[0] == 'polygon'){ // needs expanded for other shapes
                $sql_where .= "ST_CONTAINS(ST_GEOMFROMTEXT('POLYGON((";
                foreach ($frag[2] as $polybound){ // 0 = lng
                    $sql_where .= $polybound[0].' '.$polybound[1].', ';
                }
                $sql_where .= $frag[2][0][0].' '.$frag[2][0][1]; // Close the poly
                //$sql = substr($sql, 0, -2);
                $sql_where .= "))'), point(longitude, latitude)) AND  ";
            }
            else{
                $sql_where .= $frag[0].' '.$frag[1].' :'.$frag[3].$frag[0].' AND  ';
                $param_arr[':'.$frag[3].$frag[0]] = $frag[2];
                
            }
        }
        
        $sql_where = substr($sql_where, 0, -6);
        
        $sql = $sql_select.$sql_where.$sql_having;
        //echo $sql_where.'where';die();
        
        $sql .= ' ORDER BY rand()';
        $sql .= ' LIMIT '.$limit;
        //echo 'GetAllMarkers SQL:'. $sql.'<br><br>';
            //die();
        if(MAP_SEARCH_DEBUG)
        {
            echo 'GetAllMarkers SQL:'. $sql.'<br><br>';
            var_dump($param_arr);
            die();
        }
        $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
        
        return $db->GetRows($sql, $param_arr);
    }
    
    public function GetListingIds(array $sql_frags, $limit = 12){
        $sql = 'SELECT listingsdb_id as id ';
        $sql .= 'FROM '.WPR_TABLE_PFX.'listingsdb WHERE ';
        $param_arr = array();
        foreach ($sql_frags as $frag){
            $sql .= $frag[0].' '.$frag[1].' :'.$frag[3].$frag[0].' AND ';
            $param_arr[':'.$frag[3].$frag[0]] = $frag[2];
        }
        $sql = substr($sql, 0, -5);
        $sql .= ' LIMIT '.$limit;
        
        $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
        return $db->GetRows($sql, $param_arr);
    }
    
    private function GetClusters(array $sql_frags, array $search_bounds){
        return NULL;
    }
    
    public function GetMarkers(array $sql_frags, array $search_bounds, $limit = 1000){
        return $this->GetAllMarkers($sql_frags, $limit); 
        /*$sql = 'SELECT count(*) as count, latitude, longitude, listingsdb_title ';
        $sql .= 'FROM '.WPR_TABLE_PFX.'listingsdb WHERE ';
        $param_arr = array();
        foreach ($sql_frags as $frag){
            $sql .= $frag[0].' '.$frag[1].' :'.$frag[3].$frag[0].' AND ';
            $param_arr[':'.$frag[3].$frag[0]] = $frag[2];
        }
        $sql = substr($sql, 0, -5);
        
        //return $sql;
        $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
        
        $return_counter = $db->FetchSingleRow($sql, $param_arr);
        //return $return_counter['count'];
        if($return_counter['count'] < 30000){
            return $this->GetAllMarkers($sql_frags, $limit);
        }
        return $this->GetClusters($sql_frags, $search_bounds);*/
    }
    

}

