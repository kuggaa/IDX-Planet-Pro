<?php
namespace MapSearch;

define('MAP_SEARCH_SCRIPT_URL', MBX_WPR_AJAX_URL.'Modules/MapSearch/scripts/');
define('MAP_SEARCH_AJAX_URL', MBX_WPR_AJAX_URL.'Modules/MapSearch/ajax/');
define('MAP_SEARCH_BASEPATH', WPR_MODULES_PATH.'MapSearch/');

define('MAPSEARCH_ADMIN_CSS_FILE', WPR_MOD_TPL_DIR.'/Modules/MapSearch/css/admin-css.css');

function Main(){
    $output = '<link rel="stylesheet" type="text/css" href="'.ADMIN_GLOBAL_CSS_FILE.'">';
    $output .= file_get_contents(dirname(__FILE__).'/assets/templates/admin/Settings.html');
    $config = \Mbx\System\GetModuleConfig('MapSearch');
    $output .= "<script type='text/javascript' src='http://maps.googleapis.com/maps/api/js?libraries=drawing&key=".$config['gmap_key']."'></script>";
    //$output .= "<script type='text/javascript' src='".MBX_WPR_AJAX_URL."System/scripts/Framework.js'></script>";
    $output .= "<script type='text/javascript' src='".MBX_WPR_AJAX_URL."Modules/MapSearch/scripts/admin-script.js'></script>";
    return new \Mbx\Page\PageReturn('Map Settings', $output);
}

function AdvSetup(){
    //return new \Mbx\Page\PageReturn('Advanced Map Settings', file_get_contents(WPR_TEMPLATE_PATH.'/Modules/MapSearch/admin/AdvSettings.html'));
    $output = '<link rel="stylesheet" type="text/css" href="'.ADMIN_GLOBAL_CSS_FILE.'">';
    $output .= '<link rel="stylesheet" type="text/css" href="'.MAPSEARCH_ADMIN_CSS_FILE.'">';
    $output .= file_get_contents(dirname(__FILE__).'/assets/templates/admin/AdvSettings.html');
    //$output .= "<script type='text/javascript' src='".MBX_WPR_AJAX_URL."System/scripts/Framework.js'></script>";
    $output .= "<script type='text/javascript' src='".MBX_WPR_AJAX_URL."Modules/MapSearch/scripts/admin-script.js'></script>";
    return new \Mbx\Page\PageReturn('Advanced Map Settings', $output);
}

function GetAdminLinks(){
    $links = array();
    $links[] = array(
        'href' => WPR_ADMIN_SITE_ROOT.'index.php?apage=MapSearch&Feature=Main',
        'icon' => WPR_ICONS_BASEURL.'small/grey/apartment_building.png',
        'text' => 'Map Settings',
        'menu' => 'maps'
        );
    $links[] = array(
        'href' => WPR_ADMIN_SITE_ROOT.'index.php?apage=MapSearch&Feature=AdvSetup',
        'icon' => WPR_ICONS_BASEURL.'small/grey/apartment_building.png',
        'text' => 'Advanced Map Settings',
        'menu' => 'maps'
        );
    return $links;
}



