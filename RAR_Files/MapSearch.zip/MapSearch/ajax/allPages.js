jQuery(document).ready(function($){
    $('#listing_map').mbxSearch();
});


