<?php
namespace MapSearch;

function LinkToListing($listing, $classes){
    $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]); 
    $baselink = "http://".$_SERVER['SERVER_NAME'].$port."/listing-details/";
    $space = WPR_SPACE_CHAR;
    $title = isset($listing['title']) ? $listing['title'] : $listing['listingsdb_title'];
    return $baselink.'listing'.
            $space.strtolower($listing['MLS']).$space.
            $classes[$listing['class_id']].
            $space.str_replace(' ', $space, strtolower($title)).
            $space.  strtolower($listing['City']);
}

function GetClasses(){
    $sql = "SELECT * FROM ".WPR_TABLE_PFX.'class';
    $paramArr = array();
    $db = \Mbx\DataStore\MbxGetDb();
    $classes = $db->GetRows($sql, $paramArr);
    // Place the display ready classes in array indexed by the class_id in listingsdb
    $classArr = array();
    
    foreach ($classes as $class){
        $classArr[$class['class_id']] = strtolower($class['class_name']);
    }
    return $classArr;
}

