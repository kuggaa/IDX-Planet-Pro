<?php
namespace MapSearch;

function Uninstall($keepCustom){
    if(!$keepCustom){
        $template_dirs = glob(TPL_ROOT . '*', GLOB_ONLYDIR);
        foreach ($template_dirs as $tpl){
            \Mbx\System\MbxRemoveDir($tpl.'/Modules/MapSearch');
        }
        
        $drop_settings_table = "DROP TABLE IF EXISTS `".WPR_TABLE_PFX."mapsearch_settings`;";
        $db = \Mbx\DataStore\MbxGetDb();
        $db->TableOp($drop_settings_table);
    }
}

