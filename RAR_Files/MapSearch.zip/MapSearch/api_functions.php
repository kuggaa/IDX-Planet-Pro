<?php
namespace MapSearch\API;

include 'include/functions.php';

define('WPR_MARKERS_BASEURL', WPR_ADMIN_SITE_ROOT.WPR_CURRENT_TPL.'/Modules/MapSearch/markers/');

function GetListingTemplate($data){
    $raw = file_get_contents(MAPSEARCH_RES_TPL_FILE);
    return str_replace("\r\n", '', $raw);
}

function GetInfoWindowTemplate($data){
    $raw = file_get_contents(MAPSEARCH_INFO_WINDOW_FILE);
    return str_replace("\r\n", '', $raw);
}

function GetFilterBox($data){
    $raw = file_get_contents(MAPSEARCH_SEARCH_FORM_FILE);
    return str_replace("\r\n", '', $raw);
}

function GetDistinctValues($data){
    $sql = 'SELECT DISTINCT '.$data['fieldname'].' FROM '.WPR_TABLE_PFX.'listingsdb ORDER BY :orderby ASC';
    $paramArr = array(':orderby' => $data['fieldname']);
    $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
    $returnArr = array();
    $rawresults = $db->GetRows($sql, $paramArr);
    
    if(!count($rawresults))
        return NULL;
    
    foreach($rawresults as $result){
        $returnArr[] = array($result[$data['fieldname']], ucwords(strtolower($result[$data['fieldname']])));
    }
    sort($returnArr);
    //return array('hit' => 'Hit');
    return $returnArr;
}

function ReturnTemplatedListings($data, $return_html = false, $start_at = 0){
    include_once WPR_INCLUDE_PATH.'parse.inc.php';
    $parser = new \parseClass();
    $listing_data = SearchListings($data, FALSE);
    $single_lstg_tpl = GetListingTemplate($data);
    $templated_listings = array();
    
    $classes = \MapSearch\GetClasses();
    
    // Seed the html return fo if returning html
    $html = '';
    
    foreach ($listing_data as $listing) {
        // Local parse. Consider some sort of function
        $link = \MapSearch\LinkToListing($listing, $classes);
        $prepped_tpl = str_replace('{full_link_to_listing}', $link, $single_lstg_tpl);
        $templated_listing = $parser->MainParse($single_lstg_tpl, $listing['id'], WPR_USING_EXTERNAL_DB);
        $templated_listings[] = $templated_listing;
        $html .= $templated_listing;
    }
    
    return $return_html ? $html : $templated_listings;
}

function ReturnInfoWindow($data){
    include_once WPR_INCLUDE_PATH.'parse.inc.php';
    $parser = new \parseClass();
    $infoWindowTpl = GetInfoWindowTemplate($data);
    
    $classes = \MapSearch\GetClasses();
    $lo = new \MapSearch\Models\Listing();
    $listing = $lo->GetListing($data['listingid']);

    $link = \MapSearch\LinkToListing($listing, $classes);
    
    $infoWindowTpl = str_replace('{full_link_to_listing}', $link, $infoWindowTpl);
    // Get the
    return $parser->MainParse($infoWindowTpl, $data['listingid'], WPR_USING_EXTERNAL_DB);
}

$targetFile = WPR_TEMPLATE_PATH.'/Modules/MapSearch/markers/';
define('WPR_MARKERS_PATH', WPR_TEMPLATE_PATH.'/Modules/MapSearch/markers/');
define('WPR_MARKER_THEME', 'default_');

function GetCustomMarkers($data){
    $markers = glob(WPR_MARKERS_PATH."*.{jpg,png,gif}", GLOB_BRACE);
    
    $markerInfo = array();
    foreach ($markers as $marker) {
        $marker_file = basename($marker);
        
        $sss = strrpos($marker_file, '.');
        $name_part = substr($marker_file, 0, $sss);
        $name_part = str_replace(WPR_MARKER_THEME, '', $name_part);
        $name_part = str_replace('__', '/', $name_part);
        $name_part = str_replace('--', ' ', $name_part);
        
        $marker_disp_name = $name_part;
        
        $markerInfo[] = array('filename' => $marker_file, 'display' => $marker_disp_name);
    }
    
    return array('baseurl' => WPR_MARKERS_BASEURL, 'markers' => $markerInfo);
}

function FileUpload($data){
    foreach ($_FILES as $file) {
        $sss = strrpos($file['name'], '.');
        $ext = strtolower(substr($file['name'], $sss));
        
        if($ext != '.jpg' && $ext != '.png' && $ext != '.gif'){
            return 'failed - file type not allowed';
        }
        
        $targetFile = WPR_MARKERS_PATH.$data['new_file_name'].'.png';
        error_log('target file: '.$targetFile);
        if (move_uploaded_file($_FILES["upload_file"]["tmp_name"], $targetFile)){
            
            // Return the image url
            return WPR_ADMIN_SITE_ROOT.WPR_CURRENT_TPL.'/Modules/MapSearch/markers/'.$data['new_file_name'].'.png';
        }
        else{
            return 'failed to move uploaded file';
        }
        break;
    }
}

function DeleteCustomMarker($data){
    $file_targets = glob(WPR_MARKERS_PATH. substr(basename($data['markerurl']), 0, -4) .".{jpg,png,gif}", GLOB_BRACE);
    
    foreach ($file_targets as $file) {
        unlink($file);
    }
    
    return count($file_targets);
}

function SearchListings($data, $get_markers, $get_ids = FALSE){
    $valid_search_terms = array('classid', 'ne', 'sw', 'id', 'polygon', 'circle'); // This needs to go dynamic
    
    //$valid_search_terms = array();
    $sql = 'SHOW columns FROM '.WPR_TABLE_PFX.'listingsdb';
    $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
    $res = $db->GetRows($sql, array());
    
    foreach ($res as $fld){
        
        //if(strpos($fld['Field'], '_') === FALSE)
           $valid_search_terms[] = $fld['Field'];     
    }
    //var_dump($valid_search_terms);
    $sql_filter_frags = array();
    $mapcenter = array();
    $limit = 1000;
    $startat = 0;
    $searchbounds = array();
    foreach ($data as $key_name => $value)
    {
        if($value == '' || is_array($value))
            continue;
        
        $operator = '';
        $term = '';
        $param_prefix = '';
        $bound = '';
        $delimiter = '';
        
        // This chain of elseif's will leave in favor or sp1
        if($key_name == 'mapcenter'){
            $mapcenter = array('lat' => $value['lat'], 'lon' => $value['lon']);
            continue;
        }
        elseif($key_name == 'limit'){
            $limit = $value;
            continue;
        }
        elseif($key_name == 'startat')
        {
            $startat = $value;
            continue;
        }
        
        elseif(strpos($key_name, '-'))
                $delimiter = '-';
        elseif(strpos($key_name, '__'))
                $delimiter = '__';
        
        if($delimiter != '')
            list($term, $bound) = explode($delimiter, $key_name);
        else 
            $term = $key_name;
        
        
        if(MAP_SEARCH_DEBUG)
            echo 'key '.$key_name;
        
        if(!in_array($term, $valid_search_terms))
        {
            if(MAP_SEARCH_DEBUG)
                echo '<br>';
            continue;
        }
        
        
        if($delimiter == '-')
        {
            $operator = ($bound == 'min') ? ' >= ' : ' <= ';
            $param_prefix = $bound;
        }
        
        elseif($delimiter == '__') // This will need a rework to handle more client initiated vars
        {
            if($bound == 'To' || $bound == 'From'){
                $operator = ($bound == 'From') ? ' >= ' : ' <= ';
                $param_prefix = $bound;
            }
            else{
                $operator = ($term == 'ne') ? ' <= ' : ' >= ';
                // Here is the entry for translating search terms to db fields
                $param_prefix = $term;
                $term = ($bound == 'lat') ? 'latitude' : 'longitude';
                $search_bounds[$key_name] = $value;
            }
            
        }
        elseif(strpos($value, '%') !== FALSE){
            $operator = 'LIKE';
        }
        else 
        {
            $term = $key_name;
            $operator = '=';
        }
        
        if($term == 'classid'){
            $term = 'class_id';
        }
        elseif($term == 'id')
            $term = 'listingsdb_id';
        
        
        $sql_filter_frags[] = array($term, $operator, $value, $param_prefix);
        
        if(MAP_SEARCH_DEBUG)
            echo ' db -> '.$term.'<br>';    
        
    }
    
    if($data['action'] == 'GetSamples')
        $sql_filter_frags[] = array('latitude', '!=', 0, '');
    
    if(MAP_SEARCH_DEBUG)
        echo '<br>';
    
    $instance = \MapSearch\Models\Listings::GetInstance();
    if($get_markers)
        return $instance->GetMarkers($sql_filter_frags, $mapcenter, $limit);
    elseif($get_ids){
        return $instance->GetListingIds($sql_filter_frags);
    }
    else{
        return $instance->GetListings($sql_filter_frags, $mapcenter, $startat);
    }
}

