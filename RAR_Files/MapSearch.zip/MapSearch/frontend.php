<?php
namespace MapSearch;

//define('WPR_BEDS_COL', 'Bedrooms');
//define('WPR_BATHS_COL', 'FullBaths');

$mod_settings = \Mbx\System\GetModuleConfig('MapSearch');

if(isset($mod_settings['beds_col'])) define('WPR_BEDS_COL', $mod_settings['beds_col']);
if(isset($mod_settings['baths_col'])) define('WPR_BATHS_COL', $mod_settings['baths_col']);
if(isset($mod_settings['half_baths_col'])) define('WPR_HALF_BATHS_COL', $mod_settings['half_baths_col']);
if(isset($mod_settings['classField'])) define('WPR_PROPTYPE_COL', $mod_settings['classField']);

if(!defined('MAP_SEARCH_DEBUG'))
    define('MAP_SEARCH_DEBUG', 0);

define('MAPSEARCH_RES_TPL_FILE', WPR_TEMPLATE_PATH.'/Modules/MapSearch/SingleResult.html');
define('MAPSEARCH_SEARCH_FORM_FILE', WPR_TEMPLATE_PATH.'/Modules/MapSearch/MapSearchForm.html');
define('MAPSEARCH_INFO_WINDOW_FILE', WPR_TEMPLATE_PATH.'/Modules/MapSearch/InfoWindow.html');

include_once 'Models/Models.php';
include_once 'api_functions.php';

function MapSearchApi($data){
    switch($data['action'])
    {
        case 'GetListings':
            $listings =  \MapSearch\API\SearchListings($data, FALSE);
            return new MapSearchDto($listings);
            break;
        case 'GetTemplatedListings':
            
            $listings =  \MapSearch\API\ReturnTemplatedListings($data, FALSE);
            //var_dump($listings);
            $dto = new MapSearchDto(NULL); // Hack needs updated to MapSearchObject
            $dto->templatedListings = $listings; // Hack needs updated to MapSearchObject
            return $dto; // Hack needs updated to MapSearchObject
            break;
        case 'GetTemplatedListingsHtml': // This exists for brevity. raw html should be in another controller maybe?
            
            $listings =  \MapSearch\API\ReturnTemplatedListings($data, TRUE);
            //var_dump($listings);
            $dto = new MapSearchDto(NULL); // Hack needs updated to MapSearchObject
            $dto->templatedListings = $listings; // Hack needs updated to MapSearchObject
            return $dto; // Hack needs updated to MapSearchObject
            break;
        case 'GetInfoWindow':
            //return new MapSearchDto($data['id']);
            $infowindow =  \MapSearch\API\ReturnInfoWindow($data);
            //var_dump($listings);
            return $infowindow; // Hack needs updated to MapSearchObject
            break;
        case 'GetMarkers':
            $markers =  \MapSearch\API\SearchListings($data, TRUE);
            return new MapSearchDto($markers, 'Markers'); // Hack needs updated to MapSearchObject
            break;
        case 'GetSamples':
            $markers =  \MapSearch\API\SearchListings($data, TRUE);
            return new MapSearchDto($markers, 'Markers'); // Hack needs updated to MapSearchObject
            break;
        case 'GetListingTemplate':
            $template =  \MapSearch\API\GetListingTemplate($data);
            return $template; // Hack needs updated to MapSearchObject
            break;
        case 'GetFilterBox':
            $template =  \MapSearch\API\GetFilterBox($data);
            return $template; // Hack needs updated to MapSearchObject
            break;
        case 'GetDistinctValues':
            $values = \MapSearch\API\GetDistinctValues($data);
            return new MapSearchDto($values, 'SelectList');
        case 'GetCustomMarkers':
            //return 'arrived';
            return \MapSearch\API\GetCustomMarkers($data);
        case 'DeleteCustomMarker':
            return \MapSearch\API\DeleteCustomMarker($data);
        case 'GetMarkersPoly':
            $markers =  \MapSearch\API\SearchListings($data, TRUE);
            return new MapSearchDto($markers, 'Markers');
        case 'GetListingsPoly':
            $listings =  \MapSearch\API\ReturnTemplatedListings($data, FALSE);
            //var_dump($listings);
            $dto = new MapSearchDto(NULL); // Hack needs updated to MapSearchObject
            $dto->templatedListings = $listings; // Hack needs updated to MapSearchObject
            return $dto; // Hack needs updated to MapSearchObject
        case 'GetMarkersCircle':
            $markers =  \MapSearch\API\SearchListings($data, TRUE);
            return new MapSearchDto($markers, 'Markers');
        case 'GetListingsCircle':
            $listings =  \MapSearch\API\ReturnTemplatedListings($data, FALSE);
            //var_dump($listings);
            $dto = new MapSearchDto(NULL); // Hack needs updated to MapSearchObject
            $dto->templatedListings = $listings; // Hack needs updated to MapSearchObject
            return $dto; // Hack needs updated to MapSearchObject
        default:
            echo '0';
            die();
    }
}

function init($data){
    MapSearchApi($data);
}

class MapSearchDto{
    public $results;
    public $resultCount;
    public $templatedListings; // Hack needs updated to MapSearchObject
    public $MapSearchObject;


    public function __construct($results, $Mso = 'default', $listing_count = NULL) {
        $this->results = $results;
        //echo '<br><br>----------------------------------------------------------';
        //var_dump($this->listings);
        //echo '<br><br>----------------------------------------------------------';
        if($results != NULL){
            foreach ($this->results as $k => $v){
            //echo strlen($v['Remarks']).'<br>';
            if(strlen($v['Remarks']) > 150)
                $this->results[$k]['Remarks'] = substr ($v['Remarks'], 0, 150);
            }
        }
        $this->resultCount = $listing_count;
        $this->MapSearchObject = $Mso;
    }
    
}