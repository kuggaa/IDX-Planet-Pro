var mapPins = [];
var thisMap;
var markersArr = [];

function MbxRemoteMap(){
    this.map = false;
    $ = jQuery;
    
    
    this.MapMarkers = function(){
        var count = 0;
        var lats = 0;
        var lngs = 0;
        var rawMarkers = [];
        var infowindow;
        // Starting a bounds we can fit to
        var bounds = new google.maps.LatLngBounds();
        //alert(JSON.stringify(markersSrc));
        $.each(markersSrc, function(i, v){
            count++;
            // Get an initial rough center
            lats = lats + v.lat;
            lngs = lngs + v.lng;
            // Extend the bounds by the listing
            var xyz = new google.maps.LatLng(parseFloat(v.lat), parseFloat(v.lng));
            bounds.extend(xyz);
            // Add to the markers array
            rawMarkers.push({url: v.link, lat: v.lat, lng: v.lng, lid: v.lid, img: v.img});
            //console.log('image: ' + v.img);
        })
        
        var mapSettings;
        if(!rawMarkers.length && mapPolygon.length){
            //alert('using poly');
            mapSettings = {
                center: mapPolygon[0],
                zoom: 9
            }
        }
        else{
            mapSettings = {
                center: {lat: lats / count, lng: lngs / count},
                zoom: 9
            }
        }
        //alert(rawMarkers.length);
        
        //alert(JSON.stringify(mapSettings));
        this.map = new google.maps.Map(document.getElementById('remote-map'), mapSettings);
        thisMap = this.map;
        var oms = new OverlappingMarkerSpiderfier(thisMap);
        //alert($('#remote-map').attr('data-showPolygon'));
        //alert($('#remote-map').data('showpolygon'));
        if($('#remote-map').attr('data-showPolygon') != undefined){
            //alert($('#remote-map').attr('data-showPolygon'));
            var showPolygon = $('#remote-map').attr('data-showPolygon');
            // We only want to attempt a polygon if there is one and it is set to show
            if(showPolygon === 'true' && typeof mapPolygon != 'undefined'){
                //alert('map poly');
                $.each(mapPolygon, function(i,v){
                    bounds.extend(v);
                    
                });
                //alert($('#remote-map').data('polygon-style'));
                var styles;
                if($('#remote-map').data('polygon-style') != undefined){
                    var style = $('#remote-map').data('polygon-style');
                    styles = style.split('|');
                    //alert(styles.length);
                }
                else{
                    styles = [];
                    styles[0] = 'black';
                    styles[1] = 0.8;
                    styles[2] = 2;
                    styles[3] = 0;
                    styles[4] = 0;
                }
                
                var poly = new google.maps.Polygon({
                    paths: mapPolygon,
                    strokeColor: styles[0],
                    strokeOpacity: styles[1],
                    strokeWeight: styles[2],
                    fillColor: styles[3],
                    fillOpacity: styles[4]
                })
                poly.setMap(thisMap);
            }
        }
        
        this.map.fitBounds(bounds);
        var thatmap = this.map;
        //alert(rawMarkers.length);
        $.each(rawMarkers, function(i,v){
            // Put the marker on the map
            
            var markerIcon = {};
            markerIcon.url = WPR.MapSearch.markerUrl + 'default_' + v.img + '.png';
            console.log(markerIcon.url);
            //alert(v.lid);
            var marker = new google.maps.Marker({
                position: {lat: v.lat, lng: v.lng},
                map: thatmap,
                url: v.url,
                title: 'Click for details',
                lid: v.lid,
                iwindow: $('#infowindow_' + v.lid).html(),
                icon: markerIcon
            });
        mapPins[v.lid] = marker;
        markersArr.push(marker);
        oms.addMarker(marker);
            // Add a click handler to the marker
            /*marker.addListener('click', function(){
                /*var infowindow = new google.maps.InfoWindow({
                        content: this.iwindow
                      });
                infowindow.open(thatmap, this);*/
           
            
                
                /*if($('#remote-map').attr('data-onMarkerClick') != undefined){
                    
                    var onMarkerClick = $('#remote-map').attr('data-onMarkerClick');
                    
                    if(onMarkerClick === 'infowindow'){
                        if(infowindow)
                            infowindow.close();
                        infowindow = new google.maps.InfoWindow({
                            content: this.iwindow
                          });
                          
                    infowindow.open(thatmap, this);
                    
                    }
                    else{
                        window.location.href = this.url;
                    }
                }
                else{
                    alert('Not exist');
                }
            });*/
            
            
            
        });
        //alert(mapPins.length);
        var iw = new google.maps.InfoWindow();
oms.addListener('click', function(marker, event) {
  iw.setContent($('#infowindow_' + marker.lid).html());
  iw.open(thatmap, marker);
});
        //alert(this.map.getZoom());   
            if(thatmap.getZoom() <= 19)
            {
                var style = [
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m1.png',
                        height: 53,
                        width: 52,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m2.png',
                        height: 56,
                        width: 55,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m3.png',
                        height: 66,
                        width: 65,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m4.png',
                        height: 78,
                        width: 77,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m5.png',
                        height: 90,
                        width: 89,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    }
                ]
                var markerCluster = new MarkerClusterer(thisMap, markersArr, {styles: style, maxZoom: 14});
                //alert(mapPins);
                // Set the function to handle display elements of clusters
                //markerCluster.setCalculator(clusterCalc);
            }
        
    }
    
    

}

    jQuery(document).ready(function($){
        // Only if we have markers do we consider mapping
        if(typeof markersSrc != 'undefined'){
            var hope = new MbxRemoteMap();
            hope.MapMarkers();

            $('.property_listing').on('mouseenter', function(){
                var id = $(this).attr('data-lid');
                var infowindow = new google.maps.InfoWindow({
                    content: $('#infowindow_' + id).html()
                  });
                infowindow.open(thisMap, mapPins[id]);
                
                $('.listing_wrapper').on('mouseenter', function(){
                    infowindow.close();
                })
            })
        }


    });


        function clusterCalc(markers, styles){
            var count = markers.length;
            var ndx;
            var text;
            if(count < 20)
            {
                ndx = 1;
            }
            else if(count < 100)
            {
                ndx = 2;
            }
            else
            {
                ndx = 3;
            }

            text = WPR.map.getZoom() > 11 ? count + '+' : '+';

            return {index: ndx, text: text, title: "Click to Zoom"};
        }