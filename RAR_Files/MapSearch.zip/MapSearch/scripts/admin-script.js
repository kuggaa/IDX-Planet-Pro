WPR.map;
WPR.MapSearch = WPR.MapSearch || {};
WPR.MapSearch.markerPrefix = 'default_';

function initMap() {
  var clat = typeof WPR.MapSearch.settings != 'undefined' && typeof WPR.MapSearch.settings['ctr-lat'] != 'undefined' ? WPR.MapSearch.settings['ctr-lat'] : '39.809734';
  var clng = typeof WPR.MapSearch.settings != 'undefined' && typeof WPR.MapSearch.settings['ctr-lng'] != undefined ? WPR.MapSearch.settings['ctr-lng'] : '-98.56';
  
  WPR.map = new google.maps.Map(document.getElementById('map-div'), {
    center: {lat: parseFloat(clat), lng: parseFloat(clng)},
    zoom:  typeof WPR.MapSearch.settings != 'undefined' && WPR.MapSearch.settings['zoom'] ? parseInt(WPR.MapSearch.settings['zoom']) : 4
  });
}

WPR.MapSearch = WPR.MapSearch || {};
WPR.MapSearch.PopulateMarkersAdmin = function(){
    $.getJSON(
        WPR.ajaxurl,
        {
            controller: "System",
            action: "GetTableFieldsFiltered",
            tablename: 'listingsdb'
        },
        function(data){
            $('#classField').html('');
            var doreturn = false;
            
            if(data !== null){
                $('#classField').append($('<option value="">Select Field</option>'));
                $('#specialMarkerField').append($('<option value="">Select Field</option>'));
                $.each(data.objectContents, function(i, val){
                    if(typeof WPR.MapSearch.settings != 'undefined' && typeof WPR.MapSearch.settings.classField != 'undefined' && WPR.MapSearch.settings.classField == val)
                    {
                        $('#classField').append($('<option selected="selected" value="' + val + '">' + val + '</option>'));
                        //$('#specialMarkerField').append($('<option selected="selected" value="' + val + '">' + val + '</option>'));
                        doreturn = true;
                    }
                    else if(typeof WPR.MapSearch.settings != 'undefined' && typeof WPR.MapSearch.settings.specialMarkerField != 'undefined' && WPR.MapSearch.settings.specialMarkerField == val)
                    {
                        //$('#classField').append($('<option selected="selected" value="' + val + '">' + val + '</option>'));
                        $('#specialMarkerField').append($('<option selected="selected" value="' + val + '">' + val + '</option>'));
                        doreturn = true;
                    }
                    else{
                        $('#classField').append($('<option value="' + val + '">' + val + '</option>'));
                    $('#specialMarkerField').append($('<option value="' + val + '">' + val + '</option>'));
                    }
                    
                });
            }
            else{
                $('#classField').append($('<option value="">No Values Found</option>'));
                $('#specialMarkerField').append($('<option value="">No Values Found</option>'));
            }
            
            $.uniform.update();
        }
    );
    //$('#markerTheme option[value="' + WPR.MapSearch.settings.MarkerTheme + '"]').attr('selected','selected');
}

WPR.MapSearch.SetPropTypeSelect = function(){
    var classField = WPR.MapSearch.settings.classField;
    var SpecialMarkerField = WPR.MapSearch.settings.specialMarkerField;
    WPR.GetDistinctList('listingsdb', classField, function(objectContents){
        $('#PropType').html('');
        $('#PropType').append('<option value="">Select Primary Type</option>');
        $('#PropType').append('<optgroup id="primary" label="Primary Markers"></optgroup>');
        if(!objectContents.length){
            $('#primary').append('<option value="">No Primary Types Found</option>');
            return;
        }
        
        //$('#primary').append('<option value="">Select Primary Type</option>');
        $.each(objectContents, function(i, val){
            $('#primary').append('<option value="' + val[0] + '">' + val[1] + '</option>');
        });
        
        WPR.GetDistinctList('listingsdb', SpecialMarkerField, function(objectContents){
            //$('#PropType').html('');
            $('#PropType').append('<optgroup id="special" label="Special Markers"></optgroup>');
            if(!objectContents.length){
                $('#special').append('<option value="">No Special Types Found</option>');
                return;
            }

            //$('#primary').append('<option value="">Select Primary Type</option>');
            $.each(objectContents, function(i, val){
                $('#special').append('<option value="' + val[0] + '">' + val[1] + '</option>');
            });


        });
    });
}

WPR.MapSearch.SetSingleMarkerAdmin = function(i, val){
    
}

WPR.MapSearch.DeleteCustomMarker = function(el){
    if(!confirm("Delete marker?\r\n")){
         return;       
    }
    
    $.getJSON(
        WPR.ajaxurl,
        {
            controller: "MapSearch",
            action: "DeleteCustomMarker",
            markerurl: $(el).attr('data-filetodelete')
        },
        function(data){
            $(el).parent().parent().remove();
        }
    );
}

WPR.MapSearch.LoadCurrentMarkers = function(){
    $.getJSON(
        WPR.ajaxurl,
        {
            controller: "MapSearch",
            action: "GetCustomMarkers"
        },
        function(data){
            $.each(data.objectContents.markers, function(i, marker){
                var newEl = $('#marker_row').clone();
                newEl.removeAttr('id');
                $(newEl).find('.caption-column').html(marker.display + ' Marker');
                var newFileName = marker.filename.substring(0, (marker.filename.length - 4));
                $(newEl).find('input[name="new_file_name"]').val(newFileName);
                $(newEl).find('.default_marker').attr('src', data.objectContents.baseurl + marker.filename);
                $(newEl).find('.marker-delete').attr('data-filetodelete', $(newEl).find('.default_marker').attr('src'));
                $('#custom_markers_list').append(newEl);
            })
        }
    );
}

WPR.MapSearch.PlaceNewMarkerAdmin = function(input){
    var newEl = $('#marker_row').clone();
    
    var raw_proptype = $('#PropType').val();
    var clean_proptype = raw_proptype.replace('_', ' ').replace(' ', '-').replace('/', '-');
    var newElStr = WPR.MapSearch.markerPrefix + clean_proptype + '_row';
    $(newEl).attr('id', newElStr);
    
    var unUnderscored = $('#PropType').val().replace('_', ' ');
    
    var markerDispName = unUnderscored.toLowerCase().replace(/\b[a-z]/g, function(letter) {
        return letter.toUpperCase();
    }) + ' Marker';
    
    $(newEl).find('.caption-column').html(markerDispName);
    
    $(newEl).find('input[name="new_file_name"]').val($('#new_marker_form').find('input[name="new_file_name"]').val());
    
    if(input.data.objectContents.indexOf('http') != -1){
        newEl.find('.default_marker').attr('src', input.data.objectContents);
        $('#custom_markers_list').prepend(newEl);
        // Now clear out the new marker form
        $('#new_marker_form')[0].reset();
        $.uniform.update();
        $('#new_marker_form').find('.filename').text('No file selected');
    }
    else{
        alert(input.data.objectContents);
    }
    
    
}

;(function($){
        $(document).ready(function(){
        //initMap();
        WPR.MapSearch = WPR.MapSearch || {};
        // The really cool part. Simply add the form field in the admin tpl and
        // WPR.[FeatureName].settings.[Setting] is there for you right after page load
        GetModuleConfig('MapSearch', populateForm);

        if($('MarkersContainer').length){

        }

        /*if(typeof WPR.MapSearch.settings.classField == 'undefined' || WPR.MapSearch.settings.classField == '')
            {
                $('#PropType').append('<option selected="selected" value="">Set Property Type Field</option>');
                $.uniform.update();
            }*/

        $('#Settings').on('MbxAdminFormLoaded', function(){        
            WPR.MapSearch.SetPropTypeSelect();
            WPR.SetupSelects();
        })

        $('.icon-form').on('submit', function(e){
            e.preventDefault();

            WPR.UploadFile(this, function(input){
                $(this).closest('.default_marker').attr('src', input.data.objectContents);
            })
        });

        $('#new_marker_form').on('submit', function(e){
            e.preventDefault();

            var raw_new_filename = WPR.MapSearch.markerPrefix + $('#PropType').val();
            var new_filename = WPR.encodeFileName(raw_new_filename);

            $(this).find('input[name="new_file_name"]').val(new_filename);

            WPR.UploadFile(this, WPR.MapSearch.PlaceNewMarkerAdmin);

        });

        WPR.MapSearch.LoadCurrentMarkers();

        $('#classField').change(function(){
            WPR.MapSearch.settings = WPR.MapSearch.settings || {};
            WPR.MapSearch.settings.classField = $('#classField').val(); // Just in case our ajax gets delayed

            saveConfig($('#UpdateConfig')); // This is where the Module name is stored
            WPR.MapSearch.LoadCurrentMarkers();
        })



        $('body').on('click', '.marker-delete', function(){
            //alert('delete clicked');
            WPR.MapSearch.DeleteCustomMarker(this);
        })

        $('#map-toggle').click(function(){

            if($('#map-toggle').text() == 'Use Map to Set Values'){
                $('#map-div-wrap').slideDown();
                setTimeout(function(){
                    initMap();
                    new google.maps.event.addListener( WPR.map , 'idle' , function(){
                        var center = WPR.map.getCenter();
                        var zoom = WPR.map.getZoom();
                        $('input[name="ctr-lat"]').val(center.lat);
                        $('input[name="ctr-lng"]').val(center.lng);
                        $('input[name="zoom"]').val(zoom);
                    });
                    $('#map-toggle').text('Hide Map');
                }, 500);
            }
            else{
                $('#map-div-wrap').slideUp();
                $('#map-toggle').text('Use Map to Set Values');
            }
        });

        if(window.location.href.indexOf('AdvSetup') != -1){
            WPR.MapSearch.PopulateMarkersAdmin();
        }
    });
})(WPR.jq);







