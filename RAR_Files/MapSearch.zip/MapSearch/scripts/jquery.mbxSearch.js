(function ( $ , window , undefined) {
    $.fn.mbxSearch = function(){
        WPR.mapDiv = this[0];
        WPR.map;
        WPR.isGeoSearch = 0;
        var markersArray = [];
        var markersArrayById = [];
        var markerCluster;
        WPR.preventRefresh = false;
        var preventRefreshPersist = false;
        WPR.infoWindowsCount = 0;
        WPR.infoWindows = [];
        WPR.listingOffset = 0;
        WPR.markerInfoWindows = []; // InfoWindows from map marker click - temporary
        var noBounce = 0;
        var infoWindowCloseTimer = 0;
        var hoverId = 0;
        var preventHover;
        
        var defaultMapSettings;
        


        function getMapBounds(){

            return {

                    sw_lat : WPR.map.getBounds().getSouthWest().lat(),

                    sw_lng : WPR.map.getBounds().getSouthWest().lng(),

                    ne_lat : WPR.map.getBounds().getNorthEast().lat(),

                    ne_lng : WPR.map.getBounds().getNorthEast().lng()

            };

        }
        
        function GetUserLocation(){
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                  var pos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                  };

                  //infoWindow.setPosition(pos);
                  //infoWindow.setContent('Location found.');
                  WPR.map.setCenter(pos);
                  //alert(pos.lat + ' | ' + pos.lng);
                },
                function() {
                    handleLocationError(true, new google.maps.InfoWindow({content: ''}), WPR.map.getCenter());
                });
            }
            else{
                // Browser doesn't support Geolocation
                handleLocationError(false, new google.maps.InfoWindow({content: ''}), WPR.map.getCenter());
            }
        }
        
        function handleLocationError(browserHasGeolocation, infoWindow, pos) {
            infoWindow.setPosition(pos);
            infoWindow.setContent(browserHasGeolocation ?
                                  'Error: The Geolocation service failed.' :
                                  'Error: Your browser doesn\'t support geolocation.');
        }
        
        
        
        window.getListings = function(operation, shape, shapeBounds){
            // Get the bounds of the viewable area
            //alert(operation);
            var bounds = getMapBounds();
            shape = shape || '';
            shapeBounds = shapeBounds || '';
            
            if(shape === 'polygon'){
                
            }
            
            // Searches based on this center of the viewable area
            var center = WPR.map.getCenter();
            var mapcenter = {};
            mapcenter.lat = center.lat();
            mapcenter.lon = center.lng();
            
            var formObj = formToObj('MapSearchForm');
            
            var autosettings = {
                sw__lat: operation === 'GetSamples' || operation === 'GetMarkersPoly' ? '' : bounds.sw_lat,
                sw__lng: operation === 'GetSamples' || operation === 'GetMarkersPoly' ? '' : bounds.sw_lng,
                ne__lat: operation === 'GetSamples' || operation === 'GetMarkersPoly' ? '' : bounds.ne_lat,
                ne__lng: operation === 'GetSamples' || operation === 'GetMarkersPoly' ? '' : bounds.ne_lng,
                controller: 'MapSearch',
                action: operation === undefined ? 'GetListings' : operation,
                mapcenter: mapcenter,
                limit: operation === 'GetSamples' ? 10 : operation === 'GetTemplatedListings' ? 25 : '',
                startat: WPR.listingOffset
            };
            ;
            // Merge the form values with the autosettings
            $.extend(formObj, autosettings);
            
            // Do the ajax request
            $.getJSON(WPR.ajaxurl,
            formObj,
            function(data){
                // This means listings as results
                //alert('hit');
                if(operation === 'GetListings')
                {
                    WPR.mbxSearch.listings = data.objectContents.results;
                    parseListings();
                }
                // This means listings as markers
                else if(operation === 'GetMarkers')
                {
                    WPR.mbxSearch.markers = data.objectContents.results;
                    if(WPR.mbxSearch.markers)
                        mapListings();
                    else{
                        toggleMapLoadingOverlay();
                    }
                }
                // This means listings as markers just a few for centering
                else if(operation === 'GetSamples')
                {
                    var samples = data.objectContents.results;
                    var count = samples.length;
                    //alert(count);
                    var latTotal = 0;
                    var latAvg = 0;
                    var lngTotal = 0;
                    var lngAvg = 0;
                    
                    // If results then find the center roughly and quickly
                    if(count)
                    {
                        var bounds = new google.maps.LatLngBounds();
                        //alert(JSON.stringify(bounds));
                        for(var i = 0; i < count; i++){
                            //alert('before');
                            var xyz = new google.maps.LatLng(parseFloat(samples[i].latitude), parseFloat(samples[i].longitude));
                            //bounds.extend({lat: parseFloat(samples[i].latitude), lng: parseFloat(samples[i].longitude)});
                            bounds.extend(xyz);
                            //alert('after');
                            latTotal = latTotal + parseFloat(samples[i].latitude);
                            lngTotal = lngTotal + parseFloat(samples[i].longitude);
                        }
                        
                        //alert(JSON.stringify(bounds));
                        
                        latAvg = latTotal / count;
                        
                        lngAvg = lngTotal / count;
                        //alert(JSON.stringify({lat: latAvg, lng: lngAvg}));
                        //WPR.map.setCenter({lat: latAvg, lng: lngAvg});
                        
                        WPR.map.fitBounds(bounds);
                        
                        toggleMapLoadingOverlay();
                        
                        getListings('GetTemplatedListings');
                        getListings('GetMarkers');
                    }
                    else{
                        //toggleMapLoadingOverlay();
                    }
                }
                // This means the results are templated listings from the server.
                else if(operation == 'GetTemplatedListings')
                {
                    WPR.mbxSearch.templatedListings = data.objectContents.templatedListings;
                    
                    insertListings();
                    noBounce = 0;
                    WPR.listingOffset = WPR.listingOffset + data.objectContents.templatedListings.length;
                }
            });
        };
        
        WPR.GetCircle = function(queryType, center, radMi){
            var formObj = formToObj('MapSearchForm');
            WPR.isPolySearch = true;
            WPR.preventRefresh = true;
            
            var querySettings = {
                controller: 'MapSearch',
                action: 'Get' + queryType + 'Circle',
                circle: [center.lat, center.lng, radMi]
            }
            
            $.extend(formObj, querySettings);
            $.getJSON(WPR.ajaxurl, formObj, function(data){
                //alert(JSON.stringify(myPoly));
                if(queryType === 'Markers'){
                    WPR.mbxSearch.markers = data.objectContents.results;
                    if(WPR.mbxSearch.markers)
                        mapListings();
                }
                else{
                    WPR.mbxSearch.templatedListings = data.objectContents.templatedListings;
                    
                    insertListings();
                    noBounce = 0;
                    WPR.listingOffset = WPR.listingOffset + data.objectContents.templatedListings.length;
                }
                
                
            });
        };
        
        /**
         * 
         * @param {type} queryType "Markers" or "Listings"
         * @param {type} bounds Raw.b from gmap
         */
        WPR.GetPolygon = function(queryType, bounds){
            var formObj = formToObj('MapSearchForm');
            var bounding = [];
            WPR.polygon = bounds;
            $.each(bounds, function(i, v){
                //alert(JSON.stringify(v));
                //var bound = [];
                //bound.push(parseFloat(v.lng));
                //bound.push(v.lat);
                var bound = [v.lng, v.lat].slice();
                //alert(JSON.stringify(bound[0]))
                bounding.push(bound);
            });
            WPR.isPolySearch = true;
            myPoly = JSON.parse(JSON.stringify(bounding));
            //alert(JSON.stringify(bounding[0]));
            WPR.preventRefresh = true;
            var querySettings = {
                controller: 'MapSearch',
                action: 'Get' + queryType + 'Poly',
                polygon: bounding
            }
            $.extend(formObj, querySettings);
            $.getJSON(WPR.ajaxurl, formObj, function(data){
                //alert(JSON.stringify(myPoly));
                if(queryType === 'Markers'){
                    WPR.mbxSearch.markers = data.objectContents.results;
                    if(WPR.mbxSearch.markers)
                        mapListings();
                }
                else{
                    WPR.mbxSearch.templatedListings = data.objectContents.templatedListings;
                    
                    insertListings();
                    noBounce = 0;
                    WPR.listingOffset = WPR.listingOffset + data.objectContents.templatedListings.length;
                }
                
                
            });
        }
        
        // Client side listings
        function getListingTemplate(){
            $.get(WPR.ajaxurl,
            {
                controller: 'MapSearch',
                action: 'GetListingTemplate'
            },
            function(data){
                //alert(data);
                var tplraw = $.parseJSON(data);
                sessionStorage.setItem('WPR.mbxSearch.template', tplraw.objectContents);
                //WPR.mbxSearch.template = tplraw.objectContents;
                //alert(WPR.mbxSearch.template);
                //alert(sessionStorage.getItem('WPR.mbxSearch.template'));
            });
        };
        
        function getFilterBox(){
            // Get the templated filter section from the server
            $.get(WPR.ajaxurl,
            {
                controller: 'MapSearch',
                action: 'GetFilterBox'
            },
            function(data){
                
                filterBoxRaw = $.parseJSON(data);
                
                // Set the contents
                $('#filter_box').html(filterBoxRaw.objectContents);
                
                // Make any server side generated lists for the selects and set the contents
                $('.dynamic_select').each(function(i, Element){
                    //alert($(Element).siblings('input').attr('name') + ' ul -> ' + $(Element).siblings('ul').attr('id'));
                    if($(Element).data('field').indexOf('mbx_') != -1){
                        var fieldname = $(Element).data('field').replace('mbx_', '');
                        var fieldKey = WPR.MapSearch.settings[fieldname];
                        
                        $(Element).siblings('input').attr('name', fieldKey);
                        $(Element).siblings('ul').attr('id', 'select_' + fieldKey);
                        makeSelectList(fieldKey);
                    }
                    else{
                        makeSelectList($(Element).data('field'));
                    }
                    
                });
                
            });
            
        };
        
        // Client side listings
        function parseListings(){
            $('#results_view').empty();
            $.each(WPR.mbxSearch.listings, function(i, v){
                var tpl = sessionStorage.getItem('WPR.mbxSearch.template');
                //alert(JSON.stringify(v));
                tpl = tpl.replace('{title}', v.title);
                tpl = tpl.replace('{city}', v.City);
                tpl = tpl.replace('{price}', v.Price);
                tpl = tpl.replace('{remarks}', v.Remarks);
                tpl = tpl.replace('{priceflag}', '');
                tpl = tpl.replace(/{mls}/g, v.MLS);
                var node = $.parseHTML(tpl);
                $('#results_view').prepend(node);
            });
        };
        
        function insertListings(){
            //alert('inserting');
            // Clear existing listings - gate for continuous scroll
            if(WPR.listingOffset === 0)
                $('#results_view').empty(); // Clear the results because this is a new search
            
            // Insert the templated listings - todo move to func
            $.each(WPR.mbxSearch.templatedListings, function(i, v){
                var node = $.parseHTML(v);
                $('#results_view').append(node);
            });
            
            // Attach click "go to details" handler to image overlay
            $('.listing-cover').on('click', function(){
                //alert($(this).data('lid'));
                var listingLink = $(this).parent().parent().data('link');
                window.location.href = listingLink;
            });
            
            var afterListingsInserted;
            if (navigator.appName == 'Microsoft Internet Explorer' || navigator.appName == 'Netscape'){
                afterListingsInserted = document.createEvent('CustomEvent');
                afterListingsInserted.initCustomEvent("MbxListingsInserted", true, true, {message: 'done'});
            }
            else{
                afterListingsInserted = new CustomEvent(
                    "MbxListingsInserted", 
                    {
                        detail: {
                                message: 'done'
                        },
                        bubbles: true,
                        cancelable: true
                    }
                );
            }
            
            document.getElementById('results_view').dispatchEvent(afterListingsInserted);
        }
        
        function mapListings(){
            // If there are visible clusters remove them
            if(typeof(markerCluster) === 'object')
                markerCluster.clearMarkers();
            
            // Remove any markers
            clearOverlays();
            
            // Set all the markers
            var count = 1;
            $.each(WPR.mbxSearch.markers, function(i, v){
                
                var markerfile = WPR.encodeFileName(v.classField);
                var markerIcon = {};
                markerIcon.url = WPR.MapSearch.markerUrl + 'default_' + markerfile + '.png';
                
                var myLatLng = {};
                myLatLng.lat = parseFloat(v.latitude);
                myLatLng.lng = parseFloat(v.longitude);
                setMarker(myLatLng, v.title, v.id, markerIcon);
            });
            
            
            // Enforce the highest zoom to cluster setting with a default fallback
            
            if(WPR.map.getZoom() <= WPR.MapSearch.settings['max-cluster-zoom'])
            {
                var style = [
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m1.png',
                        height: 53,
                        width: 52,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m2.png',
                        height: 56,
                        width: 55,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m3.png',
                        height: 66,
                        width: 65,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m4.png',
                        height: 78,
                        width: 77,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    },
                    {
                        url: WPR.MapSearch.markerUrl + 'clusters/m5.png',
                        height: 90,
                        width: 89,
                        anchor: [0, 0],
                        textColor: '#000',
                        textSize: 10
                    }
                ]
                markerCluster = new MarkerClusterer(WPR.map, markersArray, {styles: style});
                //alert(markerCluster);
                // Set the function to handle display elements of clusters
                markerCluster.setCalculator(clusterCalc);
            }
                
                toggleMapLoadingOverlay();
        }
        
        function clusterCalc(markers, styles){
            var count = markers.length;
            var ndx;
            var text;
            if(count < 20)
            {
                ndx = 1;
            }
            else if(count < 100)
            {
                ndx = 2;
            }
            else
            {
                ndx = 3;
            }

            text = WPR.map.getZoom() > 11 ? count + '+' : '+';

            return {index: ndx, text: text, title: "Click to Zoom"};
        }
        
        window.toggleMapLoadingOverlay = function(){
            if($('#map_modal').is(":visible")){
                $('#loading_msg').hide();
                $('#map_modal').hide();
            }
            else{
                $('#map_modal').show();
                var wrapH = $('#listing_map').height();
                var wrapW = $('#listing_map').width();
                var msgH = $('#loading_msg').height();
                var msgW = $('#loading_msg').width();
                
                var top = (Math.floor(wrapH / 2) - Math.floor(msgH / 2));
                var left = (Math.floor(wrapW / 2) - Math.floor(msgW / 2));
                $('#loading_msg').css('top', top);
                $('#loading_msg').css('left', left);
                $('#loading_msg').show();
            }
        }
        
        var infowindow = null;
        
        function setMarker(pos, title, id, markericon){
            // Create and place a single marker
            var marker = new google.maps.Marker({
                position: pos,
                map: WPR.map,
                icon: markericon,
                title: title + '\r\nClick for details'
            });
                                               
            // Add an click handler to populate and open the window
            marker.addListener('click', function() {
                // Close any open infowindow
                if (infowindow) {
                    infowindow.close();
                }
                // Create an InfoWindow for the marker with no content
                infowindow = new google.maps.InfoWindow({
                    content: ''
                });
                getInfoWindow(infowindow, marker, id);
                
            });
            
            // Push the marker onto the control array (for MarkerClusterer and to remove)
            markersArray.push(marker);
        }
        
        function getInfoWindow(infowindow, marker, id){
            // Stabilize the markers in case showing this moves the map
            WPR.preventRefresh = true;
            // Get the templated infowindow from the server
            $.get(WPR.ajaxurl,
            {
                controller: 'MapSearch',
                action: 'GetInfoWindow',
                listingid: id
            },
            function(data){
                var response = $.parseJSON(data);
                var infoWindowContents = response.objectContents;
                infowindow.setContent(infoWindowContents);
                infowindow.open(WPR.map, marker);
                // Increment the open window counter locking the markers
                WPR.infoWindowsCount++;
                
                // Decrement the window counter as it is closed
                google.maps.event.addListener(infowindow,'closeclick',function(){
                    WPR.infoWindowsCount--;
                });
            });
        }
        
        function clearOverlays() {
            for (var i = 0; i < markersArray.length; i++ ) {
                markersArray[i].setMap(null);
            }
            markersArray.length = 0;
        }
        
        function makeSelectList(fieldname){
            
            $.get(WPR.ajaxurl,
            {
                controller: 'MapSearch',
                action: 'GetDistinctValues',
                fieldname: fieldname
            },
            function(data){
                var obj = $.parseJSON(data);
                // Get the first list item - typically "all" option
                var firstItem = $('#select_' + fieldname + ' li:first-child');
                // Clear the ul
                $('#select_' + fieldname).html('');
                // Put the first item back
                $('#select_' + fieldname).append(firstItem);
                // Generate and insert the li options
                $.each(obj.objectContents.results, function(i, val){
                    tpl = '<li role="presentation" data-value="' + val[0] + '">' + val[1] + '</li>';
                    $('#select_' + fieldname).append($.parseHTML(tpl));
                });
            
            });
        }
        
        function SetupDrawing(){
            var drawingManager = new google.maps.drawing.DrawingManager({
                drawingControl: true,
                drawingControlOptions: {
                  position: google.maps.ControlPosition.LEFT_BOTTOM,
                  drawingModes: [
                    google.maps.drawing.OverlayType.POLYGON
                  ]
                },
                circleOptions: {
                  fillColor: '#ffff00',
                  fillOpacity: 1,
                  strokeWeight: 5,
                  clickable: false,
                  editable: true,
                  zIndex: 1
                },
                polygonOptions: {
                    editable: false
                }
              });
              drawingManager.setMap(WPR.map);
              
              google.maps.event.addListener(drawingManager, 'circlecomplete', function(circle){
                  var rad = circle.getRadius();
                  var radMi = rad / 1609;
                  var center = circle.getCenter();
                  WPR.map.fitBounds(circle.getBounds());
                  
                  drawingManager.setDrawingMode(null);
                  WPR.GetCircle('Markers', center, radMi);
                  WPR.GetCircle('Listings', center, radMi);
                  google.maps.event.addListener(drawingManager, "drawingmode_changed",function(){
                    circle.setMap(null);
                });
              });

              google.maps.event.addListener(drawingManager, 'rectanglecomplete', function(rect){
                 var bounds = [];
                  var rectBounds = JSON.parse(JSON.stringify(rect.bounds));
                  var westNorth = {lat: rectBounds.north, lng: rectBounds.west};
                  bounds.push(westNorth);
                  var eastNorth = {lat: rectBounds.north, lng: rectBounds.east};
                  bounds.push(eastNorth);
                  var eastSouth = {lat: rectBounds.south, lng: rectBounds.east};
                  bounds.push(eastSouth);
                  var westSouth = {lat: rectBounds.south, lng: rectBounds.west};
                  bounds.push(westSouth);
                  //alert(JSON.stringify(bounds));
                  WPR.map.fitBounds(rect.bounds);
                  
                  drawingManager.setDrawingMode(null);
                WPR.GetPolygon('Markers', bounds);
                WPR.GetPolygon('Listings', bounds);
                google.maps.event.addListener(drawingManager, "drawingmode_changed",function(){
                    rect.setMap(null);
                });
              });
              

              google.maps.event.addListener(drawingManager, 'polygoncomplete', function(poly) {
                  var pth = poly.getPath();
                  //alert(JSON.stringify(pth));
                 var bounds = new google.maps.LatLngBounds();
                 var b = JSON.parse(JSON.stringify(pth.b));
                 $.each(b, function(i, v){
                    var xyz = new google.maps.LatLng(parseFloat(v.lat), parseFloat(v.lng));
                    //alert(parseFloat(v.lat));
                    bounds.extend(xyz);
                 });
                 //alert(JSON.stringify(bounds));
                 WPR.map.fitBounds(bounds);
                 //}); 
                // Set the drawing mode back to the hand
                drawingManager.setDrawingMode(null);
                WPR.GetPolygon('Markers', pth.b);
                WPR.GetPolygon('Listings', pth.b);
                google.maps.event.addListener(drawingManager, "drawingmode_changed",function(){
                    poly.setMap(null);
                });

              });
        }
        
        $(document).ready(function(){
            // Get the search box
            //getFilterBox();
            GetModuleConfig('MapSearch', populateSettings);
            //getListingTemplate();
            //$('#google_map_prop_list_sidebar').bind('scroll', function(){ // results_view
            $('#results_view').bind('scroll', function(){ // results_view
                //alert('scroll');
                if(!noBounce){
                    if($(this).scrollTop() + $(this).innerHeight() >= ($(this)[0].scrollHeight - WPR.mbxSearch.continuousScrollLoadBuffer)){
                        noBounce = 1;
                        getListings('GetTemplatedListings');
                    }
                }
             });
             
             $('body').on('MbxSettingsLoaded', function(){
                 if(1){
                     SetupDrawing();
                 }
                 getFilterBox();
             })
             
            // Click handler for filter dropdowns
            $('body').on('click','.dropdown-menu li', function(e){
                    e.preventDefault();
                    //////////////////////////////////////////////////////////////////////////////
                    $.each(WPR.infoWindows, function(i, val){
                        val.close();
                    });
                    preventHover = true;
                    WPR.listingOffset = 0;
                    // Replace the dropdown selected item display div with the clicked item
                    //$(this).parent().siblings('input').val($(this).data('value'));
                    $(this).parent().siblings('input').attr("value", $(this).data('value'));
                    $(this).parent().siblings('div').html($(this).text() + ' <span class="caret caret_filter"></span>');
                    
                    // If this is the geo search item ------------------------------------------------------------------------------------- change
                    if($(this).parent().attr('id') === 'select_City')
                    {
                        // Gets a few random listings based on the current criteria and center the map on them
                        getListings('GetSamples');
                    }
                    else{
                        toggleMapLoadingOverlay();
                        
                        if(WPR.isPolySearch){
                            //alert(JSON.stringify(WPR.polygon));
                            WPR.GetPolygon('Markers', WPR.polygon);
                            WPR.GetPolygon('Listings', WPR.polygon);
                        }
                        else{
                            getListings('GetTemplatedListings');
                            getListings('GetMarkers');
                        }
                        
                    }
                    
                });
            
            // The zoom "-" map button
            $('body').on('click', '#gmapzoomminus', function(){
                WPR.listingOffset = 0;
                var zoom = WPR.map.getZoom();
                if(zoom > 1)
                    WPR.map.setZoom(zoom - 1);
            });
            
            // The zoom "+" map button
            $('body').on('click', '#gmapzoomplus', function(){
                WPR.listingOffset = 0; // Force a new clean search
                var zoom = WPR.map.getZoom();
                if(zoom < WPR.MapSearch.settings['max-zoom'] ? WPR.MapSearch.settings['max-zoom'] : 20)
                    WPR.map.setZoom(zoom + 1);
            });
            
            // The "My location" button
            $('body').on('click', '#geolocation-button', function(){
                GetUserLocation();
            });
            
            // The "View" button options
            $('body').on('click', '.map-type', function(e){
                e.preventDefault();
                
                $('.map-type').hide();
                if(this.id === 'map-view-roadmap')
                    WPR.map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
                else if(this.id === 'map-view-satellite')
                    WPR.map.setMapTypeId(google.maps.MapTypeId.SATELLITE);
                else if(this.id === 'map-view-hybrid')
                    WPR.map.setMapTypeId(google.maps.MapTypeId.HYBRID);
                else if(this.id === 'map-view-terrain')
                    WPR.map.setMapTypeId(google.maps.MapTypeId.TERRAIN);
            });
            
            // Attach click go to details handler to image overlay
            $('body').on('click', '.listing-cover', function(e){
                e.preventDefault();
                var listingLink = $(this).parent().parent().data('link');
                registerDetails(listingLink, e)
                
            });
            
            // The server-side map settings config needs implemented
            /*var mapSettings = $.extend(defaultMapSettings, WPR.mbxSearch.mapSettings);
        alert(JSON.stringify(defaultMapSettings));
            map = new google.maps.Map(mapDiv, mapSettings);
            new google.maps.event.addListener( map , 'idle' , function(){
                listingOffset = 0;
                if(preventRefresh && infoWindowsCount < 1){
                    preventRefresh = false;
                }
                else if(preventRefresh){
                    return true;
                }
                
                toggleMapLoadingOverlay();
                
                getListings('GetTemplatedListings');
                getListings('GetMarkers');
                
            }); */
            
            $('body').on('mouseenter', '.property_listing', function(){
                        if(preventHover){
                            preventHover = false;
                            return;
                        }
                        
                        var infowindow = new google.maps.InfoWindow({
                            content: ''
                        });
                        
                        var center = WPR.map.getCenter();
                        var mapcenter = {};
                        mapcenter.lat = center.lat();
                        mapcenter.lon = center.lng();
                        
                        // The listing id
                        var thisid = $(this).data('lid');
                        if(infoWindowCloseTimer)
                        {
                            if(hoverId !== thisid){
                                clearTimeout(infoWindowCloseTimer);
                                hoverId = thisid;
                                $.each(WPR.infoWindows, function(i, val){
                                    val.close();
                                });
                            }
                            else
                                return true;
                        }
                        //alert('h' + hoverId + ' this ' + thisid);
                        
                        
                        $.getJSON(WPR.ajaxurl,
                        {id: thisid, controller: "MapSearch", action: "GetMarkers", mapcenter: mapcenter} ,
                            function(data){
                                if(data.objectContents.results[0].latitude == 0) return;
                                
                                var markerfile = WPR.encodeFileName(data.objectContents.results[0].classField);
                                var markerIcon = {};
                                markerIcon.url = WPR.MapSearch.markerUrl + 'default_' + markerfile + '.png';
                                
                                setTimeout(function(){
                                    var marker = new google.maps.Marker({
                                    position: new google.maps.LatLng(data.objectContents.results[0].latitude, data.objectContents.results[0].longitude),
                                    map: WPR.map,
                                    icon: markerIcon,
                                    title: data.objectContents.results[0].title + '\r\nClick for details'
                                    });
                                    marker.addListener('click', function() {
                                        $.each(WPR.infoWindows, function(i, val){
                                            val.close();
                                        });
                                        getInfoWindow(infowindow, marker, thisid);

                                    });
                                    markersArray.push(marker);

                                    $('.property_listing').on('mouseout', function(e){
                                        infoWindowCloseTimer = setTimeout(function(){
                                        if($(e.relatedTarget).hasClass('listing_wrapper') || $(e.relatedTarget).attr('id') == 'filter_box')
                                        {
                                            infowindow.close();
                                            WPR.infoWindowsCount = 0;
                                            infoWindowCloseTimer = 0;
                                        }
                                            
                                            
                                            
                                        }, 1);
                                        
                                    });

                                    $.each(WPR.infoWindows, function(i, val){
                                        val.close();
                                    });
                                    WPR.infoWindowsCount = 0;
                                    WPR.infoWindows = [];

                                    getInfoWindow(infowindow, marker, thisid);
                                    WPR.infoWindows.push(infowindow);
                                }, 1);
                                
                            }    
                        );
                    
            });
            
        });
        
    };
})( jQuery, window, undefined );