=== seo-pressor ===
Contributors: Daniel Tan
Author URI: http://SEOPressor.com
Tags: seo,seopressor,keywords
Tested up to: 3.5
Requires at least: 3.4
Stable tag: trunk

Support center is at: http://www.askdanieltan.com/ask/

DISCLAIMER: THIS SITE AND THE PRODUCTS AND SERVICES OFFERED ON THIS SITE ARE NOT ASSOCIATED, AFFILIATED, ENDORSED, OR SPONSORED BY GOOGLE OR WORDPRESS, NOR HAVE THEY BEEN REVIEWED, TESTED OR CERTIFIED BY GOOGLE OR WORDPRESS.
