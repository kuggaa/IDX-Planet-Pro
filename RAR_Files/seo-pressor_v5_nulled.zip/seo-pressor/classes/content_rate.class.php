<?php
if (!class_exists('WPPostsRateKeys_ContentRate')) {
	class WPPostsRateKeys_ContentRate
	{
		/**
		 * Retrieve the list of Suggestions IDs per section
		 * 
		 * The sections are: decoration, url and content
		 * 
		 * @return 	array
		 */
		static function get_suggestions_per_sections() {
			return array(
				'decoration'=>array('msg_101','msg_102','msg_103','msg_104','msg_105','msg_106'
									,'msg_119','msg_120','msg_121','msg_122','msg_123','msg_124'
								)
				,'url'=>array('msg_112', 'msg_113','msg_114','msg_115','msg_130','msg_131','msg_132'
									,'msg_133','msg_134'
								)
				,'content'=>array('msg_107', 'msg_108', 'msg_109', 'msg_110', 'msg_111' 
									, 'msg_116', 'msg_117','msg_118'
									, 'msg_125', 'msg_126', 'msg_127', 'msg_128'
									, 'msg_129', 'msg_135', 'msg_136', 'msg_137'
									, 'msg_149', 'msg_150', 'msg_151', 'msg_152'
								)
			);
		}
		
		/**
		 * Retrieve the list of Suggestions for the Box
		 * 
		 * @return array
		 */
		static function get_suggestions_for_box() {
			return array(
					// Positives
					/* translators: <<N>> and <<(s)>> should be ignored when translate */
					'msg_101' => array(__('You have <<N>> keyword<<(s)>> in bold.','seo-pressor')
									,__('Keywords decorations are important. It tells search engines what your content is all about. Bold your keywords few times but do not overdo it.','seo-pressor')
							)
					, 'msg_102' => array(__('You have <<N>> keyword<<(s)>> in italic.','seo-pressor')
									,__('Keywords decorations are important. It tells search engines what your content is all about. Italize your keywords few times but do not overdo it.','seo-pressor')
							)
					, 'msg_103' => array(__('You have <<N>> keyword<<(s)>> in underline.','seo-pressor')
									,__('Keywords decorations are important. It tells search engines what your content is all about. Underline your keywords few times but do not overdo it.','seo-pressor')
							)
					, 'msg_104' => array(__('You have keyword in <<N>> H1 tag<<(s)>>.','seo-pressor')
									,__('Most themes have H1 tag on the title. If not, always make sure you have a H1 tag in your content. An example is: <h1>Your title here</h1>','seo-pressor')
							)
					, 'msg_105' => array(__('You have keyword in <<N>> H2 tag<<(s)>>.','seo-pressor')
									,__('You should always section your content with sub-headings. An example of the tag in HTML: <h2>Your sub-heading</h2>','seo-pressor')
							)
					, 'msg_106' => array(__('You have keyword in <<N>> H3 tag<<(s)>>.','seo-pressor')
									,__('You should always section your content with sub-headings. An example of the tag in HTML: <h3>Your sub-heading</h3>','seo-pressor')
							)
					, 'msg_107' => array(__('You have keyword in <<N>> image ALT<<(s)>>.','seo-pressor')
									,__("ALT tag describes what an image is about. It's good to have keyword in your image's ALT tag. An example in HTML: " . '"<img src="http://yoursite.com/image.jpg" ALT="YOUR KEYWORD" />"','seo-pressor')
							)
					, 'msg_108' => array(__('You have keyword in first 100 words.','seo-pressor')
									,''
							)
					, 'msg_109' => array(__('You have keyword in last 100 words.','seo-pressor')
									,''
							)
					, 'msg_110' => array(__('You have keyword in the first sentence.','seo-pressor')
									,''
							)
					, 'msg_111' => array(__('You have keyword in the last sentence.','seo-pressor')
									,''
							)
					, 'msg_112' => array(__('Keyword in anchor text of an internal link.','seo-pressor')
									,__('Add a link to your other pages within the same website using your keyword as the anchor text. An example in HTML: <a href="http://yoursite.com/anotherpage/" >YOUR KEYWORD</a>','seo-pressor')
							)
					, 'msg_113' => array(__('Keyword in anchor text of an external link.','seo-pressor')
									,__('Add a link to another reputable source of information with your keyword as the anchor text. An example in HTML: <a href="http://wikipedia.org/relatedtopic">YOUR KEYWORD</a>','seo-pressor')
							)
					, 'msg_114' => array(__('Keyword found in domain name.','seo-pressor')
									,__('Your domain name is found to contain your keyword which is a good boost to your scoring.','seo-pressor')
							)
					, 'msg_115' => array(__('Keyword found in Post/Page URL.','seo-pressor')
									,__('Your main keyword should always appear in the URL of this content.','seo-pressor')
							)
					, 'msg_116' => array(__('<<N>> LSI Keyword<<(s)>> found.','seo-pressor')
									,__('Using more LSI keywords will help you rank better. Click on the LSI tab to see what other words you should include in your content. Include the ones which are most relevant to your content.','seo-pressor')
							)
					, 'msg_117' => array(__('Keyword density is OK.','seo-pressor')
									,__('The best keyword density is between 2% to 4%. There is no rule on this. Having less than 2%, your content will most likely be unfocused. Having it higher than 4% will most probably make your content unreadable. Try to adjust accordingly, focus on pleasing the readers, not the search engine.','seo-pressor')
							)
					
					// Negatives
					, 'msg_118' => array(__('Increase the length of the content.','seo-pressor')
									,__('Longer content tends to rank better. The reason is that longer content is perceived to contain more useful information. Try to increase the length of your content and make sure they are useful to the readers and not fillers.','seo-pressor')
							)
					, 'msg_119' => array(__('You do not have keyword(s) in bold.','seo-pressor')
									,__('Keywords decorations are important. It tells search engines what your content is all about. Bold your keywords few times but do not overdo it.','seo-pressor')
							)
					, 'msg_120' => array(__('You do not have keyword(s) in italic.','seo-pressor')
									,__('Keywords decorations are important. It tells search engines what your content is all about. Italize your keywords few times but do not overdo it.','seo-pressor')
							)
					, 'msg_121' => array(__('You do not have keyword(s) in underline.','seo-pressor')
									,__('Keywords decorations are important. It tells search engines what your content is all about. Underline your keywords few times but do not overdo it.','seo-pressor')
							)
					, 'msg_122' => array(__('You do not have keyword in H1 tag.','seo-pressor')
									,__('Most themes have H1 tag on the title. If not, always make sure you have a H1 tag in your content. An example is: <h1>Your title here</h1>','seo-pressor')
							)
					, 'msg_123' => array(__('You do not have keyword in H2 tag.','seo-pressor')
									,__('You should always section your content with sub-headings. An example of the tag in HTML: <h2>Your sub-heading</h2>','seo-pressor')
							)
					, 'msg_124' => array(__('You do not have keyword in H3 tag.','seo-pressor')
									,__('You should always section your content with sub-headings. An example of the tag in HTML: <h3>Your sub-heading</h3>','seo-pressor')
							)
					, 'msg_125' => array(__('You do not have keyword in Image ALT tag.','seo-pressor')
									,__("ALT tag describes what an image is about. It's good to have keyword in your image's ALT tag. An example in HTML: " . '"<img src="http://yoursite.com/image.jpg" ALT="YOUR KEYWORD" />"','seo-pressor')
							)
					, 'msg_126' => array(__('Keyword not found in first 100 words.','seo-pressor')
									,''
							)
					, 'msg_127' => array(__('Keyword not found in last 100 words.','seo-pressor')
									,''
							)
					, 'msg_128' => array(__('Keyword not found in first sentence.','seo-pressor')
									,''
							)
					, 'msg_129' => array(__('Keyword not found in last sentence.','seo-pressor')
									,''
							)
					, 'msg_130' => array(__('Link pointing to an internal page not found.','seo-pressor')
									,__('Add a link to your other pages within the same website using your keyword as the anchor text. An example in HTML: <a href="http://yoursite.com/anotherpage/" >YOUR KEYWORD</a>','seo-pressor')
							)
					, 'msg_131' => array(__('Keyword not found in anchor text of internal link.','seo-pressor')
									,__('Add a link to your other pages within the same website using your keyword as the anchor text. An example in HTML: <a href="http://yoursite.com/anotherpage/" >YOUR KEYWORD</a>','seo-pressor')
							)
					, 'msg_132' => array(__('Link pointing to an external reputable source not found.','seo-pressor')
									,__('Add a link to another reputable source of information with your keyword as the anchor text. An example in HTML: <a href="http://wikipedia.org/relatedtopic">YOUR KEYWORD</a>','seo-pressor')
							)
					, 'msg_133' => array(__('keyword not found in anchor text of an external link.','seo-pressor')
									,__('Add a link to another reputable source of information with your keyword as the anchor text. An example in HTML: <a href="http://wikipedia.org/relatedtopic">YOUR KEYWORD</a>','seo-pressor')
							)
					, 'msg_134' => array(__('Keyword not found in Post/Page URL.','seo-pressor')
									,__('Your main keyword should always appear in the URL of this content.','seo-pressor')
							)
					, 'msg_135' => array(__('No LSI Keyword used.','seo-pressor')
									,__('Using more LSI keywords will help you rank better. Click on the LSI tab to see what other words you should include in your content. Include the ones which are most relevant to your content.','seo-pressor')
							)
					, 'msg_136' => array(__('Keyword density is high.','seo-pressor')
									,__('The best keyword density is between 2% to 4%. There is no rule on this. Having less than 2%, your content will most likely be unfocused. Having it higher than 4% will most probably make your content unreadable. Try to adjust accordingly, focus on pleasing the readers, not the search engine.','seo-pressor')
							)
					, 'msg_137' => array(__('Keyword density is too low.','seo-pressor')
									,__('The best keyword density is between 2% to 4%. There is no rule on this. Having less than 2%, your content will most likely be unfocused. Having it higher than 4% will most probably make your content unreadable. Try to adjust accordingly, focus on pleasing the readers, not the search engine.','seo-pressor')
							)
					
					// Related to meta values
					, 'msg_149' => array(__('Keyword is found in META Keyword.','seo-pressor')
									,''
							)
					, 'msg_150' => array(__('Keyword is found in META description.','seo-pressor')
									,''
							)
					, 'msg_151' => array(__('You need to have Keyword in Meta Keywords.','seo-pressor')
									,''
							)
					, 'msg_152' => array(__('You need to have Keywords in META Description.','seo-pressor')
									,''
							)
					
					// If not 100%, suggest: Get your 100% easily:
					, 'msg_138' => __('Use more LSI keywords.','seo-pressor')
					, 'msg_139' => __('Add more images with ALT tag.','seo-pressor')
					, 'msg_140' => __('Section your content using more headings.','seo-pressor')
					, 'msg_141' => __('Longer content ranks better.','seo-pressor')
					, 'msg_153' => __('You can target up to 3 keywords per content.','seo-pressor')
					
					// If more than 100%, suggest:
					, 'msg_142' => __('Your score may be too high, try to reduce to 100% by adjusting decorated keywords, keyword density and LSIs or increase your content length.','seo-pressor')
					
					// Over-Optimization Warning:
					, 'msg_143' => __('You are safe. No over-optimization is detected.','seo-pressor')
					, 'msg_144' => __('Keywords are bolded too many times.','seo-pressor')
					, 'msg_145' => __('Keywords are italized too many times.','seo-pressor')
					, 'msg_146' => __('Keywords are underlined too many times.','seo-pressor')
					, 'msg_147' => __('Keyword density is too high. Try replace some of your keywords with LSI keywords.','seo-pressor')
					, 'msg_148' => __('Too many LSI keywords are used.','seo-pressor')

					, 'msg_154' => __('Too many H1 tags contain your keyword.','seo-pressor')
					, 'msg_155' => __('Too many H2 tags contain your keyword.','seo-pressor')
					, 'msg_156' => __('Too many H3 tags contain your keyword.','seo-pressor')
					, 'msg_157' => __('Keyword appear in image ALTs too many times.','seo-pressor')
					, 'msg_158' => __('Keywords are used too many times as anchor text in links.','seo-pressor')
				);
		}
		
		
		static function get_post_whole_page_to_analyze($post_id,$settings,$post_permalink) {
			// For drafts (or pending) we return False to analyze only the Post Content
			if ($post_id!='' && get_post_status($post_id) == 'publish' && $settings['analize_full_page']=='1') {
				 
				// Add "internal_call" parameter to avoid recursive call
				if (substr_count($post_permalink, '?')>0) {
					$post_permalink .= '&internal_call=true';
				}
				else {
					$post_permalink .= '?internal_call=true';
				}
				 
				$response = wp_remote_get($post_permalink,array('timeout'=>WPPostsRateKeys::$timeout));
				 
				if (is_array($response)) { // Else, was an object(WP_Error) and the Post Content is used
					$whole_post_page = $response['body'];
					
					return $whole_post_page;
				}
			}
			
			return FALSE;
		}
		
        /**
         * Function to the get all the POST data
         * 
         * This return:
         *  the Scrore in percet
         *  the Suggestions for the page 
         *  and the Suggestion box data 
         * 
         * @param	int		$post_id
         * @param	array	$keyword_arr
         * @param	string	$content_to_analize			is the whole page content or the filtered content
         * @param	string	$filtered_title
         * @param	array	$settings
         * @param	string	$from_url
         * @param	string	$post_content_filtered		Only Post Content to Edit: used for first and last sentence detection
         * @return 	array
         * @static 
         */
        static function get_all_post_data($post_id,$keyword_arr,$new_content,$filtered_title
        									,$settings,$from_url,$post_content_filtered) {
        	$total_score = 0;
        	$box_suggestions = array('box_keyword_density'=>0,'box_suggestions_arr'=>array());
        	$special_suggestions_arr = array();
        	$box_suggestions_arr = array();
        	$keyword_density_pointer = 0;
        	
        	if ($keyword_arr[0]!='') { // Only checks if is some keyword defined
        		/*
        		 * Processing/Preparing Post Content
        		 * 
        		 * For example, when the Content is getted from Url, the WP returns the ' characters
        		 * as &#039; or &#8217;
        		 */
        		$new_content = str_replace('&#039;', "'", $new_content);
        		$new_content = str_replace('&#8217;', "'", $new_content);
        		// Removing Html
        		if (WPPostsRateKeys_Settings::support_multibyte()) {
        			$new_content = html_entity_decode($new_content,ENT_COMPAT,"UTF-8");
        			$post_content_filtered = html_entity_decode($post_content_filtered,ENT_COMPAT,"UTF-8");
        		}
        		
        		/*
        		 * Making general checks
        		 */
        		// Check for: Is the Keyword bold
	        	$keywords_bold = WPPostsRateKeys_HtmlStyles::how_many_keyword_bold($keyword_arr,$new_content);
	        	// Check for: Is the Keyword italized
	        	$keywords_italized = WPPostsRateKeys_HtmlStyles::how_many_keyword_italic($keyword_arr,$new_content);
	        	// Check for: Is the Keyword underlined
	        	$keywords_underlined = WPPostsRateKeys_HtmlStyles::how_many_keyword_underline($keyword_arr,$new_content);
	        	
	        	// Check for: Keyword Density Pointer
	        	$keyword_density_pointer = self::get_keyword_density_pointer($new_content, $keyword_arr);
	        	// Check for: Post Word Count
	        	$post_word_count = self::get_post_word_count($new_content);
	        	// Check for: Keyword in the Title
	        	$keyword_in_title = WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr,$filtered_title);
	        	// Check for: Keyword in H1 Tag
	        	$keyword_inside_some_h1 = 0;
	        	if ($settings['h1_tag_already_in_theme']==1 && $keyword_in_title) { // Check first if user set this as already done by theme and the keyword is in title
	        		$keyword_inside_some_h1++;
	        	}
	        	$keyword_inside_some_h1_html = self::how_many_keyword_inside_some_h($keyword_arr,$new_content,$filtered_title,'H1');
	        	// If is $from_url and we already count for setting+title, don't count it again 1 time if is detected in HTML
	        	if ($from_url && $keyword_inside_some_h1==1 && $keyword_inside_some_h1_html>0) {
	        		$keyword_inside_some_h1 += $keyword_inside_some_h1_html-1;
	        	}
	        	else {
	        		// Sum
	        		$keyword_inside_some_h1 += $keyword_inside_some_h1_html;
	        	}
	        	
	        	// Check for: Keyword in H2 Tag
	        	$keyword_inside_some_h2 = 0;
	        	if ($settings['h2_tag_already_in_theme']==1 && $keyword_in_title) { // Check first if user set this as already done by theme and the keyword is in title
	        		$keyword_inside_some_h2++;
	        	}
	        	$keyword_inside_some_h2_html = self::how_many_keyword_inside_some_h($keyword_arr,$new_content,$filtered_title,'H2');
	        	// If is $from_url and we already count for setting+title, don't count it again 1 time if is detected in HTML
	        	if ($from_url && $keyword_inside_some_h2==1 && $keyword_inside_some_h2_html>0) {
	        		$keyword_inside_some_h2 += $keyword_inside_some_h2_html-1;
	        	}
	        	else {
	        		// Sum
	        		$keyword_inside_some_h2 += $keyword_inside_some_h2_html;
	        	}
	        	
	        	// Check for: Keyword in H3 Tag
	        	$keyword_inside_some_h3 = 0;
	        	if ($settings['h3_tag_already_in_theme']==1 && $keyword_in_title) { // Check first if user set this as already done by theme and the keyword is in title
	        		$keyword_inside_some_h3++;
	        	}
	        	$keyword_inside_some_h3_html = self::how_many_keyword_inside_some_h($keyword_arr,$new_content,$filtered_title,'H3');
	        	// If is $from_url and we already count for setting+title, don't count it again 1 time if is detected in HTML
	        	if ($from_url && $keyword_inside_some_h3==1 && $keyword_inside_some_h3_html>0) {
	        		$keyword_inside_some_h3 += $keyword_inside_some_h3_html-1;
	        	}
	        	else {
	        		// Sum
	        		$keyword_inside_some_h3 += $keyword_inside_some_h3_html;
	        	}
	        	
	        	// Check for: Keyword in the First Sentence
	        	$keyword_in_first_sentence = self::keyword_in_first_sentence($keyword_arr,$post_content_filtered,$post_id);
	        	// Check for: Keyword in the Last Sentence
	        	$keyword_in_last_sentence = self::keyword_in_last_sentence($keyword_arr,$post_content_filtered,$post_id);
	        	// Check for: Image Alt Text has Keyword
	        	$how_many_image_alt_text_has_keyword = self::how_many_image_alt_text_has_keyword($keyword_arr,$new_content);
	        	// Check for: Link to Internal Pages with Keyword as Anchor Text
	        	$how_many_link_internal_as_anchor = self::how_many_link_internal_as_anchor($keyword_arr,$new_content);
	        	// Check if has internal link
	        	$has_link_internal = self::has_link_internal($new_content);
	        	// Check for: Link to External Pages with Keyword as Anchor Text
	        	$how_many_link_external_as_anchor = self::how_many_link_external_as_anchor($keyword_arr,$new_content);
	        	$has_link_external = self::link_external($new_content);
	        	// Check for Keyword in domain name
	        	$has_keyword_in_domain = self::has_keyword_in_domain($keyword_arr);
	        	// Check for Keyword in Post URL
	        	$has_keyword_in_post_url = self::has_keyword_in_post_url($keyword_arr,$post_id);
	        	// Keyword in the first 100 words
	        	$keyword_in_first_100_words = self::keyword_in_first_100_words($keyword_arr, $post_content_filtered);
	        	$keyword_in_last_100_words = self::keyword_in_last_100_words($keyword_arr, $post_content_filtered);
	        	// Check for the LSI keywords in use
	        	$lsi_keywords_in_use = self::how_many_lsi_keywords_in_use($post_id,$new_content,$keyword_arr);
	        	
	        	// Check for: Post have outgoing link to external sites with do-follow
	        	$link_external_do_follow = self::link_external_do_follow($new_content);
	        	
	        	// Check for Keyword in Meta-Keywords
	        	$how_many_key_in_meta_keywords = self::how_many_key_in_meta_keywords($keyword_arr,$new_content,$post_id);
	        	// Check for Keyword in Meta-Description
	        	$how_many_key_in_meta_description = self::how_many_key_in_meta_description($keyword_arr,$new_content,$post_id);
	        	
	        	/*
	        	 * Score calculations and Suggestions list
	        	 */
	        	
	        	// Word Count Adjustment
	        	if ($post_word_count<300) {
	        		$total_score -= 0.4;
	        		
	        		$box_suggestions_arr[] = array(0,'msg_118');
	        	}
	        	elseif ($post_word_count<=600) { // Include >=300
	        		$total_score += 0.04;
	        	}
	        	elseif ($post_word_count<=800) { // Include >=601
	        		$total_score += 0.05;
	        	}
	        	else { // Include >800
	        		$total_score += 0.07;
	        	}
	        	
	        	// Take in care if meta values are present
	        	if ($how_many_key_in_meta_keywords>0) {
	        		
	        		// Max 3 times
	        		if ($how_many_key_in_meta_keywords>3) {
	        			$how_many_key_in_meta_keywords = 3;
	        		}
	        		
	        		$total_score += $how_many_key_in_meta_keywords * 0.01;
	        		$box_suggestions_arr[] = array(1,'msg_149');
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_151');
	        	}
	        	
	        	if ($how_many_key_in_meta_description>0) {
	        		// Max 3 times
	        		if ($how_many_key_in_meta_description>3) {
	        			$how_many_key_in_meta_description = 3;
	        		}
	        		
	        		$total_score += $how_many_key_in_meta_description * 0.01;
	        		$box_suggestions_arr[] = array(1,'msg_150');
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_152');
	        	}
	        	
	        	// Every Keyword in Bold
	        	if ($keywords_bold>0) {
	        		// At least one Keyword in Bold
	        		if ($post_word_count<300) {
	        			$total_score += $keywords_bold * 0.02;
	        		}
	        		else {
	        			$total_score += $keywords_bold * 0.01;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_101',$keywords_bold);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_119');
	        	}
	        	
	        	// Every Keyword in Italic
        		if ($keywords_italized>0) {
	        		// At least one Keyword in Italic
	        		if ($post_word_count<300) {
	        			$total_score += $keywords_italized * 0.05;
	        		}
	        		elseif ($post_word_count<=600) {
	        			$total_score += $keywords_italized * 0.03;
	        		}
	        		else {
	        			$total_score += $keywords_italized * 0.02;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_102',$keywords_italized);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_120');
	        	}
	        	
	        	// Every Keyword in Underline
	        	if ($keywords_underlined>0) {
	        		// At least one Keyword in Underline
	        		if ($post_word_count<=600) {
	        			$total_score += $keywords_underlined * 0.03;
	        		}
	        		else {
	        			$total_score += $keywords_underlined * 0.02;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_103',$keywords_underlined);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_121');
	        	}
	        		
	        	// Keyword in H1
	        	if ($keyword_inside_some_h1>0) {
	        		if ($post_word_count<300) {
	        			$total_score += $keyword_inside_some_h1 * 0.03;
	        		}
	        		elseif ($post_word_count<=600) {
	        			$total_score += $keyword_inside_some_h1 * 0.05;
	        		}
	        		else {
	        			$total_score += $keyword_inside_some_h1 * 0.04;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_104',$keyword_inside_some_h1);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_122');
	        	}
	        	
        		// Keyword in H2
	        	if ($keyword_inside_some_h2>0) {
	        		if ($post_word_count<300) {
	        			$total_score += $keyword_inside_some_h2 * 0.08;
	        		}
	        		elseif ($post_word_count<=600) {
	        			$total_score += $keyword_inside_some_h2 * 0.06;
	        		}
	        		elseif ($post_word_count<=800) {
	        			$total_score += $keyword_inside_some_h2 * 0.05;
	        		}
	        		else {
	        			$total_score += $keyword_inside_some_h2 * 0.04;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_105',$keyword_inside_some_h2);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_123');
	        	}
	        	
	        	// Keyword in H3
	        	if ($keyword_inside_some_h3>0) {
	        		if ($post_word_count<300) {
	        			$total_score += $keyword_inside_some_h3 * 0.07;
	        		}
	        		elseif ($post_word_count<=600) {
	        			$total_score += $keyword_inside_some_h3 * 0.04;
	        		}
	        		else {
	        			$total_score += $keyword_inside_some_h3 * 0.03;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_106',$keyword_inside_some_h3);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_124');
	        	}
	        	
	        	// Keyword in Image ALT
	        	if ($how_many_image_alt_text_has_keyword>0) {
	        		if ($post_word_count<=800) {
	        			$total_score += $how_many_image_alt_text_has_keyword * 0.06;
	        		}
	        		else {
	        			$total_score += $how_many_image_alt_text_has_keyword * 0.05;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_107',$how_many_image_alt_text_has_keyword);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_125');
	        	}

	        	// Keyword in First 100 words
	        	if ($keyword_in_first_100_words) {
	        		$total_score += 0.03;
	        		
	        		$box_suggestions_arr[] = array(1,'msg_108');
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_126');
	        	}
	        	
	        	// Keyword in Last 100 words
	        	if ($keyword_in_last_100_words) {
	        		$total_score += 0.02;
	        		 
	        		$box_suggestions_arr[] = array(1,'msg_109');
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_127');
	        	}
	        	
	        	// Keyword in First sentence
	        	if ($keyword_in_first_sentence) {
	        		$total_score += 0.04;
	        	
	        		$box_suggestions_arr[] = array(1,'msg_110');
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_128');
	        	}
	        	
	        	// Keyword in Last sentence
	        	if ($keyword_in_last_sentence) {
	        		$total_score += 0.02;
	        	
	        		$box_suggestions_arr[] = array(1,'msg_111');
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_129');
	        	}
	        	
	        	// Keyword in Anchor Text to own pages
	        	if ($how_many_link_internal_as_anchor>0) {
	        		if ($post_word_count<300) {
	        			$total_score += $how_many_link_internal_as_anchor * 0.03;
	        		}
	        		elseif ($post_word_count<=800) {
	        			$total_score += $how_many_link_internal_as_anchor * 0.06;
	        		}
	        		else {
	        			$total_score += $how_many_link_internal_as_anchor * 0.05;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_112');
	        	}
	        	else {
	        		// Show negative message in depends if has internal link or not
	        		if ($has_link_internal) {
	        			$box_suggestions_arr[] = array(0,'msg_131');
	        		}
	        		else {
	        			$box_suggestions_arr[] = array(0,'msg_130');
	        		}	
	        	}
	        	
	        	// Keyword in Anchor Text to external pages
	        	if ($how_many_link_external_as_anchor>0) {
	        		if ($post_word_count<300) {
	        			$total_score += $how_many_link_external_as_anchor * 0.03;
	        		}
	        		elseif ($post_word_count<=600) {
	        			$total_score += $how_many_link_external_as_anchor * 0.04;
	        		}
	        		else {
	        			$total_score += $how_many_link_external_as_anchor * 0.03;
	        		}
	        		 
	        		$box_suggestions_arr[] = array(1,'msg_113');
	        	}
	        	else {
	        		// Show negative message in depends if has internal link or not
	        		if ($has_link_external) {
	        			$box_suggestions_arr[] = array(0,'msg_133');
	        		}
	        		else {
	        			$box_suggestions_arr[] = array(0,'msg_132');
	        		}
	        	}
	        	
	        	// Keyword in Domain name
	        	if ($has_keyword_in_domain) {
	        		if ($post_word_count<300) {
	        			$total_score += 0.12;
	        		}
	        		elseif ($post_word_count<=600) {
	        			$total_score += 0.1;
	        		}
	        		else {
	        			$total_score += 0.09;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_114');
	        	}
	        	
	        	// Keyword in Post/Page URL
	        	if ($has_keyword_in_post_url) {
	        		if ($post_word_count<=600) {
	        			$total_score += 0.1;
	        		}
	        		elseif ($post_word_count<=800) {
	        			$total_score += 0.09;
	        		}
	        		else {
	        			$total_score += 0.08;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_115');
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_134');
	        	}
	        	
	        	// Every LSI keyword used
	        	if ($lsi_keywords_in_use>0) {
	        		if ($post_word_count<300) {
	        			$total_score += $lsi_keywords_in_use * 0.04;
	        		}
	        		elseif ($post_word_count<=800) {
	        			$total_score += $lsi_keywords_in_use * 0.06;
	        		}
	        		else {
	        			$total_score += $lsi_keywords_in_use * 0.05;
	        		}
	        		
	        		$box_suggestions_arr[] = array(1,'msg_116',$lsi_keywords_in_use);
	        	}
	        	else {
	        		$box_suggestions_arr[] = array(0,'msg_135');	
	        	}
	        	
	        	// Every 1% of keyword density
	        	if ($keyword_density_pointer>0) {
	        		if ($post_word_count<300) {
	        			$total_score += $keyword_density_pointer * 0.04;
	        		}
	        		elseif ($post_word_count<=600) {
	        			$total_score += $keyword_density_pointer * 0.03;
	        		}
	        		else {
	        			$total_score += $keyword_density_pointer * 0.02;
	        		}
	        	}
	        	if ($keyword_density_pointer>=1 && $keyword_density_pointer<=4) {
	        		$box_suggestions_arr[] = array(1,'msg_117');
	        	}
	        	elseif ($keyword_density_pointer>4) {
	        		$box_suggestions_arr[] = array(0,'msg_136');
	        	}
	        	else { // < 1
	        		$box_suggestions_arr[] = array(0,'msg_137');
	        	}
	        	
	        	// Fill in $special_suggestions_arr the other three groups of suggestions
	        	$suggestions_score_less_than_100 = array();
	        	$suggestions_score_more_than_100 = array();
	        	$suggestions_score_over_optimization = array();
	        	
	        	// Show as a percent value
	        	$total_score = $total_score*100;	        	
	        	
	        	if ($total_score<100) {
	        		$suggestions_score_less_than_100 = array(
	        						'msg_153'
	        						,'msg_138'
	        						,'msg_139'
	        						,'msg_140'
	        					);
	        		if ($post_word_count<300) {
	        			$suggestions_score_less_than_100[] = 'msg_141';
	        		}
	        	}
	        	elseif ($total_score>100) { // If is 100 is all fine
	        		$suggestions_score_more_than_100 = array('msg_142');
	        		
	        		if ($keywords_bold>2) {
	        			$suggestions_score_over_optimization[] = 'msg_144';
	        		}
	        		if ($keywords_italized>2) {
	        			$suggestions_score_over_optimization[] = 'msg_145';
	        		}
	        		if ($keywords_underlined>2) {
	        			$suggestions_score_over_optimization[] = 'msg_146';
	        		}
	        		if ($keyword_density_pointer>4) {
	        			$suggestions_score_over_optimization[] = 'msg_147';
	        		}
	        		if ($lsi_keywords_in_use>6) {
	        			$suggestions_score_over_optimization[] = 'msg_148';
	        		}
	        		if ($keyword_inside_some_h1>2) {
	        			$suggestions_score_over_optimization[] = 'msg_154';
	        		}
	        		if ($keyword_inside_some_h2>2) {
	        			$suggestions_score_over_optimization[] = 'msg_155';
	        		}
	        		if ($keyword_inside_some_h3>3) {
	        			$suggestions_score_over_optimization[] = 'msg_156';
	        		}
	        		if ($how_many_image_alt_text_has_keyword>3) {
	        			$suggestions_score_over_optimization[] = 'msg_157';
	        		}
	        		if (($how_many_link_internal_as_anchor+$how_many_link_external_as_anchor)>5) {
	        			$suggestions_score_over_optimization[] = 'msg_158';
	        		}
	        	}
	        	
	        	if (count($suggestions_score_over_optimization)==0 && $total_score<=100) {
	        		$suggestions_score_over_optimization[] = 'msg_143';
	        		$over_optimization_flag = 'positive';
	        	}
	        	else {
	        		$over_optimization_flag = 'negative';
	        	}
	        	
	        	$special_suggestions_arr['score_less_than_100'] = $suggestions_score_less_than_100;
	        	$special_suggestions_arr['score_more_than_100'] = $suggestions_score_more_than_100;
	        	$special_suggestions_arr['score_over_optimization'] = array($over_optimization_flag,$suggestions_score_over_optimization);
        	}
        	
        	$box_suggestions = array('box_keyword_density'=>$keyword_density_pointer,'box_suggestions_arr'=>$box_suggestions_arr);
        	
        	return array($total_score, $box_suggestions, $special_suggestions_arr);
        }
        
        /**
         * Function to check if Keyword is found in Domain name
         *
         * @param 	array	$keyword_arr
         * @param	int		$post_id
         * @return 	bool
         * @static
         */
        static function has_keyword_in_post_url($keyword_arr,$post_id) {
        	$post_url = WPPostsRateKeys_WPPosts::get_permalink($post_id);
        	
        	$domain = parse_url($post_url,PHP_URL_HOST);
        	$post_url = str_replace($domain, '', $post_url); // Remove the domain from the Url to analize
        	
        	// Replace "-" for " ", adding the empty spaces to allow identify keyword phrases that are separated by "-"
        	$post_url = str_replace('-', ' ', $post_url);
        	
        	return WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr,$post_url);
        }
        
        /**
         * Function to check if Keyword is found in Domain name
         *
         * @param 	array	$keyword_arr
         * @return 	bool
         * @static
         */
        static function has_keyword_in_domain($keyword_arr) {
        	$wp_url = get_bloginfo('wpurl');
        	$wp_domain = parse_url($wp_url,PHP_URL_HOST);
        
        	return WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr,$wp_domain);
        }
        
        /**
         * Function to check how many: Link to External Pages with Keyword as Anchor Text
         *
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @return 	bool
         * @static
         */
        static function how_many_link_external_as_anchor($keyword_arr,$content) {
        	$wp_url = get_bloginfo('wpurl');
        
        	$wp_url_clean = str_replace('http://www.','',$wp_url);
        	$wp_url_clean = str_replace('https://www.','',$wp_url_clean);
        	$wp_url_clean = str_replace('https://','',$wp_url_clean);
        	$wp_url_clean = str_replace('http://','',$wp_url_clean);
        
        	// Go through all links tags and check if keyword in as anchor
        	$matches = array();
        	 
        	preg_match_all('/<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*)<\/a>/siU',$content,$matches);
        	 
        	// In $matches[0] stores the whole tag a, in $matches[1] stores the href URLs, in $matches[2] stores the texts used as anchors
        	$index = 0;
        	$to_return = 0;
        	foreach ($matches[1] as $url) {
        		$text = $matches[2][$index];
        
        		// Check if is external
        		$is_external = FALSE;
        
        		// Clean from http://www. and http:// and https://www. and https://
        		$url_clean = str_replace('http://www.','',$url);
        		$url_clean = str_replace('https://www.','',$url_clean);
        		$url_clean = str_replace('https://','',$url_clean);
        		$url_clean = str_replace('http://','',$url_clean);
        
        		if ((strpos($url,'http://')===0 || strpos($url,'https://')===0)
        				&& strpos($url_clean,$wp_url_clean)!==0
        				&& !self::endswith($url_clean, ".$wp_url_clean")) { // Url of code begins with https:// or http://
        			$is_external = TRUE;
        		}
        
        		// Check if is key
        		$has_key_in_text = FALSE;
        		if (WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr,$text))
        			$has_key_in_text = TRUE;
        
        		if ($is_external && $has_key_in_text) {
        			$to_return++;
        		}
        		 
        		$index++;
        	}
        	 
        	return $to_return;
        }
        
        /**
         * Function to check if: Link to External Pages with Keyword as Anchor Text
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @return 	bool
         * @static 
         */
        static function link_external($content) {
        	$wp_url = get_bloginfo('wpurl');
        		
        	$wp_url_clean = str_replace('http://www.','',$wp_url);
        	$wp_url_clean = str_replace('https://www.','',$wp_url_clean);
        	$wp_url_clean = str_replace('https://','',$wp_url_clean);
        	$wp_url_clean = str_replace('http://','',$wp_url_clean);
        		
			// Go through all links tags and check if keyword in as anchor
        	$matches = array();
        	
        	preg_match_all('/<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*)<\/a>/siU',$content,$matches);
        	
        	// In $matches[0] stores the whole tag a, in $matches[1] stores the href URLs, in $matches[2] stores the texts used as anchors
        	$index = 0;
        	foreach ($matches[1] as $url) {
        		$text = $matches[2][$index];
        		
        		// Check if is external
        		$is_external = FALSE;
        		
        		// Clean from http://www. and http:// and https://www. and https://
        		$url_clean = str_replace('http://www.','',$url);
        		$url_clean = str_replace('https://www.','',$url_clean);
        		$url_clean = str_replace('https://','',$url_clean);
        		$url_clean = str_replace('http://','',$url_clean);
        		
        		if ((strpos($url,'http://')===0 || strpos($url,'https://')===0) 
        			&& strpos($url_clean,$wp_url_clean)!==0
        			&& !self::endswith($url_clean, ".$wp_url_clean")) { // Url of code begins with https:// or http://
        			$is_external = TRUE;
        		}
        		
        		if ($is_external)
        			return TRUE;
        			
        		$index++;
        	}
        	
			return FALSE;
        }
        
		/**
		 * Check if string ends with some letters
		 * 
		 * Check if $string ends with $ends_to_test
		 * 
		 * @param 	string $string
		 * @param 	string $ends_to_test
		 * @return	string
		 */
		static private function endswith($string, $ends_to_test) {
			if (WPPostsRateKeys_Settings::support_multibyte()) {
				$strlen = mb_strlen($string,'UTF-8');
				$testlen = mb_strlen($ends_to_test,'UTF-8');
			}
			else {
				$strlen = strlen($string);
			    $testlen = strlen($ends_to_test);
			}
		    
		    if ($testlen > $strlen) return false;
		    return substr_compare($string, $ends_to_test, -$testlen) === 0;
		}
        
	    /**
         * Check for meta keywords
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$new_content	Can be the whole page or the filtered Content (for Posts not publised)
         * @return 	bool
         * @static 
         */
        static function how_many_key_in_meta_keywords($keyword_arr,$new_content,$post_id) {
        	
        	$how_many = 0;
        	
        	// Check if has the SEOPressor setting
        	if (WPPostsRateKeys_WPPosts::get_allow_meta_keyword($post_id)=='1') {
        		// Check if category/tags aren't empty and match
        		$use_for = WPPostsRateKeys_WPPosts::get_use_for_meta_keyword($post_id);
        		if ($use_for=='tags') {
        			// Check if some keyword in tags
        			$post_tags = wp_get_post_tags($post_id, array( 'fields' => 'names' ));
        			foreach ($post_tags as $post_tags_name) {
        				foreach ($keyword_arr as $keyword_arr_item) {
        					if ($post_tags_name==$keyword_arr_item) {
        						$how_many++;
        					}
        				}
        			}
        		}
        		elseif ($use_for=='categories') {
        			// Check if some keyword in categories
        			$post_categories = wp_get_post_categories($post_id, array( 'fields' => 'names' ));
        			foreach ($post_categories as $post_categories_name) {
        				foreach ($keyword_arr as $keyword_arr_item) {
        					if ($post_categories_name==$keyword_arr_item) {
        						$how_many++;
        					}
        				}
        			}
        		}
        		else {
        			// Is used the same keywords, so count the ones that aren't empty
        			$keyword_arr = array_filter($keyword_arr);
					
        			$how_many = count($keyword_arr);
        		}
        	}
        	else {
	        	// Check content
	        	$doc = new DOMDocument();
	        	
	        	if (WPPostsRateKeys_Settings::support_multibyte()) {
	        		$new_content = mb_convert_encoding($new_content, 'HTML-ENTITIES', 'UTF-8');
	        	}
		        
	        	@$doc->loadHTML($new_content);
	        	
	        	$metas = $doc->getElementsByTagName('meta');
	        	for ($i = 0; $i < $metas->length; $i++) {
	        		$meta = $metas->item($i);
	        		if($meta->getAttribute('name') == 'keywords')
	        			$keywords = $meta->getAttribute('content');
	        	}
	        	
	        	$some_in_meta_key = FALSE;
	        	if (isset($keywords)) {
	        		// Some meta keyword specified
	        		$how_many = WPPostsRateKeys_Keywords::how_many_keywords($keyword_arr, $keywords);
	        	}
        	}
        	
        	return $how_many;
        }
        
	    /**
         * Check for meta description
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$new_content	Can be the whole page or the filtered Content (for Posts not publised)
         * @return 	bool
         * @static 
         */
        static function how_many_key_in_meta_description($keyword_arr,$new_content,$post_id) {
        	
        	$how_many = 0;
        	
        	// Check if has the SEOPressor setting
        	if (WPPostsRateKeys_WPPosts::get_allow_meta_description($post_id)=='1') {
        		// Check if custom meta description isn't empty and has the keyword
        		$cutom_meta_desc = WPPostsRateKeys_WPPosts::get_meta_description($post_id);
        		
        		$how_many = WPPostsRateKeys_Keywords::how_many_keywords($keyword_arr, $cutom_meta_desc);
        	}
        	else {
	        	$doc = new DOMDocument();
        	
        		if (WPPostsRateKeys_Settings::support_multibyte()) {
	        		$new_content = mb_convert_encoding($new_content, 'HTML-ENTITIES', 'UTF-8');
	        	}
		        
	        	@$doc->loadHTML($new_content);
	        	 
	        	$metas = $doc->getElementsByTagName('meta');
	        	for ($i = 0; $i < $metas->length; $i++) {
	        		$meta = $metas->item($i);
	        		if($meta->getAttribute('name') == 'description')
	        			$description = $meta->getAttribute('content');
	        	}
	        	
	        	$some_in_meta_desc = FALSE;
	        	if (isset($description)) {
	        		// Some meta description specified
	        		$how_many = WPPostsRateKeys_Keywords::how_many_keywords($keyword_arr, $description);
	        	}
        	}
        	
        	return $how_many;
        }
        
	    /**
         * Function to check if: Link to Internal Pages
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @return 	bool
         * @static 
         */
        static function has_link_internal($content) {
        	$wp_url = get_bloginfo('wpurl');
        	
        	$wp_url_clean = str_replace('http://www.','',$wp_url);
        	$wp_url_clean = str_replace('https://www.','',$wp_url_clean);
        	$wp_url_clean = str_replace('https://','',$wp_url_clean);
        	$wp_url_clean = str_replace('http://','',$wp_url_clean);
        	
       		 // Go through all links tags and check if keyword in as anchor
        	$matches = array();
        	
        	preg_match_all('/<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*)<\/a>/siU',$content,$matches);
        	
        	// In $matches[0] stores the whole tag a, in $matches[1] stores the href URLs, in $matches[2] stores the texts used as anchors
        	$index = 0;
        	foreach ($matches[1] as $url) {
        		$text = $matches[2][$index];
        		
        		// Check if is external
        		$is_internal = FALSE;
        		
        		// Clean from http://www. and http:// and https://www. and https://
        		$url_clean = str_replace('http://www.','',$url);
        		$url_clean = str_replace('https://www.','',$url_clean);
        		$url_clean = str_replace('https://','',$url_clean);
        		$url_clean = str_replace('http://','',$url_clean);
        		
        		if ((strpos($url,'http://')!==0 && strpos($url,'https://')!==0 && strpos($url,'mailto:')!==0) 
        			|| self::endswith($url_clean, ".$wp_url_clean") || strpos($url_clean,$wp_url_clean)===0) {
        			return TRUE;
        		}
        		
        		$index++;
        	}
        	
			return FALSE;
        }
        
	    /**
         * Function to check how many: Link to Internal Pages with Keyword as Anchor Text
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @return 	int
         * @static 
         */
        static function how_many_link_internal_as_anchor($keyword_arr,$content) {
        	$wp_url = get_bloginfo('wpurl');
        	
        	$wp_url_clean = str_replace('http://www.','',$wp_url);
        	$wp_url_clean = str_replace('https://www.','',$wp_url_clean);
        	$wp_url_clean = str_replace('https://','',$wp_url_clean);
        	$wp_url_clean = str_replace('http://','',$wp_url_clean);
        	
			// Go through all links tags and check if keyword in as anchor
        	$matches = array();
        	
        	preg_match_all('/<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*)<\/a>/siU',$content,$matches);
        	
        	// In $matches[0] stores the whole tag a, in $matches[1] stores the href URLs, in $matches[2] stores the texts used as anchors
        	$index = 0;
        	$to_return = 0;
        	foreach ($matches[1] as $url) {
        		$text = $matches[2][$index];
        		
        		// Check if is external
        		$is_internal = FALSE;
        		
        		// Clean from http://www. and http:// and https://www. and https://
        		$url_clean = str_replace('http://www.','',$url);
        		$url_clean = str_replace('https://www.','',$url_clean);
        		$url_clean = str_replace('https://','',$url_clean);
        		$url_clean = str_replace('http://','',$url_clean);
        		 
        		if ((strpos($url,'http://')!==0 && strpos($url,'https://')!==0 && strpos($url,'mailto:')!==0) 
        			|| self::endswith($url_clean, ".$wp_url_clean") 
        			|| strpos($url_clean,$wp_url_clean)===0) {
        			$is_internal = TRUE;
        		}
        		
        		// Check if is key
        		$has_key_in_text = FALSE;
        		if (WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr,$text)) {
        			$has_key_in_text = TRUE;
        		}
        		
        		if ($is_internal && $has_key_in_text) {
        			$to_return++;
        		}
        		
        		$index++;
        	}
        	
			return $to_return;
        }
        
	    /**
         * Function to check if: Post have outgoing link to external sites with do-follow
         * 
         * @param 	string	$keyword
         * @param 	string	$content
         * @return 	bool
         * @static 
         */
        static function link_external_do_follow($content) {
        	$wp_url = get_bloginfo('wpurl');
        	
        	$wp_url_clean = str_replace('http://www.','',$wp_url);
        	$wp_url_clean = str_replace('https://www.','',$wp_url_clean);
        	$wp_url_clean = str_replace('https://','',$wp_url_clean);
        	$wp_url_clean = str_replace('http://','',$wp_url_clean);
			
			// Go through all links tags and check if is external with do follow
        	$matches = array();
        	
        	preg_match_all('/<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*)<\/a>/siU',$content,$matches);
        	
        	// In $matches[0] stores the whole tag a, in $matches[1] stores the href URLs
        	$index = 0;
        	foreach ($matches[0] as $tags) {
        		$url = $matches[1][$index];
        		if ($url && trim($url)!='') { // This check is because are problems when a Url is dentified but not as part of a link but as an image
	        		// Check if is external
	        		$is_external = FALSE;
	        		
	        		// Clean from http://www. and http:// and https://www. and https://
	        		$url_clean = str_replace('http://www.','',$url);
	        		$url_clean = str_replace('https://www.','',$url_clean);
	        		$url_clean = str_replace('https://','',$url_clean);
	        		$url_clean = str_replace('http://','',$url_clean);
	        		
	        		if ((strpos($url,'http://')===0 || strpos($url,'https://')===0) 
	        			&& strpos($url_clean,$wp_url_clean)!==0
	        			&& !self::endswith($url_clean, ".$wp_url_clean")) { // Url of code begins with https:// or http://
	        			$is_external = TRUE;
	        		}
	        		
	        		// Check if is do follow
	        		$is_dofollow = FALSE;
	        		if (WPPostsRateKeys_Settings::support_multibyte()) {
	        			if (mb_substr_count($tags,'rel="nofollow"','UTF-8')==0
	        					&& mb_substr_count($tags,'rel=nofollow','UTF-8')==0
	        					&& mb_substr_count($tags,'rel="no follow"','UTF-8')==0
	        			) {
	        				$is_dofollow = TRUE;
	        			}
	        		}
	        		else {
	        			if (substr_count($tags,'rel="nofollow"')==0
		        			&& substr_count($tags,'rel=nofollow')==0
		        			&& substr_count($tags,'rel="no follow"')==0
		        			) {
		        			$is_dofollow = TRUE;
		        		}
	        		}
	        		
	        		if ($is_external && $is_dofollow)
	        			return TRUE;
        		}
        		$index++;
        	}
        	
			return FALSE;
        }
        
	    /**
         * Function to return the amount of: Image Alt Text has Keyword
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @return 	bool
         * @static 
         */
        static function how_many_image_alt_text_has_keyword($keyword_arr,$content) {
			// Go through all images tags and check if has alt text and has keyword
        	$matches = array();
        	/*
        	 * http://www.the-art-of-web.com/php/parse-links/
        	 * 
        	 * starts with: <img
        	 * any series of characters NOT containing the > symbol
        	 * alt=
        	 * a series of characters up to, but not including, the next double-quote (") - 1st capture
        	 * any series of characters NOT containing the > symbol
        	 * the string: ">
        	 * 
        	 * modifiers:
        	 * i - matches are 'caseless' (upper or lower case doesn't matter)
        	 * U - matches are 'ungreedy'
        	 * 
        	 */
        	preg_match_all('/<img\s[^>]*alt=\"([^\"]*)\"[^>]*>/siU',$content,$matches);
        	
        	// In $matches[0] stores the whole match, in $matches[1] stores the alt texts
        	$to_return = 0;
	        foreach ($matches[1] as $an_alt_text) {
	        	if (WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr,$an_alt_text)) {
	        		$to_return++;
	        	}
			}
			
			return $to_return;
        }
        
	    /**
         * Function to check if: Keyword in the Last Sentence
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @param 	int		$post_id				used to check if user declare this explicity
         * @return 	bool
         * @static 
         */
        static function keyword_in_last_sentence($keyword_arr,$content,$post_id) {
        	
        	/*
        	 * First check if user declare this explicity
        	 * Automatic detected by plugin (default) and if checkbox of Keyword is present is checked
        	 * override plugin detection
        	 */
        	
        	/*
        	 * First check if user declare this explicity
        	*/
        	$post_allow_keyword_overriding = WPPostsRateKeys_WPPosts::get_allow_keyword_overriding_in_sentences($post_id);
        	if ($post_allow_keyword_overriding==='1') { // This mean that user wants to use the value he set
        		$post_keyword_last_sentence = WPPostsRateKeys_WPPosts::setting_key_last_sentence($post_id);
        		if ($post_keyword_last_sentence==='1') {
        			return TRUE;
        		}
        		else {
        			return FALSE;
        		}
        	}
        	 
        	/*
        	 * If isn't specified by user: check in Post Content
        	*/
        	
        	$content_no_html = self::strip_html_tags($content);
        	
        	// Trim blank spaces
        	$content_no_html = trim($content_no_html);
        	
        	$pieces = WPPostsRateKeys_Keywords::get_pieces_by_keyword($keyword_arr,$content_no_html);
        	
        	if (count($pieces)>0) {
        		$last_piece = $pieces[count($pieces)-1];
        		
        		// Improved v5: Remove new lines, empty spaces and html tags
        		$last_piece = str_replace("&nbsp;",' ',$last_piece);
        		$last_piece = str_replace(' ',' ',$last_piece); // Seems different from previous line, but for PHP-string isn't
        		
        		// Remove the last dot ! or ? if is in the last of the sentence, because is irrelevant
        		$last_piece = trim($last_piece);
        		$last_piece = rtrim($last_piece,'.'); // Don't remove if is a previous dot
        		$last_piece = rtrim($last_piece,'?'); // Don't remove if is a previous dot
        		$last_piece = rtrim($last_piece,'!'); // Don't remove if is a previous dot
        		
        		// Add empty space at the begining to avoid fail when the puctuation mark was the next 
        		// character to the keyword, example: keyword? other text
        		$last_piece = ' ' . $last_piece;
        		
        		// Check latest piece for a punctuation mark
        		preg_match('/\A(.+?)[.?!]( |\r|\n)/s', $last_piece, $matches);
        		$count = count($matches);
        		
        		// If in the last piece is a dot (with space to void a number match like $12.50): but if I do this and the sentence has an html tag will fails, so no blank space
        		if ($count>0)
        			return FALSE;
        		else 
        			return TRUE;
        	}
        	
        	return FALSE;
        }
        
		/**
		 * Get the first sentence in a text
		 * 
		 * Take in care that the end characters must be followed by:
		 * - an space
		 * - a return
		 * - a new line
		 * The HTML is stripped by the callers of this function 
		 * 
		 * @param 	string 	$string will not containd HTML
		 * @return	string
		 */
		static function get_first_sentence($string) {
			
			preg_match('/\A(.+?)[.?!]( |\r|\n)/s', $string, $matches);
		    if (count($matches)>0) {
		    	return $matches[0];
		    }
			else {
				return $string;
			}
		}

		/**
		 * Function to check if: Keyword in the First 100 words
		 *
		 * @param 	array	$keyword_arr
		 * @param 	string	$content
		 *
		 * @return 	bool
		 * @static
		 */
		static function keyword_in_first_100_words($keyword_arr,$content) {
			 
			/*
			 * If isn't: check in Post Content
			*/
			$content_no_html = self::strip_html_tags($content);
			$content_no_html_arr = explode(' ', $content_no_html);
			$content_no_html_first_100_words_arr = array_slice($content_no_html_arr, 0, 100); // The first 100 words
			$content_no_html_first_100_words = implode(' ', $content_no_html_first_100_words_arr);
			
			return WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr, $content_no_html_first_100_words);
		}
		
		/**
		 * Remove HTML tags, including invisible text such as style and
		 * script code, and embedded objects.  Add line breaks around
		 * block-level tags to prevent word joining after tag removal.
		 */
		static function strip_html_tags( $text )
		{
			$text = str_replace('<?php', 'mphpB', $text);
			$text = str_replace( '?>', 'mphpE',$text);
			
			$text = preg_replace(
					array(
							// Remove invisible content
							'@<head[^>]*?>.*?</head>@siu',
							'@<style[^>]*?>.*?</style>@siu',
							'@<script[^>]*?.*?</script>@siu',
							'@<object[^>]*?.*?</object>@siu',
							'@<embed[^>]*?.*?</embed>@siu',
							'@<applet[^>]*?.*?</applet>@siu',
							'@<noframes[^>]*?.*?</noframes>@siu',
							'@<noscript[^>]*?.*?</noscript>@siu',
							'@<noembed[^>]*?.*?</noembed>@siu',
							// Add line breaks before and after blocks
							'@</?((address)|(blockquote)|(center)|(del))@iu',
							'@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
							'@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
							'@</?((table)|(th)|(td)|(caption))@iu',
							'@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
							'@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
							'@</?((frameset)|(frame)|(iframe))@iu',
					),
					array(
							' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
							"\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
							"\n\$0", "\n\$0",
					),
					$text );
			return strip_tags( $text );
		}
		
		/**
		 * Function to check how_many_lsi_keywords_in_use
		 *
		 * @param 	int		$post_id
		 * @param 	string	$content
		 * @param 	array	$keyword_arr
		 *
		 * @return 	int
		 * @static
		 */
		static function how_many_lsi_keywords_in_use($post_id,$content,$keyword_arr) {
			
			$lsi_keywords = array();
			// Get all the lsi keyword for all the keywords defined by user
			foreach ($keyword_arr as $keyword_arr_item) {
				$lsi_keywords = array_merge($lsi_keywords, WPPostsRateKeys_LSI::get_lsi_by_keyword($keyword_arr_item));
			}
			$lsi_keywords_keys = array();
			foreach ($lsi_keywords as $lsi_keywords_item) {
				$lsi_keywords_keys[] = $lsi_keywords_item['lsi'];
			}
			
			// Before use the content, strip the tags
			$content = self::strip_html_tags($content);
			
			$to_return = 0;
			foreach ($lsi_keywords_keys as $tmp_keyword) {
				if (WPPostsRateKeys_Keywords::keyword_in_content(array($tmp_keyword), $content)) {
					$to_return++;
				}
			}
			
			return $to_return;
		}
		
		/**
		 * Function to check if: Keyword in the Last 100 words
		 *
		 * @param 	array	$keyword_arr
		 * @param 	string	$content
		 *
		 * @return 	bool
		 * @static
		 */
		static function keyword_in_last_100_words($keyword_arr,$content) {
		
			/*
			 * If isn't: check in Post Content
			*/
			$content_no_html = self::strip_html_tags($content);
			$content_no_html_arr = explode(' ', $content_no_html);
			
			// Only get the slice of the array if they are more than 100 items
			$count = count($content_no_html_arr);
			if ($count>100) {
				$begin_in = $count-100;
				$content_no_html_last_100_words_arr = array_slice($content_no_html_arr, $begin_in);
				$content_no_html_last_100_words = implode(' ', $content_no_html_last_100_words_arr);
			}
			else {
				// Get all the words
				$content_no_html_last_100_words = implode(' ', $content_no_html_arr);
			}
			
			return WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr, $content_no_html_last_100_words);
		}
		
		/**
         * Function to check if: Keyword in the First Sentence
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @param 	int		$post_id	used to check if user declare this explicity
         * 
         * @return 	bool
         * @static 
         */
        static function keyword_in_first_sentence($keyword_arr,$content,$post_id) {
        	
        	/*
        	 * First check if user declare this explicity
        	 */
        	$post_allow_keyword_overriding = WPPostsRateKeys_WPPosts::get_allow_keyword_overriding_in_sentences($post_id);
        	if ($post_allow_keyword_overriding==='1') { // This mean that user wants to use the value he set
        		$post_keyword_first_sentence = WPPostsRateKeys_WPPosts::setting_key_first_sentence($post_id);
        		if ($post_keyword_first_sentence==='1') {
        			return TRUE;
        		}
        		else {
        			return FALSE;
        		}
        	}
        	
        	/*
        	 * If isn't specified by user: check in Post Content
        	 */
        	$content_no_html = self::strip_html_tags($content);
        	$first_sentence = self::get_first_sentence($content_no_html);
        	
        	if (WPPostsRateKeys_Keywords::keyword_in_content($keyword_arr, $first_sentence)) {
        		return TRUE;
        	}
			
			return FALSE;
        }
        
	    /**
         * Function to check if is a keyword inside a H<some> tag
         * 
         * @param 	array	$keyword_arr
         * @param 	string	$content
         * @param 	string	$title
         * @param 	string	$h			can be H1, H2 or H3
         * @return 	int
         * @static 
         */
        static function how_many_keyword_inside_some_h($keyword_arr,$content,$title,$h) {
        	
        	// Set the array of styles that define the current check
        	$arrays_to_check = WPPostsRateKeys_HtmlStyles::get_h_styles($h);
        	
        	// Check in title and content, for that join both before analysis
        	$title_content = $title . ' ' . $content;
        	
        	$pieces = WPPostsRateKeys_Keywords::get_pieces_by_keyword($keyword_arr,$title_content);
        	
        	// Checks for each piece of code, is needed the total
        	$to_return = 0;
        	
        	for ($i=0;$i<(count($pieces)-1);$i++) {
        		
        		$result = WPPostsRateKeys_HtmlStyles::if_some_style_in_pieces($pieces, $i, $arrays_to_check, $keyword_arr);
        		if ($result && strpos($result[1],'H')===0) {
        			$to_return++;
        		}
        	}
        	
        	return $to_return;
        }
        
	    private function sanitize_words($string) {
        	preg_match_all("/\p{L}[\p{L}\p{Mn}\p{Pd}'\x{2019}]*/u",$string,$matches,PREG_PATTERN_ORDER);
        	return $matches[0];
        }
        
	    /**
         * Function to the get the: Post Word Count
         * 
         * @param 	string	$new_content	the content to search in (after changes made by our filter)
         * @return 	int
         * @static 
         */
        static function get_post_word_count($new_content) {
        	// Remove tags html to not be counted as words
        	$content_no_html = self::strip_html_tags($new_content);
        	
        	return count(self::sanitize_words($content_no_html));// Done to suport Greek
        	
        	// How many words
        	$how_many_words = str_word_count($content_no_html);
        	
        	return $how_many_words;
        }
        
        
        
	    /**
         * Function to the get the: Keyword Density Pointer
         * 
         * @param 	string	$new_content	the content to search in (after changes made by our filter)
         * @param 	array	$keyword_arr
         * @return 	double					return the percent of keywords in the text
         * @static 
         */
        static function get_keyword_density_pointer($new_content, $keyword_arr) {
        	
        	// Remove tags html to not be counted as words or keywords
        	$content_no_html = self::strip_html_tags($new_content);
        	$content_no_html = str_replace("&nbsp;",' ',$content_no_html);
        	
        	// How many words: this method allow don't fails when keyword is a phrase
        	$post_content_no_keywords = $content_no_html;
        	$post_content_no_keywords = WPPostsRateKeys_Keywords::delete_keywords($keyword_arr, $post_content_no_keywords);
			
        	$how_many_words = self::get_post_word_count($post_content_no_keywords);
        	
        	// How many times is the key in content
        	$how_many_keys = WPPostsRateKeys_Keywords::how_many_keywords($keyword_arr, $content_no_html);
        	
        	// Update keyword count: this allow don't fails when keyword is a phrase
        	$how_many_words += $how_many_keys;
        	
        	if ($how_many_words>0)
        		$percent = $how_many_keys * 100 / $how_many_words;
        	else
        		$percent = 0;
        	
        	return $percent;
        }
	}
}