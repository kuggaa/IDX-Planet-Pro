// Prevent name collisions wrapping the code in an anonymous function.
jQuery( function($) {
	/*
	 * Global behavior.
	 */
	/*
	 * Make Support Menu link to open in another tab.
	 */
	$('#toplevel_page_seo-pressor a[href="admin.php?page=seopressor-support"]').attr('target','_blank');

	/*
	 * Actions menu.
	 */
	$('.actions-menu-button').live('click',function(){
		$(this).next().show();
	});
});