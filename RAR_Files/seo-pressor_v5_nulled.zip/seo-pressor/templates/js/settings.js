// Prevent name collisions wrapping the code in an anonymous function.
jQuery( function($) {
	/*
	 * Settings Page behaviour.
	 */
	/*
	 * Tabs. Horizontal Tabs.
	 */
	$('.seopressor-tabs','.seopressor-page').tabs({
		collapsible: false,
		cookie: {
			expires: 7
		}
	});

	/*
	 * Buttons.
	 */
	$('.seopressor-button').button();

	/*
	 * Tabs. Vertical Tabs.
	 */
	$('.seopressor-tabs-second-lvl','.seopressor-page').tabs({
		collapsible: false,
		cookie: {
			expires: 7
		}
	}).addClass('ui-tabs-vertical ui-helper-clearfix');

	$('.seopressor-tabs-second-lvl','.seopressor-page').removeClass('ui-corner-top').addClass('ui-corner-left');

	/*
	 * Uniform fields.
	 */
	$('[type="radio"]','.seopressor-page').uniform();

	/*
	 * Checkboxes.
	 */
	$('[type="checkbox"]').iCheckbox({
		switch_container_src: WPPostsRateKeys.plugin_url + 'templates/js/lib/iCheckbox/images/switch-frame.png',
		class_container: 'seopressor-checkbox-switcher-container',
		class_switch: 'seopressor-checkbox-switch',
		class_checkbox: 'seopressor-checkbox-checkbox',
		switch_speed: 100,
		switch_swing: -13
	});

	/*
	 * Dropdowns.
	 */
	$('select','.seopressor-page').chosen();

	/*
	 * Handler for  seopressor-show-files button.
	 */
	$('button#seopressor-show-files').click(function() {
		$('#seopressor-file-list-wrapper').toggle();
		$('button#seopressor-show-files .ui-icon').toggleClass('ui-icon-plus ui-icon-minus');
	});

	/*
	 * Ajax Form Declaration.
	 */
	$('.seopressor-ajax-form').ajaxForm({
		beforeSubmit: function(form_data_arr, form$, options) {
			/*
			 * Used to disable the button and show the loader.
			 */
			$('.seopressor-submit-tr img, .seopressor-submit-div img', form$).show();
			$('.seopressor-button,.seopressor-submit-tr button[type="submit"], .seopressor-submit-div button[type="submit"]', form$).button('disable');
		},
		dataType: 'json',
		error: function(a, b, c){
			/*
			 * Don't show the message in case that the user cancel the query.'
			 */
			if (c) {
				// Get selected tab in main tabset for reduce the selectors scope.
				var selected_tab$ = $('.ui-tabs-panel').not('.ui-tabs-hide');

				/*
				 * Remove ajax loader and disable button.
				 */
				$('.seopressor-submit-tr img, .seopressor-submit-div img', selected_tab$).hide();
				$('.seopressor-button,.seopressor-submit-tr button[type="submit"], .seopressor-submit-div button[type="submit"]', selected_tab$).button('enable');

				// Clear message dashboard.
				$('#seopressor-message-container').html('');

				$('#seopressor-templates-container .seopressor-error-message .seopressor-msg-mark').html(b + ': '+ c);
				$('#seopressor-templates-container .seopressor-error-message').clone().appendTo('#seopressor-message-container');

				$('.seopressor-error-message').effect('highlight', {
					color: '#FF655D'
				}, 2000, function(){
				});
				$('.seopressor-notification-message').effect('highlight', {
					color: '#BDD1B5'
				}, 2000, function(){
				});

				$.scrollTo(0, 800, {
					easing:'swing'
				});
			}
		},
		success: function(response_from_server, statusText, xhr, form$){
			/*
			 * Remove ajax loader and show button.
			 */
			$('.seopressor-submit-tr img, .seopressor-submit-div img', form$).hide();
			$('.seopressor-button,.seopressor-submit-tr button[type="submit"], .seopressor-submit-div button[type="submit"]', form$).button('enable');

			// Clear message dashboard.
			$('#seopressor-message-container').html('');

			if (response_from_server.type == 'notification') {
				/*
				 * Show server message to user.
				 */
				$('#seopressor-templates-container .seopressor-notification-message .seopressor-msg-mark').html(response_from_server.message);
				$('#seopressor-templates-container .seopressor-notification-message').clone().appendTo('#seopressor-message-container');
			}
			else if (response_from_server.type == 'error') {
				/*
				 * Show server message to user.
				 */
				$('#seopressor-templates-container .seopressor-error-message .seopressor-msg-mark').html(response_from_server.message);
				$('#seopressor-templates-container .seopressor-error-message').clone().appendTo('#seopressor-message-container');
			}

			$('.seopressor-error-message').effect('highlight', {
				color: '#FF655D'
			}, 2000, function(){
			});
			$('.seopressor-notification-message').effect('highlight', {
				color: '#BDD1B5'
			}, 2000, function(){
			});

			$.scrollTo(0, 800, {
				easing:'swing'
			});
		},
		type: 'POST',
		url: WPPostsRateKeys.plugin_url + 'pages/ajax/update_settings.php'
	});

	/*
	 * Wizards.
	 */
	$("a[rel^='prettyPhoto']").prettyPhoto({
		overlay_gallery: false,
		social_tools: false
	});

	api_images = [
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/1.jpg',
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/2.jpg',
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/3.jpg',
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/4.jpg',
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/5.jpg',
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/6.jpg',
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/7.jpg',
		WPPostsRateKeys.plugin_url + 'templates/images/bing-api-steps/8.jpg'
	];
	api_titles = [
		'<strong>Step 1:</strong> Go to the Bing Search API page at <a target="_blank" href="https://datamarket.azure.com/dataset/5BA839F1-12CE-4CCE-BF57-A49D98D29A44" title="Windows Azure Marketplace">Windows Azure Marketplace</a>.',
		'<strong>Step 2:</strong> Select the free service of 5,000 transactions/month. This is enough for most users.',
		'<strong>Step 3:</strong> Accept the Terms and Privacy Policy and Sign Up.',
		'<strong>Step 4:</strong> The go to your accounts page at the Bing API page.',
		'<strong>Step 5:</strong> Go to the Accounts Keys page.',
		'<strong>Step 6:</strong> Add and new account and click Save.',
		'<strong>Step 7:</strong> Copy the generated key.',
		'<strong>Step 8:</strong> Paste the generated key into Bing API Key field in SEOPressor and Save Settings.'
	];
	api_descriptions = [
		'',
		'',
		'',
		'',
		'',
		'',
		'',
		''
	];

	$('#seopressor-bing-api-get-api-keys-steps-button').click(function(){
		$.prettyPhoto.open(api_images, api_titles, api_descriptions);
	});
});