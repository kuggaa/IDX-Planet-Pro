<?php
/** Commercial Codebase by WP Realty Development Team.* Copyright - WP Realty - 2009 - 2012 - All Rights Reserved* License: http://wprealty.org/faq/license/*/
header('Access-Control-Allow-Origin: *');
session_start();error_reporting(E_ALL^E_NOTICE);
global $config;
require_once('config.php');
$file = $_GET['f'];
$url = $config['wpradmin_basepath']."ajax/".$file;
require_once($url);?>