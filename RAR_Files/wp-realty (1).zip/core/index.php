<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
session_start();
ob_start();
error_reporting(E_ALL^E_NOTICE);
ini_set("display_errors", 0);
if(file_exists('config.php'))
{
global $dbClass,$config,$blog_id;
require_once("config.php");
require_once($config['wpradmin_basepath']."include/core/core.inc.php");
$page = new Page();
echo $page->IndexController();
}
ob_flush();
?>