jQuery(document).ready(function(){
        
    jQuery.get(WPR.ajaxurl,
        {
            controller: 'System',
            action: 'GetAdminMenuLinks'
        },
        function(data){
            var dataObj = JSON.parse(data);
            jQuery.each(dataObj.objectContents, function(i, item){
                el = '<li><a href="' + item['href'] + '"><img src="' + item['icon'] + '"/>' + item['text'] + '</a></li>';
                jQuery('#' + item['menu'] + '-menu').append(jQuery(el));
            });
        });
});


