jQuery(document).ready(function($) 
                    {
            
            $(".alertinfo").click(function()
            {
                var href = $(this).attr("href");
                var name = $(this).attr("name");
                jConfirm(name, "", function(r) {
                    if(r==true)
                    {
                        location.href=href;
                    }
                });
                
            });
            
            
            
            });