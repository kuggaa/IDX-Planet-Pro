document.write('<script src="js/uniform/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>');
document.write('<script src="js/livevalidation/livevalidation_standalone.js" type="text/javascript" charset="utf-8"></script>');
document.write('<script src="js/tipsy/jquery.tipsy.js" type="text/javascript" charset="utf-8"></script>');
document.write('<script type="text/javascript" src="js/iPhone/jquery.iphoneui.js"></script>');
document.write('<script type="text/javascript" src="js/uitotop/js/jquery.ui.totop.js"></script>');