jQuery(document).ready(function() {	
jQuery('.auto_suggest .suggestions').fadeOut();
jQuery(".auto_suggest input[type=text]")
.blur(function(){
jQuery('.suggestions', jQuery(this).parents('.auto_suggest')).fadeOut();
})
.keyup(function() {
var val = jQuery(this).val();
var holder = jQuery(this).parents('.auto_suggest');
if(val.length > 1) {
jQuery.post(autosuggest.ajaxurl, {action: 'wpr_autosuggest', attr: jQuery(this).data('attr'), keywords: ""+val+""}, function(data) {
jQuery('.suggestions', holder).html(data);
jQuery('.suggestions', holder).fadeIn();
});
}
else 
{
jQuery('.suggestions', holder).fadeOut();
}
});
});