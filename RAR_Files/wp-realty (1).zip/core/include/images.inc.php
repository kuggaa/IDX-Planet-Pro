<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class ImagesClass {
var $effects_tab = array('blindX', 'blindY', 'blindZ', 'cover', 'curtainX', 'curtainY', 'fade', 'fadeZoom', 'growX', 'growY', 'scrollUp', 'scrollDown', 'scrollLeft', 'scrollRight', 'scrollHorz', 'scrollVer', 'shuffle', 'slideX', 'slideY', 'toss', 'turnUp', 'turnDown', 'turnLeft', 'turnRight', 'uncover', 'wipe', 'zoom');
private $_t_img_url_base;
private $_t_img_count;
function image_url_exists($url, $remote = false) {
return true;
$handle = curl_init($url);
if (false === $handle) {
return false;
}
curl_setopt($handle, CURLOPT_HEADER, false);
curl_setopt($handle, CURLOPT_FAILONERROR, true); // this works
curl_setopt($handle, CURLOPT_HTTPHEADER, Array(
"User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.15) Gecko/20080623 Firefox/2.0.0.15"
)); // request as if Firefox
curl_setopt($handle, CURLOPT_NOBODY, false);
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
$connectable = curl_exec($handle);
curl_close($handle);
if (!$connectable || $connectable == 'Photo Not Found')
return false;
if ($remote)
$this->ImagesCache($connectable, $url);
return true;
}
function image_exists($url) {
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_NOBODY, true);
curl_exec($ch);
$retcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
// $retcode >= 400 -> not found, $retcode = 200, found.
curl_close($ch);
return $retcode == 200 ? TRUE : FALSE;
}
function DoTorontoImgCount($maxcount, $params) {
//var_dump($params);
for ($t = 1; $t <= $maxcount; $t++) {
$params['num'] = $t;
$file = $this->QuickReplace($params);
if ($this->image_exists($file)) {
$this->_t_img_count = $t;
} else {
return $this->_t_img_count;
}
//echo $this->_t_img_count.'<br>';
}
return $this->_t_img_count;
/* $mid = (($maxcount - $this->_t_img_count) - 1) / 2;// Sets up initial lookup
$spread = $maxcount - $mid;
if($spread <= 3)
{
for($i = $this->_t_img_count; $i < $maxcount; $i++)
{
$params['num'] = $i;
$file = $this->QuickReplace($params);
if($this->image_url_exists($file))
{
$this->_t_img_count = $i;
}
else
{
return $this->_t_img_count;
}
}
}
else
{
$params['num'] = $mid;
//$file = $this->QuickReplace($params);
if($this->image_url_exists($this->QuickReplace($params)))
{
$this->_t_img_count = $mid;
$this->DoTorontoImgCount($maxcount);
}
else
{
$this->DoTorontoImgCount($mid);
}
} */
}
/*     * **********************************************************\
* Image Caching Feature For Remote Images
\*********************************************************** */
function ImagesCache($content_file, $url) {
global $config, $dbClass;
if ($config['images_cache_bool'] !== false) {
$sql = "SELECT * FROM " . $config['table_prefix'] . "images_cache WHERE path='" . $url . "'";
$reImage = $dbClass->query($sql);
if ($reImage->RecordCount() > 0) {
$last_check_min = time() - (($config['images_cache_time'] + 1) * 3600 * 24);
if ($reImage->fields['last_check'] == "" OR $reImage->fields['last_check'] < $last_check_min) {
$sql = "UPDATE " . $config['table_prefix'] . "images_cache SET last_check='" . time() . "' WHERE id='" . $reImage->fields['id'] . "'";
if ($dbClass->query($sql)) {
$f_image = fopen($config['basepath'] . $config['img_dir'] . "/cache_images/" . $reImage->fields['filename'], "w");
fwrite($f_image, $content_file);
fclose($f_image);
}
}
} else {
$sql = "INSERT INTO " . $config['table_prefix'] . "images_cache SET path='" . $url . "',last_check='" . time() . "'";
if ($dbClass->query($sql)) {
$id = $dbClass->LastID();
$ext_tab = explode(".", $url);
$ext = $ext_tab[count($ext_tab) - 1];
$filename = 'images_cache_' . $id . "." . $ext;
$sql = "UPDATE " . $config['table_prefix'] . "images_cache SET filename='" . $filename . "' WHERE id='" . $id . "'";
$dbClass->query($sql);
$f_image = fopen($config['basepath'] . $config['img_dir'] . "/cache_images/" . $filename, "w");
fwrite($f_image, $content_file);
fclose($f_image);
}
}
}
}
function ChooseOptionUrlExists($url) {
global $config, $dbClass;
if ($config['images_cache_bool'] == 1 AND $config['remote_checkphoto_bool'] == 1) {
$sql = "SELECT * FROM " . $config['table_prefix'] . "images_cache WHERE path='" . $url . "'";
$reImage = $dbClass->query($sql);
if ($reImage->RecordCount() > 0) {
$last_check_min = time() - (($config['images_cache_time'] + 1) * 3600 * 24);
if ($reImage->fields['last_check'] == "" OR $reImage->fields['last_check'] < $last_check_min OR $reImage->fields['filename'] == "") {
if ($this->image_url_exists($url, true)) {
return $url;
} else {
return $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
}
} else {
return $config['wpr_baseurl'] . $config['img_dir'] . "/cache_images/" . $reImage->fields['filename'];
}
} else {
if ($this->image_url_exists($url, true)) {
return $url;
} else
return false;
}
}
return $url;
}
/************************************************************\
* Functions for generating the Upload Image Form and Creating
* Image Files and Directories.
\*********************************************************** */
function GenerateUploadImagesForm($count = 5, $edit_id, $submit_name, $tab, $action_url, $mode = 0) {
global $dbClass, $formsClass, $presentationClass, $UrlClass, $jqueryscript;
$content = $formsClass->startform('', array(
'enctype' => 'multipart/form-data',
'id' => 'listingimage_upload_form'
));
$content .= $formsClass->create_hidden('MAX_FILE_SIZE', '100000000');
for ($i = 0; $i < $count; $i++) {
$content_tab[$i] = array(
"Send this file: ",
$formsClass->create_file('upload_image[]', '')
);
}
//$content_tab[] = array("Send this file: ",$formsClass->create_file('listingimage',array('id'=>'listingimage')));
$content .= $presentationClass->StandardTableWithData($content_tab);
$content .= $formsClass->create_hidden('content_action_main', 'upload_images');
$content .= $formsClass->create_hidden('change_tab', $tab);
$content .= $formsClass->create_hidden('action_url', $action_url);
$content .= $formsClass->create_hidden('upload_mode', $mode);
$content .= $formsClass->create_submit($submit_name, 'Upload', array(
'id' => $submit_name
));
$content .= $formsClass->endform();
return $content;
}
function GenerateUploadImagesFormL($count = 5, $edit_id, $submit_name, $tab, $action_url, $mode, $sel = false) {
global $dbClass, $formsClass, $presentationClass, $UrlClass, $jqueryscript;
$content = $formsClass->startform('', array(
'enctype' => 'multipart/form-data',
'id' => 'listingimage_upload_form'
));
$content .= $formsClass->create_hidden('MAX_FILE_SIZE', '100000000');
for ($i = 0; $i < $count; $i++) {
$content_tab[$i] = array(
"Send this file: ",
$formsClass->create_file('upload_image[]', '')
);
}
//$content_tab[] = array("Send this file: ",$formsClass->create_file('listingimage',array('id'=>'listingimage')));
$content .= $presentationClass->StandardTableWithData($content_tab);
$content .= $formsClass->create_hidden('content_action_main', 'upload_images');
$content .= $formsClass->create_hidden('change_tab', $tab);
if ($sel !== false)
$content .= $formsClass->create_hidden('selected_tab', $sel);
$content .= $formsClass->create_hidden('action_url', $action_url);
$content .= $formsClass->create_hidden('upload_mode', $mode);
$content .= $formsClass->create_submit($submit_name, 'Upload', array(
'id' => $submit_name
));
$content .= $formsClass->endform();
return $content;
}
function GenerateUploadImagesFormNormal($count = 5, $edit_id, $submit_name) {
global $dbClass, $formsClass, $presentationClass, $UrlClass, $jqueryscript;
$content = $formsClass->startform('', array(
'enctype' => 'multipart/form-data'
));
$content .= $formsClass->create_hidden('MAX_FILE_SIZE', '100000000');
for ($i = 0; $i < $count; $i++) {
$content_tab[$i] = array(
"Send this file: ",
$formsClass->create_file('upload_image[]', '')
);
}
$content .= $presentationClass->StandardTableWithData($content_tab);
$content .= $formsClass->create_hidden('content_action', 'upload_images');
$content .= $formsClass->create_submit($submit_name, 'Upload');
$content .= $formsClass->endform();
return $content;
}
function UploadImages($mode = 0) {
global $config;
if (!isset($_FILES['upload_image']))
return false;
$return = false;
$files = $_FILES['upload_image'];
if (count($files['name'] > 0)) {
$return = array();
for ($i = 0; $i < count($files['name']); $i++) {
$name = $files['name'][$i];
$type = $files['type'][$i];
$tmp_name = $files['tmp_name'][$i];
$error = $files['error'][$i];
$size = $files['size'][$i];
if ($error == 0) {
// NOTE FIX REQ
if (is_uploaded_file($tmp_name)) {
if ($mode == 1)
$new_path = $config['basepath'] . $config['img_dir'] . "/user_images/";
elseif ($mode == 2)
$new_path = $config['basepath'] . $config['img_dir'] . "/agent_images/";
elseif ($mode == 3)
$new_path = $config['basepath'] . $config['img_dir'] . "/office_images/";
else
$new_path = $config['basepath'] . $config['img_dir'] . "/listing_images/";
// IF File doesn't exist
if (!file_exists($new_path)) {
@mkdir($new_path);
}
$new_name = $this->GenerateImageName($name, $new_path);
if (move_uploaded_file($tmp_name, $new_path . $new_name)) {
$return[$i]['name'] = $new_name;
$return[$i]['error'] = 0;
} else
$return[$i]['error'] = 100;
} else
$return[$i]['error'] = 99;
} else
$return[$i]['error'] = $error;
}
}
return $return;
}
function GenerateImageName($name, $path) {
$nname = $path . $name;
$tmp_path = @pathinfo($nname);
if ($files = $this->GetFiles($path)) {
$tmp_path['filename'] = str_replace(" ", "_", $tmp_path['filename']);
$search = $tmp_path['filename'] . '.' . $tmp_path['extension'];
$cnt = 1;
while (isset($files[$search])) {
$search = $tmp_path['filename'] . '_' . $cnt . '.' . $tmp_path['extension'];
$cnt++;
}
return $search;
}
return false;
}
function GetFiles($dir) {
if (is_dir($dir)) {
$dir = opendir($dir);
$tab_file = array();
while (($file = readdir($dir)) !== false) {
$file_parts = explode(".", $file);
if (count($file_parts) > 0) {
$tab_file[$file] = $file;
}
}
return $tab_file;
}
return false;
}
function GenerateUploadImagesFormUniversal($count = 5, $edit_id, $submit_name, $tab, $action_url, $mode, $id_form) {
global $dbClass, $formsClass, $presentationClass, $UrlClass, $jqueryscript;
$content = $formsClass->startform('', array(
'enctype' => 'multipart/form-data',
'id' => $id_form
));
$content .= $formsClass->create_hidden('MAX_FILE_SIZE', '100000000');
for ($i = 0; $i < $count; $i++) {
$content_tab[$i] = array(
"Send this file: ",
$formsClass->create_file('upload_image[]', '')
);
}
//$content_tab[] = array("Send this file: ",$formsClass->create_file('listingimage',array('id'=>'listingimage')));
$content .= $presentationClass->BlockTable($content_tab);
$content .= $formsClass->create_hidden('content_action_main', 'upload_images');
$content .= $formsClass->create_hidden('change_tab', $tab);
$content .= $formsClass->create_hidden('action_url', $action_url);
$content .= $formsClass->create_hidden('upload_mode', $mode);
$content .= $formsClass->create_submit($submit_name, 'Upload', array(
'id' => $submit_name
));
$content .= $formsClass->endform();
return $content;
}
//Remote db options
function getAllImageUrls($listing_id, $params) {
$settings = $this->GetPhotosSettings($params['masterdb']);
$params['options'] = $settings;
//echo '<pre>';
//var_dump($params);
//echo '</pre>';
$this->checkMlsField($params, $listing_id);
//get all images
if ($params['options']['controlpanel_remote_checkphoto_bool']) {
//$photocount = $this->getPhotoCount($listing_id, 0, TRUE, $params['options']['controlpanel_remote_photocount']);
//$f_name = $this->QuickReplace($params);
//$photoCount = $this->DoTorontoImgCount($params['options']['controlpanel_remote_photocount'], $params);
$photoCount = $this->DoTorontoImgCount(20, $params);
//$photoCount = 20;
$pics = array();
for ($t = 1; $t <= $photoCount; $t++) {
$params['num'] = $t;
//echo $this->QuickReplace($params).'<br>';
$pics[] = $this->QuickReplace($params, TRUE);
}
//var_dump($pics);
return $pics > 0 ? $pics : FALSE;
}
$photoCount = $this->getPhotoCount($listing_id, $params['options']['controlpanel_photocount']);
$iCount = 1;
$images;
//loop all listing photos
while ($iCount <= $photoCount) {
$params['num'] = $iCount;
$images[] = $this->ImageListingUrl($listing_id, $params);
$iCount++;
}
if (count($images) > 0)
return $images;
return false;
}
function getAllListingImageUrls($listing_id, $params) {
$settings = $this->GetPhotosSettings($params['masterdb']);
$params['options'] = $settings;
//get all images
if ($params['options']['controlpanel_remote_checkphoto_bool']) {
//$photocount = $this->getPhotoCount($listing_id, 0, TRUE, $params['options']['controlpanel_remote_photocount']);
//$f_name = $this->QuickReplace($params);
//$photoCount = $this->DoTorontoImgCount($params['options']['controlpanel_remote_photocount'], $params);
$photocount = 5;
$pics = array();
for ($t = 1; $t <= $photoCount; $t++) {
$params['num'] = $t;
$pics[] = $this->QuickReplace($params);
}
//var_dump($pics);
return $pics > 0 ? $pics : FALSE;
}
$photoCount = $this->getPhotoCount($listing_id, $params['options']['controlpanel_photocount']);
$iCount = 1;
$content = '';
//loop all listing photos
while ($iCount <= $photoCount) {
$params['num'] = $iCount;
$content .= $params['start_wrapper'] . "<img src='" . $this->ImageListingUrl($listing_id, $params) . "' />" . $params['end_wrapper'];
$iCount++;
}
if (!empty($content))
return $content;
return false;
}
//Remote db options
/************************************************************\
* 
\*********************************************************** */
function ImageListingUrl($listing_id, $params) {
global $config, $dbClass;
$settings = $this->GetPhotosSettings($params['masterdb']);
if ($settings['controlpanel_remote_checkphoto_bool_default'] == 1)
//die("test");
return $this->ImageRemoteListingUrl($listing_id, $params);
if (!is_numeric($params['num'])) {
$params['num'] = 0;
}
$sql = "SELECT * FROM " . $config['table_prefix'] . "listingsimages WHERE listingsdb_id='" . $listing_id . "' AND listingsimages_rank='" . $params['num'] . "' LIMIT 1";
$res = $dbClass->Query($sql, $params['masterdb'], true);
if ($res->recordCount() > 0) {
if (file_exists($config['basepath'] . $config['img_dir'] . "/listing_images/" . $res->fields['listingsimages_file_name']))
return $config['adm_baseurl'] . $config['img_dir'] . "/listing_images/" . $res->fields['listingsimages_file_name'];
} else // WHY? Was this commented out?
return false;
}
function getAllRemoteURLs($replace, $mls) {
$settings = $this->GetPhotosSettings();
$file_name = $settings['controlpanel_remote_path'];
$file_name = str_replace(".jpg", '', $file_name);
$file_name = str_replace("{custom_mls_1}", substr($mls, $settings['controlpanel_remote_custom_mls1_from'], $settings['controlpanel_remote_custom_mls1_to']), $file_name);
$url = $file_name . $replace;
return $url;
}
function ImageRemoteListingUrl($listing_id, $params) {
global $config, $dbClass;
if (!is_numeric($params['num'])) {
$params['num'] = 1;
}
$remote_options = $this->GetPhotosSettings($params['masterdb']);
$params['options'] = $remote_options;
$url = $this->ImageListingRemoteUrl($listing_id, $params, false);
return $url; //hack
if ($remote_options['controlpanel_remote_checkphoto_bool'] == 1 AND $params['checkphoto'] !== 'false') {
if ($url = $this->ChooseOptionUrlExists($url)) {
return $url;
} else
return $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
;
} else
return $url;
}
/************************************************************\
* 
\*********************************************************** */
// I need to add a variable in the event thumbnail settings are not used.
function ImageListingThumbUrl($listing_id, $params, $rsListing = false) {
global $config, $dbClass;
$settings = $this->GetPhotosSettings($params['masterdb']);
if ($settings['controlpanel_remote_checkphoto_bool_default'] == 1 || $settings['controlpanel_wprets'] !== 0) {
$url = $this->ImageRemoteListingThumbUrl($listing_id, $params, $rsListing);
return $url;
}
//echo 'url '.$url;
if (!isset($params['num']) || !is_numeric($params['num'])) {
$params['num'] = 0;
}
$sql = "SELECT * FROM " . $config['table_prefix'] . "listingsimages WHERE listingsdb_id='" . $listing_id . "' AND listingsimages_rank='" . $params['num'] . "' LIMIT 1";
$res = $dbClass->query($sql, $params['masterdb'], true);
if ($res->recordCount() > 0) {
if (file_exists($config['basepath'] . $config['img_dir'] . "/listing_images/" . $res->fields['listingsimages_thumb_file_name']))
return $config['adm_baseurl'] . $config['img_dir'] . "/listing_images/" . $res->fields['listingsimages_thumb_file_name'];
}
return false;
}
function ImageRemoteListingThumbUrl($listing_id, $params, $rsListing = false) {
global $config, $dbClass;
//var_dump($params);
if (!isset($params['num']) || !is_numeric($params['num'])) {
$params['num'] = 1;
}
$remote_options = $this->GetPhotosSettings($params['masterdb']);
$params['options'] = $remote_options;
$url = $this->ImageListingRemoteUrl($listing_id, $params, true, $rsListing);
return $url;
if ($remote_options['controlpanel_remote_checkphoto_bool'] == 1 AND $params['checkphoto'] !== 'false') {
if ($url = $this->ChooseOptionUrlExists($url)) {
return $url;
} else
return $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
} else
return $url;
}
/************************************************************\
* These Two Functions Photo Settings then Remote Image
\*********************************************************** */
static $PhotosSettings = false;
function GetPhotosSettings($masterdb = false) {
//die('here');
if (self::$PhotosSettings && is_array(self::$PhotosSettings)) {
return self::$PhotosSettings;
}
self::$PhotosSettings = false;
global $dbClass, $config;
$sql = "SELECT
controlpanel_baseurl,
controlpanel_wprets,
controlpanel_remote_custom_mls1_from,
controlpanel_remote_custom_mls1_to,
controlpanel_remote_custom_mls2_from,
controlpanel_remote_custom_mls2_to,
controlpanel_remote_custom_mls3_from,
controlpanel_remote_custom_mls3_to,
controlpanel_images_cache_bool,
controlpanel_images_cache_time,
controlpanel_remote_path,
controlpanel_remote_path_addit,
controlpanel_remote_numeric,
controlpanel_remote_numeric_bool,
controlpanel_remote_photocount,
controlpanel_remote_checkphoto_bool,
controlpanel_remote_photonumber_prefix,
controlpanel_remote_checkphoto_bool_default,
controlpanel_mls_field_name,
controlpanel_remote_photonumber_prefix_thumb,
controlpanel_photocount,
controlpanel_remote_path_thumb,
controlpanel_remote_custom_mls1_from_thumb,
controlpanel_remote_custom_mls1_to_thumb,
controlpanel_remote_custom_mls2_from_thumb,
controlpanel_remote_custom_mls2_to_thumb,
controlpanel_remote_custom_mls3_from_thumb,
controlpanel_remote_custom_mls3_to_thumb,
controlpanel_remote_numeric_thumb,
controlpanel_mls_field_name
FROM " . $config['table_prefix'] . "controlpanel
WHERE blog_id='" . $config['blog_id'] . "'";
$res = $dbClass->Query($sql);
if ($res->recordCount() > 0) {
self::$PhotosSettings = $res->fields;
}
if ($masterdb) {
$sql = "SELECT
controlpanel_baseurl,
controlpanel_wprets,
controlpanel_remote_custom_mls1_from,
controlpanel_remote_custom_mls1_to,
controlpanel_remote_custom_mls2_from,
controlpanel_remote_custom_mls2_to,
controlpanel_remote_custom_mls3_from,
controlpanel_remote_custom_mls3_to,
controlpanel_images_cache_bool,
controlpanel_images_cache_time,
controlpanel_remote_path,
controlpanel_remote_path_addit,
controlpanel_remote_numeric,
controlpanel_remote_numeric_bool,
controlpanel_remote_photocount,
controlpanel_remote_checkphoto_bool,
controlpanel_remote_photonumber_prefix,
controlpanel_remote_checkphoto_bool_default,
controlpanel_mls_field_name,
controlpanel_remote_photonumber_prefix_thumb,
controlpanel_photocount,
controlpanel_remote_path_thumb,
controlpanel_remote_custom_mls1_from_thumb,
controlpanel_remote_custom_mls1_to_thumb,
controlpanel_remote_custom_mls2_from_thumb,
controlpanel_remote_custom_mls2_to_thumb,
controlpanel_remote_custom_mls3_from_thumb,
controlpanel_remote_custom_mls3_to_thumb,
controlpanel_remote_numeric_thumb,
controlpanel_mls_field_name
FROM " . $config['table_prefix'] . "controlpanel";
//WHERE blog_id='".$config['blog_id']."'";
$res = $dbClass->Query($sql, $masterdb);
if ($res->recordCount() > 0) {
//$res->fields['controlpanel_baseurl'] = self::$PhotosSettings['controlpanel_baseurl'];
self::$PhotosSettings = $res->fields;
}
}
return self::$PhotosSettings;
}
function checkMlsField(&$params, $listing_id) {
global $dbClass, $config;
if (!isset($params['mls'])) { //adding this if needed
if (empty($params['options']['controlpanel_mls_field_name']))
return false;
if (empty($listing_id))
return false;
$sql_mls = "SELECT " . $params['options']['controlpanel_mls_field_name'] . "
FROM " . $config['table_prefix'] . "listingsdb
WHERE listingsdb_id=$listing_id";
$resMLS = $dbClass->Query($sql_mls, $params['masterdb']);
if ($resMLS->recordCount() > 0)
$params['mls'] = $resMLS->fields[$params['options']['controlpanel_mls_field_name']];
return TRUE;
} else {
return TRUE;
}
}
function retsType1(&$params, $listingInfo) {
global $config;
unset($params['mls']);
$this->checkMlsField($params, $listingInfo["listingsdb_id"]);
if ($this->getWprRetsConfig()) {
$arrConfig = $_SESSION['arrConfig'];
}
$replace = $params['num'];
if (!empty($arrConfig)) {
//global $arrConfig;
//var_dum($arrConfig);
$settings['check_path'] = $arrConfig['photo_download_path'] . "{mls}/mls-{mls}-{numeric_mls}.jpg";
$settings['check_path_thumb'] = $arrConfig['photo_download_path'] . "{mls}/thumb-mls-{mls}-{numeric_mls}.jpg";
$params['options']['controlpanel_remote_path'] = str_replace($config['basepath'], $config['adm_baseurl'], $settings['check_path']);
$params['options']['controlpanel_remote_path_thumb'] = str_replace($config['basepath'], $config['adm_baseurl'], $settings['check_path_thumb']);
$params['options']['controlpanel_remote_numeric_thumb'] = 1;
$params['options']['controlpanel_remote_numeric'] = 1;
$listingFields = registry::register('ListingFields');
$searchClassID = false;
if (($listingInfo && isset($listingInfo["class_id"])) || $listingInfo = $listingFields->GetListingInfo($listing_id)) {
$class_id = $listingInfo['class_id'];
foreach ($arrConfig['Listing']['Config'] as $k => $v) {
foreach ($v as $detailKey => $detailValue) {
if ($detailKey == 'wp_realty_class' AND $detailValue == $class_id) {
$searchClassID = $k;
break;
}
}
}
}
if ($searchClassID !== false) { // If searchClassID is not false
$searchField = $arrConfig['Listing']['Config'][$searchClassID]['unique_field'];
$uniqueField = $arrConfig['Listing']['Config'][$searchClassID]['mapping'][$searchField];
//$params['mls'] = $listingInfo[$uniqueField];
}
} else {
$settings['controlpanel_wprets'] = 0;
}
$fileCheck = $settings['check_path_thumb'];
$fileCheck = str_replace("{mls}", $params['mls'], $fileCheck);
//$fileCheck = preg_replace("/\{numeric_mls\}/",$start,$fileCheck);
$fileCheck = preg_replace("/\{numeric_mls\}/", $params['options']['controlpanel_remote_photonumber_prefix'] . $replace, $fileCheck);
//echo '<br>$filecheck -> '.$fileCheck.'<br>';
if (file_exists($fileCheck)) {
$file_name = $params['options']['controlpanel_remote_path_thumb'];
$file_name = str_replace("{mls}", $params['mls'], $file_name);
$url = preg_replace("/\{numeric_mls\}/", $replace, $file_name);
//echo '<br>$url -> '.$url.'<br>';
} else {
//echo '<br>file not found<br>';
$url = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
}
return $url;
}
function getConvertedImgNum(&$params, $num = FALSE) {
if ($num !== FALSE) {
$start = $num;
} else {
if ($params['options']['controlpanel_remote_numeric_bool'] == 1) {
$start = $params['num'] - 1;
} else {
$start = $params['num'];
}
}
//echo $start."///";
//mail('Debug@YourEmailHere.com','start offset',$start);
// Photo Numbering Formats - Notes: 
$replace = "";
switch ($params['options']['controlpanel_remote_numeric']) {
case 0:
if ($start < 10)
$replace = "0" . $start;
else
$replace = $start;
break;
case 1:
$replace = $start;
break;
// Upper Case a..z
case 2:
$replace = chr($start + "96");
break;
// Upper Case A..Z
case 3:
$replace = chr($start + "64");
break;
case 4:
$replace = $start - 1;
break;
case 5:
if ($start == 1)
$replace = "0";
elseif ($start <= 10)
$replace = "0" . ($start - 1);
else
$replace = ($start - 1);
case 6:
if ($start == 1)
$replace = "00";
elseif ($start <= 10)
$replace = "0" . ($start - 1);
else
$replace = ($start - 1);
break;
case 7:
$replace = ($start + 1);
break;
}
return $replace;
}
function checkThumbPath(&$params, $thumbs) {
if ($params['options']['controlpanel_remote_path_thumb'] != "" AND $thumb === true) {
$params['options']['controlpanel_remote_custom_mls1_from'] = $params['options']['controlpanel_remote_custom_mls1_from_thumb'];
$params['options']['controlpanel_remote_custom_mls1_to'] = $params['options']['controlpanel_remote_custom_mls1_to_thumb'];
$params['options']['controlpanel_remote_custom_mls2_from'] = $params['options']['controlpanel_remote_custom_mls2_from_thumb'];
$params['options']['controlpanel_remote_custom_mls2_to'] = $params['options']['controlpanel_remote_custom_mls2_to_thumb'];
$params['options']['controlpanel_remote_custom_mls3_from'] = $params['options']['controlpanel_remote_custom_mls3_from_thumb'];
$params['options']['controlpanel_remote_custom_mls3_to'] = $params['options']['controlpanel_remote_custom_mls3_to_thumb'];
$params['options']['controlpanel_remote_numeric_bool'] = $params['options']['controlpanel_remote_numeric_bool_thumb'];
$params['options']['controlpanel_remote_numeric'] = $params['options']['controlpanel_remote_numeric_thumb'];
$params['options']['controlpanel_remote_photonumber_prefix_thumb'];
$params['options']['controlpanel_remote_path'] = $params['options']['controlpanel_remote_path_thumb'];
//echo $params['options']['controlpanel_remote_numeric_bool'];
}
}
function parsePathTags($params, $is_addit = false) {
$file_name = '';
//Remote db options
if ($is_addit && $params['options']['controlpanel_remote_path_addit'] != null)
$file_name = $params['options']['controlpanel_remote_path_addit'];
else
$file_name = $params['options']['controlpanel_remote_path'];
//Remote db options
if (strpos($file_name, "{") === FALSE) {
return $file_name;
} else {
$file_name = str_replace("{custom_mls_1}", substr($params['mls'], $params['options']['controlpanel_remote_custom_mls1_from'], $params['options']['controlpanel_remote_custom_mls1_to']), $file_name);
$file_name = str_replace("{custom_mls_2}", substr($params['mls'], $params['options']['controlpanel_remote_custom_mls2_from'], $params['options']['controlpanel_remote_custom_mls2_to']), $file_name);
$file_name = str_replace("{custom_mls_3}", substr($params['mls'], $params['options']['controlpanel_remote_custom_mls3_from'], $params['options']['controlpanel_remote_custom_mls3_to']), $file_name);
return $file_name;
}
}
function checkRemoteVerifyURL($url) {
global $config;
if ($this->ChooseOptionUrlExists($url) !== FALSE) {
return $url;
} else {
return $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
}
}
function ImageListingRemoteUrl($listing_id, $params, $thumb = false, $listingInfo = false) {
global $dbClass, $config;
$settings = $this->GetPhotosSettings($params['masterdb']);
if (!$this->checkMlsField($params, $listing_id)) {
return FALSE;
}
switch ($settings['controlpanel_wprets']) { //top setting in CP - Select Listing Photo Format
case 0:
$image_full_url_basdir = $config['wpr_baseurl'] . $config['img_dir'] . '/listing_images/';
//die($image_full_url_basdir);
$image = $this->getImagePathToFileFromDB('filename', $listing_id, $real_num);
//die($image);
if ($image !== FALSE) {
$url = $image_full_url_basdir . $image;
if (!file_exists($config["basepath"] . $config['img_dir'] . '/listing_images/' . $image))
$url = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
} else {
$url = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
}
//echo $url.'<br>';
return $url;
break;
case 1: //WPR-RETS Image Path
return $this->retsType1($params, $listingInfo);
break;
case 2: //Media Server Image
if (!$this->checkMlsField($params, $listing_id)) {
return FALSE;
}
$file_name = $this->parsePathTags($params);
$this->checkThumbPath($params, $thumb);
$file_name = str_replace("{mls}{numeric_mls}.jpg", "{numeric_mls}", $file_name);
if ($params['options']['controlpanel_remote_numeric_bool'] == 1 AND $params['num'] == 1) {
return preg_replace("/\{numeric_mls\}/", "", $file_name);
} else {
$real_num = $this->getConvertedImgNum($params);
}
$url = checkRemoteVerifyURL($file_name);
return $url;
break;
case 3: //Full RETS Image Path
/* if($this->getWprRetsConfig()){
$arrConfig = $_SESSION['arrConfig'];
}
if(!$this->checkMlsField($params, $listing_id)){
return FALSE;
}
$file_name = $this->parsePathTags($params);
$this->checkThumbPath($params, $thumb);
$file_name = str_replace("{mls}{numeric_mls}.jpg","{numeric_mls}",$file_name);
if($params['options']['controlpanel_remote_numeric_bool']==1 AND $params['num']==1)
{
return preg_replace("/\{numeric_mls\}/","",$file_name);
}
else{
$real_num = $this->getConvertedImgNum($params);
} */
$image = $this->getImagePathToFileFromDB('url', $listing_id, $this->getConvertedImgNum($params), false, $params['options']['controlpanel_remote_path']);
if ($image !== FALSE) {
$url = $image;
} else {
$url = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
}
$url = $this->checkRemoteVerifyURL($url);
return $url;
break;
case 4: //RETS Image File Name
if (!$this->checkMlsField($params, $listing_id)) {
return FALSE;
}
$file_name = $this->parsePathTags($params);
$this->checkThumbPath($params, $thumb);
$file_name = str_replace("{mls}", $params['mls'], $file_name);
if ($params['options']['controlpanel_remote_numeric_bool'] == 1 AND $params['num'] == 1) {
$file_name = preg_replace("/\{numeric_mls\}/", "", $file_name);
} else {
$real_num = $this->getConvertedImgNum($params);
}
$images = $this->getImagePathToFileFromDB('filename', $listing_id, $real_num);
if ($images !== FALSE) {
$replace = $images;
$url = $file_name . $replace;
} else {
$url = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
}
$url = $this->checkRemoteVerifyURL($url);
return $url;
break;
case 5: //Cloud Image Storage
//error_reporting(-1);
//ini_set('display_errors', 'On');
//var_dump($params['options']);
//die();
//echo 'base '.$f_name.'<br>';
$photocount = FALSE;
//var_dump($params['options']['controlpanel_remote_checkphoto_bool']);
if (!$this->checkMlsField($params, $listing_id)) {
return FALSE;
}
//var_dump($params);
//echo $params['options']['controlpanel_remote_checkphoto_bool'];
if ($params['options']['controlpanel_remote_checkphoto_bool']) {
//$photocount = $this->getPhotoCount($listing_id, 0, TRUE, $params['options']['controlpanel_remote_photocount']);
$f_name = $this->QuickReplace($params);
if ($this->image_url_exists($f_name)) {
return $f_name;
} else {
$url = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
}
} else
$photocount = $this->getPhotoCount($listing_id, $params['options']['controlpanel_photocount']);
if (!$photocount) {
$url = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
return $url;
}
//this will now return the additional url if not first image and additional url is set
$file_name = $this->parsePathTags($params);
$this->checkThumbPath($params, $thumb);
//$file_name = str_replace("{mls}{numeric_mls}.jpg","{mls}{numeric_mls}",$file_name);
//echo '<pre>';
//var_dump($params);
//echo '</pre>';
if ($params['options']['controlpanel_remote_numeric_bool'] == 1 AND $params['num'] == 1) { //this means don numerate the first image
$file_name = str_replace("{mls}", $params['mls'], $file_name);
return preg_replace("/\{numeric_mls\}/", "", $file_name);
} else {
//not image number one
$file_name = $this->parsePathTags($params, true);
$real_num = $this->getConvertedImgNum($params);
}
if (strstr($file_name, "{zf_numeric_mls")) {
if ($start == 1)
$replace = "00";
elseif ($start <= 10)
$replace = "0" . ($start - 1);
else
$replace = ($start - 1);
str_replace('zf_numeric_mls', "numeric_mls", $file_name);
} else {
if ($start === 0 || empty($start))
$start = 1;
//$real_num = $this->getConvertedImgNum($params);
$replace = $real_num;
}
$file_name = str_replace("{mls}", $params['mls'], $file_name);
//echo '\\\\\\\\\\\\\\\\\\\\\\\\\\'.$file_name.'\\\\\\\\\\\\\\\\\\\\\\\\\\\\';
$url = preg_replace("/\{numeric_mls\}/", $params['options']['controlpanel_remote_photonumber_prefix'] . $replace, $file_name);
$url = $this->checkRemoteVerifyURL($url);
return $url;
break;
}
}
function QuickReplace($params) {
$path;
if (strlen($params['options']['controlpanel_remote_path_addit']) > 5 && $params['num'] > 1)
$path = str_replace('{mls}', $params['mls'], $params['options']['controlpanel_remote_path_addit']);
else
$path = str_replace('{mls}', $params['mls'], $params['options']['controlpanel_remote_path']);
$path = str_replace("{custom_mls_1}", substr($params['mls'], $params['options']['controlpanel_remote_custom_mls1_from'], $params['options']['controlpanel_remote_custom_mls1_to']), $path);
$file = str_replace('{numeric_mls}', $params['num'], $path);
//echo $file;
return $file;
}
//This begins the transition to db based urls for images !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
function getImagePathToFileFromDB($type, $listingID, $imgIndex = 0, $getAll = FALSE, $good_image_needle = '') { //gets just the first image by default
if (!is_numeric($imgIndex))
$imgIndex = 0;
global $dbClass, $config;
$whereclause = '';
if ($type == 'filename') {
$get_field = 'listingsimages_file_name';
} else {
$get_field = 'listingsimages_description';
$whereclause = " AND `" . $get_field . "` LIKE '%.jpg' ";
/* if (!empty($good_image_needle)) {
$whereclause = " AND `" . $get_field . "` LIKE '%" . $good_image_needle . "%' ";
} */
}
$images = array();
$sql = "SELECT `" . $get_field . "` FROM " . $config['table_prefix'] . "listingsimages WHERE listingsdb_id='" . $listingID . "'" . $whereclause . " order by `listingsimages_rank` ASC";
//die($sql);
//echo $sql;
//die('getall'.$getAll.' imgindex '.$imgIndex);
if (!$getAll && $imgIndex === 0) { //getting the first image
$t = $dbClass->GetOneRow($sql);
//var_dump($t);
if (empty($t)) {
//die('empty res');
return false;
}
//die($t);
//echo '<br>'.$t[$get_field].'<br>';
return $t[$get_field];
} else {
$imagesrc = $dbClass->query($sql);
if ($imagesrc->RecordCount() > 0) {
//die($sql);
while (!$imagesrc->EOF) {
$images[] = $imagesrc->fields[$get_field];
$imagesrc->MoveNext();
}
//var_dump($images);
if ($getAll) {
return $images;
} else {
return $images[$imgIndex];
}
}
}
//$replace = $images[$start - 1];
}
function getPhotoCount($listing_id, $count_field, $toronto = FALSE, $maxcount = 0) {
//echo $maxcount;
//if($toronto)
//return $this->DoTorontoImgCount($maxcount);
global $config, $dbClass;
$sql_mls = "SELECT `" . $count_field . "`
FROM " . $config['table_prefix'] . "listingsdb
WHERE listingsdb_id=$listing_id";
//echo $sql_mls;
//die();
$t = $dbClass->GetOneRow($sql_mls, true);
if (empty($t)) {
return false;
}
return $t[$count_field];
}
/************************************************************\
* All this code for a single slideshow?
* Note, core/include/urlclass.inc.php
\*********************************************************** */
function ImagesSlideshow($listing_id, $params) {
//return 'just text';
global $config, $UrlClass, $dbClass;
$id_slideshow = $params['id'];
if ($id_slideshow == '')
$id_slideshow = 'slideshow';
$settings = $this->GetPhotosSettings($params['masterdb']);
$params['options'] = $settings; //this make compat with single img settings to use the url funcs
$remote = false;
//var_dump($settings);
//return $settings['controlpanel_wprets'];
switch ($settings['controlpanel_wprets']) {
case 0:
$image_full_url_basdir = $config['wpr_baseurl'] . $config['img_dir'] . '/listing_images/';
$tab_images_filenames = $this->getImagePathToFileFromDB('filename', $listing_id, 3, TRUE);
if ($tab_images_filenames) {
$images = '';
foreach ($tab_images_filenames as $value) {
$images .= "<img src='" . $image_full_url_basdir . $value . "' width='" . $params['width'] . "' height='" . $params['height'] . "' />";
}
} else {
$images = "<img src='" . $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg'>";
}
break;
case 1:
if (!$this->checkMlsField($params, $listing_id)) {
return FALSE;
}
if ($this->getWprRetsConfig()) {
$arrConfig = $_SESSION['arrConfig'];
}
$imgdir = $arrConfig['photo_download_path'] . $params['mls'];
// echo '<br>image dir'.$imgdir.'<br>';
$imgArr = glob($imgdir . "/mls-*.jpg"); //the array of matching files
if ($imgArr) { //there are images
if (count($imgArr) > $config['slideshow_count']) { //cut down to slideshow count
$images_array = array_slice($imgArr, 0, $config['slideshow_count']);
} else {
$images_array = $imgArr;
}
$images = '';
$b = 0;
foreach ($images_array as $value) { // these are path names - merged the image url building with the path replacements
$imgurl = str_replace($arrConfig['photo_download_path'], $config['adm_baseurl'] . "modules/wprrets/photos/", $imgArr[$b]);
$images .= "<img src='" . $imgurl . "' width='" . $params['width'] . "' height='" . $params['height'] . "' />";
$b++;
}
} else {
$images = "<img src='" . $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg'>";
}
break;
case 3:
$tImages = array();
$images = '';
if ($this->getWprRetsConfig()) {
$arrConfig = $_SESSION['arrConfig'];
}
$tab_images_filenames = $this->getImagePathToFileFromDB('url', $listing_id, 3, TRUE, $settings['controlpanel_remote_path']);
for ($i = 0; $i <= $config['slideshow_count']; $i++) {
if (!empty($tab_images_filenames[$i])) {
$images .= "<img src='" . $tab_images_filenames[$i] . "' width='" . $params['width'] . "' height='" . $params['height'] . "' />";
}
}
if (empty($images)) {
$images = "<img src='" . $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg'>";
}
break;
case 4:
$tImages = array();
$images = '';
$tab_images_filenames = $this->getImagePathToFileFromDB('filename', $listing_id, 3, true);
$sql_mls = "SELECT " . $settings['controlpanel_mls_field_name'] . "
FROM " . $config['table_prefix'] . "listingsdb
WHERE listingsdb_id=$listing_id";
$resMLS = $dbClass->Query($sql_mls, true, true);
if ($resMLS->recordCount() > 0)
$mls = $resMLS->fields[$settings['controlpanel_mls_field_name']];
for ($i = 0; $i <= $config['slideshow_count']; $i++) {
if (!empty($tab_images_filenames[$i])) {
$imageurl = $this->getAllRemoteURLs($tab_images_filenames[$i], $mls);
$images .= "<img src='$imageurl' width='" . $params['width'] . "' height='" . $params['height'] . "' />";
}
}
if (empty($images)) {
$images = "<img src='" . $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg'>";
}
break;
case 5:
if ($this->getWprRetsConfig()) {
$arrConfig = $_SESSION['arrConfig'];
}
if (!$this->checkMlsField($params, $listing_id)) {
return FALSE;
}
$file_name = $this->parsePathTags($params);
$file_name = str_replace("{mls}", $params['mls'], $file_name);
$photocount = $this->getPhotoCount($listing_id, $params['options']['controlpanel_photocount']);
$config['slideshow_count'] = 100;
if ($photocount) { //we are going to construct a file name
if ($photocount < $config['slideshow_count'])
$config['slideshow_count'] = $photocount;
$tab_images_filenames = '';
} else {
$images = "<img src='" . $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg'>";
break;
}
$images = '';
for ($i = 0; $i < $config['slideshow_count']; $i++) {
//Remote db options
if ($i == 0 && $settings['controlpanel_remote_numeric_bool'] == 1) {
$url = preg_replace("/\{numeric_mls\}/", '', $file_name);
} else {
if ($settings['controlpanel_remote_numeric_bool'] == 1) {
$offset = 0;
} else {
$offset = 1;
}
//Remote db options
$url = preg_replace("/\{numeric_mls\}/", $params['options']['controlpanel_remote_photonumber_prefix'] . $this->getConvertedImgNum($params, $i + $offset), $file_name);
}
$images .= "<img src='$url' width='" . $params['width'] . "' height='" . $params['height'] . "' />";
}
if (empty($images)) {
$images = "<img src='" . $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg'>";
}
break;
default:
break;
}
//display the show
$effect = 'fade';
$timeout = 3000;
$content = "
<script>
jQuery(window).load(function() {
jQuery('#$id_slideshow').empty().html(\"$images\").css('width','" . $params['width'] . "').css('height','" . $params['height'] . "').cycle({
fx:     '$effect',
speed: 	'slow',
timeout: $timeout
});
});
</script>";
return $content;
}
function ImagesSlideshowNavigation($params) {
global $jqueryscript;
$id_slideshow = $params['id'];
if ($id_slideshow == '')
$id_slideshow = 'slideshow';
$content = "";
$content .= "<a href='#' id='" . $id_slideshow . "_stop'/>Stop</a> | ";
$content .= "<a href='#' id='" . $id_slideshow . "_start'/>Start</a> | ";
$content .= "<a href='#' id='" . $id_slideshow . "_prev'/>Prev</a> | ";
$content .= "<a href='#' id='" . $id_slideshow . "_next'/>Next</a> | ";
$content .= "<script type='text/javascript'>
jQuery(document).ready(function()
{
jQuery(\"#" . $id_slideshow . "_stop\").click(function()
{
jQuery(\"#" . $id_slideshow . "\").cycle('pause');
return false;
});
jQuery(\"#" . $id_slideshow . "_start\").click(function()
{
jQuery(\"#" . $id_slideshow . "\").cycle('resume');
return false;
});
jQuery(\"#" . $id_slideshow . "_next\").click(function()
{
jQuery(\"#" . $id_slideshow . "\").cycle('pause');
jQuery(\"#" . $id_slideshow . "\").cycle('next');
return false;
});
jQuery(\"#" . $id_slideshow . "_prev\").click(function()
{
jQuery(\"#" . $id_slideshow . "\").cycle('pause');
jQuery(\"#" . $id_slideshow . "\").cycle('prev');
return false;
});
});
</script>";
return $content;
}
/************************************************************\
* Function needs some reworking - Used to Create Thumbnail
\*********************************************************** */
function create_thumbnail($source_file, $destination_file, $mode = 'bestfit', $max_dimension, $max_dimension2 = false) {
list($img_width, $img_height) = getimagesize($source_file); // Get the original dimentions
$aspect_ratio = $img_width / $img_height;
if (($img_width > $max_dimension) || ($img_height > $max_dimension)) { // If either dimension is too big...
if ($mode == 'bestfit') {
if ($img_width > $img_height) { // For wide images...
$new_width = $max_dimension;
$new_height = $new_width / $aspect_ratio;
} elseif ($img_width < $img_height) { // For tall images...
$new_height = $max_dimension;
$new_width = $new_height * $aspect_ratio;
} elseif ($img_width == $img_height) { // For square images...
$new_width = $max_dimension;
$new_height = $max_dimension;
} else {
echo "Error reading image size.";
return FALSE;
}
} elseif ($mode == 'width') {
$new_width = $max_dimension;
$new_height = $new_width / $aspect_ratio;
} elseif ($mode == 'height') {
$new_height = $max_dimension2;
$new_width = $new_height * $aspect_ratio;
} elseif ($mode == 'both') {
$new_width = $max_dimension;
$new_height = $max_dimension2;
} else
return false;
} else {
$new_width = $img_width;
$new_height = $img_height;
} // If it's already smaller, don't change the size.
// Make sure these are integers.
$new_width = intval($new_width);
$new_height = intval($new_height);
$thumbnail = imagecreatetruecolor($new_width, $new_height); // Creates a new image in memory.
// The following block retrieves the source file.  It assumes the filename extensions match the file's format.
if (strpos($source_file, ".gif")) {
$img_source = imagecreatefromgif($source_file);
}
if ((strpos($source_file, ".jpg")) || (strpos($source_file, ".jpeg"))) {
$img_source = imagecreatefromjpeg($source_file);
}
if (strpos($source_file, ".bmp")) {
$img_source = imagecreatefromwbmp($source_file);
}
if (strpos($source_file, ".png")) {
$img_source = imagecreatefrompng($source_file);
}
// Here we resample and create the new jpeg.
imagecopyresampled($thumbnail, $img_source, 0, 0, 0, 0, $new_width, $new_height, $img_width, $img_height);
imagejpeg($thumbnail, $destination_file, 100);
// Finally, we destroy the two images in memory.
imagedestroy($img_source);
imagedestroy($thumbnail);
}
/************************************************************\
* Need a way to specify upload path.
\*********************************************************** */
function UploadListingImages($listing_id, $user_id, $files) {
global $dbClass, $config;
$return = false;
for ($i = 0; $i < count($files); $i++) {
$name = $files[$i]['name'];
$error = $files[$i]['error'];
if ($error == 0) {
if ($config['img_create_thumb'] == 1) {
$ext = explode(".", $name);
$thumb_file = $ext[0] . "-thumb." . $ext[1];
$this->create_thumbnail($config['listing_images'] . $name, $config['listing_images'] . $thumb_file, $config['img_resize_thumb_by'], $config['img_thumb_width'], $config['img_thumb_height']);
}
$sql = "INSERT INTO " . $config['table_prefix'] . "listingsimages SET
user_id = '$user_id',
listingsdb_id = '$listing_id',
listingsimages_file_name ='$name',
listingsimages_thumb_file_name = '$thumb_file'";
$dbClass->Query($sql);
$last_id = $dbClass->LastID();
$return = true;
}
}
return $return;
}
function UploadUserImage($user_id, $files) {
global $dbClass, $config;
$return = false;
$name = $files[0]['name'];
$error = $files[0]['error'];
if ($error == 0) {
$sql = "UPDATE " . $config['table_prefix'] . "users SET
user_image = '$name' WHERE user_id='" . $user_id . "'";
$dbClass->Query($sql);
$return = true;
}
return $return;
}
function UploadAgentImages($agent_id, $files) {
global $dbClass, $config;
$return = false;
for ($i = 0; $i < count($files); $i++) {
$name = $files[$i]['name'];
$error = $files[$i]['error'];
if ($error == 0) {
//if($config['img_create_thumb']==1)
//{
$ext = explode(".", $name);
$thumb_file = $ext[0] . "-thumb." . $ext[1];
$this->create_thumbnail($config['agent_images'] . $name, $config['agent_images'] . $thumb_file, $config['img_resize_thumb_by'], $config['img_thumb_width'], $config['img_thumb_height']);
//}
$sql = "INSERT INTO " . $config['table_prefix'] . "agentimages SET
agent_id = '$agent_id',
image_filename ='$name',
image_thumbname='$thumb_file'
";
$dbClass->Query($sql);
$last_id = $dbClass->LastID();
$return = true;
}
}
return $return;
}
function UploadOfficeImages($office_id, $files) {
global $dbClass, $config;
$return = false;
for ($i = 0; $i < count($files); $i++) {
$name = $files[$i]['name'];
$error = $files[$i]['error'];
if ($error == 0) {
//if($config['img_create_thumb']==1)
//{
$ext = explode(".", $name);
$thumb_file = $ext[0] . "-thumb." . $ext[1];
$this->create_thumbnail($config['office_images'] . $name, $config['office_images'] . $thumb_file, $config['img_resize_thumb_by'], $config['img_thumb_width'], $config['img_thumb_height']);
//}
$sql = "INSERT INTO " . $config['table_prefix'] . "officeimages SET
office_id = '$office_id',
image_filename ='$name',
image_thumbname='$thumb_file'
";
$dbClass->Query($sql);
$last_id = $dbClass->LastID();
$return = true;
}
}
return $return;
}
function UploadUserImages($user_id, $files) {
global $dbClass, $config;
$return = false;
for ($i = 0; $i < count($files); $i++) {
$name = $files[$i]['name'];
$error = $files[$i]['error'];
if ($error == 0) {
//if($config['img_create_thumb']==1)
//{
$ext = explode(".", $name);
$thumb_file = $ext[0] . "-thumb." . $ext[1];
$this->create_thumbnail($config['user_images'] . $name, $config['user_images'] . $thumb_file, $config['img_resize_thumb_by'], $config['img_thumb_width'], $config['img_thumb_height']);
//}
$sql = "INSERT INTO " . $config['table_prefix'] . "userimages SET
user_id = '$user_id',
image_filename ='$name',
image_thumbname='$thumb_file'
";
$dbClass->Query($sql);
$last_id = $dbClass->LastID();
$return = true;
}
}
return $return;
}
function getWprRetsConfig() {
global $config;
defined('CONFIG_FILE') || define('CONFIG_FILE', $config['basepath'] . "modules/wprrets/db/wprrets_config.txt");
$wprrets_path = $config['wpradmin_basepath'] . "modules/wprrets/libs/Utility.php";
// Check to see if the photo exists in the WPRRETS Path
if (!isset($_SESSION['arrConfig'])) {
require_once($wprrets_path);
$arrConfig = Utility::readToConfig();
$_SESSION['arrConfig'] = $arrConfig;
} ////
else {
$arrConfig = $_SESSION['arrConfig'];
} //end handling the config
if (!empty($_SESSION['arrConfig'])) {
return TRUE;
}
return FALSE;
}
}
// END class ImagesClass
?>