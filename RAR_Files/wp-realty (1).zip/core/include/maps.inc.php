<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class MapsClass{
public $_api;
function __construct()
{
global $config;
require($config['wpradmin_basepath']."include/GoogleMapAPI.class.php");
$this->_api = new GoogleMapAPI('bigmap');
}
function GenerateAddress($adress,$state,$zip,$city,$country)
{
$adress = $adress.",".$state." ".$zip.",".$city.",".$country;
$adress = preg_replace("#\(.*?\)#","",$adress);
return $adress;
}
function GenerateGoogleMaps($listing_id,$params)
{
global $dbClass,$config,$UrlClass;
if(is_numeric($listing_id))
{
require_once($config['wpradmin_basepath'].'include/controlpanel.inc.php');
$controlpanel = registry::register('controlpanelClass');
$settings = $controlpanel->GetControlPanelFields();
$address_field = $settings['controlpanel_map_address'];
$city_field = $settings['controlpanel_map_city'];
$state_field = $settings['controlpanel_map_state'];
$zip_field = $settings['controlpanel_map_zip'];
$country_field = $settings['controlpanel_map_country'];
$lat_field = $settings['controlpanel_map_lat'];
$lng_field = $settings['controlpanel_map_lng'];
$sql = "SELECT * FROM ".$config['table_prefix']."listingsdb WHERE listingsdb_id='$listing_id' LIMIT 1";
$reS = $dbClass->Query($sql,$params['masterdb']);
$content = "";
if($reS->recordCount()>0)
{
$adress_other = "'".$this->GenerateAddress($reS->fields[$address_field],$reS->fields[$state_field],$reS->fields[$zip_field],$reS->fields[$city_field],$reS->fields[$country_field])."'";
$coordinates = array();
if($lat_field!="" AND
$lng_field!="" AND
$reS->fields[$lat_field]!="" AND
(int) $reS->fields[$lng_field]!=0 AND
$reS->fields[$lng_field]!="" AND
(int) $reS->fields[$lng_field]!=0)
{
$coordinates[] = array('lat'=>$reS->fields[$lat_field],'lon'=>$reS->fields[$lng_field]);
}
else
{
if($geocode = $this->_api->getGeocode($adress_other))
{
$coordinates[] = $this->_api->getGeocode($adress_other);
} else
return false;
}
$query = $adress_other;
$query = str_replace(" ","+",$adress_other);
$adress_to_view_tab = "'<b><span style=\"color:#CF4800\">".$reS->fields['listingsdb_title']."</span></b><br/>".$reS->fields[$address_field]."<br/>".$reS->fields[$state_field]." ".$reS->fields[$zip_field]."<br/>".$reS->fields[$city_field]."'";
$this->_api->addMarkerByAddress($address,'',$infoWindow);
$links_tab = "'".$UrlClass->BaseUrlWithFile()."'";
$name_tab = "'".$reS->fields['listingsdb_title']."'";
//nearly places random
if($city_field!="")
{
$sql = "SELECT * FROM ".$config['table_prefix']."listingsdb WHERE $city_field='".$reS->fields[$city_field]."' AND listingsdb_id!=".$reS->fields['listingsdb_id']." ORDER BY rand() LIMIT 0,10";
$res_other = $dbClass->Query($sql,$params['masterdb']);
if($res_other!==false)
{
if($res_other->RecordCount()>0)
{
while(!$res_other->EOF)
{
$address = $this->GenerateAddress($res_other->fields[$address_field],$res_other->fields[$state_field],$res_other->fields[$zip_field],$res_other->fields[$city_field],$res_other->fields[$country_field]);
/*$infoWindow = ",'<b><span style=\"color:#CF4800\">".addslashes($res_other->fields['listingsdb_title'])."</span></b><br/>".addslashes($res_other->fields[$address_field])."<br/>".addslashes($res_other->fields[$state_field])." ".addslashes($res_other->fields[$zip_field])."<br/>".addslashes($res_other->fields[$city_field])."'";
$this->_api->addMarkerByAddress($address,'',$infoWindow);*/
if($lat_field!="" AND
$lng_field!="" AND
$res_other->fields[$lat_field]!="" AND
(int) $res_other->fields[$lng_field] !=0 AND
$res_other->fields[$lng_field]!="" AND
(int) $res_other->fields[$lng_field] !=0)
{
$coordinates[] = array('lat'=>$res_other->fields[$lat_field],'lon'=>$res_other->fields[$lng_field]);
}
else
{
$geocode = $this->_api->getGeocode($address);
if($geocode!==false)
{
$coordinates[] = $geocode;
$adress_other .= ",'".addslashes($this->GenerateAddress($res_other->fields[$address_field],$res_other->fields[$state_field],$res_other->fields[$zip_field],$res_other->fields[$city_field],$res_other->fields[$country_field]))."'";
$links_tab .= ",'".$config['baseurl']."index.php?page=listingdetails&listing_id=".$res_other->fields['listingsdb_id']."'";
$name_tab .= ",'".addslashes($res_other->fields['listingsdb_title'])."'";
$adress_to_view_tab .= ",'<b><span style=\"color:#CF4800\">".addslashes($res_other->fields['listingsdb_title'])."</span></b><br/>".addslashes($res_other->fields[$address_field])."<br/>".addslashes($res_other->fields[$state_field])." ".addslashes($res_other->fields[$zip_field])."<br/>".addslashes($res_other->fields[$city_field])."'";
}
}
$res_other->MoveNext();
}
}
}
}
$width = 700;
$width = 700;
if(isset($params['width']))
$width = $params['width'];
if(isset($params['height']))
$height = $params['height'];
$key = $config['googlemapskey'];
$content .= "<div id='bigmap' style='width: ".$width."px;height: ".$height."px;border: 1px solid black;background: gray;'></div>";
//$content .= '';
$pCoorinates = "";
if(count($coordinates)>0)
{
for($i=0;$i<count($coordinates);$i++)
{
$pCoorinates .= "[".$coordinates[$i]['lat'].",";
$pCoorinates .= $coordinates[$i]['lon']."],\n";
}
$pCoorinates = substr($pCoorinates,0,-2);
$pCoorinates .= "\n";
}
$content .= "<script type='text/javascript'>
var coordinates = [".$pCoorinates."];
var address_to_view = new Array(".$adress_to_view_tab.");
var links_tab = new Array(".$links_tab.");
var name_tab = new Array(".$name_tab.");
var listener = new google.maps.InfoWindow();
var geokoder = new google.maps.Geocoder();
var bound = new google.maps.LatLngBounds();
var map_option = {
zoom: 10,
mapTypeId: google.maps.MapTypeId.ROADMAP,
disableDefaultUI: true,
navigationControl: true,
};
var map = new google.maps.Map(document.getElementById('bigmap'), map_option);
var loc;
var point;
var listener;
function addMarker(latlng,txt,clicked)
{
var opcjeMarkera =
{
position: latlng,
map: map
}
var marker = new google.maps.Marker(opcjeMarkera);
marker.txt=txt;
google.maps.event.addListener(marker,'click',function()
{
listener.setContent(marker.txt);
listener.open(map,marker);
});
if(clicked==true)
{
google.maps.event.trigger(marker,'click');
}
return marker;
}
if(coordinates.length>0)
{
for(i=0;i<coordinates.length;i++)
{
point = new google.maps.LatLng(coordinates[i][0],coordinates[i][1]);
//bound.extend(point);
txt = address_to_view[i]+'<br/><a href=\"'+links_tab[i]+'\" style=\"color:#CF4800;font-size:12px\">view details</a>';
if(i==0)
{
map.setCenter(point);
addMarker(point,txt,true);
}
else
{
addMarker(point,txt,false);
}
if(i==coordinates.length-1)
{
//map.fitBounds(bound);
}
}
}
</script>
";
return $content;
}
else
return false;
}
}
function GenerateStreetView($listing_id,$params)
{
global $dbClass,$config,$UrlClass;
$controlpanel = registry::register('controlpanelClass');
$settings = $controlpanel->GetControlPanelFields();
if($settings['controlpanel_streetview']==0)
{
$content = "
<script type='text/javascript'>
jQuery(document).ready(function()
{
jQuery('a').each(function()
{
if(jQuery(this).attr('href')=='#streetview')
{
jQuery(this).closest('li').remove();
}
});
});
</script>";
return $content;
}
if(is_numeric($listing_id))
{
require_once($config['wpradmin_basepath'].'include/controlpanel.inc.php');
$controlpanel = registry::register('controlpanelClass');
$settings = $controlpanel->GetControlPanelFields();
$address_field = $settings['controlpanel_map_address'];
$city_field = $settings['controlpanel_map_city'];
$state_field = $settings['controlpanel_map_state'];
$zip_field = $settings['controlpanel_map_zip'];
$country_field = $settings['controlpanel_map_country'];
$lat_field = $settings['controlpanel_map_lat'];
$lng_field = $settings['controlpanel_map_lng'];
$sql = "SELECT * FROM ".$config['table_prefix']."listingsdb WHERE listingsdb_id='$listing_id' LIMIT 1";
$reS = $dbClass->Query($sql,$params['masterdb']);
$content = "";
if($reS->recordCount()>0)
{
$adress_other = "'".$this->GenerateAddress($reS->fields[$address_field],$reS->fields[$state_field],$reS->fields[$zip_field],$reS->fields[$city_field],$reS->fields[$country_field])."'";
if($lat_field!="" AND
$lng_field!="" AND
$reS->fields[$lat_field]!="" AND
(int) $reS->fields[$lng_field]!=0 AND
$reS->fields[$lng_field]!="" AND
(int) $reS->fields[$lng_field]!=0)
{
$coordinates[] = array('lat'=>$reS->fields[$lat_field],'lon'=>$reS->fields[$lng_field]);
} else
{
$coordinates = $this->_api->getGeocode($adress_other);
if($coordinates===false)
return;
}
$width = 700;
$width = 700;
if(isset($params['width']))
$width = $params['width'];
if(isset($params['height']))
$height = $params['height'];
$content .= "<div id='streetviewmap' style='width: ".$width."px;height: ".$height."px;border: 1px solid black;background: gray;'></div>";
$content .= "<script type='text/javascript'>
jQuery(document).ready(function()
{
var sv_address = [".$coordinates['lat'].",".$coordinates['lon']."];
var sv_point = new google.maps.LatLng(sv_address[0],sv_address[1]);
var sv_service = new google.maps.StreetViewService();
sv_service.getPanoramaByLocation(sv_point, 50, function (streetViewPanoramaData, sv_status) {
if (sv_status === google.maps.StreetViewStatus.OK) {
var panoramaOptions = {
position: sv_point,
pov: {
heading: 34,
pitch: 10,
zoom: 1
}
};
var panorama = new google.maps.StreetViewPanorama(document.getElementById('streetviewmap'), panoramaOptions);
} else {
jQuery('#streetviewmap').remove();
jQuery('a').each(function()
{
if(jQuery(this).attr('href')=='#streetview')
{
jQuery(this).closest('li').remove();
}
})
}
});
});
</script>
";
return $content;
}
else
return false;
}
}
function GenerateMapTabs($params)
{
$id = "maps";
if(isset($params['id']))
$id = $params['id'];
$content = '<script type="text/javascript">
jQuery(document).ready(function()
{
jQuery("#maps").tabs(
{
show: function (event, ui) {
var id = ui.panel.attributes[0].value;
if(id=="streetview")
{
if(document.getElementById("streetviewmap")!=null)
google.maps.event.trigger(document.getElementById("streetviewmap"),"resize");
}
else if(id=="googlemaps")
{
if(document.getElementById("bigmap")!=null)
google.maps.event.trigger(document.getElementById("bigmap"),"resize");
}
}
});
});
</script>';
return $content;
}
}
?>