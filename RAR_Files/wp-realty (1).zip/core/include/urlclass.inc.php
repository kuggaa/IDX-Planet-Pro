<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class UrlClass {
function selfURL() {
$s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
$protocol = $this->strleft(strtolower($_SERVER["SERVER_PROTOCOL"]), "/") . $s;
$port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":" . $_SERVER["SERVER_PORT"]);
return $protocol . "://" . $_SERVER['SERVER_NAME'] . $port . $_SERVER['REQUEST_URI'];
}
function strleft($s1, $s2) {
return substr($s1, 0, strpos($s1, $s2));
}
function BaseUrl() {
$url = $this->selfURL();
$tab = parse_url($url);
$path = explode("/", $tab['path'], -1);
$path = implode("/", $path);
$ret = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s://" : "://") . $tab['host'] . $path;
return $ret;
}
function BasePath() {
return $_SERVER['DOCUMENT_ROOT'] . "wprealty3";
}
function BaseUrlWithFile() {
$url = $this->selfURL();
$tab = parse_url($url);
$ret = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s://" : "://") . $tab['host'] . $tab['path'];
return $ret;
}
function ReturnGetValues($url = false) {
if ($url === false) {
$url = $this->selfURL();
}
if ($url_query = parse_url($url, PHP_URL_QUERY)) {
parse_str($url_query, $tab);
return $tab;
} else
return false;
}
function ReplaceUrlValues($new_values, $delete_values = false, $url = false, $test = false) {
if ($url === false) {
$url = $this->selfURL();
}
$tab_url = parse_url($url);
$new_url = $tab_url['scheme'] . "://" . $tab_url['host'] . $tab_url['path'];
$query = "";
if ($url_query = parse_url($url, PHP_URL_QUERY)) {
parse_str($url_query, $tab);
foreach ($tab as $key => $value) {
if ($delete_values !== false) {
if (is_array($delete_values)) {
if (in_array($key, $delete_values))
continue;
}
else {
if ($key == $delete_values)
continue;
}
}
if (is_array($value)) {
for ($i = 0; $i < count($value); $i++) {
if (isset($new_values[$key])) {
$query .= $key . "[]=" . $new_values[$key][$i] . "&";
} else
$query .= $key . "[]=" . $value[$i] . "&";
}
}
else {
if (isset($new_values[$key])) {
$query .= $key . "=" . $new_values[$key] . "&";
} else
$query .= $key . "=" . $value . "&";
}
}
if ($new_values != '' AND $new_values != false) {
foreach ($new_values as $key => $value) {
if (!isset($tab[$key])) {
$query .= $key . "=" . $value . "&";
}
}
}
if ($query != "") {
$return = $new_url . "?" . $query;
$return = substr($return, 0, strlen($return) - 1);
} else
$return = $new_url;
return $return;
} else {
if (is_array($new_values)) {
foreach ($new_values as $key => $value) {
if (!isset($tab[$key])) {
$query .= $key . "=" . $value . "&";
}
}
}
if ($query != "")
return $new_url . "?" . substr($query, 0, -1);
}
}
function ReplaceUrlValuesWithAnchor($new_values, $delete_values = false, $anchor = false, $url = false) {
if ($url === false) {
$url = $this->selfURL();
}
$tab_url = parse_url($url);
$new_url = $tab_url['scheme'] . "://" . $tab_url['host'] . $tab_url['path'];
$query = "";
if ($url_query = parse_url($url, PHP_URL_QUERY)) {
parse_str($url_query, $tab);
foreach ($tab as $key => $value) {
if ($delete_values !== false) {
if (is_array($delete_values)) {
if (in_array($key, $delete_values))
continue;
}
else {
if ($key == $delete_values)
continue;
}
}
if (isset($new_values[$key])) {
$query .= $key . "=" . $new_values[$key] . "&";
} else
$query .= $key . "=" . $value . "&";
}
if ($new_values != '' AND $new_values != false) {
foreach ($new_values as $key => $value) {
if (!isset($tab[$key])) {
$query .= $key . "=" . $value . "&";
}
}
}
if ($query != "") {
$return = $new_url . "?" . $query;
$return = substr($return, 0, strlen($return) - 1);
} else
$return = $new_url;
if ($anchor !== false)
$return .= "#" . $anchor;
return $return;
}
else {
foreach ($new_values as $key => $value) {
if (!isset($tab[$key])) {
$query .= $key . "=" . $value . "&";
}
}
if ($query != "")
return $new_url . "?" . substr($query, 0, -1);
}
}
function AddUrlValues($url_values, $url = false) {
if ($url === false) {
$url = $this->selfURL();
}
$tab_url = parse_url($url);
$new_url = $tab_url['scheme'] . "://" . $tab_url['host'] . $tab_url['path'];
$query = '';
foreach ($url_values as $key => $value) {
if (!isset($tab[$key])) {
if (is_array($value)) {
foreach ($value as $k => $v) {
$query .= $key . "[" . $k . "]=" . $v . "&";
}
} else
$query .= $key . "=" . $value . "&";
}
}
if ($query != "")
return $new_url . "?" . substr($query, 0, -1);
}
function AddUrlValuesWithAnchor($url_values, $url = false, $anchor = false) {
if ($url === false) {
$url = $this->selfURL();
}
$tab_url = parse_url($url);
$new_url = $tab_url['scheme'] . "://" . $tab_url['host'] . $tab_url['path'];
foreach ($url_values as $key => $value) {
if (!isset($tab[$key])) {
$query .= $key . "=" . $value . "&";
}
}
if ($query != "") {
$return = $new_url . "?" . substr($query, 0, -1);
} else {
$return = $new_url;
}
if ($anchor !== false)
$return .= "#" . $anchor;
return $return;
}
}
?>