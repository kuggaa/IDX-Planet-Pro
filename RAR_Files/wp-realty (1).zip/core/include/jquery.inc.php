<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class jQueryClass
{
var $javascript_content;
var $javascript_head;
var $javascript_end;
var $jqueryscript_end;
function __construct()
{
$this->javascript_end = false;
$this->javascript_head = false;
$this->jqueryscript_end = false;
}
function AddJqueryScriptEnd($script)
{
$this->jqueryscript_end .= $script;
}
function AddJavaScriptEnd($script)
{
$this->javascript_end .= $script;
}
function AddJqueryScriptHead($script)
{
$this->javascript_head .= $script."\n\n";
}
function PrintScriptEnd(){
if($this->jqueryscript_end!==false OR $this->javascript_end !==false)
{
$content = "<script type='text/javascript'>
jQuery(document).ready(function($)
{
".$this->jqueryscript_end."
});
".$this->javascript_end."
</script>";
$this->javascript_end = false;
$this->jqueryscript_end = false;
return $content;
}
}
function PrintScriptHead(){
if($this->javascript_head!==false)
{
$content = "<script type='text/javascript'>
".$this->javascript_head."
</script>";
return $content;
}
}
function PrintScript($script)
{
$content = "<script type='text/javascript'>
".$script."
</script>";
return $content;
}
function MixedData($array)
{
$ret_string = "{";
foreach($array as $key=>$value)
{
$ret_string .= "'".$key."':";
if(is_numeric($value))
$ret_string .= $value;
else
$ret_string .= "'".$value."'";
$ret_string .= ",";
}
$ret_string = substr($ret_string,0,-1);
$ret_string .= "}";
return $ret_string;
}
function SaveOrder($class_column,$save_id,$url,$success_info,$type)
{
$script .= $this->PrintScript("
jQuery('.".$class_column."').sortable({
connectWith: '.".$class_column."',
opacity: 0.4,
tolerance: 'pointer',
placeholder: 'place_holder',
});
jQuery('#".$save_id."').click(function()
{
var fields = new Array();
var cnt=0;
jQuery('.".$class_column."').each(function()
{
fields[cnt] = '';
jQuery(this).find('input').each(function()
{
var cs = jQuery(this).attr('name');
fields[cnt] = fields[cnt] + cs + '|';
});
cnt++;
});
$.ajax({
type: 'POST',
url: '".$url."',
data: 'type=".$type."&fields0='+fields[0]+'&fields1='+fields[1]+'&fields2='+fields[2]
}).done(function(data){
if(data == 'true') $('#main_container h2').before('".$success_info."');
});
});
");
return $script;
}
} // END class jQueryClass
?>