<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
Class FormsClass {
/************************************************************\
* This class is used to generate form / field structure
\*********************************************************** */
/* function createformitem($type,$name,$value,$options,$echo=false)
{
switch($type)
{
case 'text':
$content = $this->create_text($name,$value);
case 'textarea':
$content = $this->create_textarea($name,$value);
case 'radio':
$content = $this->create_radio($name,$value);
case 'checkbox':
$content = $this->create_checkbox($name,$value);
case 'select':
$content = $this->create_select($name,$value);
case 'submit':
$content = $this->create_submit($name,$value);
}
if($echo)
echo $content;
else
return $content;
} */
var $tooltip_array;
function __construct() {
global $config;
include_once($config['wpradmin_basepath'] . "include/tooltips.php");
$this->tooltips_array = $tooltips_array;
}
function generate_params_list($params) {
$content = "";
if (is_array($params)) {
foreach ($params as $key => $value) {
$content .= $key . '="' . $value . '" ';
}
}
return $content;
}
function startform($action = '', $param = false, $echo = false) {
$content = '<form action="' . $action . '" ';
if (!isset($param['method']))
$param['method'] = 'post';
if ($param != false)
$content .= $this->generate_params_list($param);
$content .= ">\n";
if ($echo === false)
return $content;
else
echo $content;
}
function endform($echo = false) {
$content = "</form>";
if ($echo === false)
return $content;
else
echo $content;
}
function create_text($name, $value, $params = '', $echo = false) {
$content = '<input type="text" name="' . $name . '" value="' . str_replace('"', "'", $value) . '" ';
if (isset($this->tooltips_array[$name])) {
$content .= 'title="' . addslashes($this->tooltips_array[$name]) . ' "';
}
$content .= $this->generate_params_list($params);
$content .= ' class="text-field" />';
if ($echo)
echo $content;
else
return $content;
}
function create_password($name, $value, $params = '', $echo = false) {
$content = "<input type='password' name='$name' value='$value' ";
$content .= $this->generate_params_list($params);
$content .= ' class="password-field" />';
if ($echo)
echo $content;
else
return $content;
}
function create_hidden($name, $value, $params = '', $echo = false) {
$content = '<input type="hidden" name="' . $name . '" value="' . str_replace('"', "'", $value) . '" ';
$content .= $this->generate_params_list($params);
$content .= "/>";
if ($echo)
echo $content;
else
return $content;
}
function create_textarea($name, $value, $params = '', $echo = false) {
$content = "<textarea name='$name' ";
$content .= $this->generate_params_list($params);
$content .= ">" . $value . "</textarea>";
if ($echo)
echo $content;
else
return $content;
}
function create_radio($name, $value, $params = '', $checked = false, $echo = false) {
$content = '<input type="radio" name="' . $name . '" value="' . str_replace('"', "'", $value) . '" ';
if ($checked)
$content .= 'checked ';
$content .= $this->generate_params_list($params);
$content .= ' class="radio-field" />';
if ($echo)
echo $content;
else
return $content;
}
function create_checkbox($name, $value, $params = '', $checked = false, $echo = false) {
$value = str_replace('"', "'", $value);
if ($value != '')
$content = '<input type="checkbox" name="' . $name . '" value="' . $value . '" ';
else
$content = '<input type="checkbox" name="' . $name . '" ';
if ($checked)
$content .= 'checked ';
$content .= $this->generate_params_list($params);
$content .= ' class="checkbox-field" />';
if ($echo)
echo $content;
else
return $content;
}
function create_select($name, $value, $params = '', $options, $echo = false) {
$content = '<select name="' . $name . '" ';
if (isset($this->tooltips_array[$name])) {
$content .= 'title="' . addslashes($this->tooltips_array[$name]) . ' "';
}
$content .= $this->generate_params_list($params);
$content .= ' class="select-field">';
//$content .= "<option value=''>Any</option>";
if (is_array($options)) {
if (array_key_exists('Any', $options)) {
$content .= "<option value=''>Any</option>";
unset($options['Any']);
}
foreach ($options as $key => $val) {
if ($key == $value)
$content .= '<option value="' . str_replace('"', "'", $key) . '" selected>' . $val . '</option>';
else
$content .= '<option value="' . str_replace('"', "'", $key) . '">' . $val . '</option>';
}
}
else {
$content .= '<option value="' . str_replace('"', "'", $options) . '">' . $options . '</option>';
}
$content .= "</select>";
if ($echo)
echo $content;
else
return $content;
}
function create_multiselect($name, $value, $params = '', $options, $echo = false) {
$content = '<select MULTIPLE name="' . $name . '[]" ';
if (isset($this->tooltips_array[$name])) {
$content .= 'title="' . addslashes($this->tooltips_array[$name]) . ' "';
}
if (!is_numeric($params['size']))
$params['size'] = 5;
$content .= $this->generate_params_list($params);
$content .= ' class="multiselect-field">';
//$content .= "<option value=''>Any</option>";
if (is_array($options)) {
if (array_key_exists('Any', $options)) {
$content .= "<option value=''>Any</option>";
unset($options['Any']);
}
foreach ($options as $key => $val) {
if ($key == $value)
$content .= '<option value="' . str_replace('"', "'", $key) . '" selected>' . $val . '</option>';
else
$content .= '<option value="' . str_replace('"', "'", $key) . '">' . $val . '</option>';
}
}
else {
$content .= '<option value="' . str_replace('"', "'", $options) . '">' . $options . '</option>';
}
$content .= "</select>";
if ($echo)
echo $content;
else
return $content;
}
function create_selectgroup($name, $value, $params = '', $options, $echo = false) {
$content = '<select name="' . $name . '" ';
$content .= $this->generate_params_list($params);
$content .= ' class="selectgroup-field" >';
$content .= "<option value=''>Any</option>";
if (is_array($options)) {
for ($i = 0; $i < count($options); $i++) {
$content .= '<optgroup label="' . $options[$i]['groupname'] . '">';
if (is_array($options[$i]['options'])) {
foreach ($options[$i]['options'] as $key => $val) {
if ($key == $value)
$content .= '<option value="' . str_replace('"', "'", $key) . '" selected>' . $val . '</option>';
else
$content .= '<option value="' . str_replace('"', "'", $key) . '">' . $val . '</option>';
}
}
$content .= "</optgroup>";
}
}
else {
$content .= '<option value="' . str_replace('"', "'", $options) . '">' . $options . '</option>';
}
$content .= "</select>";
if ($echo)
echo $content;
else
return $content;
}
function create_submit($name, $value, $params = '', $echo = false, $normal = false) {
global $config;
if ($normal === false) {
$content = '
<button class="button_colour round_all" name="' . $name . '" ';
if (!isset($params['type'])) {
$content .= 'type="submit" ';
}
$content .= $this->generate_params_list($params);
$content .= '>
<img style="width:24px; height:24px; float:left;" src="' . $config['wpradmin_baseurl'] . 'images/icons/small/white/bended_arrow_right.png" alt="">
<span>' . str_replace('"', "'", $value) . '</span>
</button>';
} else {
if ($name != '')
$content = '<input type="submit" name="' . $name . '" value="' . str_replace('"', "'", $value) . '" ';
else
$content = '<input type="submit" value="' . str_replace('"', "'", $value) . '" ';
$content .= $this->generate_params_list($params);
$content .= "/>";
}
if ($echo)
echo $content;
else
return $content;
}
function create_button($name, $value, $params = '', $echo = false) {
global $config;
$content = '
<button class="button_colour round_all" name="' . $name . '" ';
$content .= $this->generate_params_list($params);
$content .= '>
<img style="width:24px; height:24px; float:left;" src="' . $config['wpradmin_baseurl'] . 'images/icons/small/white/bended_arrow_right.png" alt="">
<span>' . str_replace('"', "'", $value) . '</span>
</button>';
if ($echo)
echo $content;
else
return $content;
}
function create_file($name, $params = '', $echo = false) {
if ($name != '')
$content = '<input type="file" name="' . $name . '" ';
else
$content = '<input type="file" ';
$content .= $this->generate_params_list($params);
$content .= "/>";
if ($echo)
echo $content;
else
return $content;
}
function GenerateField($field_type, $field_name, $field_value, $field_options, $request, $mode = 'normal', $params = false) {
$return = false;
if ($mode == 'serialize') {
$options = unserialize($field_options);
} elseif ($mode == 'explode') {
$options = explode("|", $field_options);
} elseif ($mode == 'explode_kv') {
$temp = explode("|", $field_options);
for ($i = 0; $i < count($temp); $i = $i + 2) {
$options[$temp[$i]] = $temp[$i + 1];
}
} else
$options = $field_options;
$field_type = strtolower($field_type);
switch ($field_type) {
case 'password':
$return = $this->create_password($field_name, '', $params);
break;
case 'select':
if (is_array($options)) {
$tab_opt['select'] = 'Select';
foreach ($options as $key => $value)
$tab_opt[$key] = $value;
$return .= $this->create_select($field_name, $field_value, $params, $tab_opt);
}
break;
case 'radio':
if (is_array($options)) {
foreach ($options as $key => $value) {
$check = false;
if (isset($request[$field_name]))
if ($request[$field_name] == $key)
$check = true;
$return .= $this->create_radio($field_name, $key, $params, $check) . $value;
}
}
break;
case 'checkbox':
if (is_array($options)) {
foreach ($options as $key => $value) {
$check = false;
if (isset($request[$field_name])) {
if (!is_array($request[$field_name])) {
$request[$field_name] = explode("|", $request[$field_name]);
}
if (in_array($key, $request[$field_name])) {
$check = true;
}
}
$return .= $this->create_checkbox($field_name . "[]", $key, $params, $check) . $value;
}
}
break;
case 'textarea':
$return = $this->create_textarea($field_name, $field_value, $params);
break;
default:
$return = $this->create_text($field_name, $field_value, $params);
break;
}
if ($return === false) {
echo $field_options;
}
return $return;
}
}
?>