<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class walkscoreClass{
function GetAddressFromListing($listing_id)
{
global $dbClass,$config;
$sql = "SELECT * FROM ".$config['table_prefix']."listingsdb WHERE listingsdb_id='".$listing_id."' LIMIT 1";
$reInfo = $dbClass->Query($sql,true);
if($reInfo->recordCount()>0)
{
require_once($config['wpradmin_basepath'].'include/controlpanel.inc.php');
$controlpanel = registry::register('controlpanelClass');
$settings = $controlpanel->GetControlPanelFields();
if($reInfo->fields[$settings['controlpanel_map_address']]!="")
$address[]  = $reInfo->fields[$settings['controlpanel_map_address']];
if($reInfo->fields[$settings['controlpanel_map_city']]!="")
$address[]  = $reInfo->fields[$settings['controlpanel_map_city']];
if($reInfo->fields[$settings['controlpanel_map_state']]!="")
$address[]  = $reInfo->fields[$settings['controlpanel_map_state']];
if($reInfo->fields[$settings['controlpanel_map_zip']]!="")
$address[]  = $reInfo->fields[$settings['controlpanel_map_zip']];
$ret_address = "";
for($i=0;$i<count($address);$i++)
{
if($address[$i]!="")
$ret_address .= $address[$i];
if($i<count($address)-1)
$ret_address .= ",";
}
if($ret_address=="")
return false;
else
return $ret_address;
}
else
return false;
}
function GenerateWalkScore($listing_id,$params)
{
global $config;
$width = 600;
$height =286;
if(isset($params['width']))
$width = $params['width'];
if(isset($params['height']))
$height = $params['height'];
//if Walkscore turn off
require_once($config['wpradmin_basepath']."include/controlpanel.inc.php");
$cP = registry::register('controlpanelClass');
$settings = $cP->GetControlPanelFields();
if($settings['controlpanel_walkscore']==0)
{
$content = "
<script type='text/javascript'>
jQuery(document).ready(function()
{
jQuery('a').each(function()
{
if(jQuery(this).attr('href')=='#walkscore')
{
jQuery(this).closest('li').remove();
}
});
});
</script>";
return $content;
}
if($address=$this->GetAddressFromListing($listing_id))
{
$content = "
<script type='text/javascript'>
var ws_wsid = '".$config['walkscorekey']."';
var ws_address = '".$address."';
var ws_width = '".$width."';
var ws_height = '".$height."';
var ws_layout = 'horizontal';
</script>
<style type='text/css'>
#ws-walkscore-tile{position:relative;text-align:left}
#ws-walkscore-tile *{float:none;}
#ws-footer a,
#ws-footer a:link{font:11px Verdana,Arial,Helvetica,sans-serif;margin-right:6px;white-space:nowrap;padding:0;color:#000;font-weight:bold;text-decoration:none}
#ws-footer a:hover{color:#777;text-decoration:none}#ws-footer a:active{color:#b14900}
</style>
<div id='ws-walkscore-tile' style='background-color:red'>
<div id='ws-footer' style='position:absolute;top:".($height-20)."px;left:8px;width:".($width-12)."px'>
<form id='ws-form'>
<a id='ws-a' href='http://www.walkscore.com/' target='_blank'>Find out your home's Walk Score:</a>
<input type='text' id='ws-street' style='position:absolute;top:0px;left:225px;width:331px' />
<input type='image' id='ws-go' src='http://www2.walkscore.com/images/tile/go-button.gif' height='15' width='22' border='0' alt='get my Walk Score' style='position:absolute;top:0px;right:0px' />
</form>
</div>
</div>
<script type='text/javascript' src='http://www.walkscore.com/tile/show-walkscore-tile.php'>
</script>";
return $content;
}
return false;
}
}
?>