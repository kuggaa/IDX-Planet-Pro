<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class rssClass
{
var $cp_settings = false;
function get_remote_setting(){
global $config;
if($this->cp_settings === false || !is_array($this->cp_settings)){
require_once($config['wpradmin_basepath']."include/controlpanel.inc.php");
$controlClass = new controlpanelClass();
$this->cp_settings = $controlClass->GetControlPanelFields();
}
//return $this->cp_settings["controlpanel_masterdb_bool"]
//var_dump($this->cp_settings["controlpanel_masterdb_bool"]);
}
function ParseRSSTemplate($tab_rss,$type='last',$other_template=false,$linkDelete=false)
{
//var_dump(($tab_rss));die();
global $config;  
/*$s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s"  : "";
$protocol = $this->strleft(strtolower($_SERVER["SERVER_PROTOCOL"]), "/").$s;
$port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);
$config['baseurl'] = $protocol."://".$_SERVER['SERVER_NAME'].$port."/";
echo $config['baseurl'];*/
require_once($config['wpradmin_basepath']."include/parse.inc.php");
//$parseClass = registry::register('parseClass');
$parseClass = new parseClass();
if($other_template===false){
$template_path = $config['wpradmin_basepath'].'/'.$config['template_dir'].'/'.$config['rss_template'];
//echo 'tpl path'.$template_path.'<br>';
$template_rss = $parseClass->GetTemplate($template_path);
}
else{
$template_rss = $parseClass->GetTemplate($other_template);
//echo 'tpl_rss'.$template_rss." other -> ".$other_template;
}
//echo $template_rss;die();
$block_rss = $parseClass->GetTemplateBlock('rss_listing_block',$template_rss);
//echo'/////////////////////////////////';die();
//echo $block_rss;
//var_dump($block_rss);die();
$block = "";
//echo $tab_rss[0]['listingsdb_id'];die();
for($i=0;$i<count($tab_rss);$i++)
{
//$block .= $block_rss['content'];
$block .= $parseClass->MainParse($block_rss['content'],$tab_rss[$i]['listingsdb_id'],true);
//echo $block;
}
$template_rss = $parseClass->ReplaceTemplateBlock('rss_listing_block',$block,$template_rss);
//echo $template_rss;die();
if($type=='last')
{
$template_rss = str_replace("{rss_title}","Last Modified Listing Feed",$template_rss);
} elseif($type=='featured')
{
$template_rss = str_replace("{rss_title}","Featured Listings",$template_rss);
}
elseif($type=='subscribe')
{
$template_rss = str_replace("{rss_title}","RSS Subscribe Listings",$template_rss);
}
if($linkDelete)
{
$template_rss = preg_replace("#<link>.*?</link>\s*#is","",$template_rss);
}
//$template_rss = str_replace("{rss_webroot}","http://www.google.pl",$template_rss);
//echo $template_rss;
//$template_rss = str_replace("{rss_listing_guid}",,$template_rss);
//$template_rss = str_replace("{rss_title}","Last Modified Listing Feed",$template_rss);
//$template_rss = $parseClass->MainParse($template_rss);
//$template_rss = str_replace("&","&amps;",$template_rss);
return trim($template_rss);
}
function GetLastModifiedListings()
{
global $dbClass,$config;
$sql = "SELECT * FROM ".$config['table_prefix']."listingsdb ORDER BY listingsdb_last_modified DESC LIMIT 0,".$config['rss_limit_lastmodified'];
//die($sql);
$reRSS = $dbClass->Query($sql,true);
//var_dump($reRSS);die();
$tab_rss = array();
if($reRSS->recordCount()>0)
{
while(!$reRSS->EOF)
{
$tab_rss[] = $reRSS->fields;
$reRSS->MoveNext();
}
}
//var_dump($tab_rss);die();
return $this->ParseRSSTemplate($tab_rss,'last');
}
function GetFeaturedListings()
{
global $dbClass,$config;
$sql = "SELECT * FROM ".$config['table_prefix']."listingsdb WHERE  listingsdb_featured='yes' LIMIT 0,".$config['rss_limit_featured'];
$reRSS = $dbClass->Query($sql,true);
$tab_rss = array();
if($reRSS->recordCount()>0)
{
while(!$reRSS->EOF)
{
$tab_rss[] = $reRSS->fields;
$reRSS->MoveNext();
}
}
return $this->ParseRSSTemplate($tab_rss,'featured');
}
function GetSubscribeListings($tab_rss,$rss_template)
{
global $config;
//$this->get_remote_setting();
for($i=0;$i<count($tab_rss);$i++)
{
$ret_tab[$i]['listingsdb_id'] = $tab_rss[$i];
}
return $this->ParseRSSTemplate($ret_tab,'subscribe',$rss_template);
}
}
?>