<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
header('Access-Control-Allow-Origin: *');
//var_dump($config);die();
error_reporting(E_ALL ^ E_NOTICE);
if (!$config) {
//include_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))).'/wpradmin/config.php');
}
global $config;
global $dbClass;
//$dbClass->GetOneRow($sql);
?>
<head>
<!--<link rel='stylesheet' id='colors-css'  href='../css/all.css' type='text/css' media='all' />-->
<!--<link rel='stylesheet' id='colors-css'  href='../css/wprealty.css' type='text/css' media='all' />-->
<link rel='stylesheet' id='colors-css'  href='../css/listingbox.css' type='text/css' media='all' />
</head>
<body>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
<!-- Load JQuery UI -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
<script src="../js/jquery.livequery.js"></script>
<form class="media_buttons" id="theform" method="POST">
<h3 class="media-title"><img src="../images/admin_content.png" /> Listings Box</h3>
<?php
$config_src = base64_decode(str_replace("/", "__", $_GET['config']));
//echo $config_src;die();
if (file_exists($config_src)) {
unset($config);
require_once($config_src);
} else
die();
//include_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))).'/wpradmin/config.php');
//var_dump($config);die();
//$db = new dbClass();
//$db->GetOneRow($sql);
require_once('listingsearch_func.php');
require_once('listingfields.inc.php');
$listignFields = registry::register('ListingFields');
if (isset($_POST['generate_code'])) {
media_buttons_send_to_editor($_POST['generate_code']);
}
$fields = $listignFields->GetShortcodeListingFields();
//var_dump($config);die(); // $config should be live here
//echo $config['basepath'].'mbx/Modules/MapSearch/scripts/remote-map.js';die();
if(file_exists($config['basepath'].'mbx/Modules/MapSearch/scripts/remote-map.js')){
$sql = 'SELECT value FROM ' . $config['table_prefix'] . "mapsearch_settings WHERE configKey = 'gmap_key'";
$db = new dbClass();
global $db_data;
$conn = $db->ConnectBase($db_data["db_host"], $db_data["user"], $db_data["password"], $db_data["db_name"]);
$res = $db->GetOneRow($sql);
//echo $res['value'];
$sql = 'SELECT value FROM ' . $config['table_prefix'] . "mapsearch_settings WHERE configKey = 'ctr-lat'";
$ctrlat = $db->GetOneRow($sql);
$sql = 'SELECT value FROM ' . $config['table_prefix'] . "mapsearch_settings WHERE configKey = 'ctr-lng'";
$ctrlng = $db->GetOneRow($sql);
$sql = 'SELECT value FROM ' . $config['table_prefix'] . "mapsearch_settings WHERE configKey = 'zoom'";
$zoom = $db->GetOneRow($sql);
}
?>
<script src="https://maps.googleapis.com/maps/api/js?libraries=drawing&key=<?php echo $res['value']; ?>"></script>
<script src="/wp-content/plugins/wp-realty/js/listingbox_map.js"></script>
<script>var MBX = {};
MBX.ctrLat = <?php echo $ctrlat['value']; ?>;
MBX.ctrLng = <?php echo $ctrlng['value']; ?>;
MBX.zoom = <?php echo $zoom['value']; ?>;</script>
<div class="wpr_form">
<form id="theform" method="POST">
<a href="#" id="map_select" class="maptool button">Use Mapping Tool</a>
<div id="map-div" style="border: 1px solid black; height: 500px; width:100%;display:none"></div>
<table cellpadding="5">
<tr>
<td style="vertical-align: text-bottom;">RSS <img src ="<?php echo $config['wpradmin_baseurl'] . "images/rss.png"; ?>" /></td>
<td><select id="rss">
<option value="1">Yes</option>
<option value="0" selected>No</option>
</select>
</td>
</tr>
<tr id="template_rss_tr" style="display: none;">
<td> RSS Template </td>
<td><?php echo GenerateTemplateSelect('template_rss', $config['basepath'] . $config['template_dir'] . '/sc_templates/'); ?> <a href="#" class="preview button" id="create_new_template_rss">Create New RSS Template</a></td>
</tr>
<tr id="create_new_template_rss_div" style="display: none;">
<td colspan="2"><table cellpadding="0">
<tr>
<td colspan="2" id="create_result_rss"></td>
</tr>
<tr>
<td colspan="2">File Name:
<input type="text" name="file_name" id="file_name_rss"/>
.php </td>
</tr>
<tr valign="top">
<td>Content:</td>
<td>&nbsp;</td>
</tr>
<tr valign="top">
<td><textarea id="file_content_rss" cols="30" rows="10"></textarea></td>
</tr>
<tr>
<td colspan="2"><a href="#" class="preview button"  id="new_template_rss_submit" tabindex="4">Create RSS Template</a></td>
</tr>
</table></td>
</tr>
<!--  <tr>
<td>Featured:</td>
<td><select name="featured" id="featured">
<option value="0">No</option>
<option value="1">Yes</option>
</select>
</td>
</tr>-->
<!--tr>
<td>Custom:</td>
<td><select name="custom" id="custom">
<option value="0">No</option>
<option value="1">Yes</option>
</select>
</td>
</tr-->
<tr id="template_tr">
<td> Custom Template </td>
<td><?php echo GenerateTemplateSelectWithDefault('template', $config['basepath'] . $config['template_dir'] . '/sc_templates/'); ?> <a href="#" class="preview button" id="create_new_template">Create New Custom Template</a></td>
</tr>
<tr id="create_new_template_div" style="display: none;">
<td colspan="2"><table cellpadding="0">
<tr>
<td colspan="2" id="create_result"></td>
</tr>
<tr>
<td colspan="2">File Name:
<input type="text" name="file_name" id="file_name"/>
.php </td>
</tr>
<tr valign="top">
<td>Content:</td>
<td><b>Example:</b></td>
</tr>
<tr valign="top">
<td><textarea id="file_content" cols="30" rows="10"></textarea></td>
<td><span style="font-size: 12px;"> &lt;table border="1"&gt;<br />
{repeat_row_block}<br />
&lt;tr&gt;<br />
{repeat_in_row_block repeat="4"}<br />
&lt;td&gt;<br />
&nbsp;<br />
&nbsp;&nbsp;&lt;a href="{featured_url}"&gt;<br />
&nbsp;&nbsp;{featured_img_block}&lt;img src="{featured_thumb_src}"<br />
&nbsp;height="{featured_thumb_height}" width="{featured_thumb_width}" <br />
&nbsp;alt="{lang_click_to_learn_more}" /&gt;&lt;br /&gt;{/featured_img_block}<br />
&nbsp;&nbsp;&lt;strong&gt;{listing_title}&lt;/strong&gt;&lt;/a&gt;<br />
&nbsp;&nbsp;&lt;br /&gt;&lt;br /&gt;<br />
<br />
&lt;/td&gt;<br />
{/repeat_in_row_block}<br />
&lt;/tr&gt;<br />
{/repeat_row_block}<br />
&lt;/table&gt;<br />
<br />
</span></td>
</tr>
<tr>
<td colspan="2"><a href="#" class="preview button"  id="new_template_submit" tabindex="4">Create template</a></td>
</tr>
</table></td>
</tr>
<tr>
<td>Sort type:</td>
<td><select id="sort_type" name="sort_type">
<option value='LOCAL'>Random</option>
<option value='GLOBAL'>Static</option>
</select>
</td>
</tr>
<!--<tr>
<td colspan="2"><button id="map_select">Use Mapping Tool</button></td>
</tr>
<tr id="map-row" style="display:block">
<td colspan="10">
<div id="map-div" style="border: 1px solid black; height: 500px; width:100%;"></div>
</td>
</tr>-->
<tr>
<td>Pagination:</td>
<td><select id="pagination" name="pagination">
<option value='0'>All</option>
<option value='10'>10</option>
<option value='20'>20</option>
<option value='50'>50</option>
<option value='100'>100</option>
</select>
</td>
</tr>
<tr>
<td>Order by:</td>
<td><?php echo GenerateFieldsSelect('orderby', $fields, 'orderbyo', True); ?> </td>
</tr>
<tr>
<td>Order Dir:</td>
<td><select id="orderdir" name="orderdir">
<option value='ASC'>ASC</option>
<option value='DESC'>DESC</option>
</select></td>
</tr>
<td>Count:</td>
<td><input type="text" name="count" id="count" value="3"/></td>
<td>&nbsp;</td>
</tr>
<tr>
<td>Field Type:</td>
<td><?php echo GenerateFieldsSelect('fields', $fields, 'option'); ?> <a href="#" class="preview button" id="add_field">Add Field</a></td>
</tr>
</table>
<br />
<hr />
<br />
<table id="fields_tab">
</table>
<input type="hidden" id="generate_code" name="generate_code"/>
<input type="submit" value="Generate" id="generate_sumbit"/>
</form>
</div>
<script type="text/javascript">
function select_template(name) {
jQuery("#template_field").val(name);
jQuery("#theform").submit();
}
jQuery(document).ready(function () {
//jQuery("#template").attr('disabled','disabled');
//jQuery("#template_tr").hide();
jQuery("#create_new_template").click(function ()
{
jQuery("#create_new_template_div").toggle();
});
jQuery("#create_new_template_rss").click(function ()
{
jQuery("#create_new_template_rss_div").toggle();
});
jQuery("#new_template_submit").click(function ()
{
var file_content = jQuery("#file_content").attr('value');
var file_name = jQuery("#file_name").attr('value');
jQuery.get('<?php echo $config['baseurl']; ?>ajax.php', {f: 'create_template.php', file: file_name, content: file_content}, function (data) {
if (data == "0")
jQuery("#create_result").html('<b style="color:red">Field Template Name must be filled</b>');
else if (data == "1")
jQuery("#create_result").html('<b style="color:red">Template file already exists</b>');
else if (data == "2")
jQuery("#create_result").html('<b style="color:red">Field Content must be filled</b>');
else if (data == "3")
jQuery("#create_result").html('<b style="color:red">Failed to create template directory </b>');
else if (data == "4")
jQuery("#create_result").html('<b style="color:red">Failed to create template file</b>');
else {
jQuery("#create_new_template_div").hide();
jQuery("#file_content").attr('value', '');
jQuery("#file_name").attr('value', '');
jQuery("#create_result").text('');
jQuery("#template").append("<option value='" + data + "' selected='selected'>" + data + "</option>");
}
});
});
jQuery("#new_template_rss_submit").click(function ()
{
var file_content = jQuery("#file_content_rss").attr('value');
var file_name = jQuery("#file_name_rss").attr('value');
$.get('<?php echo $config['wpradmin_baseurl']; ?>ajax.php', {f: 'create_template.php', file: file_name, content: file_content}, function (data) {
if (data == "0")
jQuery("#create_result_rss").html('<b style="color:red">Field Template Name must be filled</b>');
else if (data == "1")
jQuery("#create_result_rss").html('<b style="color:red">Template file already exists</b>');
else if (data == "2")
jQuery("#create_result_rss").html('<b style="color:red">Field Content must be filled</b>');
else if (data == "3")
jQuery("#create_result_rss").html('<b style="color:red">Failed to create template directory </b>');
else if (data == "4")
jQuery("#create_result_rss").html('<b style="color:red">Failed to create template file</b>');
else {
jQuery("#create_new_template_rss_div").hide();
jQuery("#file_content_rss").attr('value', '');
jQuery("#file_name_rss").attr('value', '');
jQuery("#create_result_rss").text('');
jQuery("#template_rss").append("<option value='" + data + "' selected='selected'>" + data + "</option>");
}
});
});
/*jQuery("#custom").change(function()
{
if(jQuery(this).attr('value')=="1")
{
jQuery("#template").attr('disabled','');
jQuery("#template_tr").show();
}
else
{
jQuery("#template").attr('disabled','disabled');
jQuery("#template_tr").hide();
}
});*/
jQuery("#rss").change(function ()
{
if (jQuery(this).attr('value') == "1")
{
jQuery("#template_rss_tr").show();
}
else
{
jQuery("#template_rss_tr").hide();
}
});
jQuery("#add_field").click(function ()
{
var id = jQuery("#fields").attr('value');
var temp_option;
var option_id;
jQuery("#fields option").each(function ()
{
if (jQuery(this).attr('value') == id)
{
option_id = jQuery(this).attr('id');
temp_option = option_id.split('_');
temp_option = temp_option[1];
}
});
if (jQuery("#" + option_id).attr('disabled') == false)
{
jQuery("#" + option_id).attr('disabled', 'disabled');
$.ajax({
url: "<?php echo $config['baseurl']; ?>ajax.php",
type: "GET",
data: {f: 'searchvalues.php', field: id, number: temp_option},
success: function (html) {
$("#kalorie_dnia").append(html);
}
});
jQuery.get('<?php echo $config['baseurl']; ?>ajax.php', {f: 'searchvalues.php', field: id, number: temp_option}, function (data) {
var max_length = 12;
if (id.length > max_length)
shortname = id.substr(0, max_length) + "...";
else
shortname = id;
jQuery("#fields_tab").append("<tr id=trfield_" + temp_option + "><td><b id='bid_" + temp_option + "' class='namefields'><input type='hidden' id='name_" + temp_option + "' value='" + id + "'>" + shortname + "</b></td><td>" + data + "</td></tr>");
});
}
});
jQuery(".adelclass").livequery('click', function () {
var id_del_field = this.id.split('_');
var div_content = jQuery("#fields_tab").html();
id_del_field = id_del_field[1];
var field_name = jQuery("#bid_" + id_del_field).text();
jQuery("#trfield_" + id_del_field).remove();
jQuery("#fields option").each(function ()
{
if (jQuery(this).attr('value') == field_name)
{
jQuery(this).attr('disabled', '');
}
});
});
jQuery(".avalclass").livequery('click', function () {
var id_add_value = this.id.split('_');
id_add_value = id_add_value[1];
var content_value = jQuery("#selectval_" + id_add_value).attr('value');
content_value = jQuery("#field_" + id_add_value).attr('value') + content_value;
jQuery("#field_" + id_add_value).attr('value', content_value + "|");
});
jQuery("#generate_sumbit").click(function ()
{
var counter = 0;
var fields;
var values;
var temp;
var temp_field;
var generate_code;
fields = new Array();
values = new Array();
counter = 0;
jQuery(".namefields").each(function ()
{
var id_field = this.id.split("_");
id_field = id_field[1];
temp = jQuery("#field_" + id_field).attr('value');
if (temp[temp.length - 1] == "|")
temp = temp.substring(0, temp.length - 1);
if (temp[0] == "|")
temp = temp.substring(1, temp.length);
values[counter] = temp;
temp = temp.split("|");
temp_field = jQuery("#name_" + id_field).attr("value");
if (temp.length > 1)
{
temp_field = temp_field + "(" + temp.length + ")";
}
fields[counter] = temp_field;
counter++;
});
generate_code = '[shortcode fields=\"';
for (i = 0; i < fields.length; i++)
{
generate_code += fields[i];
if (i < fields.length - 1)
generate_code += "|";
}
generate_code += "\" values=\"";
for (i = 0; i < values.length; i++)
{
generate_code += values[i];
if (i < fields.length - 1)
generate_code += "|";
}
generate_code += '\" ';
if (jQuery("#featured").attr('value') == '1')
generate_code += ' featured=\"true\" ';
if (jQuery("#template").attr('disabled') == "")
{
generate_code += ' template=\"' + jQuery("#template").attr('value') + '\" ';
}
if (jQuery("#orderby").attr('value') != "none")
{
generate_code += ' orderby=\"' + jQuery("#orderby").attr('value') + '\"';
generate_code += ' orderdir=\"' + jQuery("#orderdir").attr('value') + '\"';
}
generate_code += ' sort_type=\"' + jQuery("#sort_type").attr('value') + '\"';
if (jQuery("#pagination").attr('value') != "0")
generate_code += ' pagination=\"' + jQuery("#pagination").attr('value') + '\"';
generate_code += ' count=\"' + jQuery("#count").attr('value') + '\"';
if (jQuery("#template_rss").attr('value') != "default" && jQuery("#rss").attr("value") == "1")
generate_code += ' rss_temp=\"' + jQuery("#template_rss").attr('value') + '\" ';
if (jQuery("#rss").attr('value') == "1")
generate_code += ' rss=\"yes\"';
// Insert polygon value
if(formPolygon.length)
generate_code += ' polygon=\"' + formPolygon + '\" ';
generate_code += "]";
// mm 10-9-15 debug generated
//alert(generate_code);
jQuery("#generate_code").attr('value', generate_code);
jQuery("#theform").submit();
});
});
</script>
</form>
</body>
