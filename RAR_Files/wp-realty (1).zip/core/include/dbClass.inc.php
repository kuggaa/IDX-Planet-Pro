<?php

/*
 * Commercial Codebase by WP Realty - RETS PRO Development Team.
 * Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
 * License: http://retspro.com/faq/license/
 */

Class dbClass {

    var $connectionLink;
    var $masterDB_connectionLink;
    var $connection_database;
    var $masterDB_connection_database;
    var $mode; // 0 -> filter all data, 1 -> oppositive 0
    var $debug_mode;
    var $debug_file;

    function __construct() {
        $this->mode = 0;
        $this->masterDB_connectionLink = false;
        $this->debug_mode = false;
    }

    function destruct() {
        if ($this->connectionLink !== false)
            mysqli_close($this->connectionLink);
        if ($this->masterDB_connectionLink !== false)
            mysqli_close($this->masterDB_connectionLink);
    }

    function SetDebugFile($file) {
        $this->debug_file = $file;
    }

    function ConnectBase($db_server, $db_user, $db_password, $db_database) {
        $connection = mysqli_connect($db_server, $db_user, $db_password);
        if ($connection === false)
            return false;
        if ($this->SelectDB($db_database, $connection) === false)
            return false;
        $this->connection_database = $db_database;
        $this->connectionLink = $connection;
        return $connection;
    }

    function SelectDB($db_database, $connection) {
        if (mysqli_select_db($connection, $db_database) === false)
            return false;
        return true;
    }

    function ConnectMasterDB($db_server, $db_user, $db_password, $db_database) {
        if (!$connection = @mysqli_connect($db_server, $db_user, $db_password))
            return false;
        if ($this->SelectDB($db_database, $connection) === false)
            return false;
        $this->masterDB_connection_database = $db_database;
        $this->masterDB_connectionLink = $connection;
        return true;
    }

    function ChangeDebugMode($debug_mode) {
        if ($debug_mode === true)
            $this->debug_mode = true;
        else
            $this->debug_mode = false;
    }

    function ErrorConnect() {
        echo "error connect:" . $error;
    }

    function ErrorSelectDatabase() {
        echo "ErrorSelectDatabase";
    }

    function LastID($ismaster = false) {
        if ($ismaster)
            return mysqli_insert_id($this->masterDB_connectionLink);
        else
            return mysqli_insert_id($this->connectionLink);
    }

    function Query($sql, $master_bool = false, $debug = false) {
        global $config;
        $option_tab = $this->NormalDbOrMasterDbAutoChoose($sql, $master_bool);
        mysqli_query($option_tab['conID'], $option_tab['sql_use']);
        $result = mysqli_query($option_tab['conID'], $option_tab['sql']);
        if ($result !== false) {
            if($result === true || is_numeric($result))return $result;
            $recordSet = new RecordSet($option_tab['conID']);
            $recordSet->SetResultData($result);
            //mysql_free_result($result);
            if ($recordSet->recordCount() == 0) {
                $recordSet->SetFirstRecord();
                return $recordSet;
            } else {
                $recordSet->SetFirstRecord();
                return $recordSet;
            }
        } else {
            error_log('DB Error: ' . "\nQuery:\n" . $option_tab['sql'] . "\nError: " . mysqli_error($option_tab['conID']) . "\nBacktrace:\n" . var_export(debug_backtrace()));
            if ($debug === false)
                $this->log_error($option_tab['sql'], debug_backtrace(), $this->debug_mode);
            else
                $this->log_error($option_tab['sql'], $debug, $this->debug_mode);
            return false;
        }
    }

    function Query2($sql, $master_bool = false, $debug = false) {
        global $config;
        $option_tab = $this->NormalDbOrMasterDbAutoChoose($sql, $master_bool);
        /**
         * Dinesh - Monday, September 12, 2016, 01:57 PM
         * Implemented cache
         */
        $cacheId = md5(serialize($option_tab));
//        if (isset($GLOBALS[$cacheId]) && !is_admin())
//        {
//            $_SESSION['wp-realty-queries'][$cacheId]['QueryCount'] ++;
//            $GLOBALS[$cacheId]->EOF     = false;
//            $GLOBALS[$cacheId]->counter = 0;
//            $GLOBALS[$cacheId]->SetFirstRecord();
//
////            print_r($GLOBALS[$cacheId]);
//
//            return $GLOBALS[$cacheId];
//        }
# Store start time
        $t_start = 0;
        list($usec, $sec) = explode(" ", microtime());
        $t_start = ((float) $usec + (float) $sec);

        mysqli_query($option_tab['conID'], $option_tab['sql_use']);
        $result = mysqli_query($option_tab['conID'], $option_tab['sql']);
# Check end time
        $t_end = 0;
        list($usec, $sec) = explode(" ", microtime());
        $t_end = ((float) $usec + (float) $sec);
        if (!isset($_SESSION['wp-realty-queries'])) {
            $_SESSION['wp-realty-queries'] = [];
        }
        $option_tab = array_merge($option_tab, [
//            'QueryCount' => 1,
            'Time' => microtime(),
            'ExecTime' => ($t_end - $t_start),
            'QueryTime' => date('Y-M-d H:i:s'),
        ]);
        if (($t_end - $t_start) >= 1) {
            $option_tab = array_merge($option_tab, [
                'TooHigh' => 1
            ]);
        } elseif (($t_end - $t_start) >= .1) {
            $option_tab = array_merge($option_tab, [
                'High' => 1
            ]);
        }
        if (!isset($_SESSION['wp-realty-queries'][$cacheId])) {
            $_SESSION['wp-realty-queries'][$cacheId] = [];
            $_SESSION['wp-realty-queries'][$cacheId]['QueryCount'] = 0;
            $_SESSION['wp-realty-queries'][$cacheId]['Query'] = [];
        }
        $_SESSION['wp-realty-queries'][$cacheId]['QueryCount'] ++;
        $_SESSION['wp-realty-queries'][$cacheId]['Query'][] = $option_tab;
        if ($result !== false) {
            $recordSet = new RecordSet($option_tab['conID']);
            $recordSet->SetResultData($result);
            if ($recordSet->recordCount() == 0) {
                $recordSet->SetFirstRecord();
            } else {
                $recordSet->SetFirstRecord();
            }
            $GLOBALS[$cacheId] = $recordSet;
            return $recordSet;
        } else {
            error_log('DB Error: ' . "\nQuery:\n" . $option_tab['sql'] . "\nError: " . mysqli_error($this->connectionLink) . "\nBacktrace:\n" . var_export(debug_backtrace()));
            if ($debug === false)
                $this->log_error($option_tab['sql'], debug_backtrace(), $this->debug_mode);
            else
                $this->log_error($option_tab['sql'], $debug, $this->debug_mode);
            return false;
        }
    }

    function CronQuery($sql, $remote_db) {
        global $config;
        $option_tab = $this->NormalDbOrMasterDbAutoChoose($sql, $remote_db);
        mysqli_query($option_tab['conID'], $option_tab['sql_use']);
        $result = mysqli_query($option_tab['conID'], $option_tab['sql']);
        if ($result !== false) {
            $recordSet = new RecordSet($option_tab['conID']);
            $recordSet->SetResultData($result);
            //mysql_free_result($result);
            if ($recordSet->recordCount() == 0) {
                $recordSet->SetFirstRecord();
                return $recordSet;
            } else {
                $recordSet->SetFirstRecord();
                return $recordSet;
            }
        } else {
            error_log('DB Error: ' . "\nQuery:\n" . $option_tab['sql'] . "\nError: " . mysqli_error($option_tab['conID']) . "\nBacktrace:\n" . var_export(debug_backtrace()));
            if ($debug === false)
                $this->log_error($option_tab['sql'], debug_backtrace(), $this->debug_mode);
            else
                $this->log_error($option_tab['sql'], $debug, $this->debug_mode);
            return false;
        }
    }

    function DataFilters($data) {
//mail('Debug@YourEmailHere.com', 'gpc single', $data .' '.count($data));
        $data = stripslashes($data);
        if (!is_array($data))
            $data = mysqli_real_escape_string($this->connectionLink, $data);
        else
            $data = $this->DataFiltersArray($data);
        return $data;
    }

    function DataFiltersArray($data) {
//mail('Debug@YourEmailHere.com', 'gpc arr', $data .' '.count($data));
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_array($value)) {
                    $return[$key] = $this->DataFiltersArray($value);
                } else {
                    if (!is_string($value))
                        continue;
                    $value = stripslashes($value);
                    $return[$key] = mysqli_real_escape_string($this->connectionLink, $value);
                }
            }
            return $return;
        }
    }

    function AddSlashesFilter($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_array($value)) {
                    $return[$key] = $this->DataFiltersArray($value);
                } else {
                    $return[$key] = addslashes($value);
                }
            }
            return $return;
        }
    }

    function log_error($sql, $debug, $echo = false) {
        $out = "";
        $echo_out = "";
        $echo_out .= "<br><h3>Log Error</h3><div style='background: #EAEAEA'>";
        $echo_out .= "<strong>Debug Backtrace</strong><br>";
        $echo_out .= "&nbsp;&nbsp;File: " . $debug[0]['file'] . "<br>";
        $echo_out .= "&nbsp;&nbsp;Line:  " . $debug[0]['line'] . "<br>";
        $echo_out .= "<strong>SQL</strong>";
        $echo_out .= "<br>&nbsp;&nbsp;";
        $echo_out .= $sql;
        $echo_out .= "<br><strong>MySql Error</strong><br>&nbsp;&nbsp;";
        $echo_out .= mysqli_error($this->connectionLink);
        $echo_out .= "</div><hr>";
        $out .= "File: " . $debug[0]['file'] . "\n";
        $out .= "Line: " . $debug[0]['line'] . "\n";
        $out .= "SQL: " . $sql . "\n";
        $out .= "MySql Error: " . mysqli_error($this->connectionLink);
        if ($echo === true)
            echo $echo_out;
        if ($this->debug_file != "") {
            $f = fopen($this->debug_file, 'a');
            fwrite($f, $out . "\n---------------------------\n");
            fclose($f);
        }
    }

    function ColumnExists($table, $column, &$param = '', $masterdb = false) {
        $sql = "SHOW columns FROM " . $this->DataFilters($table);
        $recordSet = $this->Query($sql, $masterdb);
        if ($recordSet->recordCount() > 0) {
            while (!$recordSet->EOF) {
                if (strtolower($recordSet->fields['Field']) == strtolower($column)) {
                    $param = $recordSet->fields;
                    return true;
                }
                $recordSet->MoveNext();
            }
        }
        return false;
    }

    /*     * **********************************************************\
     *
      \*********************************************************** */

    function NormalDbOrMasterDbAutoChoose($sql, $master_bool = false) {
        global $config;
        $ret_tab = array();
        if ($master_bool AND $this->masterDB_connectionLink !== false) {
            if (strpos($sql, '{table_prefix}') !== false) {
                $replacement = $config['table_const_prefix'];
                $ret_tab['sql'] = str_replace("{table_prefix}", $replacement, $sql);
            } else {
                $ret_tab['sql'] = $sql;
            }
            $ret_tab['sql_use'] = "USE " . $this->masterDB_connection_database . ";";
            $ret_tab['conID'] = $this->masterDB_connectionLink;
        } else {
            /*
              if($config['mu_mode']==1)
              {
              $reg_access_table = "#".$config['table_prefix']."(\w+)#";
              if(preg_match($reg_access_table,$sql,$match))
              {
              if(in_array($match[1],$config['access_table']))
              {
              $replacement = $config['table_const_prefix'];
              $sql = str_replace("{table_prefix}",$replacement,$sql);
              }
              }
              }
             */
            if (strpos($sql, '{table_prefix}') !== false) {
                $replacement = $config['table_variable_prefix'];
                $ret_tab['sql'] = str_replace("{table_prefix}", $replacement, $sql);
            } else {
                $ret_tab['sql'] = $sql;
            }
            $ret_tab['sql_use'] = "USE " . $this->connection_database . ";";
            $ret_tab['conID'] = $this->connectionLink;
        }
        return $ret_tab;
    }

    function TableExists($table) {
        $sql = "SHOW tables";
        $debug_temp = $this->debug_mode;
        if ($debug_temp)
            $this->ChangeDebugMode(false);
        $reTables = $this->Query($sql);
        if ($debug_temp)
            $this->ChangeDebugMode($debug_temp);
        $option_tab = $this->NormalDbOrMasterDbAutoChoose($table);
        $table = $option_tab['sql'];
        if ($reTables !== false) {
            if ($reTables->recordCount() > 0) {
                foreach ($reTables->fields as $key => $value) {
                    $field = $key;
                    break;
                }
                while (!$reTables->EOF) {
//echo "1";
                    if ($table == $reTables->fields[$field]) {
                        return true;
                    }
                    $reTables->movenext();
                }
                return false;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    function GetColumns($table, $block_fields = false, $params = false, $masterdb = false) {
        $sql = "SHOW columns FROM " . $this->DataFilters($table);
        $recordSet = $this->Query($sql, $masterdb);
        if ($recordSet->recordCount() > 0) {
            $return_tab = array();
            while (!$recordSet->EOF) {
                if (is_array($block_fields)) {
                    if (!in_array($recordSet->fields['Field'], $block_fields)) {
                        if ($params === true)
                            $return_tab[] = $recordSet->fields;
                        else
                            $return_tab[] = $recordSet->fields['Field'];
                    }
                }
                else {
                    if ($params === true)
                        $return_tab[] = $recordSet->fields;
                    else
                        $return_tab[] = $recordSet->fields['Field'];
                }
                $recordSet->MoveNext();
            }
            return $return_tab;
        }
        return false;
    }

    function LastColumnInTable($table, $masterdb = false) {
        $sql = "SHOW columns FROM " . $this->DataFilters($table);
        $recordSet = $this->Query($sql, true, $masterdb);
        while (!$recordSet->EOF) {
            $recordSet->MoveNext();
        }
        return $recordSet;
    }

    /*     * **********************************************************\
     *
      \*********************************************************** */

    function AddColumn($table, $column, $param = 'varchar(100)') {
        $tab_param['primary_key'] = false;
        $tab_param['type'] = 'varchar(100)';
        $tab_param['not_null'] = false; // Dinesh, keep all field with null allowed
        $tab_param['after_column'] = false;
        $tab_param['first_column'] = false;
        if (is_array($param)) {
            foreach ($param as $key => $value) {
                $tab_param[$key] = $this->DataFilters($value);
            }
        } else
            $tab_param['type'] = $this->DataFilters($param);
        $primary_key = '';
        $not_null = '';
        if ($tab_param['primary_key'] == true)
            $primary_key = 'PRIMARY KEY';
        //if ($tab_param['not_null'] == true)
            //$not_null = 'NOT NULL';
        //else
            $not_null = 'NULL';
        $column_sql = '';
        if ($tab_param['after_column'] !== false) {
            $column_sql = "FIRST";
        } else {
            if ($tab_param['after_column'] !== false) {
                $column_sql = "AFTER " . $tab_param['after_column'];
            }
        }
        if ($this->ColumnExists($table, $column) === false) {
            $sql = "ALTER TABLE " . $this->DataFilters($table) . " ADD " . $this->DataFilters($column) . " " . $tab_param['type'] . " $not_null $primary_key $column_sql";
            return $this->Query($sql);
        } else
            return false;
    }

    /*     * **********************************************************\
     *
      \*********************************************************** */

    function ChangeColumn($table, $column, $param) {
        $tab_param['primary_key'] = false;
        $tab_param['type'] = '';
        $tab_param['not_null'] = false;
        $tab_param['new_column_name'] = '';
        $tab_param['after_column'] = false;
        $tab_param['first_column'] = false;
        if (is_array($param)) {
            foreach ($param as $key => $value) {
                $tab_param[$key] = $this->DataFilters($value);
            }
        } else
            $tab_param['type'] = $this->DataFilters($param);
        $primary_key = '';
        $not_null = '';
        if ($tab_param['primary_key'] == true)
            $primary_key = 'PRIMARY KEY';
        //if ($tab_param['not_null'] == true)
            //$not_null = 'NOT NULL';
        //else
            $not_null = 'NULL';
        if ($tab_param['new_column_name'] != '')
            $new_column_name = $tab_param['new_column_name'];
        else
            $new_column_name = $column;
        $column_sql = '';
        if ($tab_param['first_column'] !== false) {
            $column_sql = "FIRST";
        } else {
            if ($tab_param['after_column'] !== false) {
                $last_column_param = $this->LastColumnInTable($table);
                if ($last_column_param->fields['Field'] != $column)
                    $column_sql = "AFTER " . $last_column_param->fields['Field'];
            }
            elseif ($tab_param['after_column'] !== false)
                $column_sql = "AFTER " . $tab_param['after_column'];
        }
        if ($this->ColumnExists($table, $column, $param) !== false) {
            if ($tab_param['type'] == '')
                $tab_param['type'] = $param['Type'];
            $sql = "ALTER TABLE " . $this->DataFilters($table) . " CHANGE " . $this->DataFilters($column) . " $new_column_name " . $tab_param['type'] . " $not_null $primary_key $column_sql";
            return $this->Query($sql, false);
        } else
            return false;
    }

    function DeleteColumn($table, $column) {
        $sql = "ALTER TABLE " . $this->DataFilters($table) . " DROP " . $this->DataFilters($column);
        return $this->Query($sql, false);
    }

    function stripslashesarray($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_array($value)) {
                    $return[$key] = $this->stripslashesarray($value);
                } else {
                    $return[$key] = stripslashes($value);
                }
            }
            return $return;
        }
    }

    function GetResults($sql, $byid = false, $master_bool = false) {
        $re = $this->query($sql, $master_bool);
        if ($re->RecordCount() > 0) {
            $ret = array();
            while (!$re->EOF) {
                if ($byid !== false)
                    $ret[$re->fields[$byid]] = $re->fields;
                else
                    $ret[] = $re->fields;
                $re->MoveNExt();
            }
            return $ret;
        } else
            return false;
    }

    function GetOneRow($sql, $master_bool = false) {
//echo $sql;
        $debug = debug_backtrace();
        $re = $this->query($sql, $master_bool, $debug);
        if ($re->RecordCount() > 0) {
            return $re->fields;
        } else
            return false;
    }

}

/* * **********************************************************\
 *
  \*********************************************************** */

Class RecordSet {

    var $res;
    var $EOF;
    var $fields;
    var $counter;

    function __construct($conID) {
        $this->EOF = false;
        $this->counter = 0;
    }

    function __destruct() {
        mysqli_free_result($this->res);
    }

    function stripslashesarray($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_array($value)) {
                    $return[$key] = $this->stripslashesarray($value);
                } else {
                    $return[$key] = stripslashes($value);
                }
            }
            return $return;
        }
    }

    function SetResultData($result) {
        $this->res = $result;
    }

    function SetFirstRecord() {
        $this->MoveNext($this->res);
    }

    function MoveNext($result = false) {
        if ($result !== false) {
            $this->res = $result;
        }
        if ($this->counter < $this->recordCount()) {
            $result = mysqli_fetch_assoc($this->res);
            if ($result !== false) {
                $result = $this->stripslashesarray($result);
                $this->counter++;
                $this->fields = $result;
                return $this->fields;
            } else
                $this->EOF = true;
        } else
            $this->EOF = true;
    }

    function recordCount() {
        $result = mysqli_num_rows($this->res);
        if ($result !== false) {
            return $result;
        } else {
            $this->EOF = true;
            return false;
        }
    }

}

?>