<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
session_start();
class templateClass{
function GetTemplateDir()
{
global $config;
if(@$handle=opendir($config['basepath']."template/"))
{
$ret_tab = array();
while($dir = readdir($handle))
{
if(is_dir($config['basepath']."template/".$dir) AND $dir!='.' AND $dir!='..')
{
$ret_tab[] = $dir;
}
}
if(count($ret_tab)>0)
return $ret_tab;
else
return false;
}
else
return false;
}
function GetTemplateFile($dir)
{
if (is_dir($dir))
{
$dir = opendir($dir);
$i=0;
$y=0;
$tab_file = array();
while (($file = readdir($dir)) !== false) {
$file_parts = explode(".",$file);
if(count($file_parts)>0)
{
$ext = $file_parts[count($file_parts)-1];
if(($ext=="php"))
{
$tab_file['php'][$file]=$file;
$i++;
}
elseif($ext=="css")
{
$tab_file['css'][$file]=$file;
$y++;
}
}
}
return $tab_file;
}
return false;
}
function TemplateEditorWindow($request,$form_prefix,$actual_template)
{
global $config,$formsClass,$presentationClass,$jqueryscript,$dbClass,$UrlClass;
$content = "";
// Add New Template File
if(isset($request[$form_prefix.'createbutton']))
{
if($request[$form_prefix.'newfile_name']!="")
{
$new_name = $request[$form_prefix.'newfile_name'].".".$request[$form_prefix.'newfile_type'];
$new_name_with_dir = $actual_template."/".$new_name;
if(!file_exists($new_name_with_dir))
{
if($f = fopen($new_name_with_dir,"w"))
{
fclose($f);
$request[$form_prefix.'editfile'] = $new_name;
$content .= $presentationClass->OperationSuccessfull('Template File Created');
}
} else
$content .= $presentationClass->OperationFailed('Template File Already Exists');
}
else
$content .= $presentationClass->OperationFailed('You must fill filename');
}
// Edit Template
if(isset($request[$form_prefix.'editbutton']))
{
if($f = fopen($actual_template."/".$request[$form_prefix.'editfile'],"w"))
{
$t = $request[$form_prefix.'edit_file'];
$t = str_replace('\r\n',"[NLNL]",$t);
$t = stripslashes($t);
$t = str_replace("[NLNL]","\r\n",$t);
fwrite($f,$t);
fclose($f);
$content .= $presentationClass->OperationSuccessfull('Template File Edited');
}
} elseif($request[$form_prefix.'delbutton']==1)
{
$dname = $actual_template."/".$request[$form_prefix.'editfile'];
unset($request[$form_prefix.'editfile']);
if(file_exists($dname))
{
if(@unlink($dname))
{
$content .= $presentationClass->OperationSuccessfull("Template has been deleted");
} else
$content .= $presentationClass->OperationSuccessfull("Template hasn\'t been deleted");
}
} elseif(!isset($request[$form_prefix.'editsubmit']))
{
unset($request[$form_prefix.'editfile']);
}
$template_tab = $this->GetTemplateFile($actual_template);
if($template_tab['php']!=NULL)
ksort($template_tab['php']);
if($template_tab['css']!=NULL)
ksort($template_tab['css']);
$tab_file[] = array('groupname'=>"PHP Files",'options'=>$template_tab['php']);
$tab_file[] = array('groupname'=>"CSS Files",'options'=>$template_tab['css']);
$content_div = "";
$content_div .= $formsClass->startform();
$content_div .= "Name: ".$formsClass->create_text($form_prefix.'newfile_name','');
$content_div .= " Type: ".$formsClass->create_select($form_prefix.'newfile_type','','',array('php'=>'PHP','css'=>'CSS'));
$content_div .= " ".$formsClass->create_submit($form_prefix.'createbutton','Create',array('style'=>'margin-bottom:0;float:none;display:inline'));
$content_div .= $formsClass->endform();
$content_div .= $formsClass->startform('',array('id'=>'delform'));
$content_div .= $formsClass->create_selectgroup($form_prefix.'editfile',$request[$form_prefix.'editfile'],'',$tab_file);
$content_div .= $formsClass->create_submit($form_prefix.'editsubmit','Edit File',array('style'=>'margin-bottom:0;float:none;display:inline'));
$content_div .= $formsClass->create_hidden($form_prefix.'delbutton','0',array('id'=>'delbutton'));
$content_div .= $formsClass->create_submit('','Delete File',array('id'=>'delfile','style'=>'margin-bottom:0;float:none;display:inline','onclick'=>'return false;'));
$content_div .= $formsClass->endform();
$content_div .= "<div id='deldialog'>Delete this template?</div>";
$content_div .= $jqueryscript->AddJqueryScriptEnd('
jQuery("#deldialog").dialog({
autoOpen: false,
hide:"explode",
buttons: {
"Yes": function() {
jQuery("#delbutton").attr("value","1");
jQuery("#delform").submit();
jQuery( this ).dialog( "close" );
},
Cancel: function() {
jQuery( this ).dialog( "close" );
}
}
});
jQuery("#delfile").click(function()
{
jQuery("#deldialog").dialog("open");
});
');
$content_div .= "<br/>";
$textarea_params = array(
"cols" => "120",
"id"=>$form_prefix."edit_file",
"name"=>$form_prefix."edit_file",
"rows"=>"25",
"tabindex"=>"1"
);
if(isset($request[$form_prefix.'editfile']))
{
if(file_exists($actual_template."/".$request[$form_prefix.'editfile']))
{
$content_file = file_get_contents($actual_template."/".$request[$form_prefix.'editfile']);
$content_file = str_replace("<","&lt;",$content_file);
$content_file = str_replace(">","&gt;",$content_file);
$ext = explode(".",$request[$form_prefix.'editfile']);
$ext = $ext[count($ext)-1];
$content_div .= $formsClass->startform();
$content_div .= $formsClass->create_textarea($form_prefix.'edit_file',$content_file,$textarea_params);
$content_div .= '<script type="text/javascript">
var editor = CodeMirror.fromTextArea(document.getElementById("'.$form_prefix.'edit_file"), {mode: "text/html", lineNumbers: true});
</script>';
$content_div .= $formsClass->create_hidden($form_prefix.'editfile',$request[$form_prefix.'editfile']);
$content_div .= $formsClass->create_submit($form_prefix.'editbutton','Edit');
$content_div .= $formsClass->endform();
}
}
return array('head'=>$content,'content'=>$content_div);
}
function TemplateEditorBackEnd($post_vars,$sc=false)
{
global $config,$formsClass,$presentationClass,$jqueryscript,$dbClass;
//$request = $dbClass->DataFiltersArray($_POST);
$actual_dir = $config['basepath'].$config['template_dir'];
if($sc===false)
{
$wpr_templates = $this->TemplateEditorWindow($post_vars,'wpr_',$actual_dir);
$content .= $wpr_templates['head'];
$content .= $presentationClass->ContentWithHeader("WP Realty Templates Editor",$wpr_templates['content'],false,true);
} else
{
$tmp = false;
if(!is_dir($actual_dir.'/sc_templates/'))
{
if(mkdir($actual_dir.'/sc_templates/',0755))
{
$tmp = true;
}
} else
$tmp = true;
if($tmp===true)
{
$sc_templates = $this->TemplateEditorWindow($post_vars,'sc_',$actual_dir.'/sc_templates/');
$content .= $sc_templates['head'];
$content .= "<br/>".$presentationClass->ContentWithHeader("ShortCode Templates",$sc_templates['content'],array('class'=>'togcontent'),true);
} else
$content .= $presentationClass->OperationFailed('ShortCode Dir Error');
}
return $content;
}
}
?>