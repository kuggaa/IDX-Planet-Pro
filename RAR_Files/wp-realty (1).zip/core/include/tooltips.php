<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
global $tooltips_array;
$tooltips_array = array(
"controlpanel_img_allowed_ext"=>'Allowed file extensions',
"controlpanel_img_allowed_file_types"=>'Allowed file types',
"controlpanel_img_create_thumb"=>'Use a thumbnailing tool to resize images',
"controlpanel_img_thumb_width"=>'	Width (in pixels) of thumbnails',
"controlpanel_img_thumb_height"=>'Height (in pixels) of thumbnails',
"controlpanel_img_resize_thumb_by"=>'Which dimension of your thumbnails should we use to display them on your site? If "Create Thumbnails" is turned on this is the dimension that they will be created with. (Selecting both will likely cause distortion in thumbnails)',
/*Template*/
"controlpanel_template_dir"=>'Current site template',
//"controlpanel_frontend_template"=>'Current frontend template',
"controlpanel_listing_template"=>'Current listing template',
"controlpanel_listing_template_section"=>"You can set sections for your template",
"controlpanel_rss_template"=>'Current RSS template',
"controlpanel_rss_limit_lastmodified"=>'RSS last modified limit',
"controlpanel_rss_limit_featured"=>'RSS featured limit',
"controlpanel_main_searchengine"=>'Main search engine',
/*Numbers*/
"controlpanel_number_format_style"=>'Support for international numbering format',
"controlpanel_money_format"=>'Defaults to $123, but other folks in other lands do it different',
"controlpanel_date_format"=>'This is the format that all dates will display in.',
/*Maps*/
/*External*/
"controlpanel_masterdb_bool"=>'Specify the use of external database',
"controlpanel_masterdb_user"=>'Enter databse user name',
"controlpanel_masterdb_db"=>'Enter name of database',
"controlpanel_masterdb_server"=>'Enter database server IP or name',
/*Remote Photos*/
"controlpanel_custom_listing_photos"=>'If you plan on using any of these custom settings below then you need to go ahead and check this box.',
"controlpanel_mls_field_name"=>'Specify the M.L.S field name',
"controlpanel_photocount"=>'Select this option if photo count exist in local db',    /* SNH*/
"controlpanel_remote_path"=>'Specify the path using the following example : http://localhost-or-domain.com/{custom_mls_1}/{mls}{numeric_mls}.jpg',
"controlpanel_images_cache_bool"=>'Specify whether to use image cache or not',
/* SEO */
"controlpanel_default_page_title"=>"This is the default page title for your site.",
"controlpanel_default_meta"=>"This is the default description WP-Realty will place into the meta description tag on your site",
"controlpanel_keyword_default_META"=>"These are the default keywords WP-Realty will place into the meta keywords tag on your site.",
"controlpanel_listing_page_url"=>"By setting this default value, you can maintain URL consistency based on actual listing data. Simply add fields as follows;{listing field='Address'}-{listing field='City'}-{listing field='State'}, be sure to place the hyphen between each template tag for best results.",
"controlpanel_listing_page_title"=>"This is the listing page title for your site.",
"controlpanel_META_keywords_listing"=>"These are the keywords for the META tag that WP-Realty will place on listing pages.",
"controlpanel_META_Description"=>"This is the description for the META tag that WP-Realty will place on listing pages.",
);
?>