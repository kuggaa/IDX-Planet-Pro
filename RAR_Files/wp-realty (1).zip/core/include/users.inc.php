<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class usersClass {
var $level_tab = array(0 => "user", 1 => "agent", 2 => "super agent", 3 => "admin");
var $block_fields_name = array(
"user_id", "user_type", "user_level"
);
var $standard_fields_name = array(
"user_username" => array('field_required' => 1, 'field_caption' => "Username"),
"user_password" => array('field_required' => 1, 'field_caption' => "Password", 'field_type' => 'password'),
"user_email" => array('field_required' => 1, 'field_caption' => "Email"),
//"user_level"=>array('field_required'=>1,'field_caption'=>"Level",'field_type'=>'select','field_elements'=>'0|1|2|3','field_tip'=>'0 => Normal User,1 => Agent2 => SuperAgent,3 => ADMIN'),
);
var $tab_select_datatype = array(
"int(11)" => 'Integer',
"float" => 'Float',
"char(5)" => 'Char(5)',
"char(20)" => 'Char(20)',
"char(50)" => 'Char(50)',
"char(100)" => 'Char(100)',
"char(200)" => 'Char(200)',
"text" => 'Text',
"longtext" => 'Long Text'
);
function GetUserRoster($param, $request) {
global $config, $dbClass, $UrlClass;
$template = new ParseClass();
$userinfo = false;
if (is_numeric($param['user_id'])) {
if ($userinfo = $this->GetUserInfo($param['user_id'])) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "userdetails.php");
$content = $template->MainParse($content, $userinfo['user_id']);
}
}
if ($userinfo === false) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "userroster.php");
if ($users = $this->GetUsers(0)) {
require_once($config['wpradmin_basepath'] . "include/controlpanel.inc.php");
$controlClass = new controlpanelClass();
$spacechar_array = $controlClass->GetControlPanelFields();
$spacechar = $spacechar_array['controlpanel_space_character'];
$rows = "";
$reg_user_name = "#({user_name})#";
$reg_user_link = "#({user_link})#";
for ($i = 0; $i < count($users); $i++) {
$template_row = $template->GetTemplateBlock('users', $content);
if ($users[$i]['user_firstname'] != "" && $users[$i]['user_lastname'] != "") {
$username = $users[$i]['user_firstname'] . " " . $users[$i]['user_lastname'];
} else
$username = $users[$i]['user_username'];
$user_link = $config['baseurl'] . "index.php?user_id=" . $users[$i]['user_id'] . "&page=userroster";
$tmp = preg_replace($reg_user_link, $user_link, $template_row['content']);
$tmp = preg_replace($reg_user_name, $username, $tmp);
if ($i % 2 == 0)
$odd = 0;
else
$odd = 1;
$tmp = $template->ReplaceTag("{row_num_even_odd}", $odd, $tmp);
$rows .= $tmp;
}
$content = $template->ReplaceTemplateBlock('users', $rows, $content);
} else
$content = $template->ReplaceTemplateBlock('users', "No users", $content);
}
return $content;
}
function ReplaceUserFieldTags($user_id, $param) {
global $config, $dbClass;
$return = false;
if (isset($param['field'])) {
$field = $param['field'];
if ($temp_fields = $this->GetUserInfo($user_id)) {
foreach ($temp_fields as $key => $value) {
$re[strtolower($key)] = $value;
}
if (isset($re[$field])) {
$return = $re[$field];
}
}
}
return $return;
}
function GetUsers($level = false) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "users";
if ($level !== false)
$sql .= " WHERE user_level='" . $level . "'";
$reU = $dbClass->query($sql);
if ($reU->RecordCount() > 0) {
$ret = array();
while (!$reU->EOF) {
$ret[] = $reU->fields;
$reU->MoveNext();
}
return $ret;
} else
return false;
}
function GetUserInfo($user_id, $fields = false) {
global $dbClass, $config;
$fields_sql = "*";
if ($fields !== false) {
if (is_array($fields)) {
$fields_sql = "";
for ($i = 0; $i < count($fields); $i++) {
$fields_sql .= $fields[$i] . ",";
}
$fields_sql = substr($fields_sql, 0, -1);
}
}
$sql = "SELECT $fields_sql FROM " . $config['table_prefix'] . "users WHERE user_id='" . $dbClass->DataFilters($user_id) . "'";
$reUser = $dbClass->Query($sql);
if ($reUser->recordCount() > 0) {
return $reUser->fields;
} else
return false;
}
function GetAllUsersInfo($fields = false) {
global $dbClass, $config;
$fields_sql = "*";
if ($fields !== false) {
if (is_array($fields)) {
$fields_sql = "";
for ($i = 0; $i < count($fields); $i++) {
$fields_sql .= $fields[$i] . ",";
}
$fields_sql = substr($fields_sql, 0, -1);
}
}
$sql = "SELECT $fields_sql FROM " . $config['table_prefix'] . "users";
$reUser = $dbClass->Query($sql);
if ($reUser->recordCount() > 0) {
$tab_user_info = array();
while (!$reUser->EOF) {
$tab_user_info[] = $reUser->fields;
$reUser->MoveNext();
}
return $tab_user_info;
} else
return false;
}
function CheckAccess($user_level, $user_id, $listing_id) {
global $dbClass, $config;
if ($user_level == 3)
return true;
$sql = "SELECT * FROM " . $config['table_prefix'] . "users WHERE user_id='" . $user_id . "'";
$reCheck = $dbClass->query($sql);
if ($reCheck->RecordCount() > 0) {
return true;
}
return false;
}
function AddToFavoriteListing($user_id, $listing_id) {
global $config, $dbClass;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userfavoritelistings WHERE user_id='" . $user_id . "' AND listing_id='" . $listing_id . "'";
$reCheck = $dbClass->Query($sql);
if ($reCheck->recordCount() == 0) {
$sql = "INSERT INTO " . $config['table_prefix'] . "userfavoritelistings SET user_id='" . $user_id . "',listing_id='" . $listing_id . "'";
return $dbClass->Query($sql);
} else
return true;
}
function CheckFavoriteListing($user_id, $listing_id) {
global $config, $dbClass;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userfavoritelistings WHERE user_id='" . $user_id . "' AND listing_id='" . $listing_id . "'";
$reCheck = $dbClass->Query($sql);
if ($reCheck->recordCount() > 0)
return true;
else
return false;
}
function DeleteFavoriteListing($user_id, $listing_id) {
global $config, $dbClass;
$sql = "DELETE FROM " . $config['table_prefix'] . "userfavoritelistings WHERE user_id='" . $user_id . "' AND listing_id='" . $listing_id . "'";
return $dbClass->Query($sql);
}
function GetFavourtieListings($user_id) {
global $config, $dbClass;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userfavoritelistings WHERE user_id='" . $user_id . "'";
$reFav = $dbClass->Query($sql);
if ($reFav->recordCount() > 0) {
$ret_tab = array();
while (!$reFav->EOF) {
$ret_tab[] = $reFav->fields;
$reFav->MoveNext();
}
return $ret_tab;
} else
return false;
}
function ShowFrontendAccount($user_info, $postvars) {
global $presentationClass, $config;
$content = "";
$headers = array(
"saved_searches" => "View Saved Searches",
"modify_account" => "Modify Account",
"fav_listings" => "View Favorite",
"listing_alert" => "Set Listing Alert Details",
"logout" => "Log-Out",
);
$data = array(
'modify_account' => $this->ModifyAccount($user_info['user_id']),
'fav_listings' => $this->ShowFavoriteListing($user_info['user_id']),
'saved_searches' => $this->SavedSearch($user_info['user_id']),
'logout' => "link:index.php?page=myaccount&action=logout",
);
$content .= $presentationClass->JqueryTabsWithData($data, $headers, array('id' => 'maps'));
return $content;
}
function CheckPasswordChange($request, $user_id) {
if ($info = $this->GetUserInfo($user_id)) {
if (md5($request['oldpassword']) == $info['password']) {
if (strlen($request['newpassword']) > 3) {
if ($request['newpassword'] == $request['newpassword_reply']) {
return false;
} else {
return "Passwords in not same";
}
} else {
return "New password is to short";
}
} else {
return "Old password isn't correct";
}
}
return 0;
}
function ModifyAccount($user_id) {
global $formsClass, $dbClass, $config;
if ($user_info = $this->GetUserInfo($user_id)) {
if (isset($postvars['modify_account'])) {
$postvars['edit_id'] = $user_info['user_id'];
unset($postvars['password']);
if ($this->UpdateUserInfo($postvars)) {
$_GET['successinfo'] = "Account has been edited";
}
}
if (isset($postvars['changepass'])) {
$postvars['edit_id'] = $user_info['user_id'];
$error = $this->CheckPasswordChange($postvars, $user_info['user_id']);
if ($error === false) {
$user_info['password'] = $postvars['newpassword'];
$user_info['edit_id'] = $user_info['user_id'];
if ($this->UpdateUserInfo($user_info)) {
require_once($config['wpradmin_basepath'] . "include/login.inc.php");
$loginClass = new loginClass();
$loginClass->SaveDataInSession($user_info['username'], $user_info['password']);
$_GET['successinfo'] = "Password has been changed";
} else
$_GET['errorinfo'] = "Password hasn't been changed";
} else {
$_GET['errorinfo'] = $error;
}
}
require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
$template = new parseClass();
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . "/" . "modify_account.php");
return $content;
}
return false;
}
function ShowFavoriteListing($user_id) {
global $presentationClass, $config;
require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
$template = new parseClass();
if ($tab_fav = $this->GetFavourtieListings($user_id)) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . "/" . "view_favourite.php");
$template_row = $template->GetTemplateBlock('favorites', $content);
$repeat = count($tab_fav);
$rows = "";
for ($i = 0; $i < $repeat; $i++) {
$rows .= $template->MainParse($template_row['content'], $tab_fav[$i]['listing_id']);
}
$content = $template->ReplaceTemplateBlock('favorites', $rows, $content);
} else
$content = "No listings";
return $content;
}
function GetFavourtieSearch($user_id) {
global $dbClass, $config;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "searchfavorite` WHERE user_id='" . $user_id . "'";
$reFav = $dbClass->query($sql);
if ($reFav->RecordCount() > 0) {
$ret = array();
while (!$reFav->EOF) {
$ret[] = $reFav->fields;
$reFav->MoveNext();
}
return $ret;
} else
return false;
}
function DeleteFavoriteSearch($favorite_id, $user_id) {
global $config, $dbClass;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "searchfavorite` WHERE favorite_id='" . $favorite_id . "' AND user_id='" . $user_id . "'";
$reCheck = $dbClass->query($sql);
if ($reCheck->RecordCount() > 0) {
$sql = "DELETE FROM `" . $config['table_prefix'] . "searchfavorite` WHERE favorite_id='" . $favorite_id . "' AND user_id='" . $user_id . "'";
return $dbClass->query($sql);
} else
return false;
}
function SavedSearch($user_id) {
global $presentationClass, $config;
require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
$template = new parseClass();
if ($tab_fav = $this->GetFavourtieSearch($user_id)) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . "/" . "view_favourite_search.php");
$template_row = $template->GetTemplateBlock('favorites', $content);
$repeat = count($tab_fav);
$rows = "";
for ($i = 0; $i < $repeat; $i++) {
//$tmp = $template->MainParse($template_row['content'],$tab_fav[$i]['listing_id']);
$tmp = $template_row['content'];
$tmp = str_replace("{favorite_search_name}", $tab_fav[$i]['name'], $tmp);
$tmp = str_replace("{favorite_search_delete}", "index.php?page=myaccount&delfavorite_search=" . $tab_fav[$i]['favorite_id'], $tmp);
$tmp = str_replace("{favorite_search_link}", "index.php?" . $tab_fav[$i]['link'], $tmp);
$rows .= $tmp;
}
$content = $template->ReplaceTemplateBlock('favorites', $rows, $content);
} else
$content = "No favorite search";
return $content;
}
/* BACKEND */
function CheckUserName($username) {
global $dbClass, $config;
$sql = "SELECT user_id FROM " . $config['table_prefix'] . "users WHERE user_username='" . $username . "'";
$reCheck = $dbClass->Query($sql);
if ($reCheck->RecordCount() == 0) {
return false;
} else
return $reCheck->fields['user_id'];
}
function CheckAddEditUserForm($request, $edit_id = false, $captcha = false, $email = true) { // Seems no way to edit mode check pw rep pw match -mm
$edit = false;
global $config;
$errors = array();
if ($edit !== false) {
if ($request['password'] != "") {
if ($request['password'] != $request['password_rep'])
$errors[] = "You need to type two identical passwords";
if (strlen($request['password']) < $config['min_length_pass'])
$errors[] = "Password is too short";
}
}
else {
if (strlen($request['password']) < $config['min_length_pass']) {
$errors[] = "Password is too short";
} else {
if ($request['password'] != $request['password_rep'])
$errors[] = "You need to type two identical passwords";
}
if (strlen($request['username']) < $config['min_length_username']) {
$errors[] = "Username is too short";
} else
if ($this->CheckUserName($request['username']) !== false)
$errors[] = "Username already exists";
if ($captcha !== false) {
if ($_SESSION['captcha'] != md5(strtolower($request[$captcha]))) {
$errors[] = "Invalid Captcha";
}
}
}
if ($this->checkEmail($request['email']) === false AND $email === true) {
$errors[] = "Invalid e-mail";
}
if (count($errors) == 0)
return false;
else
return $errors;
}
function checkEmail($email) {
if (!preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $email)) {
return false;
}
return true;
}
function AddUserBackEnd($post_vars, $get_vars) {
global $dbClass, $presentationClass, $UrlClass, $jqueryscript, $array_numbers, $config;
$content = "";
$error_info = "";
$pagename = "editusers";
$base = $config['adm_baseurl'] . "index.php?apage=" . $pagename;
$content .= "<h3>Add User</h3>";
if (isset($post_vars['adduser_submit'])) {
//var_dump($post_vars);
//require_once($config['basepath'].'include/fields.inc.php');
require_once($config['wpradmin_basepath'] . 'include/fields.inc.php');
$fieldsClass = new fieldsClass();
$errors = $fieldsClass->CheckRequiredField($post_vars, "userfields", "userfields");
if ($errors === false) {
$error = false;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "users` WHERE user_username='" . $post_vars['user_username'] . "'";
$reCheck = $dbClass->Query($sql);
if ($reCheck->recordCount() > 0) {
$error = true;
$content .= $presentationClass->OperationFailed("Login already exists");
}
if ($post_vars['user_password'] != $post_vars['user_password_reply']) {
$error = true;
$content .= $presentationClass->OperationFailed("You need to type two identical passwords");
}
if (strlen($post_vars['user_password']) < $config['min_length_pass']) {
$error = true;
$content .= $presentationClass->OperationFailed("Password is too short");
}
if ($error === false) {
require_once($config['wpradmin_basepath'] . "include/bridge.inc.php");
$bridgeClass = new Bridge();
$post_vars['user_password'] = $bridgeClass->GeneratePassword($post_vars['user_password']);
//$post_vars['user_password'] = md5($post_vars['user_password']);
$last_id = $this->InsertNewUser($post_vars);
//var_dump($post_vars);
//$content .= var_dump($last_id);
if ($last_id) {
//$url = $UrlClass->AddUrlValues(array('page'=>'users','cpage'=>'editusers','action'=>'edit_user','edit_id'=>$last_id));
//$content .= $presentationClass->OperationSuccessfull("User has been added");
header("location: $base");
die();
unset($post_vars);
} else
$content .= $presentationClass->OperationFailed("User hasn't been added");
}
}
else {
$error_info = "Field required: ";
for ($i = 0; $i < count($errors); $i++) {
$error_info .= str_replace("users_", "", $errors[$i]) . ", ";
}
$error_info = substr($error_info, 0, -2);
$content .= $presentationClass->OperationFailed($error_info);
}
}
$request = $post_vars;
$content .= $this->ShowAddEditUserTable($post_vars);
return $content;
}
function InsertNewUser($request_vars) {
global $dbClass, $config, $log_user_id;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userfields";
//echo $sql.'<br>';
$reFields = $dbClass->Query($sql);
//var_dump($reFields);
//echo '<br><br />';
//var_dump($request_vars);
$sql = "INSERT INTO " . $config['table_prefix'] . "users SET ";
// WP user create vals
$username;
$password;
$email;
$fn;
$ln = '';
while (!$reFields->EOF) {
//RYAN C.
//$field = $reFields->fields['userfields_field_name'];
$field = str_replace('user_', '', $reFields->fields['userfields_field_name']); // mm
//END RYAN C.
//echo $reFields->fields['userfields_field_name'].'<br>';
if ($reFields->fields['userfields_field_type'] == "checkbox") {
$value = implode("|", $field);
} else {
$value = $request_vars[$reFields->fields['userfields_field_name']];
// Wp user create assignments
if ($field == 'username')
$username = $value;
if ($field == 'password')
$password = $value;
if ($field == 'email')
$email = $value;
if ($field == 'firstname')
$fn = $value;
if ($field == 'lastname')
$ln = $value;
}
//echo $field.' -> '.$value.'<br>';
// Tighten up to only set fields with vals MM 1-16-17
if(!isset($request_vars[$reFields->fields['userfields_field_name']]) || $request_vars[$reFields->fields['userfields_field_name']] == ''){
    
}
else{
    $sql .= $reFields->fields['userfields_field_name'] . "='" . $value . "',";
    
}
$reFields->MoveNext();
}
$sql = substr($sql, 0, -1);
//$sql .= ",listingsdb_creation_date='".time()."'";
//echo $sql;
if ($dbClass->Query($sql) !== false) {
if (is_callable('WpRegWprUser'))
WpRegWprUser($username, $password, $email, $fn, $ln); // mm 10-10-15 enables wp - wpr cross registration
return $dbClass->LastID();
//return $count;
}
return false;
}
function DeleteUserImage($del_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userimages WHERE  userimage_id='" . $del_id . "'";
$reImages = $dbClass->Query($sql);
if ($reImages->recordCount() > 0) {
if ($reImages->fields['image_thumbname'] != "") {
@unlink($config['user_images'] . $reImages->fields['image_thumbname']);
}
@unlink($config['user_images'] . $reImages->fields['image_filename']);
$sql = "DELETE FROM " . $config['table_prefix'] . "userimages WHERE userimage_id='$del_id'";
return $dbClass->Query($sql);
} else
return false;
}
function GetUserImage($edit_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userimages WHERE  userimage_id='" . $edit_id . "'";
$reImages = $dbClass->Query($sql);
if ($reImages->recordCount() > 0) {
return $reImages->fields;
} else
return false;
}
function ShowAddEditUserTable($request, $mode = '', $edit_id = '', $user_id = false) {
global $dbClass, $config, $presentationClass, $jqueryscript, $UrlClass, $log_user_id;
//require_once($config['basepath']."include/images.inc.php");
require_once($config['wpradmin_basepath'] . "include/images.inc.php");
$imagesClass = new ImagesClass();
$content = "";
$actual_page_id = "adduser";
$selected = false;
if ($mode == 'edit') {
if ($user_id !== false)
$actual_page_id = "myaccount";
else
$actual_page_id = "editusers";
if ($request['content_action'] == 'upload_images') {
//require_once($config['basepath'].'include/images.inc.php');
require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
$imagesClass = new ImagesClass();
if ($files = $imagesClass->UploadImages(1)) {
if ($imagesClass->UploadUserImages($edit_id, $files)) {
$content .= $presentationClass->OperationSuccessfull('Upload Images Success');
} else
$content .= $presentationClass->OperationFailed('Upload Images Failed');
} else
$content .= $presentationClass->OperationFailed('Upload Images Failed');
$selected = 1;
}
if ($request['content_action'] == 'edit_images') {
for ($i = 0; $i < count($request['image_id']); $i++) {
$sql = "UPDATE " . $config['table_prefix'] . "userimages SET
image_caption = '" . $request['caption'][$i] . "',
image_rank = '" . $i . "'
WHERE userimage_id='" . $request['image_id'][$i] . "'";
$dbClass->Query($sql);
}
$selected = 1;
}
if ($_GET['content_action'] == 'delete_image') {
if (is_numeric($_GET['del_id']) AND $this->GetUserImage($_GET['del_id'])) {
if ($this->DeleteUserImage($_GET['del_id'])) {
$content .= $presentationClass->OperationSuccessfull('Delete Image Success');
} else
$content .= $presentationClass->OperationFailed('Delete Image Failed');
}
$selected = 1;
}
}
//require_once($config['basepath'].'include/forms.inc.php');
require_once($config['wpradmin_basepath'] . 'include/forms.inc.php');
$formsClass = registry::register('FormsClass');
$sql = "SELECT * FROM " . $config['table_prefix'] . "userfields ORDER by userfields_rank_col,userfields_rank";
$reFields = $dbClass->Query($sql);
$user_tabs = "";
if ($reFields->recordCount() > 0) {
$user_tab = array();
while (!$reFields->EOF) {
if ($dbClass->ColumnExists($config['table_prefix'] . "users", $reFields->fields['userfields_field_name']) !== false) {
if ($reFields->fields['userfields_field_caption'] != "")
$right_col = $reFields->fields['userfields_field_caption'];
else {
$right_col = str_replace("users", "", $reFields->fields['userfields_field_name']);
$right_col = str_replace("_", " ", $right_col);
}
$elements = "";
if (strpos($reFields->fields['userfields_field_elements'], "|") !== false) {
$elements_temp = explode("|", $reFields->fields['userfields_field_elements']);
$elements = array();
for ($i = 0; $i < count($elements_temp); $i++) {
if ($reFields->fields['userfields_field_type'] == 'checkbox')
$elements[$elements_temp[$i]] = $elements_temp[$i] . "<br/>";
else
$elements[$elements_temp[$i]] = $elements_temp[$i];
}
}
$params = false;
if ($reFields->fields['userfields_field_type'] == 'text' OR $reFields->fields['userfields_field_type'] == 'textarea' OR $reFields->fields['userfields_field_type'] == 'textarea') {
$params['class'] = "large";
}
if ($reFields->fields['userfields_tip'] != "") {
$params['title'] = $reFields->fields['userfields_tip'];
}
if ($reFields->fields['userfields_field_name'] == 'user_password') {
$left_col = $formsClass->GenerateField($reFields->fields['userfields_field_type'], "user_password", "", false, $request, 'normal', $params);
$user_tab[$reFields->fields['userfields_rank_col']][] = array("<strong>" . $right_col . "</strong>", $left_col);
$right_col.= " (reply)";
$left_col = $formsClass->GenerateField($reFields->fields['userfields_field_type'], "user_password_reply", "", $elements, $request, 'normal', $params);
$user_tab[$reFields->fields['userfields_rank_col']][] = array("<strong>" . $right_col . "</strong>", $left_col);
} else {
$left_col = $formsClass->GenerateField($reFields->fields['userfields_field_type'], $reFields->fields['userfields_field_name'], $request[$reFields->fields['userfields_field_name']], $elements, $request, 'normal', $params);
$user_tab[$reFields->fields['userfields_rank_col']][] = array("<strong>" . $right_col . "</strong>", $left_col);
}
}
$reFields->MoveNext();
}
$user_tabs .= $formsClass->startform();
$user_tabs .= "<div><button onclick='return false' id='save_order' style='float:right'>Save order field</button><div style='clear:both'></div></div>";
$success_info = $presentationClass->OperationSuccessfull('The order of the fields has been saved');
$user_tabs .= $presentationClass->BlockTableSortable($user_tab[0], 2);
$user_tabs .= $presentationClass->BlockTableSortable($user_tab[1], 2);
$user_tabs .= $jqueryscript->SaveOrder("sd_column", "save_order", $config['adm_baseurl'] . "ajax.php?f=ajax_fields_sort.php", $success_info, "user");
if ($mode == 'edit')
$user_tabs .= $formsClass->create_submit($actual_page_id . '_submit', 'Edit', array('id' => $actual_page_id . '_submit'));
else
$user_tabs .= $formsClass->create_submit('adduser_submit', 'Add', array('id' => 'adduser_submit'));
$user_tabs .= $formsClass->endform();
}
if ($mode == 'edit') {
$edituser_user_tab_name = $actual_page_id . "_user_tab";
$edituser_images_tab_name = $actual_page_id . "_images_tab";
$headers = array(
$edituser_user_tab_name => "User Details",
$edituser_images_tab_name => "Images",
);
$images_tab = $imagesClass->GenerateUploadImagesFormNormal(5, $edit_id, 'upload_userimage');
$images_tab .= $this->UserImagesForm($edit_id, $actual_page_id);
$data[$edituser_user_tab_name] = $user_tabs;
$data[$edituser_images_tab_name] = $images_tab;
$jquery_tabs_id = "jqt_" . $actual_page_id;
$content .= $presentationClass->JqueryTabsWithDataNew($data, $headers, array('id' => $jquery_tabs_id, 'class' => 'box grid_16 round_all tabs'), $selected);
} else {
$content .= $user_tabs; //$presentationClass->StandardTableWithData($user_tab);
}
return $content;
}
function UserImagesForm($user_id, $actual_page_id) {
global $dbClass, $config, $presentationClass, $UrlClass, $formsClass, $jqueryscript;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userimages WHERE user_id='$user_id' ORDER BY image_rank";
$reImages = $dbClass->Query($sql);
$content = $formsClass->startform();
if ($reImages->recordCount() > 0) {
$view_tab = array();
$tabRANK = array();
for ($i = 0; $i < $reImages->recordCount(); $i++) {
$tabRANK[$i] = $i;
}
while (!$reImages->EOF) {
$delurl = $UrlClass->ReplaceUrlValues(array('content_action' => 'delete_image', 'del_id' => $reImages->fields['userimage_id']));
$tables = array();
$tables[] = $formsClass->create_hidden('image_id[]', $reImages->fields['userimage_id']) .
"<strong>" . $reImages->fields['image_filename'] . "</strong><br/>";
$tables[] = "<img src='" . $config['baseurl'] . $config['img_dir'] . "/user_images/" . $reImages->fields['image_thumbname'] . "'>";
//$tables[] = $formsClass->create_select('rank[]',$reImages->fields['listingsimages_rank'],'',$tabRANK);
$tables[] = $formsClass->create_text('caption[]', $reImages->fields['image_caption']);
$tables[] = "<a href='$delurl' class='delbutton' onclick='return false;' name='Delete image?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
$right .= $presentationClass->BlockTable($tables);
$view_tab[] = $tables;
$reImages->MoveNext();
}
$headers = array('Name', 'Thumb', 'Caption', '');
$content .= $presentationClass->StandardTableWithDataNew($view_tab, $headers, false, array('id' => 'editimages_datatable', 'style' => 'wpr_form'), true);
$content .= $formsClass->create_hidden('content_action', 'edit_images');
$content .= $formsClass->create_submit('editsubmit', 'Edit');
$content .= $formsClass->endform();
}
return $content;
}
function UpdateUser($request_vars, $user_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "userfields";
$reFields = $dbClass->Query($sql);
$sql = "UPDATE " . $config['table_prefix'] . "users SET ";
while (!$reFields->EOF) {
if ($dbClass->ColumnExists($config['table_prefix'] . "users", $reFields->fields['userfields_field_name'])) {
if ($reFields->fields['userfields_field_type'] == "checkbox" AND is_array($request_vars[$reFields->fields['userfields_field_name']])) {
$value = implode("|", $request_vars[$reFields->fields['userfields_field_name']]);
} else
$value = $request_vars[$reFields->fields['userfields_field_name']];
if(!isset($request_vars[$reFields->fields['userfields_field_name']]) || $request_vars[$reFields->fields['userfields_field_name']] == ''){
    
}
else{
    $sql .= $reFields->fields['userfields_field_name'] . "='" . $value . "',";
}

}
$reFields->MoveNext();
}
$sql = substr($sql, 0, -1);
$sql .= " WHERE user_id='" . $user_id . "'";
if ($dbClass->Query($sql) !== false)
return true;
return false;
}
function DeleteUser($del_id) {
global $config, $dbClass, $user_level;
$this->DeleteUserImages($del_id);
$sql = "DELETE FROM " . $config['table_prefix'] . "users WHERE user_id='$del_id'";
return $dbClass->query($sql);
}
function DeleteUsers($del_tab) {
$true = 0;
for ($i = 0; $i < count($del_tab); $i++) {
if ($this->DeleteUser($del_tab[$i]))
$true++;
}
if ($true == $i)
return true;
else
return false;
}
function GetUserImages($user_id, $agent_image = false) {
global $dbClass, $config;
if ($agent_image === false) {
$sql = "SELECT * FROM " . $config['table_prefix'] . "userimages WHERE user_id='$user_id' ORDER BY image_rank";
return $dbClass->GetResults($sql);
} else {
$sql = "SELECT ai.* FROM " . $config['table_prefix'] . "agentimages ai," . $config['table_prefix'] . "agents a WHERE a.agent_id=ai.agent_id AND a.user_id='" . $user_id . "' ORDER BY image_rank";
return $dbClass->GetResults($sql);
}
}
function DeleteUserImages($user_id) {
if ($imagesTab = $this->GetUserImages($user_id)) {
for ($i = 0; $i < count($imagesTab); $i++) {
$this->DeleteUserImage($imagesTab[$i]['image_id']);
}
}
}
function MyAccount($post_vars, $get_vars, $user_id) {
global $config, $dbClass;
require_once($config['wpradmin_basepath'] . "include/agent.inc.php");
$agentClass = registry::register('AgentClass');
$sql = "SELECT agent_id FROM " . $config['table_prefix'] . "agents  WHERE user_id='" . $user_id . "'";
$reA = $dbClass->Query($sql);
if ($reA->RecordCount() > 0) {
$get_vars['edit_id'] = $reA->fields['agent_id'];
$get_vars['action'] = 'edit_agent';
return $agentClass->EditAgentBackEnd($post_vars, $get_vars);
}
return false;
}
function EditUserBackEnd($post_vars, $get_vars, $user_id = false) {
global $dbClass, $config, $presentationClass, $UrlClass, $jqueryscript, $user_level, $log_user_id, $formsClass;
$errors = false;
$actual_page_id = "editusers";
//require_once($config['basepath'].'include/fields.inc.php');
require_once($config['wpradmin_basepath'] . 'include/fields.inc.php');
// echo $config['wpradmin_basepath'];
$fieldsClass = new fieldsClass();
if ($user_id !== false) {
$get_vars['edit_id'] = $user_id;
$get_vars['action'] = 'edit_user';
$actual_page_id = "myaccount";
}
if (isset($post_vars[$actual_page_id . '_submit']) AND is_numeric($get_vars['edit_id'])) {
if ($uInfo = $this->GetUserInfo($get_vars['edit_id'])) {
$post_vars = $dbClass->DataFiltersArray($post_vars);
$errors = $fieldsClass->CheckRequiredField($post_vars, "userfields", "userfields", array('user_password', 'user_username'));
$new_pass = false;
if ($errors === false) {
$error = false;
require_once($config['wpradmin_basepath'] . "include/bridge.inc.php");
$bridgeClass = new Bridge();
if ($post_vars['user_password'] != "") {
if ($post_vars['user_password'] != $post_vars['user_password_reply']) {
$error = true;
$content .= $presentationClass->OperationFailed("You need to type two identical passwords");
}
if (strlen($post_vars['user_password']) < $config['min_length_pass']) {
$error = true;
$content .= $presentationClass->OperationFailed("Password is too short");
}
if ($error === false) {
//$new_pass = md5($post_vars['user_password']);
$new_pass = $bridgeClass->GeneratePassword($post_vars['user_password']);
}
}
if ($post_vars['user_username'] != $uInfo['user_username']) {
$sql = "SELECT * FROM `" . $config['table_prefix'] . "users` WHERE user_username='" . $post_vars['user_username'] . "' AND user_id='" . $get_vars['edit_id'] . "'";
$reCheck = $dbClass->Query($sql);
if ($reCheck->recordCount() > 0) {
$error = true;
$content .= $presentationClass->OperationFailed("Login already exists");
}
}
if ($error === false) {
if ($new_pass !== false)
$post_vars['user_password'] = $new_pass;
else
$post_vars['user_password'] = $uInfo['user_password'];
$post_vars['user_password'] = $uInfo['user_password'];
if ($this->UpdateUser($post_vars, $get_vars['edit_id'])) {
if ($new_pass !== false) {
$bridgeClass->ChangePass($post_vars['user_username'], $new_pass);
}
if ($get_vars['edit_id'] == $log_user_id) {
//require_once($config['basepath']."include/login.inc.php");
require_once($config['wpradmin_basepath'] . 'include/login.inc.php');
$loginC = new loginClass();
$loginC->SaveDataInSession($post_vars['user_username'], $new_pass);
}
$content = $presentationClass->OperationSuccessfull("User edited");
} else
$content = $presentationClass->OperationFailed("User edit failed");
}
}
else {
$error_info = "Field required: ";
for ($i = 0; $i < count($errors); $i++) {
$error_info .= $errors[$i] . ", ";
}
$error_info = substr($error_info, 0, -2);
$content .= $presentationClass->OperationFailed($error_info);
}
}
}
if (!isset($get_vars['action']) OR $get_vars['action'] == 'delete_user') {
//multi delete
$content = $presentationClass->SecondHeader('All Users');
if (isset($post_vars['delete_users'])) {
if (count($post_vars['del_id'])) {
if ($this->DeleteUsers($post_vars['del_id']))
$content .= $presentationClass->OperationSuccessfull('Delete users success');
else
$content .= $presentationClass->OperationSuccessfull('Delete users failed');
}
}
if ($get_vars['action'] == 'delete_user' AND is_numeric($get_vars['del_id'])) {
if ($this->DeleteUser($get_vars['del_id']))
$content .= $presentationClass->OperationSuccessfull('Delete user success');
else
$content .= $presentationClass->OperationSuccessfull('Delete user failed');
}
$pagination = new SearchEngineClass();
require_once($config['wpradmin_basepath'] . "include/agent.inc.php");
$agentsClass = registry::register('AgentClass');
/*
$where = "";
if($agents = $agentsClass->GetAgents())
{
$where = " WHERE user_id NOT IN (";
for($i=0;$i<count($agents);$i++)
{
$where .= $agents[$i]['user_id'].",";
}
$where = substr($where,0,-1);
$where .= ")";
}
*/
$sql = "SELECT * FROM " . $config['table_prefix'] . "users WHERE user_level=0";
$reUsers = $dbClass->Query($sql);
$number_records = $reUsers->recordCount();
if ($number_records > 0) {
$headers = array("ID", "User Name", array("name" => "", "align" => "right"));
$tab = array();
while (!$reUsers->EOF) {
$editurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=edit_user&edit_id=" . $reUsers->fields['user_id'];
$deleteurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=delete_user&del_id=" . $reUsers->fields['user_id'];
$checkbox = "<input type='checkbox' value='" . $reUsers->fields['user_id'] . "' name='del_id[]'>";
$tab[] = array($checkbox . $reUsers->fields['user_id'], $reUsers->fields['user_username'], "
<a href='$editurl'>
<img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a>
<a href='$deleteurl' class='delbutton' name='Delete this user?' onclick='return false'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>");
$reUsers->MoveNext();
}
$content .= "<form method='post' id='delete_users_form'>";
$content .= $formsClass->create_submit('', 'Delete checked users', array('id' => 'delete_users', 'onclick' => 'return false;', 'type' => ''));
$content .= $presentationClass->StandardTableWithDataNew($tab, $headers, false, array('id' => $actual_page_id . '_datatable'), false);
$content .= "<input type='hidden' name='delete_users' value='1' /></form>";
$content .= $presentationClass->MultiDeleteConfirm("Delete checked users?", "delete_users_form", "delete_users");
} else
$content .= "No users";
}
else {
if ($get_vars['action'] == 'edit_user' AND is_numeric($get_vars['edit_id'])) {
$content .= "<h3>Edit User</h3>";
$backurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id;
$content .= "<div class='tophref'><a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a></div>";
$sql = "SELECT * FROM " . $config['table_prefix'] . "users WHERE user_id='" . $dbClass->DataFilters($get_vars['edit_id']) . "'";
$reUsers = $dbClass->Query($sql);
if ($reUsers->recordCount() > 0) {
if ($errors !== false) {
$request = $post_vars;
$content .= $this->ShowAddEditUserTable($request, 'edit', $get_vars['edit_id'], $user_id);
} else {
$request = $reUsers->fields;
foreach ($request as $key => $values) {
$post_vars[$key] = $values;
}
$content .= $this->ShowAddEditUserTable($post_vars, 'edit', $get_vars['edit_id'], $user_id);
}
} else {
header("location: " . $backurl);
die();
}
}
}
$return = $content;
return $return;
}
function EditUserFieldsBackEnd($post_vars, $get_vars) {
global $dbClass, $presentationClass, $formsClass, $UrlClass, $config, $jqueryscript;
//require_once($config['basepath']."/include/fields.inc.php");
require_once($config['wpradmin_basepath'] . 'include/fields.inc.php');
$fieldsClass = new fieldsClass();
$page_name = "edituserfields";
$backurl = $config['baseurl'] . "index.php?apage=" . $page_name;
$tablename = "userfields";
$field_prefix = "userfields";
$user_table = "users";
$field_name_prefix = "user_";
if (!isset($get_vars['action']) OR ( $get_vars['action'] == 'delete_field')) {
if ($get_vars['action'] == 'delete_field' AND is_numeric($get_vars['del_id'])) {
if ($field_info = $fieldsClass->FieldExists($tablename, $field_prefix . "_id", $get_vars['del_id'])) {
if ($fieldsClass->DeleteField($field_info[$field_prefix . '_field_name'], $user_table, $tablename, $this->block_fields_name)) {
$content .= $presentationClass->OperationSuccessfull("User Field delete");
} else {
$content .= $presentationClass->OperationFailed("User Field delete failed");
}
}
}
$content .= $formsClass->startform();
//update
$tab_fields = $fieldsClass->GetFields($tablename, $this->block_fields_name);
if ($tab_fields !== false) {
if (isset($post_vars['send_form'])) {
foreach ($post_vars as $key => $value) {
for ($i = 0; $i < count($value); $i++) {
$new_array[$i][$key] = $value[$i];
}
}
for ($i = 0; $i < count($tab_fields); $i++) {
$field_vars = $new_array[$i];
$new_name = $field_name_prefix . $field_vars[$field_prefix . '_field_newname'];
$field_name = $field_vars[$field_prefix . '_field_name'];
//change name
$colExists = $dbClass->ColumnExists($config['table_prefix'] . $user_table, $field_name, $colInfo);
if ($new_name != $field_name AND $colExists === false AND ( !array_key_exists($field_name, $this->standard_fields_name))) {
if ($dbClass->ChangeColumn($config['table_prefix'] . "users", $field_name, array('new_column_name' => $new_name))) {
$field_vars[$field_prefix . '_field_name'] = $new_name;
$fieldsClass->DeleteFieldInfo($field_name, $tablename);
$fieldsClass->UpdateFieldsInfo($field_vars, $tablename, $field_prefix);
}
} else {
if ($colExists !== false) {
$fieldsClass->UpdateFieldsInfo($field_vars, $tablename, $field_prefix);
}
}
}
$content .= $presentationClass->OperationSuccessfull("User Fields edited");
}
}
$tab_fields = $fieldsClass->GetFields($user_table, $this->block_fields_name);
if ($tab_fields !== false) {
$newfieldurl = $backurl . "&action=add_new_field";
$content .= "<a href='$newfieldurl'>Add new field</a>";
$pre_table_head = array('Name', 'Change name', 'Type', 'Caption', 'Elements', 'Required', '');
$pre_table = array();
for ($i = 0; $i < count($tab_fields); $i++) {
if ($field_info = $fieldsClass->FieldExists($tablename, $field_prefix . "_field_name", $tab_fields[$i])) {
$field_information = $field_info;
} else {
$field_information[$field_prefix . '_field_name'] = $tab_fields[$i];
$field_information[$field_prefix . '_field_caption'] = "";
$field_information[$field_prefix . '_field_elements'] = "";
$field_information[$field_prefix . '_field_required'] = 0;
$field_information[$field_prefix . '_rank'] = 0;
$field_information[$field_prefix . '_field_type'] = 'text';
$field_information[$field_prefix . '_id'] = 0;
}
if ($field_information[$field_prefix . '_field_type'] == '') {
}
if ($field_information[$field_prefix . '_field_required'] == 1) {
$required_check = true;
} else
$required_check = false;
$field_name = str_replace($field_name_prefix, "", $field_information[$field_prefix . '_field_name']);
$delurl = $UrlClass->ReplaceUrlValues(array('page' => 'users', 'cpage' => $page_name, 'action' => 'delete_field', 'del_id' => $field_information[$field_prefix . '_id']));
if (!in_array($field_information[$field_prefix . '_field_datatype'], $fieldsClass->tab_select_datatype)) {
if ($dbClass->ColumnExists($config['table_prefix'] . "users", $field_information[$field_prefix . '_field_name'], $params)) {
$field_information[$field_prefix . '_field_datatype'] = $params['type'];
}
}
$pre_table['table'][$i][] = $field_name . $formsClass->create_hidden($field_prefix . '_field_name[]', $field_information[$field_prefix . '_field_name'], '');
;
if (!array_key_exists($field_information['userfields_field_name'], $this->standard_fields_name))
$pre_table['table'][$i][] = $formsClass->create_text('userfields_field_newname[]', $field_name, '');
else
$pre_table['table'][$i][] = $formsClass->create_text('', $field_name, array('disabled' => 'disabled'));
$pre_table['table'][$i][] = $formsClass->create_select($field_prefix . '_field_type[]', $field_information[$field_prefix . '_field_type'], '', $fieldsClass->tab_select_type);
$pre_table['table'][$i][] = $formsClass->create_text($field_prefix . '_field_caption[]', $field_information[$field_prefix . '_field_caption'], '');
$pre_table['table'][$i][] = $formsClass->create_text($field_prefix . '_field_elements[]', $field_information[$field_prefix . '_field_elements'], '');
$pre_table['table'][$i][] = $formsClass->create_select($field_prefix . '_field_required[]', $field_information[$field_prefix . '_field_required'], '', array(0 => 'No', 1 => 'Yes'));
$edit_url = $config['adm_baseurl'] . "index.php?apage=edituserfields&action=edit_field&edit_id=" . $field_information['userfields_id'];
$del_url = $config['adm_baseurl'] . "index.php?apage=edituserfields&action=delete_field&del_id=" . $field_information['userfields_id'];
$options_col = "<a href='$edit_url'><img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a>";
if (!array_key_exists($field_information['userfields_field_name'], $this->standard_fields_name))
$options_col .= "<a href='$del_url' class='delbutton' onclick='return false' name='Delete this field?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
$pre_table['table'][$i][] = $options_col;
$pre_table['rank'][$i] = $field_information[$field_prefix . '_rank'];
}
}
array_multisort($pre_table['rank'], $pre_table['table']);
$content .= $presentationClass->StandardTableWithDataNew($pre_table['table'], $pre_table_head, false, array('id' => 'sort', 'class' => 'wpr_form'));
$content .= $formsClass->create_hidden('send_form', 'yes');
$content .= $formsClass->create_submit('editsubmit', 'Edit', array('id' => 'editsubmit'));
$content .= $formsClass->endform();
}
else {
if (isset($post_vars['add_new_field_submit'])) {
$errors = $fieldsClass->CheckAddEditField($post_vars, $tablename, $field_name_prefix);
if ($errors == "") {
if (!in_array($post_vars[$field_prefix . '_field_datatype'], $this->tab_select_datatype)) {
$post_vars[$field_prefix . '_field_datatype'] == 'text';
}
$dbClass->ChangeDebugMode(false);
$field_name = $field_name_prefix . $post_vars[$field_prefix . '_field_name'];
if ($dbClass->AddColumn($config['table_prefix'] . $user_table, $field_name, $post_vars[$field_prefix . '_field_datatype'])) {
$post_vars[$field_prefix . '_field_name'] = $field_name;
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix);
$url = $config['adm_baseurl'] . "index.php?apage=" . $page_name;
header("Location: " . $url);
die();
} else {
$content = $presentationClass->OperationFailed("Add field failed");
}
$dbClass->ChangeDebugMode(true);
}
}
if (isset($post_vars['edit_field_submit'])) {
if ($fieldinfo = $fieldsClass->GetFieldInfo($get_vars['edit_id'], $tablename, $field_name_prefix)) {
$errors = $fieldsClass->CheckAddEditField($post_vars, $tablename, $field_name_prefix, $get_vars['edit_id']);
if ($errors == "") {
if (!in_array($post_vars[$field_prefix . '_field_datatype'], $this->tab_select_datatype)) {
$post_vars[$tablename . '_field_datatype'] == 'text';
}
$new_name = $field_name_prefix . $post_vars[$field_prefix . '_field_name'];
if ($new_name != $fieldinfo[$field_prefix . '_field_name']) {
if ($dbClass->ChangeColumn($config['table_prefix'] . $user_table, $fieldinfo[$field_prefix . '_field_name'], array('new_column_name' => $new_name))) {
$post_vars[$field_prefix . '_field_name'] = $fieldinfo[$field_prefix . '_field_name'];
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix, '', $new_name);
}
} else {
$post_vars[$field_prefix . '_field_name'] = $fieldinfo[$field_prefix . '_field_name'];
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix, '', $new_name);
}
$content .= $presentationClass->OperationSuccessfull("User fields has been edited");
}
}
}
if ($get_vars['action'] == 'add_new_field') {
if ($errors != "")
$content .= $presentationClass->OperationFailed($errors);
$content .= "<h3>Add New Field</h3>";
$content .= "<a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a><br>";
$content .= $fieldsClass->AddEditField($post_vars, $tablename, $field_name_prefix);
} elseif ($get_vars['action'] == 'edit_field') {
if ($errors != "") {
$content .= $presentationClass->OperationFailed($errors);
}
$content .= "<h3>Edit Field</h3>";
$content .= "<a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a><br>";
if ($field_info = $fieldsClass->GetFieldInfo($get_vars['edit_id'], $tablename, $field_name_prefix)) {
$content .= $fieldsClass->AddEditField($field_info, $tablename, $field_name_prefix, $get_vars['edit_id'], $this->standard_fields_name);
}
}
}
return $content;
}
function SaveUserFieldOrder($column, $fields) {
global $config, $dbClass;
if (count($fields) > 0) {
for ($i = 0; $i < count($fields); $i++) {
$sql = "UPDATE `" . $config['table_prefix'] . "userfields` SET userfields_rank_col='" . $column . "', userfields_rank='" . $i . "' WHERE userfields_field_name='" . $fields[$i] . "'";
$dbClass->Query($sql);
}
return true;
}
}
/*     * **********************************************************\
* return key value array, user_id as key & user_firstname
* user_lastname as value
\*********************************************************** */
function getKeyValueArray() {
global $dbClass, $config;
$sql = "SELECT a.*,u.user_username FROM `" . $config['table_prefix'] . "agents` a,`" . $config['table_prefix'] . "users` u
WHERE a.user_id=u.user_id ";
//ORDER BY a.agent_first_name,a.agent_last_name";
$reC = $dbClass->query($sql);
$arr = array();
if ($reC->RecordCount() > 0) {
while (!$reC->EOF) {
if (trim($reC->fields['agent_first_name'] . ' ' . $reC->fields['agent_last_name']) == "")
$arr[$reC->fields['agent_id']] = $reC->fields['user_username'];
else
$arr[$reC->fields['agent_id']] = $reC->fields['agent_first_name'] . ' ' . $reC->fields['agent_last_name'];
$reC->MoveNext();
}
}
return $arr;
}
/*
function getKeyValueArray()
{
global $dbClass, $config;
$sql = "SELECT user_id, user_firstname, user_lastname FROM `".$config['table_prefix']."users` ORDER BY user_firstname, user_lastname ";
$reC = $dbClass->query($sql);
$arr = array();
if($reC->RecordCount()>0)
{
while(!$reC->EOF)
{
$arr[$reC->fields['user_id']] = $reC->fields['user_firstname']. ' '.  $reC->fields['user_lastname'];
$reC->MoveNext();
}
}
return $arr;
} */
}
?>