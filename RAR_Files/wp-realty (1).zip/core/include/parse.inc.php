<?php

/*
 * Commercial Codebase by WP Realty - RETS PRO Development Team.
 * Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
 * License: http://retspro.com/faq/license/
 */
$remote_db = FALSE;

Class parseClass {

    var $reg_listing_field_tags = "listing\s([^}]*)";
    var $reg_param = "#(\w+)\s*=(?:'([^']*)'|\"([^\"]*)\")#";
    var $table_prefix_tab = array("\{", "\{\!", "\{\!\!");
    var $page;

    function ReplaceTag($tag, $replacement, $content) {
        $content = str_replace($tag, $replacement, $content);
        return $content;
    }

    function TemplateError($name) {
        echo "Template doesn't exist!($name)";
    }

    function GetTemplate($name) {
        if ($content = @file_get_contents($name) or $this->TemplateError($name))
            $content = trim($content);
        return $content;
    }

    /**
     * Gets a repeating block of template - a sub-template
     * @param string $block_name The name of the repeating block - arbitrary unique
     * @param string $content The string to search for the block
     * @return mixed Array of the content of the block and count if specified
     */
    function GetTemplateBlock($block_name, $content) {
        if ($block_name != "") {
            $reg = "/{" . $block_name . "(?:\srepeat=(?:'|\"){1}([0-9]+)(?:'|\"){1})?}(.*?){\/" . $block_name . "}/is";
            if (preg_match($reg, $content, $match)) {
                $return_array = array();
                $return_array['content'] = $match[2];
                if (is_numeric($match[1]))
                    $return_array['repeat'] = $match[1];
                return $return_array;
            }
        }
    }

    /**
     * Replaces a block of template(sub-template)
     * @param string $block_name The name of the repeating block - arbitrary unique
     * @param string $replacement The string to replace the block
     * @param string $content The string to search for the block
     * @return boolean
     */
    function ReplaceTemplateBlock($block_name, $replacement, $content) {
        if ($block_name != "") {
            $reg = "/{" . $block_name . "(?:\srepeat=(?:'|\")([0-9]+)(?:'|\"))?}(.*?){\/" . $block_name . "}/is";
            if ($return = preg_replace($reg, $replacement, $content))
                return $return;
        }
        return false;
    }

    function ParseClassId($class) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "class WHERE class_id='$class'";
        $reInfo = $dbClass->Query($sql);
        if ($reInfo->recordCount() > 0) {
            return $reInfo->fields['class_name'];
        } else
            return false;
    }

    function ParseListingInfo($listing_info) {
//die('here');
        global $dbClass, $config;
        $reg_mls = "#listing-(\d+)-#";
        if (preg_match($reg_mls, $listing_info, $match)) {
            $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsdb WHERE MLS='" . $match[1] . "'";
            $reInfo = $dbClass->QUery($sql, true);
            if ($reInfo->RecordCount() > 0) {
                return $reInfo->fields['listingsdb_id'];
            } else
                return false;
        }
    }

    /*     * **********************************************************\
     * Template Tag Parsing
      \*********************************************************** */

    function MainParse($content, $listing_id = false, $masterdb = false, $only_tags_tab = false) {
//die($content);
        //echo $content;
        global $UrlClass, $config, $jqueryscript, $user_info, $wpr_user, $remote_db;
//echo 'session<br>';
//var_dump($_SESSION['get']);
//echo '<br>getsafe<br>';
//var_dump($get_safe);
        $rsListing = false;
        if (is_array($listing_id) && array_key_exists('listingsdb_id', $listing_id) && array_key_exists('listingsdb_title', $listing_id)) {
            $rsListing = $listing_id;
            $listing_id = $rsListing["listingsdb_id"];
        } elseif ($listing_id === false AND isset($_GET['listing_id'])) {
            $listing_id = $_GET['listing_id'];
            if (!is_numeric($listing_id))
                $listing_id = $this->ParseListingInfo($listing_id);
            require_once($config['wpradmin_basepath'] . 'include/listingfields.inc.php');
            $objListing = registry::register('ListingFields');
            $rsListing = $objListing->GetListingInfo($listing_id);
        }
        require_once($config['wpradmin_basepath'] . 'include/listingfields.inc.php');
        $objListing = registry::register('ListingFields');
        $rsListing = $objListing->GetListingInfo($listing_id);
//var_dump($rsListing);
        if (is_array($rsListing))
            foreach ($rsListing as $key => $value)
                $rsListing[strtolower($key)] = $value;
        for ($main_i = 0; $main_i < 3; $main_i++) {
            $prefix = $this->table_prefix_tab[$main_i];
            $reg = "#" . $prefix . "(\w*)(?:\s([^}]*))?\}#is";
            $co = 0;
            if (preg_match_all($reg, $content, $matches)) {
//echo '    '.$content.'<pre>';
//echo '<pre>';
// var_dump($matches);
//echo '</pre>';
                for ($i = 0; $i < count($matches[0]); $i++) {
                    if (is_array($only_tags_tab) !== false) {
                        if (in_array($matches[1][$i], $only_tags_tab) === false) {
                            continue;
                        }
                    }
                    if (isset($matches[1][$i])) {
                        $replacement = null;
                        $params = false;
                        if (!empty($matches[2][$i])) {
                            if (preg_match_all($this->reg_param, $matches[2][$i], $matches_params)) {
                                for ($i_p = 0; $i_p < count($matches_params[0]); $i_p++) {
                                    if ($matches_params[2][$i_p] != "")
                                        $params[$matches_params[1][$i_p]] = $matches_params[2][$i_p];
                                    else
                                        $params[$matches_params[1][$i_p]] = $matches_params[3][$i_p];
                                }
                            }
                        }
//echo "<pre>";
//print_r($params);
//echo "</pre>";
                        $params['masterdb'] = $masterdb;
//echo $matches[1][$i].'<br>';
                        switch ($matches[1][$i]) {
                            case 'is_admin':
                                if ($wpr_user !== false)
                                    $replacement = "1";
                                else
                                    $replacement = "0";
                                break;
                            case 'is_member':
                                if ($user_info !== false)
                                    $replacement = "1";
                                else
                                    $replacement = "0";
                                break;
                            case 'is_visitor':
                                if ($user_info !== false)
                                    $replacement = "0";
                                else
                                    $replacement = "1";
                                break;
                            case 'base_url':
                                $replacement = $UrlClass->BaseUrl();
                                break;
                            case 'sc_sort':
                                if (!isset($params['init_dir']))
                                    $params['init_dir'] = 'DESC'; //SETTING A DEFAULT
                                if (isset($_SESSION['get'])) {
                                    $get_safe = $_SESSION['get'];
//unset($_SESSION['get']);
                                }
//echo $params['sortedby'];
                                if (!isset($get_safe['sortedby'])) { //this page is running on the default sort from the tag
//echo 'no previous sort<br>';
                                    if ($params['sortedby'] == $get_safe['params']['orderby']) { //this is the same field, so we need to reverse it
//echo '-----------------------same field-------------------------'.$params['sortedby'].'<br>';
                                        if ($get_safe['params']['orderdir'] == 'DESC') {
                                            $next_sort = 'ASC';
                                        } else {
                                            $next_sort = 'DESC';
                                        }
                                    } else { //the sort is using a different field fresh
//echo 'fresh sort<br>';
                                        $next_sort = $params['init_dir'];
                                    }
                                } else { //there is an existing sort
//echo 'orderby '.$get_safe['sortedby'].' sortedby '.$params['sortedby'];
                                    if ($get_safe['sortedby'] == $params['sortedby']) { //this is the same field, so we need to reverse it
//echo 'same field prev sort<br>';
                                        if ($get_safe['sorteddir'] == 'DESC') {
                                            $next_sort = 'ASC';
//echo '-------------desc found-----------------';
                                        } else {
                                            $next_sort = 'DESC';
                                        }
                                    } else { //new sort over old
//echo 'new sort over old<br>';
                                        $next_sort = $params['init_dir'];
                                    }
                                }
                                $replacement = '?sortedby=' . $params['sortedby'] . '&amp;sorteddir=' . $next_sort;
//$replacement = 'sort tag'.$get_safe['sortedby'];
                                break;
                            case 'results_greater_than_max':
                                echo 'undefinedx';
                                if (defined('MAX_LISTING_COUNT')) {
                                    if (TOTAL_LISTING_COUNT > MAX_LISTING_COUNT) {
                                        $replacement = "1";
                                    } else {
                                        $replacement = '0';
                                    }
                                } else {
                                    echo 'undefined';
                                    $replacement = '0';
                                }
                                break;
                            case 'slideshow_effect':
                                if (isset($_GET['slideshow_effect']))
                                    $replacement = $_GET['slideshow_effect'];
                                else
                                    $replacement = 'fade';
                                break;
                            case 'delfavoriteshref':
                                $replacement = "index.php?page=myaccount&action=delfavorite&listing_id=" . $listing_id;
                                break;
// This is being moved to a table called featured.
                            case 'featuredagent':
                                require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
                                $agentClass = registry::register('AgentClass');
                                $replacement = "";
                                if ($aInfo = $agentClass->GetAgentInfo($listing_id)) {
                                    if ($aInfo['agent_featured'] == 'YES')
                                        $replacement = 'featuredagent';
                                }
                                break;
                            case 'agent_thumbnail':
                                require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
                                $agentClass = registry::register('AgentClass');
                                if ($aInfo = $agentClass->GetAgentInfo($listing_id)) {
                                    $rank = 0;
                                    if (is_numeric($params['rank'])) {
                                        $rank = $params['rank'];
                                    }
                                    $replacement = $aInfo['images'][$rank]['thumb'];
                                } else
                                    $replacement = "";
                                break;
                            case 'agent_photo':
                                require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
                                $agentClass = registry::register('AgentClass');
                                if ($aInfo = $agentClass->GetAgentInfo($listing_id)) {
                                    $rank = 0;
                                    if (is_numeric($params['rank'])) {
                                        $rank = $params['rank'];
                                    }
                                    $replacement = $aInfo['images'][$rank]['photo'];
                                } else
                                    $replacement = "";
                                break;
                            case 'agent_link':
                                require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
                                $agentClass = registry::register('AgentClass');
                                if ($aInfo = $agentClass->GetAgentInfo($listing_id)) {
                                    if ($lpInfo = FindPage('wp-realty agentroster')) {
                                        $agents_page = $lpInfo['post_name'];
                                    }
                                    $replacement = '/' . $agents_page . '/agent-' . $listing_id . '-' . $aInfo['first_name'] . '-' . $aInfo['last_name'];
                                }
                                break;
                            case 'office_thumbnail':
                                require_once($config['wpradmin_basepath'] . 'include/office.inc.php');
                                $officeClass = registry::register('OfficeClass');
                                if ($aInfo = $officeClass->GetOfficeInfo($listing_id)) {
                                    $rank = 0;
                                    if (is_numeric($params['rank'])) {
                                        $rank = $params['rank'];
                                    }
                                    $replacement = $aInfo['images'][$rank]['thumb'];
                                }
                                break;
                            case 'office_photo':
                                require_once($config['wpradmin_basepath'] . 'include/office.inc.php');
                                $officeClass = registry::register('OfficeClass');
                                if ($aInfo = $officeClass->GetOfficeInfo($listing_id)) {
                                    $rank = 0;
                                    if (is_numeric($params['rank'])) {
                                        $rank = $params['rank'];
                                    }
                                    $replacement = $aInfo['images'][$rank]['photo'];
                                }
                                break;
                            case 'office_link':
                                $replacement = "index.php?office_id=" . $listing_id . "&page=officeroster";
                                break;
                            case 'successinfo':
                                $replacement = $_GET['successinfo'];
                                break;
                            case 'errorinfo':
                                $replacement = $_GET['errorinfo'];
                                break;
                            case 'slideshow_effect_tab':
                                require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
                                $imagesClass = registry::register('ImagesClass');
                                $replacement = "";
                                for ($t = 0; $t < count($imagesClass->effects_tab); $t++) {
                                    if ($_GET['slideshow_effect'] == $imagesClass->effects_tab[$t])
                                        $replacement .= "<option value='" . $imagesClass->effects_tab[$t] . "' selected>" . $imagesClass->effects_tab[$t] . "</option>";
                                    else
                                        $replacement .= "<option value='" . $imagesClass->effects_tab[$t] . "'>" . $imagesClass->effects_tab[$t] . "</option>";
                                }
                                break;
                            case 'noaction':
                                $replacement = $UrlClass->selfURL();
                                break;
                            case 'adddel_favorite_href':
                                require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
                                $replacement = "index.php?page=listingdetails&action=addfavorites&listing_id=" . $listing_id;
                                if ($user_info !== false) {
                                    $usersClass = registry::register('usersClass');
                                    if ($usersClass->CheckFavoriteListing($user_info['user_id'], $listing_id) === true) {
                                        $replacement = "index.php?page=listingdetails&action=delfavorites&listing_id=" . $listing_id;
                                    }
                                }
                                break;
                            case 'adddel_favorite_caption':
                                require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
                                $replacement = "Add to favorite listings";
                                if ($user_info !== false) {
                                    $usersClass = registry::register('usersClass');
                                    if ($usersClass->CheckFavoriteListing($user_info['user_id'], $listing_id) === true) {
                                        $replacement = "Delete from favorite listings";
                                    }
                                }
                                break;
                            case 'priceformat':
                                require_once($config['wpradmin_basepath'] . 'include/listingfields.inc.php');
                                $listingFields = registry::register('ListingFields');
                                $replacement = $listingFields->ParsePrice($params['price']);
                                break;
                            case 'classformat':
                                $replacement = $this->ParseClassId($params['class']);
                                break;
                            case 'full_link_to_listing':
//ini_set('display_errors', 1);
//error_reporting(E_ALL^E_NOTICE);
                                $hackurl = $config['baseurl'];
                                if (strpos($_SERVER['REQUEST_URI'], 'page=rss') !== false || (isset($_POST['action']) && $_POST['action'] == 'wpr_autosuggest')) {
                                    $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":" . $_SERVER["SERVER_PORT"]);
                                    $config['baseurl'] = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s://" : "://") . $_SERVER['SERVER_NAME'] . $port . "/listing-details/";
//die($config['baseurl']);
                                    $replacement = $UrlClass->AddUrlValues(array(
                                        'page' => 'listingdetails',
                                        'listing_id' => $listing_id
                                            ), $config['baseurl']);
                                    break;
                                }
                                $base = str_replace('/wpradmin_' . $config["blog_id"], '', $config['baseurl']);
                                $base = str_replace('/wpradmin', '', $config['baseurl']);
                                $illegal_chars = array('  ', ' ', ',', '.', ';', ':', '?', '!', '*', '$', '&', '^', '@', '#', "\'", '\"', '(', ')');
                                $link = $base . "listing-details/";
                                $wpr_spacechar = $config['space_character'];
                                $pattern_listing = "listing" . $wpr_spacechar . $rsListing['MLS'] . $wpr_spacechar;
                                if ($config['listing_page_url'] != "") {
                                    $pattern_listing .= $config['listing_page_url'];
                                } else {
                                    $pattern_listing .= "{listing field='class_name'}-{listing field='Address'}-{listing field='City'}-{listing field='State'}";
                                }
//var_dump($rsListing);
                                $custom_url_part = preg_replace_callback('/\\{listing field=[\'"](\\w+)[\'"]\\}/', function($matches) use ($rsListing) {
                                    return $rsListing[strtolower($matches[1])];
                                }, $pattern_listing);
//$custom_url_part = $this->MainParse($pattern_listing, $listing_id, $masterdb);
                                $custom_url_part = strtolower(str_replace($illegal_chars, $wpr_spacechar, $custom_url_part));
                                $listing_link = $link . $custom_url_part;
                                $replacement = str_replace('--', '-', $listing_link);
//echo $listing_link;//die();
                                break;
                            case 'listings_counter_by_field':
                                $replacement = 'Here i am ';
                                /* foreach ($params as $value) {
                                  $replacement .= '<br>'.$key.' '.$value;
                                  } */
//mail('Debug@YourEmailHere.com', 'count tag', $replacement);
                                break;
                            case 'priceflag':
                                $fields = explode("|", $params['field']);
                                $curPrice = intval($rsListing[$fields[0]]);
                                $orgPrice = intval($rsListing[$fields[1]]);
                                if ($curPrice > $orgPrice && $orgPrice) {
                                    $class = "up";
                                    $perc = round((($curPrice / $orgPrice) * 100) - 100);
                                    $pval = number_format($curPrice - $orgPrice, 0);
                                } elseif ($curPrice < $orgPrice && $orgPrice) {
                                    $class = "down";
                                    $perc = round((($orgPrice / $curPrice) * 100) - 100);
                                    $pval = number_format($orgPrice - $curPrice, 0);
                                } else {
                                    $class = "";
                                }
                                if ($class != '') {
                                    $replacement = '<span title="Price ' . $class . ' by \$' . $pval . '" class="price_' . $class . '">' . $perc . '%</span>';
                                } else {
                                    $replacement = '';
                                }
                                break;
                            case 'listing':
                                if (!isset($listingFields)) {
                                    require_once($config['wpradmin_basepath'] . 'include/listingfields.inc.php');
                                    $listingFields = registry::register('ListingFields');
                                }
//var_dump($rsListing);
                                $replacement = $listingFields->ReplaceListingFieldTags($listing_id, $params, $rsListing);
                                $replacement = strip_tags($replacement);
                                $replacement = str_replace('http://', '', $replacement);
                                $replacement = str_replace('https://', '', $replacement);
                                $replacement = str_replace('/', ' ', $replacement);
                                break;
                            case 'compare':
                                if (file_exists(MBX_BASE_SYSTEM_PATH . '/Modules/Compare/Models/Comparison')) {
                                    include_once MBX_BASE_SYSTEM_PATH . '/Modules/Compare/Models/Comparison';
                                    $cmp = Compare\Models\Comparison::GetInstance();
                                    $replacement = $cmp->RenderComparison();
                                }
                                break;
                            case 'agent':
                                require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
                                $agentClass = registry::register('AgentClass');
//$agent_id =	$agentClass->getIdFromAgentCode($rsListing['agent_code']);
                                $agent_id = $listing_id;
                                $replacement = $agentClass->ReplaceAgentFieldTags($agent_id, $params);
                                break;
                            case 'office':
                                require_once($config['wpradmin_basepath'] . 'include/office.inc.php');
                                $officeClass = registry::register('OfficeClass');
//$office_id = $officeClass->getIdFromOfficeCode($rsListing['office_code']);
                                $replacement = $officeClass->ReplaceOfficeFieldTags($listing_id, $params);
                                break;
                            case 'user':
                                require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
                                $userClass = registry::register('usersClass');
                                $replacement = $userClass->ReplaceUserFieldTags($user_info['user_id'], $params);
                                break;
                            case 'explode': // Explode by pipe
                                $values = explode("|", $params['field']);
                                $replacement = "";
                                for ($y = 0; $y < count($values); $y++) {
                                    $replacement .= str_replace("explode_value", $values[$y], $params['template']);
                                }
                                break;
                            case 'explode_c': // Explode by comma
                                $values = explode(",", $params['field']);
                                $replacement = "";
                                for ($y = 0; $y < count($values); $y++) {
                                    $replacement .= str_replace("explode_comma_value", $values[$y], $params['template_c']);
                                }
                                break;
// We need to add in listing image by number, ie, listing_image_url_1 for example.
//SOLVED: {listing_image_url num='2'}
                            case 'listing_image_url':
                                require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
                                $imagesClass = registry::register('ImagesClass');
//var_dump($imagesClass->ImageListingUrl($listing_id, $params));
                                $replacement = $imagesClass->ImageListingUrl($listing_id, $params);
                                if ($replacement === false)
                                    $replacement = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
                                break;
//RYAN C
//parse and include gallery template
                            case 'image_gallery':
                                require_once($config['wpradmin_basepath'] . 'include/shortcode.inc.php');
                                $shortcodeClass = registry::register('ShortCodeClass');
                                require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
//$imagesClass = registry::register('ImagesClass');
                                $imagesClass = new ImagesClass();
                                $imagesClass->remote_db = FALSE;

//echo $rsListing['PhotoCount'];die();
                                if ($rsListing['PhotoCount']) {
                                    //$remote_db = new dbClass();
                                    //$remote_db->ConnectBase('localhost', 'macmullc_creatrg', 'f?cqMVgu1AIT', 'macmullc_trgcrea');
                                    //echo $rsListing['PhotoCount'].' ';//die();
                                    $images = $imagesClass->getAllImageUrls($listing_id, $params, TRUE);
                                } else {
                                    $images = $imagesClass->getAllImageUrls($listing_id, $params, FALSE);
                                }
//var_dump($params);
//$replacement = do_shortcode($shortcodeClass->Show_Gallery($images));
                                $replacement = $shortcodeClass->Show_Gallery($images);
                                break;
                            case 'ryanc_test':
//this for me to test code using a template tag
//require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
//$imagesClass = registry::register('ImagesClass');
//instead of ImageListingUrl, for additional url settings
//$replacement = var_dump($imagesClass->ImageListingAdditionalUrl($listing_id, $params));
//$replacement = "tests";
//if ($replacement === false)
// $replacement = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
                                break;
                            case 'listing_image_all_url':
                                require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
                                $imagesClass = registry::register('ImagesClass');
//var_dump($imagesClass->getAllListingImageUrls($listing_id, $params));
                                $replacement = $imagesClass->getAllListingImageUrls($listing_id, $params);
                                if ($replacement === false)
                                    $replacement = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_image.jpg";
                                break;
//END RYAN C
// Same as above
                            case 'listing_image_thumb_url':
                                if (!isset($imagesClass)) {
                                    require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
                                    $imagesClass = registry::register('ImagesClass');
                                }
                                if ($rsListing['PhotoCount']) {
                                    //$remote_db = new dbClass();
                                    //$remote_db->ConnectBase('localhost', 'macmullc_creatrg', 'f?cqMVgu1AIT', 'macmullc_trgcrea');
                                    //echo $rsListing['PhotoCount'].' tttt';die();
                                    //var_dump($rsListing);
                                    $replacement = $imagesClass->ImageListingThumbUrl($listing_id, $params, $rsListing, TRUE);
                                } else {
                                    $replacement = $imagesClass->ImageListingThumbUrl($listing_id, $params, $rsListing);
                                }

                                if (!isset($replacement) || $replacement === false)
                                    $replacement = $config['adm_baseurl'] . $config['template_dir'] . "/images/no_thumbnail.jpg";
                                break;
                            case 'rss_webroot':
//$replacement = $UrlClass->SelfUrl();
                                $replacement = str_replace("&", "&amp;", $UrlClass->SelfUrl());
                                break;
                            case 'searchengine':
                                require_once($config['wpradmin_basepath'] . 'include/searchengine.inc.php');
                                $searchengineClass = registry::register('SearchEngineClass');
                                $replacement = $searchengineClass->GenerateSearchEngine($params, $_REQUEST);
                                break;
                            case 'agentroster':
                                require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
                                $agentClass = registry::register('AgentClass');
                                $replacement = $agentClass->GetAgentRoster($params, $_REQUEST);
                                break;
                            case 'officeroster':
                                require_once($config['wpradmin_basepath'] . 'include/office.inc.php');
                                $officeClass = registry::register('OfficeClass');
                                $replacement = $officeClass->GetOfficeRoster($params, $_REQUEST);
                                break;
                            case 'userroster':
                                require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
                                $userClass = registry::register('usersClass');
                                $replacement = $userClass->GetUserRoster($params, $_REQUEST);
                                break;
                            case 'search_to_favorite_href':
                                require_once($config['wpradmin_basepath'] . 'include/searchengine.inc.php');
                                $searchengineClass = registry::register('SearchEngineClass');
                                $replacement = $searchengineClass->GenerateFavoriteLink();
                                break;
                            case 'searchengineresults':
                                require_once($config['wpradmin_basepath'] . 'include/searchengine.inc.php');
                                $searchengineClass = registry::register('SearchEngineClass');
                                $replacement = $searchengineClass->GenerateSearchEngineResults($params, $_GET, $user_info['user_id']);
                                break;
                            case 'searchengine':
                                require_once($config['wpradmin_basepath'] . 'include/searchengine.inc.php');
                                $searchengineClass = registry::register('SearchEngineClass');
                                $replacement = $searchengineClass->GenerateSearchEngineNavigation($params, $_REQUEST);
                                break;
                            case 'get_options':
                                $replacement = '';
                                foreach ($_GET as $key => $value) {
                                    $replacement .= "<input type='hidden' name='$key' value='$value'>";
                                }
                                break;
                            case 'googlemaps':
                                require_once($config['wpradmin_basepath'] . 'include/maps.inc.php');
                                $mapsClass = registry::register('MapsClass');
                                $replacement = $mapsClass->GenerateGoogleMaps($listing_id, $params);
                                break;
                            case 'streetview':
                                require_once($config['wpradmin_basepath'] . 'include/maps.inc.php');
                                $mapsClass = registry::register('MapsClass');
                                $replacement = $mapsClass->GenerateStreetView($listing_id, $params);
                                break;
// There are some modules that extend the types of slideshows.
                            case 'images_slideshow':
                                require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
                                $imagesClass = registry::register('ImagesClass');
//var_dump($imagesClass->ImagesSlideshow($listing_id, $params));
                                $replacement = $imagesClass->ImagesSlideshow($listing_id, $params);
                                break;
                            case 'images_slideshow_nav':
                                require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
                                $imagesClass = registry::register('ImagesClass');
                                $replacement = $imagesClass->ImagesSlideshowNavigation($params);
                                break;
                            case 'shortcode':
                                require_once($config['wpradmin_basepath'] . 'include/shortcode.inc.php');
                                $shortcodeClass = registry::register('ShortCodeClass');
//echo 'THIS SHORTCODE ////////////////////////////////////////////';
                                if (isset($_SESSION['get'])) {
                                    $get_safe = $_SESSION['get'];
                                }
                                $params['get'] = $get_safe;
                                if (!isset($get_safe['sorteddir'])) {
                                    $params['get']['sorteddir'] = 'DESC';
                                }
                                $get_safe['params'] = $params;
//var_dump($params);
                                $replacement = $shortcodeClass->GenerateShortCode($listing_id, $params);
                                break;
                            case 'wprcontactform':
                                if ($config['wordpress_plugin'] === true) {
                                    require_once($config['wpradmin_basepath'] . 'include/wpr_contactform.inc.php');
                                    $contactformClass = registry::register('wpr_contactformClass');
                                } else {
                                    require_once($config['wpradmin_basepath'] . 'include/contactform.inc.php');
                                    $contactformClass = registry::register('contactformClass');
                                }
                                $replacement = $contactformClass->GenerateContactForm($params, $listing_id);
                                break;
                            case 'baseurl':
                                $replacement = $config['baseurl'];
                                break;
                            case 'wpr_baseurl':
                                $replacement = $config['wpr_baseurl'];
                                break;
                            case 'template_url':
                                $replacement = $config['baseurl'] . $config['template_dir'] . "/";
                                break;
                            case 'walkscore':
                                require_once($config['wpradmin_basepath'] . 'include/walkscore.inc.php');
                                $walkscoreClass = registry::register('walkscoreClass');
                                $replacement = $walkscoreClass->GenerateWalkScore($listing_id, $params);
                                break;
// I want this removed, we simply wont need a mapsTab with new maps.
                            case 'mapsTab':
                                require_once($config['wpradmin_basepath'] . 'include/walkscore.inc.php');
                                $mapsClass = registry::register('MapsClass');
                                $replacement = $mapsClass->GenerateMapTabs($params);
                                break;
                            case 'link_printer_friendly_href':
//$replacement =  $UrlClass->AddUrlValues(array('page'=>'listingdetails','action'=>'printer_friendly','listing_id'=>$listing_id),$config['wpr_baseurl']);
//var_dump($rsListing);
                                $replacement = $config['adm_baseurl'] . 'index.php?page=printer_friendly&listing_id=' . $listing_id;
                                break;
                            case 'rss_last_modified_href':
//$replacement =  $UrlClass->AddUrlValues(array('page'=>'rss_last_modified'),$config['wpr_baseurl']);
                                $replacement = $config['adm_baseurl'] . 'index.php?page=rss&type=rss_last_modified';
                                break;
                            case 'rss_featured_href':
//$replacement =  $UrlClass->AddUrlValues(array('page'=>'rss_featured'),$config['wpr_baseurl']);
                                $replacement = $config['adm_baseurl'] . 'index.php?page=rss&type=rss_featured';
                                break;
                            case 'rss_listing_guid':
                                $replacement = base64_encode($listing_id);
                                break;
                            case 'mortgage_calculator_href':
                                if (isset($_GET['price']))
//$replacement =  $UrlClass->AddUrlValues(array('page'=>'calculator','price'=>$_GET['price']));
                                    $replacement = $config['adm_baseurl'] . 'index.php?page=calculator&price=' . $_GET['price'];
                                else
//$replacement =  $UrlClass->AddUrlValues(array('page'=>'calculator'));
                                    $replacement = $config['adm_baseurl'] . 'index.php?page=calculator';
                                break;
                            case 'register_href':
                                $replacement = "index.php?page=register";
                                break;
                            case 'logout_href':
                                $replacement = 'index.php?page=logout';
                                break;
                            case 'login_href':
                                $replacement = 'index.php?page=login';
                                break;
                        }
                        if (isset($params['limit']) AND is_numeric($params['limit']) AND $replacement !== null) {
                            $replacement = substr($replacement, 0, $params['limit']);
                        }
                        /*                         * **********************************************************\
                         *
                          \*********************************************************** */
                        if ($replacement === null) {
                            require_once($config['wpradmin_basepath'] . "include/listingfields.inc.php");
                            $listingC = registry::register('ListingFields');
# RemoteDb flag added
                            if ($section_tab = $listingC->GetListingFieldSection(0, $masterdb)) {
//var_dump($section_tab);
//echo $matches[1][$i]."<br>";
                                foreach ($section_tab as $k => $v) {
//echo $k."->".$matches[1][$i]."<br>";
                                    if ($matches[1][$i] == $k) {
# RemoteDb flag added
                                        $replacement = $listingC->GetSectionCode($k, $listing_id, array('masterdb' => $masterdb));
                                    }
                                }
                            }
                        }
                        if ($replacement !== false && $replacement !== null)
                            $content = $this->ReplaceTag($matches[0][$i], $replacement, $content);
                        elseif ($replacement === false) {
//else
                            $content = $this->ReplaceTag($matches[0][$i], "", $content);
                        }
                    }
                }
            }
        }
        for ($main_i = 0; $main_i < 3; $main_i++) {
            $prefix = $this->table_prefix_tab[$main_i];
// echo '<br>prefix: '.$prefix.'<br>';
            $reg = "#" . $prefix . "(if(?:([^}]*)))?\}(.*?)" . $prefix . "endif\}#is";
            $reg_if = "#(.*?)(?=" . $prefix . "elseif(?:[^{]*)?\}|" . $prefix . "else\}|$)#is";
            $reg_elseif = "#" . $prefix . "(elseif(?:([^}]*)))?\}(.*?)(?=" . $prefix . "elseif(?:[^{]*)?\}|" . $prefix . "else\})#is";
            $reg_else = "#" . $prefix . "else\}(.*)#is";
            if (preg_match_all($reg, $content, $matches)) {
//require_once($config['wpradmin_basepath']."include/helpers.php");
                for ($i = 0; $i < count($matches[0]); $i++) {
                    $if_content = $matches[3][$i];
                    $tem = eval("return " . str_replace("{", "", $matches[2][$i]) . ";");
// echo '<br>if content: '.$tem.'<br>';
                    if (eval("return " . str_replace("{", "", $matches[2][$i]) . ";")) {
                        if (preg_match($reg_if, $if_content, $match_if)) {
                            $replacement = $match_if[1];
                        }
                    } else {
                        $found = false;
                        if (preg_match_all($reg_elseif, $if_content, $match_elseif)) {
                            for ($z = 0; $z < count($match_elseif); $z++) {
                                if (eval("return " . $match_elseif[2][$z] . ";")) {
                                    $replacement = $match_elseif[3][$z];
                                    $found = true;
                                }
                            }
//echo '<br> replacement: '.$replacement.'<br>';
                        }
                        if (preg_match($reg_else, $if_content, $match_else) AND $found === false) {
                            $found = true;
                            $replacement = $match_else[1];
                        }
                        if ($found === false) {
                            $replacement = "";
                        }
//echo '<br> replacement: '.$replacement.'<br>';
                    }
                    $content = $this->ReplaceTag($matches[0][$i], $replacement, $content);
                }
            }
        }
        $req_php_tags = "#<\?php\s+(.*?)\?>#is";
        if (preg_match_all($req_php_tags, $content, $match)) {
            for ($i = 0; $i < count($match[0]); $i++) {
ob_start();
                @eval($match[1][$i]);
                $code = ob_get_clean();
//ob_end_flush();
                $phpcode = str_replace('echo', 'return', $match[1][$i]);
                //$code = eval($phpcode);
                $content = str_replace($match[0][$i], $code, $content);
            }
        }
        return $content;
    }

}

// END Class parseClass
?>