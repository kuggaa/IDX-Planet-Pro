<?php

/*
 * Commercial Codebase by WP Realty - RETS PRO Development Team.
 * Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
 * License: http://retspro.com/faq/license/
 */

class Page {

    function GetTemplate($name, $die = false) {
        if ($die)
            $content = @file_get_contents($name) or $this->TemplateError();
        else
            $content = @file_get_contents($name);
        return $content;
    }

    function TemplateError() {
        echo "Template doesn't exist";
        die();
    }

    function AddJavaScriptHead($scripts, $allpath = false) {
        global $config;
        $content = "";
        if (is_array($scripts)) {
            for ($i = 0; $i < count($scripts); $i++)
                if ($allpath)
                    $content .= "<script language='JavaScript' type='text/javascript' src='" . $scripts[$i] . "'></script> \n";
                else
                    $content .= "<script language='JavaScript' type='text/javascript' src='" . $config['wpradmin_baseurl'] . $config["js_dir"] . '/' . $scripts[$i] . "'></script> \n";
        }else {
            if ($allpath)
                $content .= "<script language='JavaScript' type='text/javascript' src='" . $scripts . "'></script> \n";
            else
                $content .= "<script language='JavaScript' type='text/javascript' src='" . $config['wpradmin_baseurl'] . $config["js_dir"] . '/' . $scripts . "'></script> \n";
        }
        return $content;
    }

    function ParseCSS($file) {
        global $config;
        $content = @file_get_contents($file);
        $content = str_replace("{template_images_url}", $config['baseurl'] . $config['template_dir'] . "/images/", $content);
        return $content;
    }

    function AddStylesHead($styles, $base = false, $parse = false) {
        global $config;
        $content = "";
        if ($base === false) {
            $basepath = $config['wpradmin_baseurl'] . $config["css_dir"] . "/";
            $path = $basepath;
        } else {
            $path = "";
        }
        if ($parse === false) {
            if (is_array($styles)) {
                for ($i = 0; $i < count($styles); $i++)
                    $content .= "<link rel='Stylesheet' type='text/css' href='" . $path . $styles[$i] . "' /> \n";
            } else
                $content .= "<link rel='Stylesheet' type='text/css' href='" . $path . $styles . "' /> \n";
        }
        else {
            if (is_array($styles)) {
                for ($i = 0; $i < count($styles); $i++)
                    $content .= "<style type='text/css'>" . $this->ParseCSS($path . $styles[$i]) . "</style> \n";
            } else
                $content .= "<style type='text/css'>" . $this->ParseCSS($path . $styles) . "</style>  \n";
        }
        return $content;
    }

    function ParseLink($url, $baseurl) {
        global $config;
        $new_link = $baseurl;
        $new_page = false;
        $listing = false;
        $new_action = false;
        $other = array();
        require_once($config['wpradmin_basepath'] . "include/controlpanel.inc.php");
        $controlClass = registry::register('controlpanelClass');
        $settings = $controlClass->GetControlPanelFields();
        $spacechar = $settings['controlpanel_space_character'];
        $pattern_listing = "listing" . $spacechar . "{listing field='mls'}" . $spacechar; // change id to mls
        if ($settings['controlpanel_listing_page_url'] != "") {
            $pattern_listing .= $settings['controlpanel_listing_page_url'];
        } else
            $pattern_listing .= "{listing field='class_name'}-{listing field='address'}-{listing field='city'}-{listing field='state'}";
        $pattern_agent = "agent" . $spacechar . "{agent fieldvalue='id'}" . $spacechar . "{agent fieldvalue='permalink'}";
        $pattern_office = "office" . $spacechar . "{office fieldvalue='id'}" . $spacechar . "{office fieldvalue='permalink'}";
        $pattern_user = "user" . $spacechar . "{user field='user_id'}" . $spacechar . "{user field='user_firstname'}-{user field='user_lastname'}";
        if ($url_query = parse_url($url, PHP_URL_QUERY)) {
            parse_str($url_query, $tab);
            foreach ($tab as $key => $value) {
                if ($key == 'page' AND $value != 'searchresults') {
                    if ($value == 'listingdetails')
                        $new_page = $this->listing_page;
                    else
                        $new_page = $value;
                }
                elseif ($key == 'action') {
                    $new_action = $value;
                } elseif ($key == 'listing_id') {
                    require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
                    $parseClass = registry::register('parseClass');
                    $listing = $parseClass->MainParse($pattern_listing, $value, true);
                    $splitters = array('  ', ' ', ',', '.', ';', ':', '?', '!', '*', '$', '&', '^', '@', '#', "\'", '\"', '(', ')');
                    $listing = strtolower(str_replace($splitters, "-", $listing));
                } elseif ($key == 'agent_id') {
                    require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
                    $parseClass = registry::register('parseClass');
                    $listing = $parseClass->MainParse($pattern_agent, $value, true);
                    $splitters = array('  ', ' ', ',', '.', ';', ':', '?', '!', '*', '$', '&', '^', '@', '#', "\'", '\"', '(', ')');
                    if ($spacechar == '-')
                        $splitters[] = '/';
                    $listing = strtolower(str_replace($splitters, "-", $listing));
                }
                elseif ($key == 'office_id') {
                    require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
                    $parseClass = registry::register('parseClass');
                    $listing = $parseClass->MainParse($pattern_office, $value, true);
                    $splitters = array('  ', ' ', ',', '.', ';', ':', '?', '!', '*', '$', '&', '^', '@', '#', "\'", '\"', '(', ')');
                    if ($spacechar == '-')
                        $splitters[] = '/';
                    $listing = strtolower(str_replace($splitters, "-", $listing));
                }
                elseif ($key == 'letter') {
                    $listing = 'letter-' . $value;
                } elseif ($key == 'user_id') {
                    require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
                    $parseClass = registry::register('parseClass');
                    $listing = $parseClass->MainParse($pattern_user, $value, true);
                    $splitters = array('  ', ' ', ',', '.', ';', ':', '?', '!', '*', '$', '&', '^', '@', '#', "\'", '\"', '(', ')');
                    if ($spacechar == '-')
                        $splitters[] = '/';
                    $listing = strtolower(str_replace($splitters, "-", $listing));
                } else
                    $other[$key] = $value;
            }
        }
        if ($new_page !== false)
            $new_link .= $new_page . "/";
        if ($listing !== false)
            $new_link .= $listing . "/";
        if ($new_action !== false)
            $new_link .= $new_action . "/";
        if (count($other > 0)) {
            $new_link .= "?";
            foreach ($other as $key => $value) {
                if (is_array($value)) {
                    for ($i = 0; $i < count($value); $i++)
                        $new_link .= $key . "[]=" . $value[$i] . "&";
                } else
                    $new_link .= $key . "=" . $value . "&";
            }
            $new_link = substr($new_link, 0, -1);
        }
        return $new_link;
    }

    public function ParseLinks($content) {
        global $config;
        if (function_exists('get_site_url')) {
            $baseurl = get_site_url() . "/";
        } else {
            $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":" . $_SERVER["SERVER_PORT"]);
            $baseurl = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s://" : "://") . $_SERVER['SERVER_NAME'] . $port . "/listing-details/";
        }
//$baseurl = get_site_url()."/";
        $reg_links = "#/(\?page.*?)(?:\s|'|\"|<)#is";
        while (preg_match($reg_links, $content, $matches)) {
            $new_link = "index.php" . $matches[1];
            $content = str_replace($matches[1], $new_link, $content);
        }
//$reg_links = "#(".$config['baseurl']."([^\s|'|\"|<]*?)index.php(.*?))(?:\s|'|\"|<)#is";
        $reg_links = "#(" . $baseurl . "index.php(.*?))(?:\s|'|\"|<)#is";
        if (preg_match_all($reg_links, $content, $matches)) {
            for ($i = 0; $i < count($matches[0]); $i++) {
                $new_link = $this->ParseLink($matches[1][$i], $baseurl);
                $temp = $matches[0][$i];
                $count = strlen($temp);
                $last_char = $temp[$count - 1];
                $content = str_replace($matches[0][$i], $new_link . $last_char, $content);
            }
        }
        return $content;
    }

    function ParseLinksWP($content, $baseurl) {
        global $config;
//$main_baseurl = $baseurl[0];
        $reg_links = "#/(\?page.*?)(?:\s|'|\"|<)#is";
        while (preg_match($reg_links, $content, $matches)) {
            $new_link = "index.php" . $matches[1];
            $content = str_replace($matches[1], $new_link, $content);
        }
        $reg_links_short = "#(index.php.*?)(?:\s|'|\"|<)#is";
        foreach ($baseurl as $key => $value) {
            $reg_links = "#((" . $value . "([^\s|'|\"|<]*?))index.php(.*?))(?:\s|'|\"|<)#is";
            if (preg_match_all($reg_links, $content, $matches)) {
                for ($y = 0; $y < count($matches[0]); $y++) {
                    $new_link = $this->ParseLink($matches[1][$y], $matches[2][$y]);
                    $temp = $matches[0][$y];
                    $count = strlen($temp);
                    $last_char = $temp[$count - 1];
                    $content = str_replace($matches[0][$y], $new_link . $last_char, $content);
                }
            }
        }
        foreach ($baseurl as $key => $value) {
            if (preg_match_all($reg_links_short, $content, $matches)) {
                for ($y = 0; $y < count($matches[0]); $y++) {
                    parse_str(str_replace("index.php?", "", $matches[1][$y]), $url_tab);
                    if (isset($url_tab['page'])) {
                        if (isset($baseurl[$url_tab['page']])) {
                            $urlm = $url_tab['page'];
                            $urlto = "index.php?";
                            if ($url_tab['page'] !== 'searchresults')
                                unset($url_tab['page']);
                            foreach ($url_tab as $k => $v) {
                                $urlto .= $k . "=" . $v . "&";
                            }
                            $new_link = $this->ParseLink($baseurl[$urlm] . $urlto, $baseurl[$urlm]);
                            $temp = $matches[0][$y];
                            $count = strlen($temp);
                            $last_char = $temp[$count - 1];
                            $content = str_replace($matches[0][$y], $new_link . $last_char, $content);
                        }
                    }
                }
            }
        }
        return $content;
    }

    function IndexController() {
        global $dbClass, $config, $blog_id, $loginClass;
        $front_pages = array(
            'calculator',
            'rss',
            'printer_friendly'
        );
        if (in_array($_GET['page'], $front_pages)) {
//var_dump($_GET);
            $frontendPage = registry::register('frontendPage');
            if ($_GET['page'] == 'calculator') {
                $get_vars = $_GET;
                $get_vars['page'] = 'calculator';
                if (!is_numeric($get_vars['price']))
                    unset($get_vars['price']);
            }
            elseif ($_GET['page'] == 'rss') {
                $get_vars = $_GET;
                if ($get_vars['type'] == 'rss_last_modified')
                    $get_vars['page'] = 'rss_last_modified';
                elseif ($get_vars['type'] == 'rss_subscribe')
                    $get_vars['page'] = 'rss_subscribe';
                else
                    $get_vars['page'] = 'rss_featured';
            }else {
                $get_vars = $_GET;
                $get_vars['action'] = 'printer_friendly';
                $get_vars['page'] = 'listingdetails';
            }
//var_dump($get_vars);
            $frontendPage->ParseTemplate($template, $get_vars, false);
            $frontent_content = $frontendPage->ReturnPage();
            return $frontent_content;
        } else {
//require_once("config.php");
//require_once($config['wpradmin_basepath']."include/core/core.inc.php");
            global $loginClass;
            $backendPage = registry::register('backendPage');
            $postvars = $dbClass->DataFiltersArray($_POST);
            $getavars = $dbClass->DataFiltersArray($_GET);
            if ($_SESSION['wordpress_plugin'] != true) {
                $postvars['wprealty_password'] = $loginClass->GenerateHash($postvars['wprealty_login'], $postvars['wprealty_password']);
                $loginClass->GetLoginPost($postvars, $info);
            }
            if (!$user_info = $loginClass->CheckLogin()) {
                echo $loginClass->ShowLoginForm($info);
                die();
            }
            if ($user_info['user_level'] == 0) {
                echo $loginClass->ShowLoginForm("Access denied");
                die();
            }
            $modules = array(
                'wprrets', 'file_manager',
            );
            $pages = array(
                'help',
                'editlistings',
                'editmylistings',
                'editofficefields',
                'editoffices',
                'edituserfields',
                'editusers',
                'myaccount',
                'sctemplates',
                'searchengines',
                'addlisting',
                'autocomplete',
                'addoffice',
                'addsearchengine',
                'adduser',
                'editagents',
                'editlistings',
                'propertyclass',
                'controlpanel',
                'templates',
                'addagent',
                'cf_messages',
                'cf_sms',
                'crm_listing_alerts',
                'mbx_system',
                'cf_forms',
                'cf_agents',
                'editagentfields',
                'listingfields',
                'listingfieldzones',
                'logout');
// mm ties in module system
//die();
            include_once $config["basepath"] . 'mbx/admin_bridge.php';
            $pages = array_merge($pages, \Mbx\ModsWithAdmin());
//var_dump($pages);
            if (in_array($_GET['apage'], $pages)) {
                $tag = $_GET['apage'];
                $type = 'page';
            } elseif (in_array($_GET['amod'], $modules)) {
                $tag = $_GET['amod'];
                $type = 'module';
            } else {
                $tag = 'dashboard';
                $type = 'page';
            }
            $content = $backendPage->GetContent($tag, $postvars, $getavars, $user_info, $type);
            return $content;
        }
    }

}

// END class Page
/* * **********************************************************\
 * BackendPage Class
  \*********************************************************** */
class backendPage extends Page {

    protected $backendTemplate;
    protected $array_numbers_admin_tabs;

    public function __construct() {
        global $config, $presentationClass, $formsClass, $jqueryscript, $loginClass, $parseClass, $UrlClass;
//require_once($config['basepath']."/include/listingfields.inc.php");
        $this->SetTemplate();
    }

    function SetTemplate() {
        global $config;
        $this->backendTemplate = $this->GetTemplate($config['wpradmin_basepath'] . 'atheme/common.tpl');
    }

    function ReturnPage() {
        return $this->backendTemplate;
    }

    function getCFClass($includes_path) {
        global $config;
        if ($config['wordpress_plugin'] == 1) {
            require_once($includes_path . "wpr_contactform.inc.php");
            return registry::register('wpr_ContactFormClass');
        } else {
            require_once($includes_path . "contactform.inc.php");
            return registry::register('ContactFormClass');
        }
    }

    function PageSwitch($page, $cpage, $includes_path, $post_vars, $get_vars, $only_content = false) {
        global $config, $UrlClass, $presentationClass, $jqueryscript, $loginClass, $parseClass, $user_level, $log_user_id, $array_numbers;
        $array_numbers = $this->array_numbers_admin_tabs;
        $header = "";
        $scripts = "";
        $styles = "";
        $current = false;
        switch ($page) {
            /*
              case 'searchenginecreator':
              //require_once('searchengine.inc.php');
              if($user_level==3)
              {
              $searchengineClass = registry::register('SearchEngineClass');
              $header = "SearchEngine Options";
              $replacement = $searchengineClass->SearchEngineBackEnd($post_vars,$get_vars);
              }
              else
              $replacement = "";
              break;
             */
            case 'searchengines':
                $current = "se";
                if ($user_level >= 3) {
                    require_once($includes_path . 'searchengine.inc.php');
                    $searchengineClass = registry::register('SearchEngineClass');
                    $header = "Search Forms";
                    $replacement = $searchengineClass->SearchEngineBackEnd($post_vars, $get_vars);
                } else
                    $replacement = "";
                break;
            case 'addsearchengine':
                $current = "se";
                if ($user_level >= 3) {
                    require_once($includes_path . 'searchengine.inc.php');
                    $searchengineClass = registry::register('SearchEngineClass');
                    $header = "Search Forms";
                    $replacement = $searchengineClass->AddEditSearchEngines($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'addagent':
                $current = "agents";
                if ($user_level > 1) {
                    require_once($includes_path . "agent.inc.php");
                    $agentClass = registry::register('AgentClass');
                    $header = "Add agent";
                    $replacement = $agentClass->AddAgentBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'editagents':
                $current = "agents";
                if ($user_level > 1) {
                    require_once($includes_path . "agent.inc.php");
                    $agentClass = registry::register('AgentClass');
                    $header = "Edit agents";
                    $replacement = $agentClass->EditAgentBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'editagentfields':
                if ($user_level >= 3) {
                    $current = "agents";
                    require_once($includes_path . "agent.inc.php");
                    $agentClass = registry::register('AgentClass');
                    $header = "Edit agent fields";
                    $replacement = $agentClass->EditAgentFieldsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'addoffice':
                if ($user_level >= 3) {
                    $current = "offices";
                    require_once($includes_path . "office.inc.php");
                    $officeClass = registry::register('OfficeClass');
                    $header = "Offices";
                    $replacement = $officeClass->AddOfficeBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'editoffices':
                if ($user_level >= 3) {
                    $current = "offices";
                    require_once($includes_path . "office.inc.php");
                    $officeClass = registry::register('OfficeClass');
                    $header = "Offices";
                    $replacement = $officeClass->EditOfficeBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'editofficefields':
                $current = "offices";
                if ($user_level >= 3) {
                    require_once($includes_path . "office.inc.php");
                    $officeClass = registry::register('OfficeClass');
                    $header = "Offices";
                    $replacement = $officeClass->EditOfficeFieldsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'editusers':
                $current = "users";
                if ($user_level >= 3) {
                    require_once($includes_path . "users.inc.php");
                    $usersClass = registry::register('usersClass');
                    $header = "Users";
                    $replacement = $usersClass->EditUserBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'adduser':
                $current = "users";
                if ($user_level >= 3) {
                    require_once($includes_path . "users.inc.php");
                    $usersClass = registry::register('usersClass');
                    $header = "Users";
                    $replacement = $usersClass->AddUserBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'edituserfields':
                $current = "users";
                if ($user_level >= 3) {
                    require_once($includes_path . "users.inc.php");
                    $usersClass = registry::register('usersClass');
                    $header = "Users";
                    $replacement = $usersClass->EditUserFieldsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'addlisting':
                require_once($includes_path . "listingfields.inc.php");
                $listingFields = registry::register('ListingFields');
                $header = "Add Listing";
                $current = "listings";
                $replacement = $listingFields->AddListingBackEnd($post_vars, $get_vars);
                break;
            case 'editlistings':
                $current = "listings";
                if ($user_level >= 2) {
                    require_once($includes_path . "listingfields.inc.php");
                    $listingFields = registry::register('ListingFields');
                    $header = "Edit All Listings";
                    $replacement = $listingFields->EditListingsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'editmylistings':
                $current = "listings";
                require_once($includes_path . "listingfields.inc.php");
                $listingFields = registry::register('ListingFields');
                $header = "Edit My Listings";
                $replacement = $listingFields->EditListingsBackEnd($post_vars, $get_vars, $log_user_id);
                break;
            case 'help':
                $current = "help";
                require_once($includes_path . "help.inc.php");
                $help = registry::register('Help');
                $header = "Help";
                $replacement = $help->ShowHelp($get_vars);
                break;
            case 'autocomplete':
                $current = "autocomplete";
                if ($user_level >= 2) {
                    require_once($includes_path . "autocomplete.inc.php");
                    $autocomplete = registry::register('AutoComplete');
                    $header = "AutoComplete";
                    $replacement = $autocomplete->AutoComplete($get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'listingfields':
                $current = "listings";
                if ($user_level >= 3) {
                    require_once($includes_path . "listingfields.inc.php");
                    $listingFields = registry::register('ListingFields');
                    $header = "Edit listing fields";
                    $replacement = $listingFields->EditListingFieldsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'listingfieldzones':
                $current = "listings";
                if ($user_level >= 3) {
                    require_once($includes_path . "listingfields.inc.php");
                    $listingFields = registry::register('ListingFields');
                    $header = "Listing field zones";
                    $replacement = $listingFields->ListingFieldZonesBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'controlpanel':
                $current = "controlpanel";
                if ($user_level >= 3) {
                    require_once($includes_path . "controlpanel.inc.php");
                    $controlpanel = registry::register('controlpanelClass');
                    $header = "Site Config";
                    $replacement = $controlpanel->ControlPanelBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'myaccount':
                require_once($includes_path . "users.inc.php");
                $usersClass = registry::register('usersClass');
                $header = "User manager";
                $replacement = $usersClass->MyAccount($post_vars, $get_vars, $log_user_id);
                break;
            case 'propertyclass':
                if ($user_level >= 3) {
                    require_once($includes_path . "class.inc.php");
                    $pclassClass = registry::register('pclassClass');
                    $header = "Property Class";
                    $replacement = $pclassClass->ClassBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'templates':
                $current = "templates";
                if ($user_level >= 3) {
                    require_once($includes_path . "template.inc.php");
                    $templateClass = registry::register('templateClass');
                    $header = "Template Editor";
                    $replacement = $templateClass->TemplateEditorBackEnd($post_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'sctemplates':
                $current = "templates";
                if ($user_level >= 3) {
                    require_once($includes_path . "template.inc.php");
                    $templateClass = registry::register('templateClass');
                    $header = "Short Code Editor";
                    $replacement = $templateClass->TemplateEditorBackEnd($post_vars, true);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'contactforms':
                if ($user_level >= 3) {
                    $cfClass = $this->GetCFClass($includes_path);
                    $header = "ContactForm Settings";
                    $replacement = $cfClass->ContactFormBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'cf_agents':
                $current = 'cf_current';
                if ($user_level >= 3) {
                    $cfClass = $this->GetCFClass($includes_path);
                    $header = "Agents";
                    $replacement = $cfClass->AgentsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'cf_messages':
                $current = 'cf_current';
                if ($user_level >= 3) {
                    $cfClass = $this->GetCFClass($includes_path);
                    $header = "Messages";
                    $replacement = $cfClass->MessagesBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'cf_sms':
                $current = 'cf_current';
                if ($user_level >= 3) {
                    $cfClass = $this->GetCFClass($includes_path);
                    $header = "Sms";
                    $replacement = $cfClass->SmsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'crm_listing_alerts':
//die('arrival');
                if ($user_level >= 3) {
                    $header = "Listing Alerts";
                    if (!class_exists($replacement))
                        $replacement = '<script>var WPR = WPR || {};WPR.ajaxurl="' . MBX_API_URL . '";</script>' . file_get_contents(MBX_SYSTEM_ROOT_PATH . '/Modules/ListingAlertsA/Views/Dashboard.html');
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'mbx_system':
                if ($user_level >= 3) {
                    include_once MBX_SYSTEM_ROOT_PATH . '/PageStart.php';
                    $pagedata = Mbx\Page\PageComposer();
                    $header = $pagedata->header;
                    $replacement = $pagedata->page_content;
                }
                break;
            case 'mbx_system_user':
                if ($user_level >= 3) {
                    
                }
                break;
            case 'cf_forms':
                $current = 'cf_current';
                if ($user_level >= 3) {
                    $cfClass = $this->GetCFClass($includes_path);
                    $header = "Forms";
                    $replacement = $cfClass->FormsBackEnd($post_vars, $get_vars);
                } else
                    $replacement = $presentationClass->OperationFailed("Access denied");
                break;
            case 'logout':
                $loginClass->LogOut();
                header("Location: " . $config['adm_baseurl']);
                break;
            case 'dashboard':
                $replacement = $presentationClass->secondHeader("<div class='rp-container'><iframe src='http://retspro.com/clients/announcements.php' height='10' width='960' allowfullscreen='' frameborder='0'></iframe></div>");
                break;
            default:
                include_once $config["basepath"] . 'mbx/PageStart.php';
                $meta = \Mbx\Page\PageComposer();
                $header = $meta->header;
                $replacement = $meta->page_content;
//$replacement = $presentationClass->secondHeader("<div class='rp-container'><iframe src='http://retspro.com/clients/' height='2000' width='960' allowfullscreen='' frameborder='0'></iframe></div>");
        }
        $ret_array = array('content' => $replacement . $script_reolad, 'header' => $header, 'styles' => $styles, 'scripts' => $scripts, 'current' => $current);
        return $ret_array;
    }

    function PrepareTab($tab) {
        $ret = array();
        if (is_array($tab)) {
            foreach ($tab as $key => $value) {
                if (is_array($value))
                    $ret[$key] = $this->PrepareTab($value);
                else
                    $ret[$key] = $value;
            }
            return $ret;
        } else
            return $tab;
    }

    /*     * *********************************************************\
     *
      \*********************************************************** */

    function GetContent($tag, $postvars, $getvars, $user_info, $type = 'page') {
        global $presentationClass, $jqueryscript, $config, $user_level, $log_user_id;
        $user_level = $user_info['user_level'];
        $log_user_id = $user_info['user_id'];
        if ($user_info['user_firstname'] != "" AND $user_info['user_lastname'] != "") {
            $account_name = $user_info['user_firstname'] . " " . $user_info['user_lastname'];
        } else
            $account_name = $user_info['user_username'];
//user_image
        require_once($config['wpradmin_basepath'] . "include/users.inc.php");
        $usersClass = registry::register('usersClass');
        $account_image = $config['wpradmin_baseurl'] . 'images/profile_small_bw.png';
        if ($user_images = $usersClass->GetUserImages($user_info['user_id'], true)) {
            $account_image = $config['adm_baseurl'] . $config['img_dir'] . "/agent_images/" . $user_images[0]["image_thumbname"];
        }
        $includes_path = $config['wpradmin_basepath'] . "/include/";
        if ($type == 'module') {
            $module_file_path = $config['wpradmin_basepath'] . "/modules/" . $tag . "/index.php";
            global $mod_postvars, $mod_getvars;
            $mod_postvars = $postvars;
            $mod_getvars = $getvars;
            if (file_exists($module_file_path)) {
//WPRRETS
                if ($tag == 'wprrets') {
                    define('CONFIG_FILE', $config['basepath'] . "modules/wprrets/db/wprrets_config.txt");
                }
                include($module_file_path);
            } else
                $page = array('content' => 'Module is not found. Please make sure you have installed it properly.<br><br>', 'header' => 'Module Not Found');
        }
        else {
            $page = $this->PageSwitch($tag, "", $includes_path, $postvars, $getvars);
        }
//common.tpl
        $template = $this->backendTemplate;
        if ($user_level >= 3) {
            $topmenu_template = $this->GetTemplate($config['wpradmin_basepath'] . 'atheme/topmenu_admin.tpl');
            $account_type_title = "Administrator";
        } elseif ($user_level == 2) {
            $topmenu_template = $this->GetTemplate($config['wpradmin_basepath'] . 'atheme/topmenu_superagent.tpl');
            $account_type_title = "Super Agent";
        } else {
            $topmenu_template = $this->GetTemplate($config['wpradmin_basepath'] . 'atheme/topmenu_agent.tpl');
            $account_type_title = "Agent";
        }
        $template = str_replace("{menu}", $topmenu_template, $template);
        $template = str_replace("{account_type_title}", $account_type_title, $template);
        $template = str_replace("{account_name}", $account_name, $template);
        $template = str_replace("{account_image}", $account_image, $template);
        $template = str_replace("{script_reload}", $script_reolad, $template);
        $array_scripts = array();
//$array_scripts[] = 'jquery-migrate.min.js'; // mm 12-3-2015 to support bk compat in jq 1.11 upg - breaks uniform.js w/o
//        $array_scripts[] = "json_encode.js";		// Dinesh: Tuesday, July 16, 2013
        $array_scripts[] = "jquery.alerts.js";
        $array_scripts[] = "jquery.forms.js";
//        $array_scripts[] = "swfobject.js";		// json_encode.js & swfobject.js File not found so commented
//$array_scripts[] = "edit_area/edit_area_full.js";
        $array_scripts[] = "jquery.livequery.js";
        $array_scripts[] = "jquery.forms.js";
        $array_scripts[] = "Mbx/admin-menu.js";
        $header = "";
        $styles = "";
        $styles = $this->AddStylesHead(array("wprealty.css", "jquery.alerts.css"/* ,"thickbox.css" */));
        if ($tag == 'sctemplates' OR $tag == 'template' OR $type == 'module') {
            $array_scripts[] = "CodeMirror-2.15/lib/codemirror.js";
            $array_scripts[] = "CodeMirror-2.15/mode/htmlmixed/htmlmixed.js";
            $array_scripts[] = "CodeMirror-2.15/mode/javascript/javascript.js";
            $array_scripts[] = "CodeMirror-2.15/mode/xml/xml.js";
            $styles .= $this->AddStylesHead(array($config['wpradmin_baseurl'] . "js/CodeMirror-2.15/lib/codemirror.css"), true);
            $styles .= $this->AddStylesHead(array($config['wpradmin_baseurl'] . "js/CodeMirror-2.15/theme/default.css"), true);
        }
        $scripts = $this->AddJavaScriptHead($array_scripts);
        $template = str_replace('{backend_content}', $page['content'], $template);
        if (get_magic_quotes_gpc())
            $template = stripslashes($template);
        if ($page['current'] == 'agents' OR $page['current'] == 'offices' OR $page['current'] == 'users') {
            $template = str_replace('{accounts_current}', "class='current'", $template);
            if ($page['current'] == 'agents')
                $template = str_replace("{agents_current}", "style='display:block'", $template);
            if ($page['current'] == 'ageofficesnts')
                $template = str_replace("{offices_current}", "style='display:block'", $template);
            if ($page['current'] == 'users')
                $template = str_replace("{users_current}", "style='display:block'", $template);
        }
        $template = str_replace('{accounts_current}', "", $template);
        $template = str_replace('{agents_current}', "", $template);
        $template = str_replace('{offices_current}', "", $template);
        $template = str_replace('{users_current}', "", $template);
        if ($page['current'] == 'se')
            $template = str_replace('{se_current}', "class='current'", $template);
        else
            $template = str_replace('{se_current}', "", $template);
        if ($page['current'] == 'cf_current')
            $template = str_replace('{cf_current}', "class='current'", $template);
        else
            $template = str_replace('{cf_current}', "", $template);
        if ($page['current'] == 'templates')
            $template = str_replace('{templates_current}', "class='current'", $template);
        else
            $template = str_replace('{templates_current}', "", $template);
        if ($page['current'] == 'autocomplete')
            $template = str_replace('{autocomplete_current}', "class='current'", $template);
        else
            $template = str_replace('{autocomplete_current}', "", $template);
        if ($page['current'] == 'help')
            $template = str_replace('{help_current}', "class='current'", $template);
        else
            $template = str_replace('{help_current}', "", $template);
        if ($page['current'] == 'controlpanel')
            $template = str_replace('{siteconfig_current}', "class='current'", $template);
        else
            $template = str_replace('{siteconfig_current}', "", $template);
        if ($page['current'] == 'listings')
            $template = str_replace('{listings_current}', "class='current'", $template);
        else
            $template = str_replace('{listings_current}', "", $template);
        if ($page['current'] == false)
            $template = str_replace('{dashboard_current}', "class='current'", $template);
        else
            $template = str_replace('{dashboard_current}', "", $template);
//WORDPRESS PLUGIN
        if ($_SESSION['wordpress_plugin'] == true) {
            $template = str_replace('{closeorlogout}', '', $template);
        } else {
            $template = str_replace('{closeorlogout}', '<li><a href="' . $config['baseurl'] . 'index.php?apage=logout">logout</a></li>', $template);
        }
// mm 12-4-15 tie in WPR
        $modulesConfig = '<script>var WPR = WPR || {};WPR.ajaxurl = "' . $config["adm_baseurl"] . 'mbx/index.php";</script>';
        $template = str_replace('{backend_header}', $page['header'], $template);
        $template = str_replace('{backend_scripts_head}', $modulesConfig . $scripts . $page['scripts'], $template);
//if($type!='module')
//{
        $jqueryscript->AddJqueryScriptEnd(
                '$("select, input:checkbox, input:radio, input:file").livequery(function(){
$(this).uniform();
});');
//}
        $template = str_replace('{jqueryend_scripts}', $jqueryscript->PrintScriptEnd(), $template);
        $template = str_replace('{jqueryhead_scripts}', $jqueryscript->PrintScriptHead(), $template);
        $template = str_replace('{css_styles}', $styles . $page['styles'], $template);
        $template = str_replace('{wpr_baseurl}', $config['wpradmin_baseurl'], $template);
        $template = str_replace('{adm_baseurl}', $config['adm_baseurl'], $template);
        return $template;
    }

    /*     * **********************************************************\
     *
      \*********************************************************** */

    function ParseTemplate($template = false) {
//die('here');
        global $config, $UrlClass, $presentationClass, $jqueryscript, $loginClass, $parseClass, $user_level, $log_user_id, $formsClass;
        $only_content = false;
        if ($_GET['only_content'] == true) {
            $only_content = true;
        }
        $tmp = array();
        if (isset($_POST['json_ajax'])) {
            $post_vars = json_decode(stripslashes($_POST['json_ajax']), true);
            if (isset($post_vars['sess_vars'])) {
                $_SESSION = array_merge($_SESSION, $post_vars['sess_vars']);
            }
        } else {
            $post_vars = $_POST;
        }
        $files = false;
        $user_info = $_SESSION['admin_user_info'];
        if ($template == false)
            $template = $this->backendTemplate;
        $template = $parseClass->MainParse($template);
        $template = str_replace("{wpr_baseurl}", $config['wpradmin_baseurl'], $template);
        $template = str_replace("{baseurl}", $config['baseurl'], $template);
        $sel_tab = "";
        $user_level = $user_info['user_level'];
        $log_user_id = $user_info['user_id'];
        $scripts = $this->AddJavaScriptHead(array("jquery-1.4.2.min.js", "jquery-ui-1.8.2.custom.min.js", //"json_encode.js", 	Dinesh: Tuesday, July 16, 2013
            "jquery.alerts.js", "jquery.forms.js", "jquery.uploadify.v2.1.4.js", //"swfobject.js",	json_encode.js & swfobject.js File not found so commented
            "edit_area/edit_area_full.js", "thickbox.js",
            "jquery.livequery.js", "codemirror.js", "codemirror_htmlmixed.js", "codemirror_xml.js", "codemirror_javascript.js", "jquery.forms.js", "jquery-jvert-tabs-1.1.4.js", "jquery.tooltip.js"));
        $header = "";
        $styles = "";
        $styles = $this->AddStylesHead(array("jqueryui.css", "standartstyle.css", "jquery.alerts.css", "thickbox.css"));
        $includes_path = $config['wpradmin_basepath'] . "/include/";
        $reg_menu_content = "#\{menu_content_(\w+)\}#";
        if ($only_content === false) {
            if (preg_match_all($reg_menu_content, $template, $matches)) {
                for ($i = 0; $i < count($matches[0]); $i++) {
                    $ret_tab = $this->PageSwitch($matches[1][$i], false, $includes_path, $post_vars, $_GET, $only_content);
                    $action_hide = $config['wpr_baseurl'] . "admin/index.php?page=" . $matches[1][$i];
                    $replacement = "<div class='main_tabs' id='" . $matches[1][$i] . "'>";
                    $replacement .= "<span class='action_hide' style='display:none'>$action_hide</span>";
                    $replacement .= $ret_tab['content'] . "</div>\n";
                    $template = str_replace('{menu_content_' . $matches[1][$i] . '}', $replacement . $jqueryscript->PrintScriptEnd(), $template);
                }
            }
        } else {
            $ret_tab = $this->PageSwitch($_GET['page'], $_GET['cpage'], $includes_path, $post_vars, $_GET, $only_content);
            $template = $ret_tab['content'];
        }
        $template = str_replace('{backend_content}', $replacement, $template);
        if (get_magic_quotes_gpc())
            $template = stripslashes($template);
        $template = str_replace('{backend_header}', $presentationClass->MainHeader($ret_tab['header']), $template);
        $template = str_replace('{backend_scripts_head}', $scripts . $ret_tab['scripts'], $template);
        $template = str_replace('{jqueryend_scripts}', $jqueryscript->PrintScriptEnd(), $template);
        $template = str_replace('{jqueryhead_scripts}', $jqueryscript->PrintScriptHead(), $template);
        $template = str_replace('{css_styles}', $styles . $ret_tab['styles'], $template);
        $this->backendTemplate = $template;
        return $template;
    }

}

// END class backendPage extends Page
/* * **********************************************************\
 * class frontendPage extends Page
  \*********************************************************** */
class frontendPage extends Page {

    var $frontendTemplate;
    var $template_loginform;
    var $listing_page;

    function __construct($template = false, $listing_page = false) {
        global $config, $presentationClass, $formsClass, $jqueryscript, $loginClass, $parseClass, $UrlClass, $usersClass;
//require_once($config['basepath']."/include/listingfields.inc.php");
        require_once($config['wpradmin_basepath'] . "include/forms.inc.php");
        require_once($config['wpradmin_basepath'] . "include/urlclass.inc.php");
        require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
        require_once($config['wpradmin_basepath'] . "include/searchengine.inc.php");
        require_once($config['wpradmin_basepath'] . "include/presentation.inc.php");
        require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
        require_once($config['wpradmin_basepath'] . "include/jquery.inc.php");
        require_once($config['wpradmin_basepath'] . "include/login.inc.php");
        $this->listing_page = $listing_page;
        $presentationClass = registry::register('PresentationClass');
        $parseClass = registry::register('parseClass');
        $UrlClass = registry::register('UrlClass');
        $formsClass = registry::register('FormsClass');
        $jqueryscript = registry::register('jQueryClass');
        $loginClass = registry::register('loginClass');
        $usersClass = registry::register('usersClass');
        $this->template_loginform = $config['basepath'] . $config['template_dir'] . "/frontend_login.php";
        $this->template_registerform = $config['basepath'] . $config['template_dir'] . "/frontend_register.php";
    }

    function SetTemplate($template) {
        $this->frontendTemplate = $this->GetTemplate($template);
    }

    function CompressScripts($content) {
        $reg_compress = "#<script[^>]*>(.*)</script>#is";
        if (preg_match_all($reg_compress, $content, $matches)) {
            for ($i = 0; $i < count($matches); $i++) {
                $replace = $matches[1][$i];
                $replace = str_replace("\n", " ", $replace);
                $content = str_replace($matches[1][$i], $replace, $content);
                $content = preg_replace('#jQuery#', '$', $content);
            }
        }
        return $content;
    }

    function ReturnPage() {
//$this->frontendTemplate = $this->CompressScripts($this->frontendTemplate);
        return $this->frontendTemplate;
    }

    function ParseTemplate($template = "", $get_vars = false, $wp_realty_pages = false) {
        global $config, $UrlClass, $presentationClass, $jqueryscript, $loginClass, $parseClass, $user_info, $usersClass, $dbClass, $wpr_user;
        $loginClass = registry::register('loginClass');
        $usersClass = registry::register('usersClass');
        $postvars = $dbClass->DataFiltersArray($_POST);
        $loginClass->GetLoginPost($postvars, $info, true);
        $user_info = $loginClass->CheckLogin();
        if ($get_vars === false)
            $get_vars = $_GET;
        if ($template == "")
            $template = $this->frontendTemplate;
//print_r($get_vars);
        $styles .= $this->AddStylesHead("jqueryui.css");
        $includes_path = $config['basepath'] . "/include/";
        $printer = false;
        if (empty($get_vars['page']))
            $get_vars['page'] = 'index';
        $scripts = "";
        $successinfo = 0;
        $errorinfo = 0;
        switch ($get_vars['page']) {
            case 'searchpage':
                require_once($config['wpradmin_basepath'] . "include/searchengine.inc.php");
                $sE = registry::register('SearchEngineClass');
                if (is_numeric($_GET['search_id'])) {
                    $content = "{!searchengine id='" . $_GET['search_id'] . "' page='searchresults'}";
                } elseif ($config['main_searchengine'] !== NULL) {
                    $content = "{!searchengine id='" . $config['main_searchengine'] . "' page='searchresults'}";
                } else
                    $content = "";
                break;
            case 'searchresults':
                require_once($config['wpradmin_basepath'] . "include/searchengine.inc.php");
                $sE = registry::register('SearchEngineClass');
                $search_tmp = false;
                $reg = "#searchengine(\d+)_validate#";
                foreach ($_GET as $k => $v) {
                    if (preg_match($reg, $k, $m)) {
                        $se_id = $m[1];
                        $search_tmp = true;
                        break;
                    }
                }
                if ($search_tmp === false AND $config['main_searchengine'] != 'null') {
                    $se_id = $config['main_searchengine'];
                }
                if (is_numeric($se_id)) {
                    if (isset($postvars['addfavorite'])) {
                        if ($url_query = parse_url($UrlClass->SelfUrl(), PHP_URL_QUERY)) {
                            if ($postvars['favorite_name'] != "") {
                                parse_str($url_query, $get_tab);
//delete bad info
                                unset($get_tab['cur_page']);
                                unset($get_tab['errorinfo']);
                                unset($get_tab['successinfo']);
                                unset($get_tab['addfavorite']);
                                $link = http_build_query($get_tab);
                                $ret = $sE->InsertFavoriteSearch($se_id, $link, $user_info['user_id'], $postvars['favorite_name']);
                                if ($ret === false) {
                                    $_GET['errorinfo'] = "Search hasn't been added to favorite";
                                } elseif ($ret == 'already') {
                                    $_GET['errorinfo'] = "Search has already been added";
                                } else
                                    $_GET['successinfo'] = "Search has been added to favorite";
                            } else
                                $_GET['errorinfo'] = "Search hasn't been added to favorite (no name)";
                        }
                    }
                    $content = "{!searchengineresults id='" . $se_id . "'}";
                } else
                    $content = "";
                break;
            case 'myaccount':
                if ($_GET['action'] == 'logout') {
                    $loginClass->LogOut();
                    $content = "<a href='{login_href}'>Log in!</a>";
                } else {
                    if (!$user_info) {
                        $content = $loginClass->ShowLoginForm($info, $this->template_loginform);
                    } else {
                        if ($_GET['action'] == 'addfavorite') {
                            if ($usersClass->CheckFavoriteListing($user_info['user_id'], $get_vars['listing_id']) === false) {
                                if ($usersClass->AddToFavoriteListing($user_info['user_id'], $get_vars['listing_id'])) {
                                    $successinfo = "Listing has been added to your favorites";
                                }
                            }
                        } elseif ($_GET['action'] == 'delfavorite') {
                            if ($usersClass->CheckFavoriteListing($user_info['user_id'], $get_vars['listing_id']) === true) {
                                if ($usersClass->DeleteFavoriteListing($user_info['user_id'], $get_vars['listing_id'])) {
                                    $successinfo = "Listing has been deleted from your favorites";
                                }
                            }
                        }
                        if (is_numeric($_GET['delfavorite_search'])) {
                            if ($usersClass->DeleteFavoriteSearch($_GET['delfavorite_search'], $user_info['user_id'])) {
                                $successinfo = "Seach has been deleted from your favorites";
                            } else
                                $errorinfo = "Search hasn't been deleted from your favorites";
                        }
                        $content .= $usersClass->ShowFrontendAccount($user_info, $_POST);
                    }
                }
                break;
            case 'listingdetails':
//----------------------------------------------------------------------------------------------------------------------------
// Hack to make by MLS work
                if ($get_vars['action'] != "printer_friendly") {
                    preg_match('%listing-details/listing-([^-]+)-(.*)$%', $_SERVER['REQUEST_URI'], $matches);
                    $sql = "SELECT listingsdb_id FROM " . $config['table_prefix'] . "listingsdb WHERE MLS LIKE '$matches[1]'";
//var_dump($get_vars);
                    $reInfo = $dbClass->GetOneRow($sql, true);
                    $get_vars['listing_id'] = $reInfo['listingsdb_id'];
                    $_GET['listing_id'] = $reInfo['listingsdb_id'];
                }
//die($_GET['listing_id']);
// End hack
                $listing_id = $get_vars['listing_id'];
                require_once($config['wpradmin_basepath'] . "include/listingfields.inc.php");
                $listingC = registry::register('ListingFields');
                if ($get_vars['action'] == 'printer_friendly') {
                    $template_listing = $this->GetTemplate($config['basepath'] . '/' . $config['template_dir'] . '/' . $config['listing_template_printer']);
                } else {
//$template_listing = $this->GetTemplate($config['basepath'].'/'.$config['template_dir'].'/'.$config['listing_template']);
                    $template_listing = $this->GetTemplate($config['basepath'] . '/' . $config['template_dir'] . '/' . 'listing_detail.php');
                }
                $content = $listingC->GetListingDetails($template_listing, $listing_id);
                if ($content) {
//echo '<br>Content<br>'.$content;
                    $rTemp = false;
                    if ($get_vars['action'] == 'addfavorite') {
                        if (!$user_info) {
                            $rTemp = true;
                            $content = $loginClass->ShowLoginForm($info, $this->template_loginform);
                            break;
                        } else {
                            if ($usersClass->CheckFavoriteListing($user_info['user_id'], $listing_id) === false) {
                                if ($usersClass->AddToFavoriteListing($user_info['user_id'], $listing_id)) {
                                    $successinfo = "Listing has been added to your favorites";
                                }
                            }
                        }
                    }
                    if ($get_vars['action'] == 'delfavorite') {
                        if (!$user_info) {
                            $rTemp = true;
                            $content = $loginClass->ShowLoginForm($info, $this->template_loginform);
                            break;
                        } else {
                            if ($usersClass->CheckFavoriteListing($user_info['user_id'], $listing_id) === true) {
                                if ($usersClass->DeleteFavoriteListing($user_info['user_id'], $listing_id)) {
                                    $successinfo = "Listing has been deleted from your favorites";
                                }
                            }
                        }
                    }
                    if ($rTemp == false)
                        $template = $content;
                }
                break;
            case 'agentroster':
                if (is_numeric($_GET['agent_id'])) {
                    $content = "{!agentroster agent_id='" . $_GET['agent_id'] . "'}";
                } else
                    $content = "{!agentroster}";
                break;
            case 'officeroster':
                if (is_numeric($_GET['office_id'])) {
                    $content = "{!officeroster office_id='" . $_GET['office_id'] . "'}";
                } else
                    $content = "{!officeroster}";
                break;
            case 'userroster':
                if (is_numeric($_GET['user_id'])) {
                    $content = "{!userroster user_id='" . $_GET['user_id'] . "'}";
                } else
                    $content = "{!userroster}";
                break;
            case 'rss_last_modified':
                require_once($config['wpradmin_basepath'] . "include/rss.inc.php");
                $rssClass = registry::register('rssClass');
                $template = $rssClass->GetLastModifiedListings();
                break;
            case 'rss_featured':
                require_once($config['wpradmin_basepath'] . "include/rss.inc.php");
                $rssClass = registry::register('rssClass');
                $template = $rssClass->GetFeaturedListings();
                break;
            case 'rss_subscribe':
                require_once($config['wpradmin_basepath'] . "include/controlpanel.inc.php");
                $controlClass = new controlpanelClass();
                $cp_settings = $controlClass->GetControlPanelFields();
                require_once($config['wpradmin_basepath'] . "include/rss.inc.php");
                require_once($config['wpradmin_basepath'] . "include/shortcode.inc.php");
                $data = base64_decode($_GET['data']);
                $data = unserialize($data);
                $data['masterdb'] = $cp_settings["controlpanel_masterdb_bool"];
                $scClass = new ShortCodeClass();
                $id_listings = $scClass->GenerateShortCode(false, $data, true);
                $rssClass = new rssClass();
                $rssClass = registry::register('rssClass');
                if ($data['rss_temp'] != "")
                    $temp = $config['basepath'] . $config['template_dir'] . "/sc_templates/" . $data['rss_temp'];
                else
                    $temp = $config['basepath'] . $config['template_dir'] . "/rss.php";
                $template = $rssClass->GetSubscribeListings($id_listings, $temp);
                break;
            case 'calculator':
                require_once($config['wpradmin_basepath'] . 'include/calculators.inc.php');
                $calc = registry::register('calculators');
                $template = $calc->start_calc();
                break;
            case 'register':
                if (!$user_info OR empty($user_info)) {
//echo "1";
                    if (!isset($_POST['request']))
                        $_POST['request'] = $config['baseurl'] . "index.php?" . $_SERVER['QUERY_STRING'];
                    if ($loginClass->GetRegisterPost($register_info, "register_captcha")) {
                        $request_vars = $_POST;
                        require_once($config['wpradmin_basepath'] . "include/bridge.inc.php");
                        $bridgeClass = new Bridge();
                        $request_vars['password'] = $bridgeClass->GeneratePassword($request_vars['password']);
                        if ($usersClass->InsertNewUser($request_vars)) {
                            $url = $UrlClass->AddUrlValues(array('page' => 'myaccount'), $config['baseurl']);
                            $content = "<a href='{login_href}'>Log In!</a>";
                        }
                    } else {
                        if (is_array($register_info)) {
                            $temp = "";
                            for ($i = 0; $i < count($register_info); $i++)
                                $temp .= $register_info[$i] . "<br/>";
                            $register_info = $temp;
                        }
                        $content = $loginClass->ShowRegisterForm($register_info, $_POST, $this->template_registerform);
                    }
                }
                break;
            case 'login':
                if (!$user_info) {
                    $content = $loginClass->ShowLoginForm($info, $this->template_loginform);
                } else {
                    if ($wp_realty_pages === false)
                        header("Location: " . $UrlClass->AddUrlValues(array('page' => 'myaccount'), $config['baseurl']));
                    else
                        header("Location: " . $wp_realty_pages['myaccount']);
                    die();
                }
                break;
            default:
                if (file_exists($config['basepath'] . $config['template_dir'] . "/" . $_GET['page'] . ".php")) {
                    $content = file_get_contents($config['basepath'] . $config['template_dir'] . "/" . $_GET['page'] . ".php");
                } else
                    $content = $config['template_dir'] . "<h3>Welcome to WPRealty</h3>";
                break;
        }
        $template = str_replace("{content}", $content, $template);

        if (get_magic_quotes_gpc())
            $template = stripslashes($template);
        $listing_id = false;
//if (is_numeric($_GET{'listing_id'}))
        $listing_id = $_GET['listing_id'];
        if ($successinfo == 0 AND ! isset($_GET['successinfo'])) {
            $_GET['successinfo'] = $successinfo;
        }
        if ($errorinfo == 0 AND ! isset($_GET['errorinfo'])) {
            $_GET['errorinfo'] = $errorinfo;
        }
        $tmp = '{!if "{errorinfo}" != "0"}<div class="alert alert_red"><img width="24" height="24" src="' . $config['wpradmin_baseurl'] . 'images/icons/small/white/alarm_Bell.png">{errorinfo}</div>{!endif}';
        $tmp .= '{!if "{successinfo}" !="0"}<div class="alert alert_green"><img width="24" height="24" src="' . $config['wpradmin_baseurl'] . 'images/icons/small/white/alert.png">{successinfo}</div>{!endif}';
        $template = $tmp . $template;
        
        $template = $parseClass->MainParse($template, false, true);
        //die($_GET['listing_id']);
        $template = $parseClass->MainParse($template, false, true);
        $template = $parseClass->MainParse($template, false, true, false, true);
        $template = str_replace('{scripts_head}', $scripts, $template);
        $template = str_replace('{css_styles}', $styles, $template);
//$template = str_replace('{jqueryend_scripts}',$jqueryscript->PrintScriptEnd(),$template);
//$template = str_replace('{jqueryhead_scripts}',$jqueryscript->PrintScriptHead(),$template);
        require_once($config['wpradmin_basepath'] . "include/controlpanel.inc.php");
        $controlClass = registry::register('controlpanelClass');
        $settings = $controlClass->GetControlPanelFields();
//if($settings['controlpanel_url_type']==1)
        $template = $this->ParseLinks($template);
        
        $this->frontendTemplate = $template;
    }

}

// END class frontendPage extends Page
?>
