<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
global $dbClass;
global $config;
//include("../include/common.php");
//include ($config['basepath']."config.php");
function GenerateFieldsSelect($ni,$fields,$option,$none_bool=False)
{
$content = "<SELECT name=".$ni." id=".$ni.">";
if($none_bool==False)
{
$z = 0;
}
else
{
$z=1;
$content .= "<option value='none' id='".$option."_0'>None</option>";
}
//$content .= "<option value='pclass' id='".$option."_pclass'>Pclass</option>";
for($i=$z;$i<count($fields)+$z;$i++)
{
$content .= "<option value='".$fields[($i-$z)]."' id='".$option."_".$i."'>".$fields[($i-$z)]."</option>";
}
$content .= "</select>";
return $content;
}
function media_buttons_send_to_editor($html) {
$html = str_replace("\n"," ", $html);
$html = str_replace("\r"," ", $html);
$html = str_replace("'", "'", $html);
//$html = addslashes($html);
?>
<script type="text/javascript">
/* <![CDATA[ */
var win = window.dialogArguments || opener || parent || top;
win.replace_in_editor("<?php echo str_replace('"', '\"', $html);?>");
//win.ip_doPreview();
/* ]]> */
</script>
<?php
exit;
}
function GenerateTemplateSelect($name,$path)
{
$content = "";
$content .= "<select id='".$name."' name='".$name."'>";
if(is_dir($path))
{
if($dh = opendir($path))
{
while (($file = readdir($dh)) !== false) {
$fileinfo = pathinfo($file);
if($fileinfo['extension']=="php")
$content .= "<option value='".$file."'>".$file."</option>";
}
closedir($dh);
}
}
$content .= "</select>";
return $content;
}
function GenerateTemplateSelectWithDefault($name,$path)
{
$content = "";
$content .= "<select id='".$name."' name='".$name."'>";
$content .= "<option value='default'>default</option>";;
if(is_dir($path))
{
if($dh = opendir($path))
{
while (($file = readdir($dh)) !== false) {
$fileinfo = pathinfo($file);
if($fileinfo['extension']=="php")
$content .= "<option value='".$file."'>".$file."</option>";
}
closedir($dh);
}
}
$content .= "</select>";
return $content;
}
?>