<?php

/*
 * Commercial Codebase by WP Realty - RETS PRO Development Team.
 * Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
 * License: http://retspro.com/faq/license/
 */

class installClass {

    var $include_path;
    var $basepath;

    function __construct($bpath = false) {
        $this->include_path = $bpath . "include/";
        $this->basepath = $bpath;
    }

    function ShowInstallForm() {
        $request = array();
        $error = array();
        $connect_success = false;
        $admin_success = false;
        $content = "<center><h2>WPRealty 3 Installation</h2>";
        $post_vars = $_POST;
        require_once($this->include_path . 'dbClass.inc.php');
        $dbClass = new dbClass();
        $post_vars = $_POST;
        if ($dbClass->ConnectBase($post_vars['db_host'], $post_vars['db_username'], $post_vars['db_password'], $post_vars['db_name'])) {
            $connect_success = true;
            $dbClass->ChangeDebugMode(true);
        } else {
            if (isset($post_vars['condbsubmit']))
                $error[] = "Error Connection";
        }
        $request = $post_vars;
        if ($post_vars['createuser']) {
            if (strlen($post_vars['admin_username']) < 3) {
                $error[] = "Username is too short";
            }
            if (strlen($post_vars['admin_password']) < 5) {
                $error[] = "Password is too short";
            }
            if ($post_vars['admin_password'] != $post_vars['admin_password_rep']) {
                $error[] = "You need to type two identical passwords";
            }
            if (!preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $post_vars['admin_email'])) {
                $error[] = "Invalid e-mail";
            }
            if (!(count($error) > 0)) {
                $admin_success = true;
            } else
                count($error);
            $request = $post_vars;
        }
        if ($connect_success === false) {
//if(count($error))
            $content .= $this->ShowErrors($error);
            $content .= "
<form method='post'>
<table cellpadding='5'>
<tr><td>Database username</td><td><input type='text' value='" . $request['db_username'] . "' name='db_username'></td></tr>
<tr><td>Database password</td><td><input type='text' value='" . $request['db_password'] . "' name='db_password'></td></tr>
<tr><td>Database host</td><td><input type='text' value='" . $request['db_host'] . "' name='db_host'></td></tr>
<tr><td>Database name</td><td><input type='text' value='" . $request['db_name'] . "' name='db_name'></td></tr>
<tr><td colspan='2'><input type='submit' name='condbsubmit' value='Apply'></td></tr>
</table>
</form> ";
        } else {
            if ($admin_success === false) {
                $content .= $this->ShowErrors($error);
                $content .= "<form method='post'>
<input type='hidden' name='db_username' value='" . $post_vars['db_username'] . "'>
<input type='hidden' name='db_password' value='" . $post_vars['db_password'] . "'>
<input type='hidden' name='db_host' value='" . $post_vars['db_host'] . "'>
<input type='hidden' name='db_name' value='" . $post_vars['db_name'] . "'>
<table cellpadding='5'>
<tr><td>Admin username</td><td><input type='text' value='" . $request['admin_username'] . "' name='admin_username'></td></tr>
<tr><td>Admin password</td><td><input type='password' value='" . $request['admin_password'] . "' name='admin_password'></td></tr>
<tr><td>Admin password(again)</td><td><input type='password' value='" . $request['admin_password_rep'] . "' name='admin_password_rep'></td></tr>
<tr><td>Admin email</td><td><input type='text' value='" . $request['admin_email'] . "' name='admin_email'></td></tr>
<tr><td colspan='2'><input type='submit' name='createuser' value='Apply'></td></tr>
</table>
</form>";
            } else {
                if ($this->CreateConfigFile($post_vars)) {
                    $content .= $this->ShowSuccess("Create Common File success!");
                    $content .= $this->CreateDatabaseStructure($request);
                } else
                    $content .= $this->ShowErrors("Create Common File failed!");
            }
        }
        return $content;
    }

    function CreateDatabaseStructure($request, $md5 = false, $blog_id = 0) {
        global $dbClass, $config;
        $basepath = $this->GetBasePath();
        if (!isset($dbClass))
            require_once($basepath . "config.php");
        if ($blog_id > 1)
            $config['table_prefix'] = $config['table_const_prefix'] . $blog_id . "_";
        $dbClass->ChangeDebugMode(true);
// CONTROL PANEL INSTALL
        if (!$dbClass->TableExists($config['table_prefix'] . 'controlpanel')) {
            if ($this->CreateControlPanel())
                $content .= $this->ShowSuccess("ControlPanel Base install success");
            else
                $content .= $this->ShowErrors("ControlPanel Base install failed");
            if ($this->InsertControlPanelData())
                $content .= $this->ShowSuccess("ControlPanelData install success");
            else
                $content .= $this->ShowErrors("ControlPanelData install failed");
        }
// CLASS INSTALL
        if (!$dbClass->TableExists($config['table_prefix'] . 'class')) {
            if ($this->CreateTableClass())
                $content .= $this->ShowSuccess("Class Base install success");
            else
                $content .= $this->ShowErrors("Class Base install failed");
            if ($this->InsertClassData())
                $content .= $this->ShowSuccess("Class Data install success");
            else
                $content .= $this->ShowErrors("Class Data install failed");
        }
// Featured Table
        if (!$dbClass->TableExists($config['table_prefix'] . 'featured')) {
            if ($this->CreateTableFeatured())
                $content .= $this->ShowSuccess("Featured Base install success");
            else
                $content .= $this->ShowErrors("Featured Base install failed");
        }
// GeoCode Table
        if (!$dbClass->TableExists($config['table_prefix'] . 'geocoding')) {
            if ($this->CreateTableGeoCoding())
                $content .= $this->ShowSuccess("GeoCoding Base install success");
            else
                $content .= $this->ShowErrors("GeoCoding Base install failed");
        }
// ListingsDB
        if (!$dbClass->TableExists($config['table_prefix'] . 'listingsdb')) {
            if ($this->CreateTableListingsdb())
                $content .= $this->ShowSuccess("Listingsdb Base install success");
            else
                $content .= $this->ShowErrors("Listingsdb Base install failed");
        }
// Listings Fields Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'listingsfields')) {
            if ($this->CreateTableListingsField())
                $content .= $this->ShowSuccess("ListingsField Base install success");
            else
                $content .= $this->ShowErrors("ListingsField Base install failed");
            if ($this->InsertListingsFieldData($config['table_prefix']))
                $content .= $this->ShowSuccess("ListingsFieldData install success");
            else
                $content .= $this->ShowErrors("ListingsFieldData install failed");
        }

// ListingsImages Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'listingsimages')) {
            if ($this->CreateTableListingsImages())
                $content .= $this->ShowSuccess("ListingsImages Base install success");
            else
                $content .= $this->ShowErrors("ListingsImages Base install failed");
        }
// Media Table
        if (!$dbClass->TableExists($config['table_prefix'] . 'media')) {
            if ($this->CreateTableMedia())
                $content .= $this->ShowSuccess("Media Base install success");
            else
                $content .= $this->ShowErrors("Media Base install failed");
        }
// Check count Listings if 0 add Example
        $this->AddExampleListing();
// Agents
        if (!$dbClass->TableExists($config['table_prefix'] . 'agents')) {
            if ($this->CreateTableAgents())
                $content .= $this->ShowSuccess("Agents Base install success");
            else
                $content .= $this->ShowErrors("Agents Base install failed");
        }
// AgentFields Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'agentfields')) {
            if ($this->CreateTableAgentFields())
                $content .= $this->ShowSuccess("AgentField Base install success");
            else
                $content .= $this->ShowErrors("AgentField Base install failed");
            if ($this->InsertAgentFieldData())
                $content .= $this->ShowSuccess("AgentFieldData install success");
            else
                $content .= $this->ShowErrors("AgentFieldData install failed");
        }
//AgentImages Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'agentimages')) {
            if ($this->CreateTableAgentImages())
                $content .= $this->ShowSuccess("AgentImages Base install success");
            else
                $content .= $this->ShowErrors("AgentImages Base install failed");
        }
// Offices
        if (!$dbClass->TableExists($config['table_prefix'] . 'offices')) {
            if ($this->CreateTableOffices())
                $content .= $this->ShowSuccess("Offices Base install success");
            else
                $content .= $this->ShowErrors("Offices Base install failed");
        }
// OfficeFields Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'officefields')) {
            if ($this->CreateTableOfficeFields())
                $content .= $this->ShowSuccess("OfficeField Base install success");
            else
                $content .= $this->ShowErrors("OfficeField Base install failed");
            if ($this->InsertOfficeFieldData())
                $content .= $this->ShowSuccess("OfficeFieldData install success");
            else
                $content .= $this->ShowErrors("OfficeFieldData install failed");
        }
// OfficeImages Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'officeimages')) {
            if ($this->CreateTableOfficeImages())
                $content .= $this->ShowSuccess("OfficeImages Base install success");
            else
                $content .= $this->ShowErrors("OfficeImages Base install failed");
        }
// Users
        if (!$dbClass->TableExists($config['table_prefix'] . 'users')) {
            if ($this->CreateTableUsers())
                $content .= $this->ShowSuccess("Users Base install success");
            else
                $content .= $this->ShowErrors("Users Base install failed");
        }
// UsersFields Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'userfields')) {
            if ($this->CreateTableUserFields())
                $content .= $this->ShowSuccess("UserFields Base install success");
            else
                $content .= $this->ShowErrors("UserFields Base install failed");
            if ($this->InsertUserFieldData())
                $content .= $this->ShowSuccess("UserFieldsData install success");
            else
                $content .= $this->ShowErrors("UserFieldsData install failed");
        }
// UserImages Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'userimages')) {
            if ($this->CreateTableUserImages())
                $content .= $this->ShowSuccess("UserImages Base install success");
            else
                $content .= $this->ShowErrors("UserImages Base install failed");
        }
        if ($this->InsertUsersData($request, $md5)) {
            $content .= $this->ShowSuccess("UsersData install success");
        } else
            $content .= $this->ShowErrors("UsersData install failed");
// Searchengines Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'searchengines')) {
            if ($this->CreateTableSearchengines())
                $content .= $this->ShowSuccess("Searchengines Base install success");
            else
                $content .= $this->ShowErrors("Searchengines Base install failed");
            if ($this->InsertSearchenginesData())
                $content .= $this->ShowSuccess("Searchengines Data install success");
            else
                $content .= $this->ShowErrors("Searchengines Data install failed");
        }
// Searchenginescontent Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'searchenginescontent')) {
            if ($this->CreateTableSearchenginescontent())
                $content .= $this->ShowSuccess("Searchenginescontent Base install success");
            else
                $content .= $this->ShowErrors("Searchenginescontent Base install failed");
            if ($this->InsertSearchenginesContentData())
                $content .= $this->ShowSuccess("SearchenginesContent Data install success");
            else
                $content .= $this->ShowErrors("SearchenginesContent Data install failed");
        }
// SearchFavoutire Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'searchfavorite')) {
            if ($this->CreateTableSearchFavorite())
                $content .= $this->ShowSuccess("Favorite search Base install success");
            else
                $content .= $this->ShowErrors("Favorite searchBase install failed");
        }
        if (!$dbClass->TableExists($config['table_prefix'] . 'images_cache')) {
            if ($this->CreateTableImageCache())
                $content .= $this->ShowSuccess("ImagesCache Base install success");
            else
                $content .= $this->ShowErrors("ImagesCache Base install failed");
        }
// WPR Contact Content Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'wprcontactcontent')) {
            if ($this->CreateTableWprcontactcontent())
                $content .= $this->ShowSuccess("Wprcontactcontent Base install success");
            else
                $content .= $this->ShowErrors("Wprcontactcontent Base install failed");
        }
// WPR Contact Fields Install
        if (!$dbClass->TableExists($config['table_prefix'] . 'wprcontactfields')) {
            if ($this->CreateTableWprcontactfields())
                $content .= $this->ShowSuccess("Wprcontactfields Base install success");
            else
                $content .= $this->ShowErrors("Wprcontactfields Base install failed");
        }
        if (!$dbClass->TableExists($config['table_prefix'] . 'wprcontactagents')) {
            if ($this->CreateTableWprcontactAgents())
                $content .= $this->ShowSuccess("WprcontactAgents Base install success");
            else
                $content .= $this->ShowErrors("WprcontactAgents Base install failed");
        }
        if (!$dbClass->TableExists($config['table_prefix'] . 'wprcontactmessages')) {
            if ($this->CreateTableWprcontactMessages())
                $content .= $this->ShowSuccess("WprcontactMessages Base install success");
            else
                $content .= $this->ShowErrors("WprcontactMessages Base install failed");
        }
        if (!$dbClass->TableExists($config['table_prefix'] . 'wprcontactaffilliaton')) {
            if ($this->CreateTableWprcontactAffilliaton())
                $content .= $this->ShowSuccess("WprcontactAffilliaton Base install success");
            else
                $content .= $this->ShowErrors("WprcontactAffilliaton Base install failed");
        }
        if (!$dbClass->TableExists($config['table_prefix'] . 'userfavoritelistings')) {
            if ($this->CreateUserFavoriteListingBase())
                $content .= $this->ShowSuccess("UserFavoriteListingBase Base install success");
            else
                $content .= $this->ShowErrors("UserFavoriteListingBase Base install failed");
        }
        if (!$dbClass->TableExists($config['table_prefix'] . 'wprcontactsmsgateways')) {
            if ($this->CreateTableWprcontactSmsGateways())
                $content .= $this->ShowSuccess("WprcontactSmsGateways Base install success");
            else
                $content .= $this->ShowErrors("WprcontactSmsGateways Base install failed");
            if ($this->InsertSMSgateways())
                $content .= $this->ShowSuccess("SmsGateways fields install success");
            else
                $content .= $this->ShowErrors("SmsGateways fields install failed");
        } // `".$config['table_prefix']."pagetaglocations`
        if (!$dbClass->TableExists($config['table_prefix'] . 'pagetaglocations')) {
            if ($this->CreatePageTags())
                $content .= $this->ShowSuccess("CreatePageTags install success");
            else
                $content .= $this->ShowErrors("CreatePageTags install failed");
        }
        $content .= "<br /><a href='" . $config['baseurl'] . "index.php'>Log IN!</a>";
        $dbClass->ChangeDebugMode(true);
        return $content;
    }

    function ShowErrors($errors) {
        $content = "";
        if (is_array($errors)) {
            foreach ($errors as $key => $value) {
                $content .= "<div style='color:red;font-size:19px'>" . $value . "</div>";
            }
        } else
            $content = "<div style='color:red;font-size:19px'>$errors</div>";
        return $content;
    }

    function ShowSuccess($success) {
        $content = "";
        if (is_array($success)) {
            foreach ($success as $key => $value) {
                $content .= "<div style='color:green;font-size:19px'>" . $value . "</div>";
            }
        } else
            $content = "<div style='color:green;font-size:19px'>$success</div>";
        return $content;
    }

    function GetBasePath() {
        $temp = $_SERVER["SCRIPT_FILENAME"];
        if (strpos($temp, 'admin'))
            $temp = explode("/", $temp, -2);
        else
            $temp = explode("/", $temp, -1);
        $temp = implode("/", $temp);
        $basepath = $temp . "/";
        return $basepath;
    }

    function GetBaseUrl() {
        $reg_baseurl = "#(.*?)admin#is";
        /*
          if(preg_match($reg_baseurl,$_SERVER['REQUEST_URI'],$match))
          {
          $baseurl = "http://".$_SERVER['HTTP_HOST'].$match[1];
          }
          else
         */
//$baseurl     = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $baseurl = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s://" : "://") . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $baseurl = preg_replace("#/[^/]*\.php#", "/", $baseurl);
        return $baseurl;
    }

    function GetWprBaseUrl() {
        return $this->GetBaseUrl();
    }

    function CreateConfigFile($request, $wordpress_plugin = false, $mwpr_path = "", $mwpr_url = "", $blog_id = 0) {
        $basepath = $this->basepath;
        $baseurl = $this->GetBaseUrl();
        $wpr_baseurl = $this->GetWprBaseUrl();
        $mainblog = false;
        if ($blog_id > 1 AND is_numeric($blog_id)) {
            $prefix = $blog_id . "_";
        } else {
            $mainblog = true;
            $prefix = "";
        }
        $content = '<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
global $db_data,$config,$dbClass,$jqueryscript,$UrlClass,$lang,$blog_id,$presentationClass;
$db_data["user"] = "' . $request['db_username'] . '";
$db_data["password"] = "' . $request['db_password'] . '";
$db_data["db_host"] = "' . $request['db_host'] . '";
$db_data["db_name"] = "' . $request['db_name'] . '";
$config["wpradmin_basepath"] = \'' . $mwpr_path . '\';
$config["wpradmin_baseurl"] =  \'' . $mwpr_url . '\';
$include_path = $config["wpradmin_basepath"].\'/include/\';
require_once($include_path."dbClass.inc.php");
$dbClass = new dbClass();
if(!$connection = $dbClass->ConnectBase($db_data["db_host"],$db_data["user"],$db_data["password"],$db_data["db_name"]))
{
die("Database Error Connection");
}
$dbClass->ChangeDebugMode(false);
$config["table_prefix"] = "{table_prefix}";
$config["table_variable_prefix"] = "wp_realty_' . $prefix . '";
$config["table_const_prefix"] = "wp_realty_";
// MasterDB
require_once($config["wpradmin_basepath"]."include/registry.inc.php");
require_once($include_path."controlpanel.inc.php");
$controlpanel = registry::register("controlpanelClass");
if($dbClass->TableExists($config["table_const_prefix"]."controlpanel"))
{
if($controlpanel_config = $controlpanel->GetControlPanelOnlyData())
{
$masterdb = false;
if($controlpanel_config["controlpanel_masterdb_bool"]==true)
{
$masterdb = $dbClass->ConnectMasterDB($controlpanel_config["controlpanel_masterdb_server"],$controlpanel_config["controlpanel_masterdb_user"],$controlpanel_config["controlpanel_masterdb_pass"],$controlpanel_config["controlpanel_masterdb_db"]);
$controlpanel_config_external = $controlpanel->GetControlPanelOnlyData($blog_id,true);
$config["baseurl_external"] =  $controlpanel_config_external["controlpanel_baseurl"];
}
foreach($controlpanel_config as $key=>$value)
{
$key = str_replace("controlpanel_","",$key);
$config[$key] = $value;
}
//if($config["baseurl_external"]=="")
if(!isset($config["baseurl_external"]) || $config["baseurl_external"]=="")
$config["baseurl_external"] = $config["baseurl"];
}
}
$config["searchresults_on_page"] = 10;
$config["searchresults_visible_page"] = 5;
$config["nophoto_url"] = "no-photo.jpg";
$config["slideshow_count"] = 8;
$config["js_dir"] = "js";
$config["css_dir"] = "css";
$config["template_dir"] = "template/".$config["template_dir"];
$config["include_dir"] = "include";
$config["basepath"] = \'' . $basepath . '\';
$dbClass->SetDebugFile($config["basepath"]."debug.log");
$config["baseurl"] = "' . $baseurl . '";
$config["adm_baseurl"] = "' . $baseurl . '";
$config["wpr_baseurl"] = "' . $wpr_baseurl . '";
$config["img_dir"] = "fimages";
$config["listing_images"] = $config["basepath"].$config["img_dir"]."/listing_images/";
$config["agent_images"] = $config["basepath"].$config["img_dir"]."/agent_images/";
$config["office_images"] = $config["basepath"].$config["img_dir"]."/office_images/";
$config["user_images"] = $config["basepath"].$config["img_dir"]."/user_images/";
$config["min_length_pass"] = 3;
$config["min_length_username"] = 3;
require_once($config["wpradmin_basepath"]."include/forms.inc.php");
require_once($config["wpradmin_basepath"]."include/urlclass.inc.php");
require_once($config["wpradmin_basepath"]."include/parse.inc.php");
require_once($config["wpradmin_basepath"]."include/searchengine.inc.php");
require_once($config["wpradmin_basepath"]."include/presentation.inc.php");
require_once($config["wpradmin_basepath"]."include/jquery.inc.php");
require_once($config["wpradmin_basepath"]."include/login.inc.php");
require_once($config["wpradmin_basepath"]."include/lang.inc.php");
$presentationClass = registry::register("PresentationClass");
$parseClass = registry::register("parseClass");
$UrlClass = registry::register("UrlClass");
$formsClass = registry::register("FormsClass");
$jqueryscript = registry::register("jQueryClass");
$loginClass = registry::register("loginClass");' . "\n";
        if ($wordpress_plugin == true)
            $content .= '$config["wordpress_plugin"]=true;' . "\n";
        if ($blog_id > 1) {
            $content .= '$config["blog_id"]=' . $blog_id . ';' . "\n";
        }
        $content .= "\n";
        $content .= "?>";
        if ($f = fopen($this->basepath . "config.php", "w")) {
            fwrite($f, $content);
            fclose($f);
            return true;
        } else
            return false;
    }

    function CreatePageTags() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "pagetaglocations` (
  `pagetag_tag_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pagetag_post_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pagetag_post_id` smallint(6) NOT NULL DEFAULT '0',
  `blogid` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableClass() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `class_rank` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`class_id`),
  KEY `idx_class_rank` (`class_rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateControlPanel() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "controlpanel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `controlpanel_basepath` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_baseurl` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_template_dir` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_frontend_template` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_listing_template` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_listing_template_printer` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_listing_template_section` text COLLATE utf8_unicode_ci NULL,
  `controlpanel_favorites_template` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_main_searchengine` int(11) NOT NULL DEFAULT '0',
  `controlpanel_googlemapskey` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_map_address` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_map_city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_map_state` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_map_zip` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_map_country` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_map_lat` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_map_lng` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_walkscorekey` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_walkscore` int(11) NOT NULL DEFAULT '0',
  `controlpanel_streetview` int(11) NOT NULL DEFAULT '0',
  `controlpanel_rss_limit_lastmodified` int(11) NOT NULL DEFAULT '0',
  `controlpanel_rss_limit_featured` int(11) NOT NULL DEFAULT '0',
  `controlpanel_rss_template` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_images_cache_bool` int(11) NOT NULL DEFAULT '0',
  `controlpanel_images_cache_time` int(11) NOT NULL DEFAULT '0',
  `controlpanel_number_format_style` int(11) NOT NULL DEFAULT '0',
  `controlpanel_money_format` int(11) NOT NULL DEFAULT '0',
  `controlpanel_date_format` int(11) NOT NULL DEFAULT '0',
  `controlpanel_img_allowed_ext` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_img_allowed_file_types` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_img_create_thumb` int(11) NOT NULL DEFAULT '0',
  `controlpanel_img_thumb_width` int(11) NOT NULL DEFAULT '0',
  `controlpanel_img_thumb_height` int(11) NOT NULL DEFAULT '0',
  `controlpanel_img_resize_thumb_by` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_masterdb_bool` int(11) NOT NULL DEFAULT '0',
  `controlpanel_masterdb_user` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_masterdb_pass` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_masterdb_db` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_masterdb_server` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_wprets` smallint(3) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls1_from` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls1_to` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls2_from` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls2_to` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls3_from` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls3_to` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_path` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_remote_numeric` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_numeric_bool` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_photocount` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_checkphoto_bool_default` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_checkphoto_bool` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_photonumber_prefix` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_remote_photonumber_prefix_thumb` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_photocount` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_remote_path_thumb` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_remote_custom_mls1_from_thumb` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls1_to_thumb` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls2_from_thumb` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls2_to_thumb` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls3_from_thumb` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_custom_mls3_to_thumb` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_numeric_thumb` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_mls_field_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_url_type` int(11) NOT NULL DEFAULT '0',
  `controlpanel_space_character` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_default_page_title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_default_meta` text COLLATE utf8_unicode_ci NOT NULL,
  `controlpanel_keyword_default_META` text COLLATE utf8_unicode_ci NULL,
  `controlpanel_listing_page_url` text COLLATE utf8_unicode_ci NULL,
  `controlpanel_listing_page_title` text COLLATE utf8_unicode_ci NULL,
  `controlpanel_META_keywords_listing` text COLLATE utf8_unicode_ci NULL,
  `controlpanel_META_Description` text COLLATE utf8_unicode_ci NULL,
  `controlpanel_mu_option` int(11) NOT NULL DEFAULT '0',
  `controlpanel_price_field` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `controlpanel_max_search_results` int(11) NOT NULL DEFAULT '0',
  `controlpanel_img_thumb_quality` int(11) NOT NULL DEFAULT '0',
  `controlpanel_remote_path_addit` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableFeatured() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "featured` (
  `featured_id` int(11) NOT NULL AUTO_INCREMENT,
  `listingsdb_id` int(11) DEFAULT NULL,
  `MLS` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `office_id` int(11) DEFAULT NULL,
  `featured_type` tinyint(3) DEFAULT NULL,
  `featured_title` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `featured_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `featured_rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `featured_active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `featured_expire` date NOT NULL DEFAULT '2001-11-05',
  PRIMARY KEY (`featured_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableGeoCoding() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "geocoding` (
  `id` bigint(16) NOT NULL AUTO_INCREMENT,
  `listingsdb_id` bigint(16) DEFAULT NULL,
  `agent_id` bigint(11) DEFAULT NULL,
  `office_id` bigint(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `mlsid` bigint(16) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` float(10,6) DEFAULT '0.000000',
  `longitude` float(10,6) DEFAULT '0.000000',
  `class_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `html` text COLLATE utf8_unicode_ci NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marker` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(3) unsigned DEFAULT '0',
  `record_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableListingsField() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "listingsfields` (
  `listingfields_id` int(11) NOT NULL AUTO_INCREMENT,
  `listingfields_field_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingfields_field_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingfields_datatype` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingfields_tip` text COLLATE utf8_unicode_ci NULL,
  `listingfields_field_caption` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingfields_field_elements` text COLLATE utf8_unicode_ci NULL,
  `listingfields_field_required` int(11) NOT NULL DEFAULT '0',
  `listingfields_rank` int(11) NOT NULL DEFAULT '0',
  `listingfields_rank_col` int(11) NOT NULL DEFAULT '0',
  `listingfields_section` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingfields_section_rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`listingfields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableListingsdb() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "listingsdb`(
`listingsdb_id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` int(11) NOT NULL DEFAULT '0',
`class_id` int(11) NOT NULL DEFAULT '0',
`agent_id` int(11) DEFAULT NULL DEFAULT '0',
`agent_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
`office_id` int(11) DEFAULT NULL,
`office_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
`listingsdb_title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`listingsdb_creation_date` date DEFAULT NULL,
`listingsdb_last_modified` timestamp NULL DEFAULT NULL,
`listingsdb_featured` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
`Address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`City` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`State` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
`Zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
`County` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
`Price` int(11) COLLATE utf8_unicode_ci DEFAULT NULL,
`listingsdb_is_photo_downloaded` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
`listingsdb_photo_last_downloaded` date DEFAULT NULL,
`listingsdb_is_mark_for_remove` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
`latitude` float(10,6) NULL DEFAULT '0.000000',
`longitude` float(10,6) NULL DEFAULT '0.000000',
`MLS` varchar(20) DEFAULT NULL,
PRIMARY KEY (`listingsdb_id`),
UNIQUE (MLS),
KEY (`Price`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableMedia() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "media` (
`media_id` bigint(16) NOT NULL AUTO_INCREMENT,
`listingsdb_id` bigint(16) NOT NULL,
`MLS` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
`media_post_id` int(11) NULL,
`media_type` tinyint(3) DEFAULT NULL,
`media_title` varchar(64) COLLATE utf8_unicode_ci NULL,
`media_path` varchar(255) COLLATE utf8_unicode_ci NULL,
`media_file_name` varchar(64) COLLATE utf8_unicode_ci NULL,
`media_description` varchar(255) COLLATE utf8_unicode_ci NULL,
`media_rank` tinyint(3) unsigned NULL DEFAULT '0',
`media_active` tinyint(3) DEFAULT NULL,
`media_expire` date NULL,
PRIMARY KEY (`media_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableAgents() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "agents` (
`agent_id` int(11) NOT NULL AUTO_INCREMENT,
`agent_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
`user_id` int(11) DEFAULT NULL,
`office_id` int(11) DEFAULT NULL,
`office_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_emailaddress` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_first_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_last_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_license` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_comments` text COLLATE utf8_unicode_ci NULL,
`agent_details` text COLLATE utf8_unicode_ci NULL,
`agent_creation_date` date NULL DEFAULT NULL,
`agent_modified_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
`agent_hit_count` int(11) DEFAULT NULL,
`agent_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_featured` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_active` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_limits` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
`agent_cellphone` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
PRIMARY KEY (`agent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableAgentFields() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "agentfields` (
  `agentfields_id` int(11) NOT NULL AUTO_INCREMENT,
  `agentfields_field_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `agentfields_field_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `agentfields_datatype` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `agentfields_tip` text COLLATE utf8_unicode_ci NULL,
  `agentfields_field_caption` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `agentfields_field_elements` text COLLATE utf8_unicode_ci NULL,
  `agentfields_field_required` int(11) NOT NULL DEFAULT '0',
  `agentfields_rank` int(11) DEFAULT NULL,
  `agentfields_rank_col` int(11) DEFAULT NULL,
  PRIMARY KEY (`agentfields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableAgentImages() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "agentimages` (
  `agentimage_id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL DEFAULT '0',
  `image_filename` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_thumbname` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_caption` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`agentimage_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableOffices() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "offices` (
  `office_id` int(11) NOT NULL AUTO_INCREMENT,
  `office_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `office_featured` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `office_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `office_email` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `office_phone` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `office_address` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `office_comments` text COLLATE utf8_unicode_ci NULL,
  `office_details` text COLLATE utf8_unicode_ci NULL,
  `office_creation_date` date NULL DEFAULT NULL,
  `office_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `office_hit_count` int(11) NOT NULL DEFAULT '0',
  `office_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `office_parent` int(11) DEFAULT NULL,
  PRIMARY KEY (`office_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableOfficeFields() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "officefields` (
  `officefields_id` int(11) NOT NULL AUTO_INCREMENT,
  `officefields_field_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `officefields_field_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `officefields_datatype` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `officefields_tip` text COLLATE utf8_unicode_ci NULL,
  `officefields_field_caption` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `officefields_field_elements` text COLLATE utf8_unicode_ci NOT NULL,
  `officefields_field_required` int(11) NOT NULL DEFAULT '0',
  `officefields_rank` int(11) NOT NULL DEFAULT '0',
  `officefields_rank_col` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`officefields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableOfficeImages() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "officeimages` (
  `officeimage_id` int(11) NOT NULL AUTO_INCREMENT,
  `office_id` int(11) NOT NULL DEFAULT '0',
  `image_filename` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_thumbname` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_caption` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`officeimage_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableUserFields() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "userfields` (
  `userfields_id` int(11) NOT NULL AUTO_INCREMENT,
  `userfields_field_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userfields_field_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userfields_datatype` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userfields_tip` text COLLATE utf8_unicode_ci NULL,
  `userfields_field_caption` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userfields_field_elements` text COLLATE utf8_unicode_ci NOT NULL,
  `userfields_field_required` int(11) NOT NULL DEFAULT '0',
  `userfields_rank` int(11) NOT NULL DEFAULT '0',
  `userfields_rank_col` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userfields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableUserImages() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "userimages` (
  `userimage_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `image_filename` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_thumbname` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_caption` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userimage_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

// Files associated with this table, images.inc.php, listings.inc.php and listingfields.inc.php
// Added listingsimages_url 06/10/2012
    function CreateTableListingsImages() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "listingsimages` (
  `listingsimages_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `listingsdb_id` int(11) NOT NULL DEFAULT '0',
  `listingsimages_caption` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingsimages_file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingsimages_full_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `listingsimages_thumb_file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `listingsimages_description` text COLLATE utf8_unicode_ci NULL,
  `listingsimages_rank` int(11) NOT NULL DEFAULT '0',
  `listingsimages_active` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`listingsimages_id`),
  KEY `idx_images_listing_id` (`listingsdb_id`),
  KEY `idx_images_rank` (`listingsimages_rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableSearchengines() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "searchengines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `template` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `searchresults_template` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `searchresults_on_page` int(11) NOT NULL DEFAULT '0',
  `searchengine_type` int(11) NOT NULL DEFAULT '0',
  `options` text COLLATE utf8_unicode_ci NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `tab_rank` int(11) NOT NULL DEFAULT '0',
  `tab_caption` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `class_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableSearchFavorite() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "searchfavorite` (
  `favorite_id` int(11) NOT NULL AUTO_INCREMENT,
  `search_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `link` varchar(400) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `save_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`favorite_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableSearchenginescontent() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "searchenginescontent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `searchengines_id` int(11) NOT NULL DEFAULT '0',
  `field_in_table` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field_caption` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `input_type` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `input_option` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field_required` int(11) NOT NULL DEFAULT '0',
  `field_value` longtext COLLATE utf8_unicode_ci NULL,
  `field_options` longtext COLLATE utf8_unicode_ci NULL,
  `field_options_type` int(11) NOT NULL DEFAULT '0',
  `field_rank` int(11) NOT NULL DEFAULT '0',
  `field_rank_col` int(11) NOT NULL DEFAULT '0',
  `field_width` int(11) NOT NULL DEFAULT '0',
  `field_height` int(11) NOT NULL DEFAULT '0',
  `field_position` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field_select_kind` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableUsers() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_username` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_password` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_firstname` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_lastname` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_level` int(11) NOT NULL DEFAULT '0',
  `user_phone` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_mobile` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_fax` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_homepage` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_info` text COLLATE utf8_unicode_ci NULL,
  `signup_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateUserFavoriteListingBase() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "userfavoritelistings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `listing_id` int(11) NOT NULL DEFAULT '0',
  `mls_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `save_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableWprcontactcontent() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "wprcontactcontent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `generic_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `generic_cc` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `generic_subj` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `generic_msg` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `thankyoumessage` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `thankyouurl` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message_hide` int(11) NOT NULL DEFAULT '0',
  `subject_hide` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableWprcontactfields() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "wprcontactfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wprcontact_id` int(11) NOT NULL DEFAULT '0',
  `field_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `standard_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field_elements` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `standard_field` int(11) NOT NULL DEFAULT '0',
  `field_required` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableWprcontactAgents() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "wprcontactagents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL DEFAULT '0',
  `receive_leads` int(11) NOT NULL DEFAULT '0',
  `use_sms` int(11) NOT NULL DEFAULT '0',
  `carrier_id` int(11) NOT NULL DEFAULT '0',
  `cell_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableWprcontactMessages() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "wprcontactmessages` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `form_id` int(20) NOT NULL DEFAULT '0',
  `sender_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sender_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci NULL,
  `sent` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recipient` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableWprcontactSmsGateways() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "wprcontactsmsgateways` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`carrier` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
`domain` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableWprcontactAffilliaton() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "wprcontactaffiliation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL DEFAULT '0',
  `user_mail` varchar(60) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function CreateTableImageCache() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS `" . $config['table_prefix'] . "images_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filename` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_check` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        return $dbClass->Query($sql);
    }

    function InsertSearchenginesData() {
        global $dbClass, $config;
        $sql = "INSERT INTO  " . $config['table_prefix'] . "searchengines SET
id = '1',
name = 'main_searchengine',
template = '',
searchresults_template = 'searchresults.php',
searchresults_on_page = 10,
searchengine_type = 1";
        $dbClass->Query($sql);
        $sql = "INSERT INTO  " . $config['table_prefix'] . "searchengines SET
id = '2',
name = 'main_searchengine',
template = '',
searchresults_template = 'searchresults.php',
searchresults_on_page = 10,
searchengine_type = 1,
parent_id=1";
        ;
        return $dbClass->Query($sql);
    }

    function InsertSearchenginesContentData() {
        global $dbClass, $config;
        $sql = "INSERT INTO  " . $config['table_prefix'] . "searchenginescontent SET
searchengines_id = '2',
field_in_table = 'class_name',
field_name = 'Class Name',
field_caption = 'Class',
field_type = 'multiselect',
input_type = '',
input_option = '',
field_required = '0',
field_value = 'Homes|Land|Farms|Commercial|Rentals|Condos|Multi-Family',
field_options = '',
field_rank = '1'";
        $dbClass->Query($sql);
        $sql = "INSERT INTO  " . $config['table_prefix'] . "searchenginescontent SET
searchengines_id = '2',
field_in_table = 'listingsdb_title',
field_name = 'listing_name',
field_caption = 'Listing Name',
field_type = 'text',
input_type = '',
input_option = '',
field_required = '0',
field_value = '',
field_options = '',
field_rank = '2'";
        $dbClass->Query($sql);
        $sql = "INSERT INTO  " . $config['table_prefix'] . "searchenginescontent SET
searchengines_id = '2',
field_in_table = 'Price',
field_name = 'listing_price_max',
field_caption = 'Max Price',
field_type = 'max',
input_type = '',
input_option = '',
field_required = '0',
field_value = '',
field_options = '',
field_rank = '3'";
        $dbClass->Query($sql);
        $sql = "INSERT INTO  " . $config['table_prefix'] . "searchenginescontent SET
searchengines_id = '2',
field_in_table = 'Price',
field_name = 'listing_price_min',
field_caption = 'Min Price',
field_type = 'min',
input_type = '',
input_option = '',
field_required = '0',
field_value = '',
field_options = '',
field_rank = '4'";
        return $dbClass->Query($sql);
    }

    function InsertListingsFieldData($tprefix = '') {
        global $dbClass, $config;
        if ($tprefix !== '')
            $config['table_prefix'] = $tprefix;

        require_once($config['wpradmin_basepath'] . 'include/listingfields.inc.php');
//$listingfields = registry::register('ListingFields');
        $listingfields = new ListingFields(false);
//die($config['wpradmin_basepath'] . 'include/listingfields.inc.php 1-> '.$config['table_prefix']);

        $colTab = $dbClass->GetColumns($config['table_prefix'] . "listingsdb", $listingfields->block_fields_name, true);
//var_dump($colTab);
        if ($colTab) {
            $cnt = 0;
            $col = 0;
            $cmax = ceil(count($colTab) / 3);
            for ($i = 0; $i < count($colTab); $i++) {
//$caption = preg_replace("","",$colTab['Field']);
                $fInfo = array();
                $fInfo['field_required'] = 0;
                $fInfo['field_elements'] = "";
                $fInfo['field_caption'] = "";
                if (array_key_exists($colTab[$i]['Field'], $listingfields->standard_fields_name)) {
                    $fInfo = $listingfields->standard_fields_name[$colTab[$i]['Field']];
                }
                if (array_key_exists($colTab[$i]['Type'], $listingfields->tab_select_datatype))
                    $datatype = $colTab[$i]['Type'];
                else
                    $datatype = 'varchar(100)';
                $sql = "INSERT INTO " . $config['table_prefix'] . "listingsfields SET
listingfields_field_name = '" . $colTab[$i]['Field'] . "',
listingfields_field_type ='text',
listingfields_datatype ='" . $datatype . "',
listingfields_field_caption ='" . $fInfo['field_caption'] . "',
listingfields_field_elements ='" . $fInfo['field_elements'] . "',
listingfields_field_required ='" . $fInfo['field_required'] . "',
listingfields_rank = '" . $cnt . "',
listingfields_rank_col = '" . $col . "'
";
                $cnt++;
                if ($cnt == $cmax) {
                    $col++;
                    $cnt = 0;
                }

                $return = $dbClass->Query($sql);
            }
            return $return;
        }
        die('no fields');
    }

    function InsertAgentFieldData() {
        global $dbClass, $config;
        require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
        $agentC = registry::register('AgentClass');
        if ($colTab = $dbClass->GetColumns($config['table_prefix'] . "agents", $agentC->block_fields_name, true)) {
            $cnt = 0;
            $col = 0;
            $cmax = ceil(count($colTab) / 2);
            for ($i = 0; $i < count($colTab); $i++) {
                $fInfo = array();
                $fInfo['field_required'] = 0;
                $fInfo['field_elements'] = "";
                $fInfo['field_caption'] = "";
                if (array_key_exists($colTab[$i]['Field'], $agentC->standard_fields_name)) {
                    $fInfo = $agentC->standard_fields_name[$colTab[$i]['Field']];
                }
                if (array_key_exists($colTab[$i]['Type'], $agentC->tab_select_datatype))
                    $datatype = $colTab[$i]['Type'];
                else
                    $datatype = 'varchar(100)';
                $sql = "INSERT INTO " . $config['table_prefix'] . "agentfields SET
agentfields_field_name = '" . $colTab[$i]['Field'] . "',
agentfields_field_type ='text',
agentfields_datatype ='" . $datatype . "',
agentfields_field_caption ='" . $fInfo['field_caption'] . "',
agentfields_field_elements ='" . $fInfo['field_elements'] . "',
agentfields_field_required ='" . $fInfo['field_required'] . "',
agentfields_rank = '" . $cnt . "',
agentfields_rank_col = '" . $col . "'";
                $return = $dbClass->Query($sql);
                $cnt++;
                if ($cnt == $cmax) {
                    $col++;
                    $cnt = 0;
                }
            }
            return $return;
        }
    }

    function InsertOfficeFieldData() {
        global $dbClass, $config;
        require_once($config['wpradmin_basepath'] . 'include/office.inc.php');
        $officeC = registry::register('OfficeClass');
        if ($colTab = $dbClass->GetColumns($config['table_prefix'] . "offices", $officeC->block_fields_name, true)) {
            $cnt = 0;
            $col = 0;
            $cmax = ceil(count($colTab) / 2);
            for ($i = 0; $i < count($colTab); $i++) {
//$caption = preg_replace("","",$colTab['Field']);
                $fInfo = array();
                $fInfo['field_required'] = 0;
                $fInfo['field_elements'] = "";
                $fInfo['field_caption'] = "";
                if (array_key_exists($colTab[$i]['Field'], $officeC->standard_fields_name)) {
                    $fInfo = $officeC->standard_fields_name[$colTab[$i]['Field']];
                }
                if (array_key_exists($colTab[$i]['Type'], $officeC->tab_select_datatype))
                    $datatype = $colTab[$i]['Type'];
                else
                    $datatype = 'varchar(100)';
                $sql = "INSERT INTO " . $config['table_prefix'] . "officefields SET
officefields_field_name = '" . $colTab[$i]['Field'] . "',
officefields_field_type ='text',
officefields_datatype ='" . $datatype . "',
officefields_field_caption ='" . $fInfo['field_caption'] . "',
officefields_field_elements ='" . $fInfo['field_elements'] . "',
officefields_field_required ='" . $fInfo['field_required'] . "',
officefields_rank = '" . $cnt . "',
officefields_rank_col = '" . $col . "'";
                $return = $dbClass->Query($sql);
                $cnt++;
                if ($cnt == $cmax) {
                    $col++;
                    $cnt = 0;
                }
            }
            return $return;
        }
    }

    function InsertUserFieldData() {
        global $dbClass, $config;
        require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
        $usersC = registry::register('usersClass');
        if ($colTab = $dbClass->GetColumns($config['table_prefix'] . "users", $usersC->block_fields_name, true)) {
            $cnt = 0;
            $col = 0;
            $cmax = ceil(count($colTab) / 2);
            for ($i = 0; $i < count($colTab); $i++) {
//$caption = preg_replace("","",$colTab['Field']);
                $fInfo = array();
                $fInfo['field_required'] = 0;
                $fInfo['field_elements'] = "";
                $fInfo['field_type'] = "text";
                $fInfo['field_caption'] = "";
                $fInfo['field_tip'] = "";
                if (array_key_exists($colTab[$i]['Field'], $usersC->standard_fields_name)) {
                    $fInfo = $usersC->standard_fields_name[$colTab[$i]['Field']];
                }
                if (array_key_exists($colTab[$i]['Type'], $usersC->tab_select_datatype))
                    $datatype = $colTab[$i]['Type'];
                else
                    $datatype = 'varchar(100)';
                $sql = "INSERT INTO " . $config['table_prefix'] . "userfields SET
userfields_field_name = '" . $colTab[$i]['Field'] . "',
userfields_field_type ='" . $fInfo['field_type'] . "',
userfields_datatype ='" . $datatype . "',
userfields_field_caption ='" . $fInfo['field_caption'] . "',
userfields_field_elements ='" . $fInfo['field_elements'] . "',
userfields_field_required ='" . $fInfo['field_required'] . "',
userfields_tip ='" . $fInfo['field_tip'] . "',
userfields_rank = '" . $cnt . "',
userfields_rank_col = '" . $col . "'";
                $return = $dbClass->Query($sql);
                $cnt++;
                if ($cnt == $cmax) {
                    $col++;
                    $cnt = 0;
                }
            }
            return $return;
        }
    }

    function InsertClassData() {
        global $dbClass, $config;
        $classes = array(
            'Homes',
            'Land',
            'Farms',
            'Commercial',
            'Rentals',
            'Condos',
            'Multi-Family'
        );
        for ($i = 0; $i < count($classes); $i++) {
            $sql = "INSERT INTO " . $config['table_prefix'] . "class SET
class_name = '" . $classes[$i] . "',
class_rank = '" . ($i + 1) . "'";
            $return = $dbClass->Query($sql);
        }
        return $return;
    }

    function InsertControlPanelData() {
        global $dbClass, $config;
        $sql = "INSERT INTO " . $config['table_prefix'] . "controlpanel SET
blog_id='0',
controlpanel_basepath='" . $this->GetBasePath() . "',
controlpanel_baseurl='" . $this->GetBaseUrl() . "',
controlpanel_frontend_template = 'frontend_template.php',
controlpanel_template_dir = 'default',
controlpanel_listing_template = 'listing_detail.php',
controlpanel_listing_template_printer = 'listing_detail_printer.php',
controlpanel_main_searchengine = '1',
controlpanel_googlemapskey='',
controlpanel_walkscorekey='',
controlpanel_walkscore='1',
controlpanel_streetview='1',
controlpanel_map_address = 'Address',
controlpanel_map_city = 'City',
controlpanel_map_state = 'State',
controlpanel_map_zip = 'Zip',
controlpanel_map_country = 'Country',
controlpanel_rss_limit_lastmodified=10,
controlpanel_rss_limit_featured=10,
controlpanel_rss_template='rss.php',
controlpanel_images_cache_bool='0',
controlpanel_images_cache_time='0',
controlpanel_number_format_style = '1',
controlpanel_money_format = '1',
controlpanel_date_format = '1',
controlpanel_img_allowed_ext = 'jpg,gif,png',
controlpanel_img_allowed_file_types = 'image/pjpeg,image/jpeg,image/gif,image/x-png,application/octet-stream',
controlpanel_img_create_thumb = '1',
controlpanel_img_thumb_width = '150',
controlpanel_img_thumb_height = '150',
controlpanel_img_thumb_quality = '75',
controlpanel_img_resize_thumb_by = 'width',
controlpanel_masterdb_bool='0',
controlpanel_masterdb_user='',
controlpanel_masterdb_pass='',
controlpanel_space_character='-',
controlpanel_masterdb_db='',
controlpanel_masterdb_server='',
controlpanel_url_type='0',
controlpanel_default_page_title='',
controlpanel_default_meta='',
controlpanel_keyword_default_META='',
controlpanel_listing_page_url='0',
controlpanel_listing_page_title='',
controlpanel_META_keywords_listing='',
controlpanel_META_Description='',
controlpanel_remote_custom_mls1_from='0',
controlpanel_remote_custom_mls1_to='0',
controlpanel_remote_custom_mls2_from='0',
controlpanel_remote_custom_mls2_to='0',
controlpanel_remote_custom_mls3_from='0',
controlpanel_remote_custom_mls3_to='0',
controlpanel_remote_path='',
controlpanel_remote_numeric='0',
controlpanel_remote_numeric_bool='0',
controlpanel_remote_numeric_thumb='0',
controlpanel_remote_photocount='0',
controlpanel_remote_checkphoto_bool='0',
controlpanel_remote_photonumber_prefix='',
controlpanel_mls_field_name='MLS',
controlpanel_price_field='Price';
";
        return $dbClass->Query($sql);
    }

    function AddExampleListing() {
        global $dbClass, $config;
        $sql = "SELECT listingsdb_id FROM `" . $config['table_prefix'] . "listingsdb`";
        if ($dbClass->GetOneRow($sql) === false) {
            $sql = "INSERT INTO `" . $config['table_prefix'] . "listingsdb` SET
`user_id` = 1,
`class_id` = 1,
`agent_id` = 1,
`office_id` = 1,
`listingsdb_title` = 'Listing Test',
`Address` =  '1600 Pennsylvania Avenue',
`City` = 'Washington',
`State` = 'NW',
`Zip` = 'D.C. 20500',
`Price` = '1000000'";
            $dbClass->query($sql);
            $sql = "INSERT INTO `" . $config['table_prefix'] . "listingsimages` SET
`user_id` = '1',
`listingsdb_id` = '1',
`listingsimages_caption` = 'Example Photo',
`listingsimages_file_name` = 'example-white-house.jpg',
`listingsimages_thumb_file_name` = 'example-white-house-thumb.jpg',
`listingsimages_active` = '1'";
            $dbClass->query($sql);
            $sql = "INSERT INTO `" . $config['table_prefix'] . "geocoding` SET
`agent_id` = '1',
`office_id` = '1',
`address` = '1600 Pennsylvania Avenue',
`latitude` = '38.898715',
`longitude` = '-77.037656',
`class_id` = '1',
`category` = '1',
`marker` = 'attached',
`active` = '1',
`record_date` = '" . date("Y-m-d") . "'";
            $dbClass->query($sql);
        }
    }

    function AddAgent($user_id) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "agents WHERE user_id='" . $user_id . "'";
        $reCheck = $dbClass->Query($sql);
        if ($reCheck->recordCount() == 0) {
            $sql = "INSERT INTO " . $config['table_prefix'] . "agents SET user_id='" . $user_id . "'";
            return $dbClass->query($sql);
        }
        return true;
    }

    function InsertUsersData($request, $md5 = true) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "users WHERE user_username='" . $request['admin_username'] . "'";
        $reCheck = $dbClass->Query($sql);
        if ($reCheck->recordCount() > 0) {
            $sql = "UPDATE " . $config['table_prefix'] . "users SET ";
            if ($md5 === false)
                $sql .= "user_password ='" . md5($request['admin_password']) . "',";
            else
                $sql .= "user_password ='" . $request['admin_password'] . "',";
            $sql .= "user_email ='" . $request['admin_email'] . "',
user_level ='4' WHERE user_username ='" . $request['admin_username'] . "'";
            if ($dbClass->query($sql)) {
                return $this->AddAgent($reCheck->fields['user_id']);
            }
        } else {
            $sql = "INSERT INTO " . $config['table_prefix'] . "users SET ";
            if ($md5 === false)
                $sql .= "user_password ='" . md5($request['admin_password']) . "',";
            else
                $sql .= "user_password ='" . $request['admin_password'] . "',";
            $sql .= "user_username ='" . $request['admin_username'] . "',
user_email ='" . $request['admin_email'] . "',
user_level ='4'";
            if ($dbClass->query($sql)) {
                return $this->AddAgent($dbClass->LastID());
            }
        }
    }

    function InsertSMSgateways() {
        global $dbClass, $config;
        $sql = "INSERT INTO " . $config['table_prefix'] . "wprcontactsmsgateways (`carrier`, `domain`) VALUES
('3River Wireless', '3River Wireless'),
('Andhra Pradesh Airtel', 'Andhra Pradesh Airtel'),
('Andhra Pradesh Idea Cellular', 'Andhra Pradesh Idea Cellular'),
('Alltel PCS', 'Alltel PCS'),
('Alltel', 'Alltel'),
('Arch Wireless', 'Arch Wireless'),
('BeeLine GSM', 'BeeLine GSM'),
('BeeLine (Moscow)', 'BeeLine (Moscow)'),
('Bell Canada', 'Bell Canada'),
('Bell Canada', 'Bell Canada'),
('Bell Atlantic', 'Bell Atlantic'),
('Bell South', 'Bell South'),
('Bell South', 'Bell South'),
('Bite GSM (Lithuania)', 'Bite GSM (Lithuania)'),
('Bluegrass Cellular', 'Bluegrass Cellular'),
('BPL mobile', 'BPL mobile'),
('Celcom (Malaysia)', 'Celcom (Malaysia)'),
('Cellular One', 'Cellular One'),
('Cellular One East Cost', 'Cellular One East Cost'),
('Cellular South', 'Cellular South'),
('Cellular One', 'Cellular One'),
('Cingular', 'Cingular'),
('CZECH EuroTel', 'CZECH EuroTel'),
('Chennai Skycell / Airtel', 'Chennai Skycell / Airtel'),
('Comviq GSM Sweden', 'Comviq GSM Sweden'),
('Corr Wireless Communications', 'Corr Wireless Communications'),
('D1 De TeMobil', 'D1 De TeMobil'),
('D2 Mannesmann Mobilefunk', 'D2 Mannesmann Mobilefunk'),
('DT T-Mobile', 'DT T-Mobile'),
('Delhi Airtel', 'Delhi Airtel'),
('Delhi Hutch', 'Delhi Hutch'),
('Dobson Cellular Systems', 'Dobson Cellular Systems'),
('E-Plus (Germany)', 'E-Plus (Germany)'),
('EMT', 'EMT'),
('Eurotel (Czech Republic)', 'Eurotel (Czech Republic)'),
('Escotel', 'Escotel'),
('Estonia EMT', 'Estonia EMT'),
('Estonia RLE', 'Estonia RLE'),
('Estonia Q GSM', 'Estonia Q GSM'),
('Estonia Mobil Telephone', 'Estonia Mobil Telephone'),
('Fido', 'Fido'),
('Georgea geocell', 'Georgea geocell'),
('Goa BPLMobil', 'Goa BPLMobil'),
('Golden Telecom', 'Golden Telecom'),
('GTE', 'GTE'),
('GTE', 'GTE'),
('Gujarat Idea', 'Gujarat Idea'),
('Gujarat Airtel', 'Gujarat Airtel'),
('Goa Airtel', 'Goa Airtel'),
('Goa BPLMobil', 'Goa BPLMobil'),
('Goa Idea Cellular', 'Goa Idea Cellular'),
('Haryana Airtel', 'Haryana Airtel'),
('Haryana Escotel', 'Haryana Escotel'),
('Himachal Pradesh Airtel', 'Himachal Pradesh Airtel'),
('Hungary Pannon GSM', 'Hungary Pannon GSM'),
('Idea Cellular', 'Idea Cellular'),
('Inland Cellular Telephone', 'Inland Cellular Telephone'),
('Israel Orange IL', 'Israel Orange IL'),
('Karnataka Airtel', 'Karnataka Airtel'),
('Kerala Airtel', 'Kerala Airtel'),
('Kerala Escotel', 'Kerala Escotel'),
('Kerala BPL Mobile', 'Kerala BPL Mobile'),
('Kyivstar  (Kiev Ukraine only)', 'Kyivstar  (Kiev Ukraine only)'),
('Latvia TELE2', 'Latvia TELE2'),
('Madhya Pradesh Airtel', 'Madhya Pradesh Airtel'),
('Maharashtra Idea Cellular', 'Maharashtra Idea Cellular'),
('MCI Phone', 'MCI Phone'),
('Meteor', 'Meteor'),
('Metro PCS', 'Metro PCS'),
('MiWorld', 'MiWorld'),
('Mobileone', 'Mobileone'),
('Mobilecomm', 'Mobilecomm'),
('Mobtel  Srbija', 'Mobtel  Srbija'),
('Mobistar Belgium', 'Mobistar Belgium'),
('Mobility Bermuda', 'Mobility Bermuda'),
('Maharashtra Airtel', 'Maharashtra Airtel'),
('Maharashtra BPL Mobile', 'Maharashtra BPL Mobile'),
('Manitoba Telecom Systems', 'Manitoba Telecom Systems'),
('Mumbai BPL Mobile', 'Mumbai BPL Mobile'),
('MTN (South Africa only )', 'MTN (South Africa only )'),
('MiWorld ( Singapore)', 'MiWorld ( Singapore)'),
('NBTel', 'NBTel'),
('Netcom GSM (Norway)', 'Netcom GSM (Norway)'),
('Nextel', 'Nextel'),
('Nextel Br', 'Nextel Br'),
('Optimus (Portugal)', 'Optimus (Portugal)'),
('Orange', 'Orange'),
('Oskar', 'Oskar'),
('Pacific Bell', 'Pacific Bell'),
('PlusGSM (Poland only)', 'PlusGSM (Poland only)'),
('P&T Luxembourg', 'P&T Luxembourg'),
('Pondicherry BPL Mobile', 'Pondicherry BPL Mobile'),
('Primtel', 'Primtel'),
('Punjab Airtel', 'Punjab Airtel'),
('Qwest', 'Qwest'),
('Rogers AT&T Wireless', 'Rogers AT&T Wireless'),
('Safaricom', 'Safaricom'),
('Satelindo GSM', 'Satelindo GSM'),
('Simobile (Slovenia)', 'Simobile (Slovenia)'),
('SCS-900', 'SCS-900'),
('Sunrise Mobile', 'Sunrise Mobile'),
('Sunrise Mobile', 'Sunrise Mobile'),
('SFR France', 'SFR France'),
('Southwestern Bell', 'Southwestern Bell'),
('Sprint PCS', 'Sprint PCS'),
('Sprint', 'Sprint'),
('Swisscom', 'Swisscom'),
('Swisscom', 'Swisscom'),
('Telecom Italia Mobile (Italy)', 'Telecom Italia Mobile (Italy)'),
('Telenor Mobil Norway', 'Telenor Mobil Norway'),
('Telecel (Portugal)', 'Telecel (Portugal)'),
('Tele2', 'Tele2'),
('Telus', 'Telus'),
('Telenor', 'Telenor'),
('Telia Denmark', 'Telia Denmark'),
('TMN (Portugal)', 'TMN (Portugal)'),
('T-Mobile Austria', 'T-Mobile Austria'),
('T-Mobile Germany', 'T-Mobile Germany'),
('T-Mobile UK', 'T-Mobile UK'),
('T-Mobile USA', 'T-Mobile USA'),
('Triton', 'Triton'),
('Tamil Nadu BPL Mobile', 'Tamil Nadu BPL Mobile'),
('UMC GSM', 'UMC GSM'),
('Unicel', 'Unicel'),
('Uraltel', 'Uraltel'),
('US Cellular', 'US Cellular'),
('Uttar Pradesh (West) Escotel', 'Uttar Pradesh (West) Escotel'),
('Verizon', 'Verizon'),
('Vodafone Omnitel (Italy)', 'Vodafone Omnitel (Italy)'),
('Vodafone Italy', 'Vodafone Italy'),
('Vodafone Japan', 'Vodafone Japan'),
('Vodafone Japan', 'Vodafone Japan'),
('Vodafone Japan', 'Vodafone Japan'),
('Vodafone Spain', 'Vodafone Spain'),
('Vodafone UK', 'Vodafone UK'),
('West Central Wireless', 'West Central Wireless'),
('Western Wireless', 'Western Wireless'),
('ACS Wireless', 'ACS Wireless'),
('Ameritech Clearpath', 'Ameritech Clearpath'),
('Andhra Pradesh Airtel', 'Andhra Pradesh Airtel'),
('Bell South (Blackberry)', 'Bell South (Blackberry)'),
('Bell South Mobility', 'Bell South Mobility'),
('Blue Sky Frog', 'Blue Sky Frog'),
('Boost', 'Boost'),
('Carolina West', 'Carolina West'),
('Carolina Mobile Comm.', 'Carolina Mobile Comm.'),
('Cellular One SW', 'Cellular One SW'),
('Cellular One PCS', 'Cellular One PCS'),
('Cellular One West', 'Cellular One West'),
('Century Tel', 'Century Tel'),
('Chennai RPG Cellular', 'Chennai RPG Cellular'),
('Cincinnati Bell', 'Cincinnati Bell'),
('Western Wireless', 'Western Wireless'),
('Clearnet', 'Clearnet'),
('Comcast', 'Comcast'),
('Dutchone/Orange-NL', 'Dutchone/Orange-NL'),
('Edge Wireless', 'Edge Wireless'),
('Gujarat Celforce', 'Gujarat Celforce'),
('Houston Cellular', 'Houston Cellular'),
('Idea Cellular', 'Idea Cellular'),
('Lauttamus Communication', 'Lauttamus Communication'),
('LMT', 'LMT'),
('Microcell', 'Microcell'),
('Midewest Wireless', 'Midewest Wireless'),
('Mobilfone', 'Mobilfone'),
('Mobitel Tanzania', 'Mobitel Tanzania'),
('Motient', 'Motient'),
('Movistar', 'Movistar'),
('Mumbai Orange', 'Mumbai Orange'),
('NPI Wireless', 'NPI Wireless'),
('Ntelos', 'Ntelos'),
('O2', 'O2'),
('Omnipoint', 'Omnipoint'),
('Omnipoint PCS', 'Omnipoint PCS'),
('One Connect Austria', 'One Connect Austria'),
('Optus Mobile', 'Optus Mobile'),
('Orange Mumbai', 'Orange Mumbai'),
('Orange NL/Dutchone', 'Orange NL/Dutchone'),
('PCS One', 'PCS One'),
('Pioneer/Enid Cellular', 'Pioneer/Enid Cellular'),
('Powertel', 'Powertel'),
('Price Communications', 'Price Communications'),
('Primeco', 'Primeco'),
('Public Service Cellular', 'Public Service Cellular'),
('Simple Freedom', 'Simple Freedom'),
('Smart Telecom', 'Smart Telecom'),
('Southern LINC', 'Southern LINC'),
('Suncom', 'Suncom'),
('Surewest Communications', 'Surewest Communications'),
('Telefonica Movistar', 'Telefonica Movistar'),
('TIM', 'TIM'),
('US West', 'US West'),
('Virgin Mobile', 'Virgin Mobile'),
('Voicestream/T-Mobile', 'Voicestream/T-Mobile'),
('Wyndtell', 'Wyndtell'),
('Starhub', 'Starhub'),
('Singnet', 'Singnet'),
('M1 Singapore', 'M1 Singapore'),
('BH Telecom - Bosnia', 'BH Telecom - Bosnia');";
        return $dbClass->Query($sql);
    }

    function DeleteDataTables() {
        global $dbClass, $config;
        $names = array(
            'agentfields',
            'agentimages',
            'agents',
            'class',
            'controlpanel',
            'featured',
            'geocoding',
            'images_cache',
            'listingsdb',
            'listingsfields',
            'listingsimages',
            'media',
            'officefields',
            'officeimages',
            'offices',
            'pagetaglocations',
            'searchengines',
            'searchenginescontent',
            'searchfavorite',
            'userfavoritelistings',
            'userfields',
            'userimages',
            'users',
            'wprcontactaffiliation',
            'wprcontactagents',
            'wprcontactcontent',
            'wprcontactfields',
            'wprcontactmessages',
            'wprcontactsmsgateways'
        );
        for ($i = 0; $i < count($names); $i++) {
            $name = $config['table_prefix'] . $names[$i];
            if ($dbClass->TableExists($name)) {
                $sql = "DROP TABLE `" . $name . "`";
                $dbClass->query($sql);
            }
        }
    }

    function removeDir($path) {
        $dir = new DirectoryIterator($path);
        foreach ($dir as $fileinfo) {
            if ($fileinfo->isFile() || $fileinfo->isLink()) {
                unlink($fileinfo->getPathName());
            } elseif (!$fileinfo->isDot() && $fileinfo->isDir()) {
                $this->removeDir($fileinfo->getPathName());
            }
        }
        rmdir($path);
    }

    function DeleteWPR() {
        global $config;
        $path = $this->basepath;
        $this->removeDir($path);
    }

    function RemoveWPRPages() {
        global $wpdb;
        $sql = "DELETE FROM `" . $wpdb->posts . "` WHERE `post_type` = 'page' AND `post_content` LIKE '%{wp-realty%'";
        $wpdb->query($sql);
    }

}

// END class installClass
?>