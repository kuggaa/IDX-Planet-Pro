<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
require_once("contactform.inc.php");
class wpr_ContactFormClass extends ContactFormClass{
var $usermeta_base;
function __construct()
{
global $config;
$this->wprcontact_content_base = $config['table_prefix']."wprcontactcontent";
$this->wprcontact_fields_base = $config['table_prefix']."wprcontactfields";
$this->wprcontact_message_base = $config['table_prefix']."wprcontactmessages";
$this->wprcontact_affilation_base = $config['table_prefix']."wprcontactaffiliation";
$this->users_base = "wp_users";
$this->usermeta_base = "wp_usermeta";
$this->wprcontact_smsgateways_base = $config['table_prefix']."wprcontactsmsgateways";
$this->wprcontact_agents_base  = $config['table_prefix']."wprcontactagents";
}
function GetAgents()
{
global $dbClass;
$sql = "SELECT ".$this->users_base.".ID,".$this->users_base.".user_login,
".$this->wprcontact_agents_base.".*
FROM ".$this->users_base." LEFT JOIN ".$this->wprcontact_agents_base." ON ".$this->users_base.".ID=".$this->wprcontact_agents_base.".agent_id";// WHERE ".$this->users_base.".user_level>0";
$reAgents = $dbClass->Query($sql);
if($reAgents->recordCount()>0)
{
$ret_tab = array();
while(!$reAgents->EOF)
{
$temp_fields  = $reAgents->fields;
//FIRST NAME
$sql = "SELECT meta_value FROM ".$this->usermeta_base." WHERE user_id='".$reAgents->fields['ID']."' AND meta_key='first_name'";
$reFirstName = $dbClass->Query($sql);
if($reFirstName->RecordCount()>0)
$temp_fields['first_name'] = $reFirstName->fields['meta_value'];
//LAST NAME
$sql = "SELECT meta_value FROM ".$this->usermeta_base." WHERE user_id='".$reAgents->fields['ID']."' AND meta_key='last_name'";
$reLastName = $dbClass->Query($sql);
if($reLastName->RecordCount()>0)
$temp_fields['last_name'] = $reLastName->fields['meta_value'];
$temp_fields['username'] = $reAgents->fields['user_login'];
$temp_fields['user_id'] = $reAgents->fields['ID'];
$ret_tab[] = $temp_fields;
$reAgents->MoveNext();
}
return $ret_tab;
}
else
return false;
}
function GenerateMessageTable($data,$recipient=false)
{
global $dbClass;
$date = date("d/m/Y  H:i",$data['sent']);
$display = '<table class="table_message"  cellspacing="0">
<tr><td >Date Sent</td><td>'.$date.'</td><td style="background-color:#E3EFF7;border-bottom:1px solid #000;" align="center">Options</td></tr>
<tr><td>Sender Name</td><td>'.$data['sender_name'].'</td><td align="center"><a href="'.$delhref.'">Delete</a></td></tr>
<tr><td>Sender Email</td><td>'.$data['sender_email'].'</td><td></td></tr>';
if($recipient!==false)
{
$recipient = $data['recipient'];
if(is_numeric($data['recipient']))
{
$sql = "SELECT * FROM ".$this->users_base." WHERE ID='".$data['recipient']."'";
$reS = $dbClass->Query($sql);
if($reS->recordCount()>0)
$recipient = $reS->fields['user_email'];
}
$display .= '<tr><td>Recipient</td><td>&nbsp;'.$recipient.'</td><td></td></tr>';
}
$display .= '<tr><td>Subject</td><td>'.$data['subject'].'</td><td></td></tr>
<tr><td style="border-bottom:0px;">Message</td><td style="border-bottom:0px;">'.str_replace("\n","<br>",$data['message']).'</td><td></td></tr>
</table>';
return $display;
}
function SendMailToAgent($id)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_message_base." WHERE id=".$id;
$reMessage = $dbClass->Query($sql);
if($reMessage->recordCount()>0)
{
if(is_numeric($reMessage->fields['recipient']))
{
$sql_mailto = "SELECT * FROM ".$this->users_base." WHERE ID=".$reMessage->fields['recipient'];
$reMailto = $dbClass->Query($sql_mailto);
if($reMailto->recordCount()>0)
{
$mailto = $reMailto->fields['user_email'];
$header = 	"From: ".$reMessage->fields['sender_name']."<".$reMessage->fields['sender_email']."> \n";
}
}
else
$mailto = $reMessage->fields['recipient'];
if(mail($mailto,$reMessage->fields['subject'],$reMessage->fields['message'],$header))
{
return True;
}
else
{
return False;
}
}
else
return False;
}
}
?>