<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
Class OfficeClass {
var $users_base;
var $block_fields_name = array(
"office_id",
/*
"office_code",
"office_creation_date",
"office_modified_date",
*/
);
var $standard_fields_name = array(
"office_code" => array('field_required' => 0, 'field_caption' => 'Office MLS ID'),
"office_featured" => array('field_required' => 0, 'field_caption' => 'Featured'),
"office_name" => array('field_required' => 1, 'field_caption' => 'Office Name'),
"office_email" => array('field_required' => 0, 'field_caption' => 'Office eMail'),
"office_phone" => array('field_required' => 0, 'field_caption' => 'Office Phone'),
"office_address" => array('field_required' => 0, 'field_caption' => 'Address'),
"office_comments" => array('field_required' => 0, 'field_caption' => 'Comments'),
"office_details" => array('field_required' => 0, 'field_caption' => 'Office Details'),
"office_creation_date" => array('field_required' => 0, 'field_caption' => 'Creating Date'),
"office_modified_date" => array('field_required' => 0, 'field_caption' => 'Modification Date'),
"office_hit_count" => array('field_required' => 0, 'field_caption' => 'Office Hit Count'),
"office_url" => array('field_required' => 0, 'field_caption' => 'Office URL'),
"office_parent" => array('field_required' => 0, 'field_caption' => 'Parent Office ID')
);
var $tab_select_type = array(
"text" => "Text",
"radio" => "Radio",
"checkbox" => "Checkbox",
"select" => "Select",
"textarea" => "TextArea"
);
var $tab_select_datatype = array(
"int(11)" => 'Integer',
"float" => 'Float',
"char(5)" => 'Char(5)',
"char(20)" => 'Char(20)',
"char(50)" => 'Char(50)',
"char(100)" => 'Char(100)',
"char(200)" => 'Char(200)',
"text" => 'Text',
"longtext" => 'Long Text'
);
function GetOfficeRoster($param, $request) {
global $config, $dbClass, $UrlClass, $presentationClass;
$template = registry::register('ParseClass');
$officeinfo = false;
if (is_numeric($param['office_id'])) {
if ($officeinfo = $this->GetOfficeInfo($param['office_id'])) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "officedetails.php");
$content = $template->MainParse($content, $officeinfo['office_id']);
}
}
if ($officeinfo === false) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "officeroster.php");
// Get the settings
preg_match('/\\{office_settings ([^}]*)?}?/', $content, $matches);
// Remove the tag
$content = str_replace($matches[0], '', $content);
$tag_params_raw = explode(' ', $matches[1]);
$tag_params = array();
foreach ($tag_params_raw as $value) {
$param_parts = explode('=', $value);
$tag_params[$param_parts[0]] = $param_parts[1];
}
$letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$current_letter = false;
if (strpos($letters, $_GET['letter']) !== false)
$current_letter = $_GET['letter'];
$cur_page = 1;
if (is_numeric($_GET['cur_page']))
$cur_page = $_GET['cur_page'];
$all_offices_serious = $this->GetCntOffices();
$all_offices = $this->GetCntOffices($current_letter);
$max_visible = 10;
$max_on_page = isset($tag_params['perpage']) ? $tag_params['perpage'] : 5;
$last_page = ceil($all_offices / $max_on_page);
$limit_s = ($cur_page - 1) * $max_on_page;
$rows = "";
$sort = isset($tag_params['sort']) ? $tag_params['sort'] : false;
$dir = isset($tag_params['orderdir']) ? $tag_params['orderdir'] : 'ASC';
$orderby = isset($tag_params['orderby']) ? $tag_params['orderby'] : 'office_name';
if($orderby == 'last_name')$orderby = 'office_name';
if ($offices = $this->GetOffices($current_letter, $limit_s, $max_on_page, $sort, $dir, $orderby)) {
for ($i = 0; $i < count($offices); $i++) {
//echo "1";
$template_row = $template->GetTemplateBlock('offices', $content);
$tmp = $template_row['content'];
$tmp = $template->MainParse($tmp, $offices[$i]['office_id']);
if ($i % 2 == 0)
$odd = 0;
else
$odd = 1;
$tmp = $template->ReplaceTag("{row_num_even_odd}", $odd, $tmp);
//$tmp = preg_replace($reg_office_name,$officename,$tmp);
$rows .= $tmp;
}
}
$content = $template->ReplaceTemplateBlock('offices', $rows, $content);
/* letter pagination */
$content_pagination = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "pagination_new.php");
$letter_row = $template->GetTemplateBlock('letterpagination', $content_pagination);
$letter_tab = $this->GetOfficeByLetter('office_name');
$burl = "index.php?page=officeroster&letter=";
$nurl = "index.php?page=officeroster";
$row_pagination = $presentationClass->PreparePaginationLetter($letter_tab, $letter_row['content'], $current_letter, $burl, $nurl);
$content_pagination = $template->ReplaceTemplateBlock('letterpagination', $row_pagination, $content_pagination);
/* number pagination */
if ($all_offices > 0) {
$number_pagination = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "pagination.php");
$number_row = $template->GetTemplateBlock('numberpagination', $number_pagination);
if ($current_letter !== false)
$burl = "index.php?page=officeroster&letter=" . $current_letter . "&cur_page=";
else
$burl = "index.php?page=officeroster&cur_page=";
//prevpage
if ($cur_page > 1)
$number_pagination = str_replace("{prevpage}", "index.php?page=officeroster&cur_page=" . ($cur_page - 1), $number_pagination);
else
$number_pagination = str_replace("{prevpage}", "index.php?page=officeroster&cur_page=" . $cur_page, $number_pagination);
//prev10page
if ($cur_page - 10 > 1)
$number_pagination = str_replace("{prev10page}", "index.php?page=officeroster&cur_page=" . ($cur_page - 10), $number_pagination);
else
$number_pagination = str_replace("{prev10page}", "index.php?page=officeroster&cur_page=" . $cur_page, $number_pagination);
//nextpage
if ($cur_page < $last_page)
$number_pagination = str_replace("{nextpage}", "index.php?page=officeroster&cur_page=" . ($cur_page + 1), $number_pagination);
else
$number_pagination = str_replace("{nextpage}", "index.php?page=officeroster&cur_page=" . $last_page, $number_pagination);
//next10page
if ($cur_page + 10 < $last_page)
$number_pagination = str_replace("{next10page}", "index.php?page=officeroster&cur_page=" . ($cur_page + 10), $number_pagination);
else
$number_pagination = str_replace("{next10page}", "index.php?page=officeroster&cur_page=" . $last_page, $number_pagination);
$number_pagination = str_replace("{firstpage}", "index.php?page=officeroster&cur_page=1", $number_pagination);
$number_pagination = str_replace("{lastpage}", "index.php?page=officeroster&cur_page=" . $last_page, $number_pagination);
$row_pagination = $presentationClass->PreparePaginationNumber($number_row['content'], $all_offices, $cur_page, $max_visible, $max_on_page, $burl);
} else
$row_pagination = "";
$number_pagination = $template->ReplaceTemplateBlock('numberpagination', $row_pagination, $number_pagination);
$content = str_replace('{active_office_rows}', $all_offices, $content);
$content = str_replace('{office_letter_pagination}', $content_pagination, $content);
$content = str_replace('{office_number_pagination}', $number_pagination, $content);
}
return $content;
}
function GetCntOffices($letter = false) {
global $dbClass, $config;
if ($letter !== false)
$sql = "SELECT count(*) as count FROM `" . $config['table_prefix'] . "offices`  WHERE `office_name` LIKE '" . $letter . "%'";
else
$sql = "SELECT count(*) as count FROM `" . $config['table_prefix'] . "offices`";
$reCnt = $dbClass->query($sql);
if ($reCnt->RecordCount() > 0) {
return $reCnt->fields['count'];
} else
return 0;
}
function GetOfficeByLetter($field) {
global $config, $dbClass;
$letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$ret_array = array();
for ($i = 0; $i < strlen($letters); $i++) {
$sql = "SELECT count(*) as count FROM `" . $config['table_prefix'] . "offices` WHERE `" . $field . "` LIKE '" . $letters[$i] . "%'";
$reCnt = $dbClass->query($sql);
if ($reCnt->RecordCount() > 0) {
$ret_array[$letters[$i]] = $reCnt->fields['count'];
} else
$ret_array[$letters[$i]] = 0;
}
return $ret_array;
}
function GetOffices($letter = false, $limit_s = false, $limit = false, $sort = false, $dir = 'ASC', $orderby = false) {
global $dbClass, $config;
if ($letter !== false)
$sql = "SELECT * FROM `" . $config['table_prefix'] . "offices` WHERE office_name LIKE '" . $letter . "%'";
else {
$sql = "SELECT * FROM `" . $config['table_prefix'] . "offices`";
if ($sort) {
switch ($sort) {
case 'rand':
$sql .= ' ORDER BY RAND()';
break;
case 'alpha':
$sql .= ' ORDER BY office_name';
}
} elseif ($orderby) {
$sql .= ' ORDER BY ' . $orderby . ' ' . $dir;
}
}
if ($limit_s !== false AND $limit !== false) {
$sql .= " LIMIT " . $limit_s . "," . $limit;
}
//die($sql);
$reOffices = $dbClass->Query($sql);
if ($reOffices->RecordCount() > 0) {
$ret_tab = array();
$cnt = 0;
while (!$reOffices->EOF) {
$ret_tab[$cnt] = $reOffices->fields;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "officeimages` WHERE office_id='" . $reOffices->fields['office_id'] . "'";
$reImages = $dbClass->query($sql);
if ($reImages->RecordCount() > 0) {
$cnt_img = 1;
while (!$reImages->EOF) {
$ret_tab[$cnt]['images'][$reImages->fields['image_rank']]['thumb'] = $config['baseurl'] . $config['img_dir'] . "office_images/" . $reImages->fields['image_thumbname'];
$ret_tab[$cnt]['images'][$reImages->fields['image_rank']]['photo'] = $config['baseurl'] . $config['img_dir'] . "office_images/" . $reImages->fields['image_filename'];
$reImages->MoveNext();
$cnt_img++;
}
}
$reOffices->MoveNext();
$cnt++;
}
return $ret_tab;
}
return false;
}
function getIdFromOfficeCode($office_code) {
global $dbClass, $config;
$sql = "SELECT office_id FROM `" . $config['table_prefix'] . "offices` WHERE office_code='" . $office_code . "' ";
$reInfo = $dbClass->query($sql);
if ($reInfo->RecordCount() > 0) {
return $reInfo->fields['office_id'];
} else {
return false;
}
}
function GetOfficeInfo($office_id) {
global $dbClass, $config;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "offices` WHERE office_id='" . $office_id . "'";
$reInfo = $dbClass->query($sql);
if ($reInfo->RecordCount() > 0) {
$ret_tab = $reInfo->fields;
foreach ($ret_tab as $k => $v) {
$nname = str_replace("office_", "", $k);
$ret_tab[$nname] = $v;
}
$sql = "SELECT * FROM `" . $config['table_prefix'] . "officeimages` WHERE office_id='" . $office_id . "'";
$reImages = $dbClass->query($sql);
if ($reImages->RecordCount() > 0) {
while (!$reImages->EOF) {
$ret_tab['images'][$reImages->fields['image_rank']]['thumb'] = $config['baseurl'] . $config['img_dir'] . "/office_images/" . $reImages->fields['image_thumbname'];
$ret_tab['images'][$reImages->fields['image_rank']]['photo'] = $config['baseurl'] . $config['img_dir'] . "/office_images/" . $reImages->fields['image_filename'];
$reImages->MoveNext();
}
}
$ret_tab['permalink'] = strtolower(str_replace(' ', '-', $ret_tab['name']));
return $ret_tab;
}
return false;
}
function ReplaceOfficeFieldTags($office_id, $param) {
global $config, $dbClass;
$return = false;
if (isset($param['fieldvalue'])) {
$field = $param['fieldvalue'];
if ($temp_fields = $this->GetOfficeInfo($office_id)) {
foreach ($temp_fields as $key => $value) {
$re[strtolower($key)] = $value;
}
if (isset($re[$field])) {
$return = $re[$field];
}
}
} elseif (isset($param['field'])) {
$field = $param['field'];
if ($temp_fields = $this->GetOfficeFields()) {
foreach ($temp_fields as $key => $value) {
$re[strtolower($key)] = $value;
}
if (isset($re[$field])) {
$return = $re[$field];
}
}
}
return $return;
}
function GetOfficeFields() {
global $config, $dbClass;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "officefields`";
$reFields = $dbClass->query($sql);
if ($reFields->RecordCount() > 0) {
$ret_array = array();
while (!$reFields->EOF) {
$nname = $reFields->fields['officefields_field_name'];
$nname = str_replace("office_", "", $nname);
$ret_array[$nname] = $reFields->fields['officefields_field_caption'];
$reFields->MoveNext();
}
return $ret_array;
}
return false;
}
/*     * **********************************************************\
*
\*********************************************************** */
function AddOfficeBackEnd($post_vars, $get_vars) {
global $dbClass, $presentationClass, $UrlClass, $jqueryscript, $array_numbers, $config;
$content = "";
$error_info = "";
$pagename = "editoffices";
$base = $config['adm_baseurl'] . "index.php?apage=" . $pagename;
$content .= "<h3>Add Office</h3>";
if (isset($post_vars['addoffice_submit'])) {
require_once($config['wpradmin_basepath'] . 'include/fields.inc.php');
$fieldsClass = registry::register('fieldsClass');
$errors = $fieldsClass->CheckRequiredField($post_vars, "officefields", "officefields");
if ($errors === false) {
if ($last_id = $this->InsertNewOffice($post_vars)) {
$url = $UrlClass->AddUrlValues(array('page' => 'offices', 'cpage' => 'editoffices', 'action' => 'edit_office', 'edit_id' => $last_id));
header("location: $base");
die();
//$content = $presentationClass->OperationSuccessfull("Listing Addedd");
} else
$content .= $presentationClass->OperationFailed("Office add failed");
}
else {
$error_info = "Field required: ";
for ($i = 0; $i < count($errors); $i++) {
$error_info .= str_replace("offices_", "", $errors[$i]) . ", ";
}
$error_info = substr($error_info, 0, -2);
$content .= $presentationClass->OperationFailed($error_info);
}
}
$request = $post_vars;
$content .= $this->ShowAddEditOfficeTable($post_vars);
return $content;
}
function InsertNewOffice($request_vars) {
global $dbClass, $config, $log_user_id;
$sql = "SELECT * FROM " . $config['table_prefix'] . "officefields";
$reFields = $dbClass->Query($sql);
$sql = "INSERT INTO " . $config['table_prefix'] . "offices SET ";
while (!$reFields->EOF) {
if ($reFields->fields['officefields_field_type'] == "checkbox") {
$value = implode("|", $request_vars[$reFields->fields['officefields_field_name']]);
} else
$value = $request_vars[$reFields->fields['officefields_field_name']];
if(!isset($request_vars[$reFields->fields['officefields_field_name']]) || $request_vars[$reFields->fields['officefields_field_name']] == ''){
    
}
else{
    $sql .= $reFields->fields['officefields_field_name'] . "='" . $value . "',";
}

$reFields->MoveNext();
}
$sql = substr($sql, 0, -1);
//$sql .= ",listingsdb_creation_date='".time()."'";
if ($dbClass->Query($sql) !== false) {
return $dbClass->LastID();
}
return false;
}
function DeleteOfficeImage($del_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "officeimages WHERE  officeimage_id='" . $del_id . "'";
$reImages = $dbClass->Query($sql);
if ($reImages->recordCount() > 0) {
if ($reImages->fields['image_thumbname'] != "") {
@unlink($config['office_images'] . $reImages->fields['image_thumbname']);
}
@unlink($config['office_images'] . $reImages->fields['image_filename']);
$sql = "DELETE FROM " . $config['table_prefix'] . "officeimages WHERE officeimage_id='$del_id'";
return $dbClass->Query($sql);
} else
return false;
}
function GetOfficeImage($edit_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "officeimages WHERE  officeimage_id='" . $edit_id . "'";
$reImages = $dbClass->Query($sql);
if ($reImages->recordCount() > 0) {
return $reImages->fields;
} else
return false;
}
function ShowAddEditOfficeTable($request, $mode = '', $edit_id = '', $user_id = false, $test = false) {
global $dbClass, $config, $presentationClass, $jqueryscript, $UrlClass, $log_user_id;
require_once($config['wpradmin_basepath'] . "include/images.inc.php");
$imagesClass = registry::register('ImagesClass');
$content = "";
$actual_page_id = "addoffice";
$selected = false;
if ($mode == 'edit') {
$actual_page_id = "editoffices";
if ($request['content_action'] == 'upload_images') {
require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
$imagesClass = registry::register('ImagesClass');
if ($files = $imagesClass->UploadImages(3)) {
if ($imagesClass->UploadOfficeImages($edit_id, $files)) {
$content .= $presentationClass->OperationSuccessfull('Upload Images Success');
} else
$content .= $presentationClass->OperationFailed('Upload Images Failed');
} else
$content .= $presentationClass->OperationFailed('Upload Images Failed');
$selected = 1;
}
if ($request['content_action'] == 'edit_images') {
for ($i = 0; $i < count($request['image_id']); $i++) {
$sql = "UPDATE " . $config['table_prefix'] . "officeimages SET
image_caption = '" . $request['caption'][$i] . "',
image_rank = '" . $i . "'
WHERE officeimage_id='" . $request['image_id'][$i] . "'";
$dbClass->Query($sql);
}
$selected = 1;
}
if ($_GET['content_action'] == 'delete_image') {
if (is_numeric($_GET['del_id']) AND $this->GetOfficeImage($_GET['del_id'])) {
if ($this->DeleteOfficeImage($_GET['del_id'])) {
$content .= $presentationClass->OperationSuccessfull('Delete Image Success');
} else
$content .= $presentationClass->OperationFailed('Delete Image Failed');
}
$selected = 1;
}
}
require_once($config['wpradmin_basepath'] . 'include/forms.inc.php');
$formsClass = registry::register('FormsClass');
$sql = "SELECT * FROM " . $config['table_prefix'] . "officefields ORDER by officefields_rank_col,officefields_rank";
$reFields = $dbClass->Query($sql);
$office_tabs = "";
if ($reFields->recordCount() > 0) {
$office_tab = array();
while (!$reFields->EOF) {
if ($dbClass->ColumnExists($config['table_prefix'] . "offices", $reFields->fields['officefields_field_name']) !== false) {
if ($reFields->fields['officefields_field_caption'] != "")
$right_col = $reFields->fields['officefields_field_caption'];
else {
$right_col = str_replace("offices", "", $reFields->fields['officefields_field_name']);
$right_col = str_replace("_", " ", $right_col);
}
$elements = "";
if (strpos($reFields->fields['officefields_field_elements'], "|") !== false) {
$elements_temp = explode("|", $reFields->fields['officefields_field_elements']);
$elements = array();
for ($i = 0; $i < count($elements_temp); $i++) {
if ($reFields->fields['officefields_field_type'] == 'checkbox')
$elements[$elements_temp[$i]] = $elements_temp[$i] . "<br/>";
else
$elements[$elements_temp[$i]] = $elements_temp[$i];
}
}
$params = false;
if ($reFields->fields['officefields_field_type'] == 'text' OR $reFields->fields['officefields_field_type'] == 'textarea') {
$params['class'] = "large";
}
if ($reFields->fields['officefields_tip'] != "") {
$params['title'] = $reFields->fields['officefields_tip'];
}
$left_col = $formsClass->GenerateField($reFields->fields['officefields_field_type'], $reFields->fields['officefields_field_name'], $request[$reFields->fields['officefields_field_name']], $elements, $request, 'normal', $params);
$office_tab[$reFields->fields['officefields_rank_col']][] = array("<strong>" . $right_col . "</strong>", $left_col);
}
$reFields->MoveNext();
}
$office_tabs .= $formsClass->startform();
$office_tabs .= "<div><button onclick='return false' id='save_order' style='float:right'>Save order field</button><div style='clear:both'></div></div>";
$success_info = $presentationClass->OperationSuccessfull('The order of the fields has been saved');
$office_tabs .= $presentationClass->BlockTableSortable($office_tab[0], 2);
$office_tabs .= $presentationClass->BlockTableSortable($office_tab[1], 2);
$office_tabs .= $jqueryscript->SaveOrder("sd_column", "save_order", $config['adm_baseurl'] . "ajax.php?f=ajax_fields_sort.php", $success_info, "office");
if ($mode == 'edit')
$office_tabs .= $formsClass->create_submit($actual_page_id . '_submit', 'Edit', array('id' => $actual_page_id . '_submit'));
else
$office_tabs .= $formsClass->create_submit('addoffice_submit', 'Add', array('id' => 'addoffice_submit'));
$office_tabs .= $formsClass->endform();
}
if ($mode == 'edit') {
$editoffice_office_tab_name = $actual_page_id . "_office_tab";
$editoffice_images_tab_name = $actual_page_id . "_images_tab";
$headers = array(
$editoffice_office_tab_name => "Office Details",
$editoffice_images_tab_name => "Images",
);
$images_tab = $imagesClass->GenerateUploadImagesFormNormal(5, $edit_id, 'upload_officeimage');
$images_tab .= $this->OfficeImagesForm($edit_id, $actual_page_id);
$data[$editoffice_office_tab_name] = $office_tabs;
$data[$editoffice_images_tab_name] = $images_tab;
$jquery_tabs_id = "jqt_" . $actual_page_id;
$content .= $presentationClass->JqueryTabsWithDataNew($data, $headers, array('id' => $jquery_tabs_id, 'class' => 'box grid_16 round_all tabs'), $selected);
} else {
$content .= $office_tabs;
//$presentationClass->StandardTableWithData($office_tab);
}
return $content;
}
function SaveOfficeFieldOrder($column, $fields) {
global $config, $dbClass;
if (count($fields) > 0) {
for ($i = 0; $i < count($fields); $i++) {
$sql = "UPDATE `" . $config['table_prefix'] . "officefields` SET officefields_rank_col='" . $column . "', officefields_rank='" . $i . "' WHERE officefields_field_name='" . $fields[$i] . "'";
$dbClass->Query($sql);
}
return true;
}
}
function OfficeImagesForm($office_id, $actual_page_id) {
global $dbClass, $config, $presentationClass, $UrlClass, $formsClass, $jqueryscript;
$sql = "SELECT * FROM " . $config['table_prefix'] . "officeimages WHERE office_id='$office_id' ORDER BY image_rank";
$reImages = $dbClass->Query($sql);
$action_url = $UrlClass->AddUrlValues(array('page' => 'offices', 'cpage' => 'editoffices', $actual_page_id . 'action' => 'edit_office', 'edit_id' => $office_id));
//$content = $formsClass->startform($action_url);
$content = $formsClass->startform();
if ($reImages->recordCount() > 0) {
$view_tab = array();
$tabRANK = array();
for ($i = 0; $i < $reImages->recordCount(); $i++) {
$tabRANK[$i] = $i;
}
while (!$reImages->EOF) {
$delurl = $UrlClass->ReplaceUrlValues(array('content_action' => 'delete_image', 'del_id' => $reImages->fields['officeimage_id']));
$tables = array();
$tables[] = $formsClass->create_hidden('image_id[]', $reImages->fields['officeimage_id']) .
"<strong>" . $reImages->fields['image_filename'] . "</strong><br/>";
$tables[] = "<img src='" . $config['baseurl'] . $config['img_dir'] . "/office_images/" . $reImages->fields['image_thumbname'] . "'>";
//$tables[] = $formsClass->create_select('rank[]',$reImages->fields['listingsimages_rank'],'',$tabRANK);
$tables[] = $formsClass->create_text('caption[]', $reImages->fields['image_caption']);
$tables[] = "<a href='$delurl' class='delbutton' onclick='return false;' name='Delete image?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
$right .= $presentationClass->BlockTable($tables);
$view_tab[] = $tables;
$reImages->MoveNext();
}
$headers = array('Name', 'Thumb', 'Caption', '');
$content .= $presentationClass->StandardTableWithDataNew($view_tab, $headers, false, array('id' => 'editimages_datatable', 'style' => 'wpr_form'), true);
$content .= $formsClass->create_hidden('content_action', 'edit_images');
$content .= $formsClass->create_submit('editsubmit', 'Edit');
$content .= $formsClass->endform();
}
return $content;
}
function UpdateOffice($request_vars, $office_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "officefields";
$reFields = $dbClass->Query($sql);
$sql = "UPDATE " . $config['table_prefix'] . "offices SET ";
while (!$reFields->EOF) {
if ($dbClass->ColumnExists($config['table_prefix'] . "offices", $reFields->fields['officefields_field_name'])) {
if ($reFields->fields['officefields_field_type'] == "checkbox" AND is_array($request_vars[$reFields->fields['officefields_field_name']])) {
$value = implode("|", $request_vars[$reFields->fields['officefields_field_name']]);
} else
$value = $request_vars[$reFields->fields['officefields_field_name']];
if(!isset($request_vars[$reFields->fields['officefields_field_name']]) || $request_vars[$reFields->fields['officefields_field_name']] == ''){
    
}
else{
    $sql .= $reFields->fields['officefields_field_name'] . "='" . $value . "',";
}

}
$reFields->MoveNext();
}
$sql = substr($sql, 0, -1);
$sql .= " WHERE office_id='" . $office_id . "'";
if ($dbClass->Query($sql) !== false)
return true;
return false;
}
function DeleteOffice($del_id) {
global $config, $dbClass, $user_level;
$this->DeleteOfficeImages($del_id);
$sql = "DELETE FROM " . $config['table_prefix'] . "offices WHERE office_id='$del_id'";
return $dbClass->query($sql);
}
function GetOfficeImages($id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "officeimages WHERE office_id='$id' ORDER BY image_rank";
return $dbClass->GetResults($sql);
}
function DeleteOfficeImages($id) {
if ($imagesTab = $this->GetOfficeImages($id)) {
for ($i = 0; $i < ($imagesTab); $i++) {
$this->DeleteOfficeImage($imagesTab[$i]['image_id']);
}
}
}
function DeleteOffices($del_tab) {
$true = 0;
for ($i = 0; $i < count($del_tab); $i++) {
if ($this->DeleteOffice($del_tab[$i]))
$true++;
}
if ($true == $i)
return true;
else
return false;
}
function EditOfficeBackEnd($post_vars, $get_vars, $user_id = false, $test = false) {
global $dbClass, $config, $presentationClass, $UrlClass, $jqueryscript, $user_level, $log_user_id, $formsClass;
$errors = false;
$actual_page_id = "editoffices";
require_once($config['wpradmin_basepath'] . 'include/fields.inc.php');
$fieldsClass = registry::register('fieldsClass');
if (isset($post_vars[$actual_page_id . '_submit'])) {
$post_vars = $dbClass->DataFiltersArray($post_vars);
$errors = $fieldsClass->CheckRequiredField($post_vars, "officefields", "officefields");
if ($errors === false) {
if ($this->UpdateOffice($post_vars, $get_vars['edit_id'])) {
$content = $presentationClass->OperationSuccessfull("Office edited");
} else
$content = $presentationClass->OperationFailed("Office edit failed");
}
else {
$error_info = "Field required: ";
for ($i = 0; $i < count($errors); $i++) {
$error_info .= $errors[$i] . ", ";
}
$error_info = substr($error_info, 0, -2);
$content .= $presentationClass->OperationFailed($error_info);
}
}
if (!isset($get_vars['action']) OR $get_vars['action'] == 'delete_office') {
$content = $presentationClass->SecondHeader('All Offices');
//multi delete
if (isset($post_vars['delete_offices'])) {
if (count($post_vars['del_id'])) {
if ($this->Deleteoffices($post_vars['del_id']))
$content .= $presentationClass->OperationSuccessfull('Delete offices success');
else
$content .= $presentationClass->OperationSuccessfull('Delete offices failed');
}
}
if ($get_vars['action'] == 'delete_office' AND is_numeric($get_vars['del_id'])) {
if ($this->DeleteOffice($get_vars['del_id']))
$content .= $presentationClass->OperationSuccessfull('Delete office success');
else
$content .= $presentationClass->OperationSuccessfull('Delete office failed');
}
$pagination = registry::register('SearchEngineClass');
$sql = "SELECT * FROM " . $config['table_prefix'] . "offices";
$reOffices = $dbClass->Query($sql);
$number_records = $reOffices->recordCount();
if ($number_records > 0) {
$headers = array("ID", "Office Name", array("name" => "", "align" => "right"));
$tab = array();
while (!$reOffices->EOF) {
$editurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=edit_office&edit_id=" . $reOffices->fields['office_id'];
$deleteurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=delete_office&del_id=" . $reOffices->fields['office_id'];
$checkbox = "<input type='checkbox' value='" . $reOffices->fields['office_id'] . "' name='del_id[]'>";
$tab[] = array($checkbox . $reOffices->fields['office_id'], $reOffices->fields['office_name'], "
<a href='$editurl'>
<img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a>
<a href='$deleteurl' class='delbutton' name='Delete this office?' onclick='return false'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>");
$reOffices->MoveNext();
}
$content .= "<form method='post' id='delete_offices_form'>";
$content .= $formsClass->create_submit('', 'Delete checked offices', array('id' => 'delete_offices', 'onclick' => 'return false;', 'type' => ''));
$content .= $presentationClass->StandardTableWithDataNew($tab, $headers, false, array('id' => $actual_page_id . '_datatable'), false);
$content .= "<input type='hidden' name='delete_offices' value='1' /></form>";
$content .= $presentationClass->MultiDeleteConfirm("Delete checked offices?", "delete_offices_form", "delete_offices");
} else
$content .= "No offices";
}
else {
if ($get_vars['action'] == 'edit_office' AND is_numeric($get_vars['edit_id'])) {
$content .= "<h3>Edit Office</h3>";
$backurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id;
$content .= "<div class='tophref'><a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a></div>";
$sql = "SELECT * FROM " . $config['table_prefix'] . "offices WHERE office_id='" . $dbClass->DataFilters($get_vars['edit_id']) . "'";
$reOffices = $dbClass->Query($sql);
if ($reOffices->recordCount() > 0) {
if ($errors !== false) {
$request = $post_vars;
$content .= $this->ShowAddEditOfficeTable($request, 'edit', $get_vars['edit_id'], $user_id, $test);
} else {
$request = $reOffices->fields;
foreach ($request as $key => $values) {
$post_vars[$key] = $values;
}
$content .= $this->ShowAddEditOfficeTable($post_vars, 'edit', $get_vars['edit_id'], $user_id, $test);
}
} else {
header("location: " . $backurl);
die();
}
}
}
$return = $content;
return $return;
}
function EditOfficeFieldsBackEnd($post_vars, $get_vars) {
global $dbClass, $presentationClass, $formsClass, $UrlClass, $config, $jqueryscript;
require_once($config['wpradmin_basepath'] . "/include/fields.inc.php");
$fieldsClass = registry::register('fieldsClass');
$page_name = "editofficefields";
$backurl = $config['baseurl'] . "index.php?apage=" . $page_name;
$tablename = "officefields";
$field_prefix = "officefields";
$office_table = "offices";
$field_name_prefix = "office_";
if (!isset($get_vars['action']) OR ( $get_vars['action'] == 'delete_field')) {
if ($get_vars['action'] == 'delete_field' AND is_numeric($get_vars['del_id'])) {
if ($field_info = $fieldsClass->FieldExists($tablename, $field_prefix . "_id", $get_vars['del_id'])) {
if ($fieldsClass->DeleteField($field_info[$field_prefix . '_field_name'], $office_table, $tablename, $this->block_fields_name)) {
$content .= $presentationClass->OperationSuccessfull("Office Field delete");
} else {
$content .= $presentationClass->OperationFailed("Office Field delete failed");
}
}
}
$content .= $formsClass->startform();
//update
$tab_fields = $fieldsClass->GetFields($tablename, $this->block_fields_name);
if ($tab_fields !== false) {
if (isset($post_vars['send_form'])) {
foreach ($post_vars as $key => $value) {
for ($i = 0; $i < count($value); $i++) {
$new_array[$i][$key] = $value[$i];
}
}
for ($i = 0; $i < count($tab_fields); $i++) {
$field_vars = $new_array[$i];
$new_name = $field_name_prefix . $field_vars[$field_prefix . '_field_newname'];
$field_name = $field_vars[$field_prefix . '_field_name'];
//change name
$colExists = $dbClass->ColumnExists($config['table_prefix'] . $office_table, $field_name, $colInfo);
if ($new_name != $field_name AND $colExists === false AND ( !array_key_exists($field_name, $this->standard_fields_name))) {
if ($dbClass->ChangeColumn($config['table_prefix'] . "offices", $field_name, array('new_column_name' => $new_name))) {
$field_vars[$field_prefix . '_field_name'] = $new_name;
$fieldsClass->DeleteFieldInfo($field_name, $tablename);
$fieldsClass->UpdateFieldsInfo($field_vars, $tablename, $field_prefix);
}
} else {
if ($colExists !== false) {
$fieldsClass->UpdateFieldsInfo($field_vars, $tablename, $field_prefix);
}
}
}
$content .= $presentationClass->OperationSuccessfull("Office Fields edited");
}
}
$tab_fields = $fieldsClass->GetFields($office_table, $this->block_fields_name);
if ($tab_fields !== false) {
$newfieldurl = $backurl . "&action=add_new_field";
$content .= "<a href='$newfieldurl'>Add new field</a>";
$pre_table_head = array('Name', 'Change name', 'Type', 'Caption', 'Elements', 'Required', '');
$pre_table = array();
for ($i = 0; $i < count($tab_fields); $i++) {
if ($field_info = $fieldsClass->FieldExists($tablename, $field_prefix . "_field_name", $tab_fields[$i])) {
$field_information = $field_info;
} else {
$field_information[$field_prefix . '_field_name'] = $tab_fields[$i];
$field_information[$field_prefix . '_field_caption'] = "";
$field_information[$field_prefix . '_field_elements'] = "";
$field_information[$field_prefix . '_field_required'] = 0;
$field_information[$field_prefix . '_rank'] = 0;
$field_information[$field_prefix . '_field_type'] = 'text';
$field_information[$field_prefix . '_id'] = 0;
}
if ($field_information[$field_prefix . '_field_type'] == '') {
}
if ($field_information[$field_prefix . '_field_required'] == 1) {
$required_check = true;
} else
$required_check = false;
$field_name = str_replace($field_name_prefix, "", $field_information[$field_prefix . '_field_name']);
$delurl = $UrlClass->ReplaceUrlValues(array('page' => 'offices', 'cpage' => $page_name, 'action' => 'delete_field', 'del_id' => $field_information[$field_prefix . '_id']));
if (!in_array($field_information[$field_prefix . '_field_datatype'], $fieldsClass->tab_select_datatype)) {
if ($dbClass->ColumnExists($config['table_prefix'] . "offices", $field_information[$field_prefix . '_field_name'], $params)) {
$field_information[$field_prefix . '_field_datatype'] = $params['type'];
}
}
$pre_table['table'][$i][] = $field_name . $formsClass->create_hidden($field_prefix . '_field_name[]', $field_information[$field_prefix . '_field_name'], '');
;
if (!array_key_exists($field_information['officefields_field_name'], $this->standard_fields_name))
$pre_table['table'][$i][] = $formsClass->create_text('officefields_field_name[]', $field_name, '');
else
$pre_table['table'][$i][] = $formsClass->create_text('', $field_name, array('disabled' => 'disabled'));
$pre_table['table'][$i][] = $formsClass->create_select($field_prefix . '_field_type[]', $field_information[$field_prefix . '_field_type'], '', $fieldsClass->tab_select_type);
$pre_table['table'][$i][] = $formsClass->create_text($field_prefix . '_field_caption[]', $field_information[$field_prefix . '_field_caption'], '');
$pre_table['table'][$i][] = $formsClass->create_text($field_prefix . '_field_elements[]', $field_information[$field_prefix . '_field_elements'], '');
$pre_table['table'][$i][] = $formsClass->create_select($field_prefix . '_field_required[]', $field_information[$field_prefix . '_field_required'], '', array(0 => 'No', 1 => 'Yes'));
$edit_url = $config['adm_baseurl'] . "index.php?apage=editofficefields&action=edit_field&edit_id=" . $field_information['officefields_id'];
$del_url = $config['adm_baseurl'] . "index.php?apage=editofficefields&action=delete_field&del_id=" . $field_information['officefields_id'];
$options_col = "<a href='$edit_url'><img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a>";
if (!array_key_exists($field_information['officefields_field_name'], $this->standard_fields_name))
$options_col .= "<a href='$del_url' class='delbutton' onclick='return false' name='Delete this field?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
$pre_table['table'][$i][] = $options_col;
$pre_table['rank'][$i] = $field_information[$field_prefix . '_rank'];
}
}
array_multisort($pre_table['rank'], $pre_table['table']);
$content .= $presentationClass->StandardTableWithDataNew($pre_table['table'], $pre_table_head, false, array('id' => 'sort', 'class' => 'wpr_form'));
$content .= $formsClass->create_hidden('send_form', 'yes');
$content .= $formsClass->create_submit('editsubmit', 'Edit', array('id' => 'editsubmit'));
$content .= $formsClass->endform();
}
else {
if (isset($post_vars['add_new_field_submit'])) {
$errors = $fieldsClass->CheckAddEditField($post_vars, $tablename, $field_name_prefix);
if ($errors == "") {
if (!in_array($post_vars[$field_prefix . '_field_datatype'], $this->tab_select_datatype)) {
$post_vars[$field_prefix . '_field_datatype'] == 'text';
}
$dbClass->ChangeDebugMode(false);
$field_name = $field_name_prefix . $post_vars[$field_prefix . '_field_name'];
if ($dbClass->AddColumn($config['table_prefix'] . $office_table, $field_name, $post_vars[$field_prefix . '_field_datatype'])) {
$post_vars[$field_prefix . '_field_name'] = $field_name;
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix);
$url = $config['adm_baseurl'] . "index.php?apage=" . $page_name;
header("Location: " . $url);
die();
} else {
$content = $presentationClass->OperationFailed("Add field failed");
}
$dbClass->ChangeDebugMode(true);
}
}
if (isset($post_vars['edit_field_submit'])) {
if ($fieldinfo = $fieldsClass->GetFieldInfo($get_vars['edit_id'], $tablename, $field_name_prefix)) {
$errors = $fieldsClass->CheckAddEditField($post_vars, $tablename, $field_name_prefix, $get_vars['edit_id']);
if ($errors == "") {
if (!in_array($post_vars[$field_prefix . '_field_datatype'], $this->tab_select_datatype)) {
$post_vars[$tablename . '_field_datatype'] == 'text';
}
$new_name = $field_name_prefix . $post_vars[$field_prefix . '_field_name'];
if ($new_name != $fieldinfo[$field_prefix . '_field_name']) {
if ($dbClass->ChangeColumn($config['table_prefix'] . $office_table, $fieldinfo[$field_prefix . '_field_name'], array('new_column_name' => $new_name))) {
$post_vars[$field_prefix . '_field_name'] = $fieldinfo[$field_prefix . '_field_name'];
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix, '', $new_name);
}
} else {
$post_vars[$field_prefix . '_field_name'] = $fieldinfo[$field_prefix . '_field_name'];
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix, '', $new_name);
}
$content .= $presentationClass->OperationSuccessfull("Office fields has been edited");
}
}
}
if ($get_vars['action'] == 'add_new_field') {
if ($errors != "")
$content .= $presentationClass->OperationFailed($errors);
$content .= "<h3>Add New Field</h3>";
$content .= "<a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a><br>";
$content .= $fieldsClass->AddEditField($post_vars, $tablename, $field_name_prefix);
} elseif ($get_vars['action'] == 'edit_field') {
if ($errors != "") {
$content .= $presentationClass->OperationFailed($errors);
}
$content .= "<h3>Edit Field</h3>";
$content .= "<a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a><br>";
if ($field_info = $fieldsClass->GetFieldInfo($get_vars['edit_id'], $tablename, $field_name_prefix)) {
$content .= $fieldsClass->AddEditField($field_info, $tablename, $field_name_prefix, $get_vars['edit_id'], $this->standard_fields_name);
}
}
}
return $content;
}
/*     * **********************************************************\
* WPRRETS - return key value array, officefields_field_name
* as key & officefields_field_caption  as value
\*********************************************************** */
function getKeyValueArray() {
global $dbClass, $config;
$sql = "SELECT officefields_field_name, officefields_field_caption FROM `" . $config['table_prefix'] . "officefields` ORDER BY officefields_field_name, officefields_field_caption";
$reC = $dbClass->query($sql);
$arr = array();
if ($reC->RecordCount() > 0) {
while (!$reC->EOF) {
$arr[$reC->fields['officefields_field_name']] = !empty($reC->fields['officefields_field_caption']) ? $reC->fields['officefields_field_caption'] : $reC->fields['officefields_field_name'];
$reC->MoveNext();
}
}
return $arr;
}
/*     * **********************************************************\
* Use by	:	wprrets cronjob module
* Purpose	:	Insert / update office data
\*********************************************************** */
function InsertUpdateOffices($arrOfficeData, $arrRETS2WPR_DirectTransfer, $retsUniqueField, $wpr_office_office_id_field) {
global $dbClass, $config;
/* Make Numerical Field List - */
$sql = 'SELECT officefields_field_name FROM `' . $config['table_prefix'] . 'officefields` ' . 'WHERE officefields_datatype LIKE "int%" OR  officefields_datatype LIKE "decimal%" ';
$reC = $dbClass->query($sql);
$numericalField = array();
/* Any listing found mark for remove? */
if ($reC->RecordCount() > 0) {
while (!$reC->EOF) {
$numericalField[] = $reC->fields['officefields_field_name'];
$reC->MoveNext();
}
}
/* Make Date Field List */
$sql = 'SELECT officefields_field_name FROM `' . $config['table_prefix'] . 'officefields` ' . 'WHERE officefields_datatype LIKE "DateTime" ';
$reC = $dbClass->query($sql);
$dateField = array();
if ($reC->RecordCount() > 0) {
while (!$reC->EOF) {
$dateField[] = $reC->fields['officefields_field_name'];
$reC->MoveNext();
}
}
$cnt = 0;
/* Loop through each data and perform insert / updates */
foreach ($arrOfficeData as $arrFieldNValue) {
/* Check for existing listing */
$sql = 'SELECT ' . $wpr_office_office_id_field . ' FROM `' . $config['table_prefix'] . 'offices` ' . 'WHERE ' . $wpr_office_office_id_field . ' = "' . $arrFieldNValue[$retsUniqueField] . '" ';
$reC = $dbClass->query($sql);
// debugMsg('<br>'. $sql);
/* Perform updates? */
$doUpdate = false;
if ($reC->RecordCount() > 0) {
$doUpdate = true;
}
if ($doUpdate) {
/* Update listingsdb for last data updates */
$sql = 'UPDATE ' . $config['table_prefix'] . 'offices ' . ' SET ';
} else {
/* Insert into listingsdb */
$sql = 'INSERT INTO ' . $config['table_prefix'] . 'offices '
. ' SET ';
}
/* Direct field to field tranfer */
foreach ($arrRETS2WPR_DirectTransfer as $retsFieldName => $wprFieldName) {
if ($doUpdate && $wprFieldName == $wpr_office_office_id_field)
continue;
if (in_array($wprFieldName, $numericalField)) {
$sql .= $wprFieldName . ' = "' . floatval(preg_replace('/[^\d.]/', "", $arrFieldNValue[$retsFieldName])) . '",';
} elseif (in_array($wprFieldName, $dateField)) {
if ($arrFieldNValue[$retsFieldName] == '')
$sql .= $wprFieldName . ' = NULL,';
else
$sql .= $wprFieldName . ' = "' . $arrFieldNValue[$retsFieldName] . '",';
}
else {
$sql .= $wprFieldName . ' = "' . $arrFieldNValue[$retsFieldName] . '",';
}
}
if ($doUpdate) {
$sql .= ' office_modified_date = CURRENT_TIMESTAMP() ';
$sql .= 'WHERE ' . $wpr_office_office_id_field . ' = "' . $arrFieldNValue[$retsUniqueField] . '" ';
} else {
$sql .= ' office_creation_date = CURDATE()';
}
//debugMsg("<br><br>$cnt : ". $sql. "<br>");
$ret = $dbClass->query($sql);
if ($ret !== false)
$cnt++;
}
return $cnt;
}
}
?>