<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
/************************************************************\
* This class is for the Property Class Features of WPR
\************************************************************/
class pclassClass{
function GetClasses($byid=false)
{
global $dbClass,$config;
$sql  =  "SELECT class_id,class_name FROM ".$config['table_prefix']."class ORDER BY class_rank";
$reClass = $dbClass->query($sql);
if($reClass->RecordCOunt()>0)
{
$ret_tab = array();
while(!$reClass->EOF)
{
if($byid!==false)
$ret_tab[$reClass->fields['class_id']] = $reClass->fields['class_name'];
else
$ret_tab[] = $reClass->fields;
$reClass->movenext();
}
return $ret_tab;
}
else
return false;
}

function GetClass($id)
{
global $dbClass,$config;
$sql  =  "SELECT class_id,class_name FROM ".$config['table_prefix']."class WHERE class_id='$id'";
$reClass = $dbClass->query($sql);
if($reClass->RecordCOunt()>0)
{
return $reClass->fields;
}
else
return false;
}

function DeleteClass($del_id)
{
global $dbClass,$config;
$sql = "DELETE FROM ".$config['table_prefix']."class WHERE class_id='$del_id'";
return $dbClass->query($sql);
}

function AddClass($name)
{
global $dbClass,$config;
$sql = "SELECT class_rank FROM ".$config['table_prefix']."class ORDER BY class_rank DESC";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordCount()>0)
$rank = $reCheck->fields['class_rank'];
else
$rank = 0;
$rank++;
$sql = "INSERT INTO ".$config['table_prefix']."class SET class_name='$name',class_rank='$rank'";
return $dbClass->Query($sql);
}

function EditClass($name,$class_id)
{
global $dbClass,$config;
$sql = "UPDATE ".$config['table_prefix']."class SET class_name='$name' WHERE class_id='$class_id'";
return $dbClass->Query($sql);
}
/************************************************************\
* Add Edit Class
\************************************************************/
function AddEditClass($request,$edit_id=false)
{
global $presentationClass,$formsClass,$UrlClass,$config,$jqueryscript;
//$content = $formsClass->startform($config['wpr_baseurl']."include/ajax_functions.php?page=listings&cpage=propertyclass",array('id'=>'addeditclass_form'));
$content = $formsClass->startform();
if($edit_id===false)
$submit = $formsClass->create_submit('addsubmit','Add');
else
$submit = $formsClass->create_submit('editsubmit','Edit');
$c = array(array('Class name',$formsClass->create_text('class_name',$request['class_name'])));
$content .= $presentationClass->BlockTable($c);
$content .= $submit;
/*
if($edit_id===false)
$content .= $formsClass->create_hidden('action_url',$UrlClass->AddUrlValues(array('page'=>'listings','cpage'=>'propertyclass','action'=>'add_class')));
else
$content .= $formsClass->create_hidden('action_url',$UrlClass->AddUrlValues(array('page'=>'listings','cpage'=>'propertyclass','action'=>'edit_class','edit_id'=>$edit_id)));
*/
$content .= $formsClass->endform();
return $content;
}
/************************************************************\
* Save Order Class
\************************************************************/
function SaveOrderClass($request)
{
global $dbClass,$config;
for($i=0;$i<count($request['class_id']);$i++)
{
$sql = "UPDATE ".$config['table_prefix']."class SET class_rank='$i' WHERE class_id='".$request['class_id'][$i]."'";
$dbClass->Query($sql);
}
return true;
}

function ClassBackEnd($post_vars,$get_vars)
{
global $presentationClass,$UrlClass,$jqueryscript,$dbClass,$config,$formsClass;
$content = "";
$page_name = "propertyclass";
//$action_url = $UrlClass->AddUrlValues(array('page'=>'listings','cpage'=>'propertyclass'));
$action_url = $config['adm_baseurl']."index.php?apage=propertyclass";
if(!isset($get_vars['action']) OR $get_vars['action']=='del_class')
{
if($get_vars['action']=='del_class' AND is_numeric($get_vars['del_id']))
{
if($this->DeleteClass($get_vars['del_id']))
$content .= $presentationClass->OperationSuccessfull('Delete class successfull');
else
$content .= $presentationClass->OperationFailed('Delete class failed');
}

if(isset($post_vars['saveorder']))
{
$post_vars = $dbClass->DataFiltersArray($post_vars);
if($this->SaveOrderClass($post_vars))
$content .= $presentationClass->OperationSuccessfull('Save order successfull');
else
$content .= $presentationClass->OperationFailed('Save order failed');
}
//$addhref = $UrlClass->ReplaceUrlValues(array('page'=>'listings','cpage'=>$page_name,'action'=>'add_class'));
$addhref = $config['adm_baseurl']."index.php?apage=propertyclass&action=add_class";
$content .= "<a href='$addhref'><button class='skin_colour round_all'><span>Add Class</span></button></a>";
if($temp_tab  = $this->GetClasses())
{
for($i=0;$i<count($temp_tab);$i++)
{
//$delhref = $UrlClass->ReplaceUrlValues(array('page'=>'listings','cpage'=>$page_name,'action'=>'del_class','del_id'=>$temp_tab[$i]['class_id']));
//$edithref = $UrlClass->ReplaceUrlValues(array('page'=>'listings','cpage'=>$page_name,'action'=>'edit_class','edit_id'=>$temp_tab[$i]['class_id']));
$delhref = $config['adm_baseurl']."index.php?apage=propertyclass&action=del_class&del_id=".$temp_tab[$i]['class_id'];
$edithref = $config['adm_baseurl']."index.php?apage=propertyclass&action=edit_class&edit_id=".$temp_tab[$i]['class_id'];
$tab_class[$i][] = $temp_tab[$i]['class_id'];
$tab_class[$i][] = $temp_tab[$i]['class_name'];
$tab_class[$i][] = "<a href='$edithref'><img src='".$config['wpradmin_baseurl']."images/pencil-small.png'></a>
<a href='$delhref' class='delbutton' onclick='return false' name='Delete this class?'>
<img src='".$config['wpradmin_baseurl']."images/cross-button.png'></a>".$formsClass->create_hidden('class_id[]',$temp_tab[$i]['class_id']);
}
$headers= array("ID","Class name",array('name'=>"",'align'=>"right"));
$content .= $formsClass->startform();
//$content .= $presentationClass->MovingTableWithData($headers,$tab_class,false);
$content .= $presentationClass->StandardTableWithDataNew($tab_class,$headers,false,array('id'=>$page_name.'_datatable'),true);
//$content .= $formsClass->create_hidden('action_url',$action_url);
$content .= $formsClass->create_submit('saveorder',"Save Order");
$content .= $formsClass->endform();
}
else
$content .= "No classes";
} else {
$backurl = "<div class='tophref'><a href='".$action_url."'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a></div>";
$content .= $backurl;
if($get_vars['action']=='add_class')
{
$post_vars = $dbClass->DataFiltersArray($post_vars);
if(isset($post_vars['addsubmit']))
{
$error = false;
if($post_vars['class_name']=="")
{
$error = "You must fill Class Name";
}
else
{
$sql = "SELECT * FROM ".$config['table_prefix']."class WHERE class_name='".$post_vars['class_name']."'";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordCount()>0)
$error = "Class name already exists";
}

if($error===false)
{
if($this->AddClass($post_vars['class_name']))
{
$content .= $presentationClass->OperationSuccessfull('Class add success');
}
else
$content .= $presentationClass->OperationFailed('Class add failed');
}
else
$content .= $presentationClass->OperationFailed($error);
}
$content .= $this->AddEditClass($request_vars);
}

if($get_vars['action']=='edit_class' AND is_numeric($get_vars['edit_id']))
{
$class_info = $this->GetClass($get_vars['edit_id']);
if(isset($post_vars['editsubmit']))
{
$post_vars = $dbClass->DataFiltersArray($post_vars);
$error = false;
if($post_vars['class_name']=="")
{
$error = "You must fill Class Name";
}
else
{
if($post_vars['class_name']!=$class_info['class_name'])
{
$sql = "SELECT * FROM ".$config['table_prefix']."class WHERE class_name='".$post_vars['class_name']."'";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordCount()>0)
$error = "Class name already exists";
}
}
if($error===false)
{
if($this->EditClass($post_vars['class_name'],$get_vars['edit_id']))
{
$content .= $presentationClass->OperationSuccessfull('Class edit success');
}
else
$content .= $presentationClass->OperationFailed('Class edit failed');
}
else
$content .= $presentationClass->OperationFailed($error);
$request_vars = $post_vars;
}
else
{
$request_vars = $class_info;
}
$content .= $this->AddEditClass($request_vars,$get_vars['edit_id']);
}
}
return $content;
}
/************************************************************\
* WPRRETS return key value array, class_id  as key & class_name  as value
\************************************************************/
function getKeyValueArray()
{
global $dbClass, $config;
$sql = "SELECT class_id, class_name FROM `".$config['table_prefix']."class` ORDER BY class_name ";
$reC = $dbClass->query($sql);
$arr = array();
if($reC->RecordCount()>0)
{
while(!$reC->EOF)
{
$arr[$reC->fields['class_id']] = $reC->fields['class_name'];
$reC->MoveNext();
}
}
return $arr;
}
} // END class pclassClass
?>