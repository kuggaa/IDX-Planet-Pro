<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class fieldsClass{
var $tab_select_datatype = array(
"int(11)" => 'Integer',
"float" => 'Float',
"char(5)" => 'Char(5)',
"char(20)" => 'Char(20)',
"char(50)" => 'Char(50)',
"char(100)" => 'Char(100)',
"char(200)" => 'Char(200)',
"text" => 'Text',
"longtext" => 'Long Text'
);
var $tab_select_type = array(
"text" => "Text",
"radio" => "Radio",
"checkbox" => "Checkbox",
"select" => "Select",
"password"=>"Password",
"textarea" => "TextArea"
);
function FieldExists($tablename,$searchfield,$search)
{
global $dbClass,$config;
$sql = "SELECT * FROM ".$config['table_prefix'].$tablename." WHERE ".$searchfield."='".$search."'";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordcount()>0)
{
return $reCheck->fields;
}else
return false;
}
function GetFields($tablename,$blockfields, $remotedb = false)
{
global $dbClass,$config;
return $dbClass->GetColumns($config['table_prefix'].$tablename,$blockfields,false, $remotedb);
}
function DeleteField($name,$tablename,$fieldtable,$blockfields)
{
global $dbClass,$config;
$name = $dbClass->DataFilters($name);
if(!in_array($name,$blockfields))
{
if($dbClass->ColumnExists($config['table_prefix'].$tablename,$name))
{
$dbClass->DeleteColumn($config['table_prefix'].$tablename,$name);
}
return $this->DeleteFieldInfo($name,$fieldtable);
}
else
return false;
}
function DeleteFieldInfo($name,$tablename)
{
global $dbClass,$config;
$sql = "DELETE FROM ".$config['table_prefix'].$tablename." WHERE ".$tablename."_field_name='".$name."'";
return $dbClass->Query($sql);
}
function GetFieldInfo($fid,$tablename,$prefix)
{
global $dbClass,$config;
$sql = "SELECT * FROM ".$config['table_prefix'].$tablename." WHERE ".$tablename."_id='".$fid."' LIMIT 1";
$recordSet = $dbClass->Query($sql);
if($recordSet->recordCount()>0)
{
$field_information = $recordSet->fields;
$field_information['field_name'] = str_replace($prefix,"",$field_information[$tablename.'_field_name']);
return $field_information;
}
return false;
}
function AddEditField($request,$tablename,$prefix,$edit_id=false,$standard_fields_name=array())
{
global $formsClass,$presentationClass;
$content .= $formsClass->startform();
if($edit_id===false OR !array_key_exists($request[$tablename.'_field_name'],$standard_fields_name))
{
$data_add[] = array("Field Name:",$formsClass->create_text($tablename.'_field_name',$request['field_name'],''));
}
else
$data_add[] = array("Field Name:",$formsClass->create_text($tablename.'_field_name',$request['field_name'],array('disabled'=>'disabled')));
$data_add[]  = array("Field Caption:",$formsClass->create_text($tablename.'_field_caption',$request[$tablename.'_field_caption'],''));
$data_add[]  = array("Field Type:",$formsClass->create_select($tablename.'_field_type',$request[$tablename.'_field_type'],'',$this->tab_select_type));
if($edit_id===false)
$data_add[] = array("Field DataType:",$formsClass->create_select($tablename.'_field_datatype',$request[$tablename.'_field_datatype'],'',$this->tab_select_datatype));
$data_add[] = array("Field Elements:",$formsClass->create_textarea($tablename.'_field_elements',$request[$tablename.'_field_elements'],''));
$data_add[] = array("Field Tip:",$formsClass->create_textarea($tablename.'_tip',$request[$tablename.'_tip'],''));
$checked = false;
if($request[$tablename.'_field_required']=='1')
$checked = true;
$data_add[] = array("Field Required:",$formsClass->create_checkbox($tablename.'_field_required','1','',$checked));
$content .= $presentationClass->BlockTable($data_add);
if($edit_id!==false)
$content .= $formsClass->create_submit('edit_field_submit',"Edit field");
else
$content .= $formsClass->create_submit('add_new_field_submit',"Add field");
$content .= $formsClass->endform();
return $content;
}
function CheckAddEditField($request,$tablename,$prefix,$edit_id=false)
{
global $dbClass,$config;
$request = $dbClass->DataFiltersArray($request);
$errors  = "";
if($request[$tablename.'_field_name']!="")
{
$field_name = $tablename."_".$request[$tablename.'_field_name'];
$request[$tablename.'_field_name'] = $field_name;
if($edit_id===false)
{
if($dbClass->ColumnExists($config['table_prefix'].$tablename,$field_name)!==false)
{
$errors .= "Field already exists<br>";
}
}else
{
$fieldinfo = $this->GetFieldInfo($edit_id,$tablename,$prefix);
if($fieldinfo[$tablename.'_field_name']!=$field_name)
{
if($dbClass->ColumnExists($config['table_prefix'].$tablename,$field_name)!==false)
{
$errors .= "Field already exists<br>";
}
}
}
}
else
{
$errors .= "You must fill field name!<br>";
}
return $errors;
}
function UpdateFieldsInfo($request_vars,$tablename,$prefix, $tab_fields='',$change_name=false)
{
global $dbClass,$config;
if(!is_array($tab_fields))
{
$sql = "SELECT * FROM ".$config['table_prefix'].$tablename." WHERE ".$tablename."_field_name = '".$request_vars[$prefix.'_field_name']."'";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordCount()==0)
{
$sql = "INSERT INTO ".$config['table_prefix'].$tablename."
SET ".$prefix."_field_caption='".$request_vars[$prefix.'_field_caption']."',
".$prefix."_field_type='".$request_vars[$prefix.'_field_type']."',
".$prefix."_datatype='".$request_vars[$prefix.'_field_datatype']."',
".$prefix."_field_elements='".$request_vars[$prefix.'_field_elements']."',
".$prefix."_field_required='".intval($request_vars[$prefix.'_field_required'])."',
".$prefix."_rank='".intval($request_vars[$prefix.'_rank'])."',
".$prefix."_rank_col='".intval($request_vars[$prefix.'_rank_col'])."',
".$prefix."_tip='".$request_vars[$prefix.'_tip']."',
".$prefix."_field_name = '".$request_vars[$prefix.'_field_name']."'
";
} else {
$sql = "UPDATE ".$config['table_prefix'].$tablename." SET ";
if($change_name!==false)
$sql .= $prefix."_field_name = '".$change_name."',";
$sql .= $prefix."_field_caption='".$request_vars[$prefix.'_field_caption']."',
".$prefix."_field_type='".$request_vars[$prefix.'_field_type']."',
".$prefix."_datatype='".$request_vars[$prefix.'_field_datatype']."',
".$prefix."_field_elements='".$request_vars[$prefix.'_field_elements']."',
".$prefix."_tip='".$request_vars[$prefix.'_tip']."',
".$prefix."_field_required='".intval($request_vars[$prefix.'_field_required'])."'
WHERE ".$prefix."_field_name = '".$request_vars[$prefix.'_field_name']."'
";
}
$dbClass->Query($sql);
}
else
{
for($i=0;$i<count($tab_fields);$i++)
{
$sql = "SELECT * FROM ".$config['table_prefix']."agentfields WHERE agentfields_field_name = '".$request_vars[$prefix.'_field_name'][$i]."'";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordCount()==0)
{
$sql = "INSERT INTO ".$config['table_prefix'].$tablename."
SET ".$prefix."_field_caption='".$request_vars[$prefix.'_field_caption'][$i]."',
".$prefix."_field_type='".$request_vars[$prefix.'_field_type'][$i]."',
".$prefix."_datatype='".$request_vars[$prefix.'_field_datatype'][$i]."',
".$prefix."_field_elements='".$request_vars[$prefix.'_field_elements'][$i]."',
".$prefix."_field_required='".intval($request_vars[$prefix.'_field_required'][$i])."',
".$prefix."_rank='".$i."',
".$prefix."_field_name = '".$request_vars[$prefix.'_field_name'][$i]."'
";
}
else
{
$sql = "UPDATE ".$config['table_prefix'].$tablename."
SET ".$prefix."_field_caption='".$request_vars[$prefix.'_field_caption'][$i]."',
".$prefix."_field_type='".$request_vars[$prefix.'_field_type'][$i]."',
".$prefix."_datatype='".$request_vars[$prefix.'_field_datatype'][$i]."',
".$prefix."_field_elements='".$request_vars[$prefix.'_field_elements'][$i]."',
".$prefix."_field_required='".intval($request_vars[$prefix.'_field_required'][$i])."',
".$prefix."_rank='".$i."'
WHERE ".$prefix."_field_name = '".$request_vars[$prefix.'_field_name'][$i]."'
";
}
$dbClass->Query($sql);
}
}
}
function CheckRequiredField($request_vars,$tablename,$prefix,$except=false)
{
global $dbClass,$config;
$sql = "SELECT * FROM ".$config['table_prefix'].$tablename." WHERE ".$prefix."_field_required=1";
if($except!==false)
{
if(is_array($except))
{
$sql .= " AND ".$prefix."_field_name NOT IN (";
for($i=0;$i<count($except);$i++)
{
$sql .= "'".$except[$i]."',";
}
$sql = substr($sql,0,-1);
$sql .= ")";
}else{
$sql .= " AND ".$prefix."_field_name !='".$except."'";
}
}
$reFields_req = $dbClass->Query($sql);
$errors=false;
while(!$reFields_req->EOF)
{
if($request_vars[$reFields_req->fields[$prefix.'_field_name']]=="" AND
$reFields_req->fields[$prefix.'_field_type']!='select' AND
$reFields_req->fields[$prefix.'_field_type']!='checkbox')
{
if($reFields_req->fields[$prefix.'_field_caption']!="")
$errors[] = $reFields_req->fields[$prefix.'_field_caption'];
else
$errors[] = $reFields_req->fields[$prefix.'_field_name'];
}
if($request_vars[$reFields_req->fields[$prefix.'_field_name']]=="select" AND $reFields_req->fields[$prefix.'_field_type']=='select')
{
if($reFields_req->fields[$prefix.'_field_caption']!="")
$errors[] = $reFields_req->fields[$prefix.'_field_caption'];
else
$errors[] = $reFields_req->fields[$prefix.'_field_name'];
}
$reFields_req->MoveNext();
}
return $errors;
}
}
?>