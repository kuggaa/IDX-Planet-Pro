<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class PresentationClass{
function generate_params_list($params)
{
$content = "";
if(is_array($params))
{
foreach ($params as $key=>$value)
{
$content .= $key."='".$value."' ";
}
}
return $content;
}
function BlockTable($data,$repeat=1)
{
$grid = floor(16/$repeat);
$hcontent = "<div class='box grid_$grid'><div class='block' >";
$content = $hcontent;
$cmax = false;
if($repeat>1)
{
$cmax = ceil(count($data)/$repeat)-1;
}
for($i=0;$i<count($data);$i++)
{
$content .= "<label>".$data[$i][0]."</label>";
$content .= $data[$i][1];
if($cmax !== false AND $i==$cmax)
$content .= "</div></div>".$hcontent;
}
$content .= "</div></div><div style='clear:both'></div>";
return $content;
}
function BlockTableSortable($data,$repeat=1,$class='sd_item')
{
global $jqueryscript;
$grid = floor(16/$repeat);
$hcontent = "<div class='box grid_$grid'><div class='sd_column'>";
$content = $hcontent;
for($i=0;$i<count($data);$i++)
{
$content .= "<div class='$class wpr_form'><label>".$data[$i][0]."</label>";
$content .= $data[$i][1]."</div>";
}
$content .= "</div></div>";
return $content;
}
function CreateItemSE($title,$content_t)
{
$content = "";
$content .= "<div class='$class box wpr_form'>";
$content .= "<h2 class='box_head grad_colour'>".$title."</h2>";
$content .= '<a class="grabber_se" href="#">&nbsp;</a>
<a class="toggle" href="#">&nbsp;</a>';
$content .= "<div class='toggle_container wpr_form' style='padding:5px'>".$content_t."</div>";
$content .= "</div>";
return $content;
}
function BlockTableSortableSE($data,$repeat=1,$title=false,$before="")
{
global $jqueryscript;
$grid = floor(16/$repeat);
$cgrid = $grid*2;
$hcontent = "<div class='box_wp grid_$grid'>";
if($title!==false)
$hcontent .= "<h2>".$title."</h2>";
if($before!="")
$hcontent .= $before;
$hcontent .= "<div class='sd_column_se'>";
$content = $hcontent;
//$hcontent = "<div class='box grid_$grid'><div class='sd_column'>";
//$content = $hcontent;
if($data!==false)
{
for($i=0;$i<count($data);$i++)
{
$content .= $this->CreateItemSE($data[$i][0],$data[$i][1]);
}
}
$content .= "</div>";
$content .= "</div>";
return $content;
}
function ContentWithHeader($header,$content)
{
$return = '<div class="box grid_16 round_all">
<h2 class="box_head grad_colour">'.$header.'</h2>
<a class="grabber" href="#">&nbsp;</a>
<a class="toggle" href="#">&nbsp;</a>
<div class="toggle_container wpr_form" style="padding:5px">'.$content.'
</div>
</div>';
return $return;
}
function StandardTableWithDataNew($data,$headers=false,$footers=false,$params=false,$sortable=false)
{
global $jqueryscript;
$param = "";
$params['class'] = 'display '.$params['class'];
if($params!==false)
$param = $this->generate_params_list($params);
$content = '<div class="box grid_16 round_all">';
$content .= "<table border='0' $param cellspacing='0'>";
if($headers!==false)
{
$content .= "<thead><tr>";
for($i=0;$i<count($headers);$i++)
{
if(is_array($headers[$i]))
$content .= "<th>".$headers[$i]['name']."</th>";
else
$content .= "<th>".$headers[$i]."</th>";
}
$content .= "</tr></thead>";
}
if($data!==false)
{
$content .= "<tbody>";
for($i=0;$i<count($data);$i++)
{
$content .= "<tr valign='top'>";
$y=0;
foreach($data[$i] as $key=>$value)
{
$param_col = "";
if(isset($headers[$y]['align']))
$param_col = "align='".$headers[$y]['align']."'";
if(isset($headers[$y]['width']))
$param_col = "width='".$headers[$y]['width']."'";
$content .= "<td $param_col>".$value."</td>";
$y++;
}
$content .= "</tr>";
}
$content .= "</tbody>";
}
if($footers!==false)
{
$content .= "<tfoot>";
for($i=0;$i<count($footers);$i++)
{
$content .= "<tr>";
for($y=0;$y<count($footers[$i]);$y++)
{
}
$content .= "</tr>";
}
$content .= "</tfoor>";
}
$content .= "</table></div>";
if(isset($params['id']))
{
$script .= '
jQuery(\'#'.$params['id'].'\').livequery(function()
{
var tmp_'.$params['id'].' = jQuery(\'#'.$params['id'].'\').dataTable( {
"bJQueryUI": true,
"sScrollX": "",
"bStateSave": false,
"bSortClasses": false,';
$script .= "\n";
if($sortable!==false)
{
$script .= '"bSort": false,
"bPaginate": false,
"bFilter": false,
';
}
else
$script .= '"aaSorting": [[0,\'asc\']],';
$script .= '"bAutoWidth": true,
"bInfo": true,
"sScrollY": "100%",
"sScrollX": "100%",
"bScrollCollapse": true,
"iDisplayLength": 100,
"sPaginationType": "full_numbers",
"bRetrieve": true,';
$script .=' });';
$script .= "\n";
if($sortable!==false)
$script .= $this->GenerateSortable($params['id']);
$script .= 'jQuery(window).resize(function(){
tmp_'.$params['id'].'.fnAdjustColumnSizing();
});
});
';
};
$content .= $jqueryscript->AddJqueryScriptEnd($script);
return $content;
}
/* TABLE TO LISTINGS */
function StandardTableWithDataHuge($data,$headers=false,$params=false,$all_results,$start_page=1,$max_on_page=10)
{
global $jqueryscript,$config;
$param = "";
$params['class'] = 'display '.$params['class'];
$content = "";
if($params!==false)
$param = $this->generate_params_list($params);
$content .= '<div class="box_wp round_all">';
$content .= "<table border='0' $param cellspacing='0'>";
if($headers!==false)
{
$content .= "<thead><tr>";
for($i=0;$i<count($headers);$i++)
{
if(is_array($headers[$i]))
$content .= "<th>".$headers[$i]['name']."</th>";
else
$content .= "<th>".$headers[$i]."</th>";
}
$content .= "</tr></thead>";
}
if($data!==false)
{
$content .= "<tbody>";
for($i=0;$i<count($data);$i++)
{
$content .= "<tr valign='top'>";
$y=0;
foreach($data[$i] as $key=>$value)
{
$param_col = "";
if(isset($headers[$y]['align']))
$param_col = "align='".$headers[$y]['align']."'";
if(isset($headers[$y]['width']))
$param_col = "width='".$headers[$y]['width']."'";
$content .= "<td $param_col>".$value."</td>";
$y++;
}
$content .= "</tr>";
}
$content .= "</tbody>";
} else {
$content .= "<tbody>";
$colspan = count($headers);
$content .= "<tr><td colspan='".$colspan."' width='100%' align='center'><b>No data</b></td></tr>";
$content .= "</tbody>";
}
$content .= "</table></div>";
$cnt_pages = @ceil($all_results/$max_on_page);
$from = ($start_page-1)*$max_on_page+1;
$to = $from+$max_on_page-1;
if($to>$all_results)
$to = $all_results;
$next = $start_page+1;
$last = $cnt_pages;
if($next>$last)
$next=$last;
$prev = $start_page-1;
if($prev<1)
$prev=1;
$content .= '<div class="box_wp tablehuge_bottom dataTables_wrapper" style="margin-bottom:15px">
<div class="fg-toolbar ui-toolbar ui-widget-header ui-corner-bl ui-corner-br ui-helper-clearfix">
<div class="dataTables_info">Showing '.$from.' to '.$to.' of '.$all_results.' entries</div>
<div class="dataTables_paginate">';
if($start_page==1)
{
$content .= '<span class="first ui-corner-tl ui-corner-bl fg-button ui-button ui-state-default ui-state-disabled">First</span>';
$content .= '<span class="previous fg-button ui-button ui-state-default ui-state-disabled">Previous</span>';
} else {
$content .= '<span id="step_1" class="first ui-corner-tl ui-corner-bl fg-button ui-button ui-state-default">First</span>';
$content .= '<span id="step_'.$prev.'"  class="previous fg-button ui-button ui-state-default">Previous</span>';
}
$content .= "<span>";
$max_visible_page = 10;
if($max_visible_page<$cnt_pages)
{
if($start_page+$max_on_page>$cnt_pages)
{
$ee = $cnt_pages;
} else
$ee = $start_page+$max_on_page;
if(($max_visible_page%2)==0)
{
$left = $max_visible_page/2;
$right  = $left-1;
$tmp=2;
} else {
$left = ($max_visible_page-1)/2;
$right = $left;
$tmp=1;
}
$ss = $start_page-$left;
if($ss<1)
$ss=1;
$ee = $ss+$right+$tmp;
if($ee>$cnt_pages)
{
$ee=$cnt_pages;
$ss=$ee-$left-$right;
}
if($ss<1)
$ss=1;
} else{
$ss = 1;
$ee = $cnt_pages;
}
for($i=$ss;$i<=$ee;$i++)
{
if($i==$start_page)
$content .= '<span class="fg-button ui-button ui-state-default ui-state-disabled">'.$i.'</span>';
else
$content .= '<span class="fg-button ui-button ui-state-default">'.$i.'</span>';
}
$content .= "</span>";
/*
<span class="fg-button ui-button ui-state-default ui-state-disabled">1</span>
<span class="fg-button ui-button ui-state-default">2</span>
<span class="fg-button ui-button ui-state-default">3</span>
<span class="fg-button ui-button ui-state-default">4</span>
<span class="fg-button ui-button ui-state-default">5</span>
*/
if($start_page==$cnt_pages)
{
$content .= '<span id="" class="next fg-button ui-button ui-state-default ui-state-disabled">Next</span>';
$content .= '<span id="" class="last ui-corner-tr ui-corner-br fg-button ui-button ui-state-default  ui-state-disabled">Last</span>';
} else {
$content .= '<span id="step_'.$next.'" class="next fg-button ui-button ui-state-default">Next</span>';
$content .= '<span id="step_'.$last.'" class="last ui-corner-tr ui-corner-br fg-button ui-button ui-state-default">Last</span>';
}
$content .= '
</div>
</div>
</div>';
return $content;
}
function GenerateSortable($id)
{
$ret = '
jQuery("#'.$id.' tbody").css("cursor","move");
jQuery("#'.$id.' tbody").livequery(function()
{
jQuery(this).sortable({update: function()
{
jQuery("#'.$id.' tbody").sortable("serialize");
}}).enableSelection();
});
';
return $ret;
}
function StandardTableWithData($data,$headers=false,$footers=false,$params=false)
{
$param = "";
$params['class'] = 'standardtable '.$params['class'];
if($params!==false)
$param = $this->generate_params_list($params);
$content = "<table border='0' $param cellspacing='0'>";
if($headers!==false)
{
$content .= "<thead><tr style='font-weight:bold'>";
for($i=0;$i<count($headers);$i++)
{
$content .= "<td>".$headers[$i]."</td>";
}
$content .= "</tr></thead>";
}
if($data!==false)
{
$content .= "<tbody>";
for($i=0;$i<count($data);$i++)
{
if(isset($data[$i]['tr']))
{
$dcontent = $data[$i]['content'];
$content .= "<tr ".$data[$i]['tr'].">";
} else {
$dcontent = $data[$i];
$content .= "<tr>";
}
if(is_array($dcontent))
{
foreach($dcontent as $key=>$value) //($y=0;$y<count($data[$i]);$y++)
{
$content .= "<td>".$value."</td>";
}
}
$content .= "</tr>";
}
$content .= "</tbody>";
}
if($footers!==false)
{
$content .= "<tfoot>";
for($i=0;$i<count($footers);$i++)
{
$content .= "<tr>";
for($y=0;$y<count($footers[$i]);$y++)
{
$content .= "<td>".$footers[$i][$y]."</td>";
}
$content .= "</tr>";
}
$content .= "</tfoor>";
}
$content .= "</table>";
return $content;
}
function JqueryTabsWithDataNew($data,$headers,$params=false,$select=false)
{
global $jqueryscript;
$content = "";
$param = "";
if(!isset($params['id']))
$params['id'] = 'tabs';
if(!isset($params['grabber']))
$grabber = true;
else
$grabber = $params['grabber'];
unset($params['grabber']);
if(!isset($params['toggle']))
$toggle = true;
else
$toggle = $params['toggle'];
unset($params['toggle']);
if($params!==false)
$param = $this->generate_params_list($params);
$reg = "#^link:(.*?)$#";
/*
<ul id="touch_sort" class="tab_header grad_colour round_top clearfix">
<li><a href="#tabs-1" class="round_top">Table Data</a></li>
<li><a href="#tabs-2" class="round_top">Table Info</a></li>
<li><a href="#tabs-3" class="round_top">Another Tab</a></li>
</ul>
<a href="#" class="grabber">&nbsp;</a>
<a href="#" class="toggle">&nbsp;</a>
*/
$content .= "<div $param ><ul class='tab_header grad_colour round_top clearfix'>";
$datacontent = "";
if(count($headers)>0)
{
foreach ($headers as $key=>$value)
{
$addValue = "";
if(is_array($value))
{
$addValue = $value['add'];
$value = $value['value'];
}
if(preg_match($reg,$data[$key],$link))
{
$content .= "<li><a href='".$link[1]."'>".$value."</a>$addValue</li>";
$datacontent .=  "<div id='$key'></div>";
} else
{
$content .= "<li><a href='#".$key."'>".$value."</a>$addValue</li>";
$datacontent .=  "<div id='$key'>".$data[$key]."</div>";
}
}
}
$content .= "</ul>";
if($grabber!==false)
$content .= "<a href='#' class='grabber'>&nbsp;</a>";
if($toggle!==false)
$content .= "<a href='#' class='toggle'>&nbsp;</a>";
$content .= "<div class='toggle_container'>";
$content .= "".$datacontent."</div>";
$content .= "</div>";
$params_sortable = "";
if($select!==false)
$params_sortable = "selected:$select,";
/*
$jqueryscript->PrintScript('
jQuery("#'.$params['id'].'").tabs({
'.$params_sortable.'
"show": function(event, ui) {
var oTable = jQuery("div.dataTables_scrollBody>table.display", ui.panel).dataTable();
if ( oTable.length > 0 ) {
oTable.fnAdjustColumnSizing();
}
}
}).sortable();
');
*/
return $content;
}
function JqueryTabsWithData($data,$headers,$params=false)
{
global $jqueryscript;
$content = "";
$param = "";
if(!isset($params['id']))
$params['id'] = 'jquerytabs';
//if(!isset($params['class']))
//  $params['class'] = 'vartical_tab';
if($params!==false)
$param = $this->generate_params_list($params);
$reg = "#^link:(.*?)$#";
if(!isset($params['class']))
{
$content .= "<div id='".$params['id']."' class='vertical_tabs'><div class='vertical_tabs_left'><ul>";
$datacontent = "";
foreach ($headers as $key=>$value)
{
if(preg_match($reg,$data[$key],$link))
{
$content .= "<li><a  href='#".$key."' onclick='document.location=\"".$link[1]."\"'>".$value."</a></li>";
$datacontent .=  "";
} else
{
$content .= "<li class='litab'><a href='#".$key."'>".$value."</a></li>";
$datacontent .=  "<div id='$key' class='vertical_tabs_right'>".$data[$key]."</div>";
}
}
$content .= "</ul></div>";
$content .= "".$datacontent."<div style='clear:both'></div></div>";
} else {
$content .= "<div $param ><ul>";
$datacontent = "";
foreach ($headers as $key=>$value)
{
if(preg_match($reg,$data[$key],$link))
{
die('asd');
$content .= "<li><a href='".$link[1]."'>".$value."</a></li>";
$datacontent .=  "<div id='$key'></div>";
} else
{
$content .= "<li><a href='#".$key."'>".$value."</a></li>";
$datacontent .=  "<div id='$key'>".$data[$key]."</div>";
}
}
$content .= "</ul><div style='clear:both'></div>";
$content .= "".$datacontent."</div>";
}
$content .= $jqueryscript->PrintScript('jQuery(document).ready(function() { jQuery("#'.$params['id'].'").tabs(); })');
//echo '<div style="display:none;">'.$content.'</div>';
return $content;
}
function ShowError($error)
{
return "<span style='font-weight:bold;color:red'>".$error."</span>";
}
function SecondHeader($text)
{
return "<h3 class='SecondHeader'>$text</h3>";
}
function MainHeader($text)
{
return "<h1 class='MainHeader'>$text</h1>";
}
function GenerateAjaxPagination($max_visible_page,$max_on_page,$count_pages,$cur_page,$page,$cpage,$anchor=false)
{
global $UrlClass;
$pages  = "";
if($cur_page+$max_on_page>$count_pages)
{
$end_page = $count_pages;
}
else
$end_page = $cur_page+$max_on_page;
if(($max_visible_page%2)==0)
{
$left = $max_visible_page/2;
$right  = $left-1;
}
else
{
$left = ($max_visible_page-1)/2;
$right = $left;
}
$start_page = $cur_page-$left;
if($start_page<1)
$start_page=1;
$end_page = $start_page+$right+2;
if($end_page>$count_pages)
{
$end_page=$count_pages;
$start_page=$end_page-$left-$right;
}
if($start_page<1)
$start_page=1;
for($i=$start_page;$i<=$end_page;$i++)
{
if($anchor===false)
$adress = $UrlClass->ReplaceUrlValues(array('page'=>$page,'cpage'=>$cpage,'cur_page'=>$i),'action');
else
$adress = $UrlClass->ReplaceUrlValuesWithAnchor(array('page'=>$page,'cpage'=>$cpage,'cur_page'=>$i),'action',$anchor);
if($i==$cur_page)
$pages .= "<b><a href='$adress' class='ajax_href' onclick='return false'>$i</a></b>&nbsp;";
else
$pages .= "<a href='$adress' class='ajax_href' onclick='return false'>$i</a>&nbsp;";
}
return $pages;
}
function GeneratePagination($max_visible_page,$max_on_page,$count_pages,$cur_page,$anchor=false)
{
global $UrlClass;
$pages  = "";
if($cur_page+$max_on_page>$count_pages)
{
$end_page = $count_pages;
}
else
$end_page = $cur_page+$max_on_page;
if(($max_visible_page%2)==0)
{
$left = $max_visible_page/2;
$right  = $left-1;
}
else
{
$left = ($max_visible_page-1)/2;
$right = $left;
}
$start_page = $cur_page-$left;
if($start_page<1)
$start_page=1;
$end_page = $start_page+$right+2;
if($end_page>$count_pages)
{
$end_page=$count_pages;
$start_page=$end_page-$left-$right;
}
if($start_page<1)
$start_page=1;
for($i=$start_page;$i<=$end_page;$i++)
{
if($anchor===false)
$adress = $UrlClass->ReplaceUrlValues(array('cur_page'=>$i),'');
else
$adress = $UrlClass->ReplaceUrlValuesWithAnchor(array('cur_page'=>$i),'',$anchor);
if($i==$cur_page)
$pages .= "<b><a href='$adress'>$i</a></b>&nbsp;";
else
$pages .= "<a href='$adress'>$i</a>&nbsp;";
}
return $pages;
}
function ControlPanelHeader($text){
return "<span style='font: italic 17px/30px Georgia,\"Times New Roman\",\"Bitstream Charter\",Times,serif'>".$text."</span>";
}
function OperationSuccessfull($text)
{
global $config;
return '<div class="alert alert_green"><img width="24" height="24" src="'.$config['wpradmin_baseurl'].'images/icons/small/white/alert.png">'.$text.'</div>';
}
function OperationFailed($text)
{
global $config;
return '<div class="alert alert_red"><img width="24" height="24" src="'.$config['wpradmin_baseurl'].'images/icons/small/white/alarm_bell.png">'.$text.'</div>';
}
function ControlPanelHeaderCheck($a)
{
return;
}
function ControlPanelHeaderSide($a)
{
return;
}
function SEOTableHelp($a)
{
return;
}
function PreparePaginationLetter($tab,$row,$act_letter,$url,$normalurl)
{
global $config;
$letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$replacement = "";
$currentbool= false;
$hasresultbool = false;
for($i=0;$i<strlen($letters);$i++)
{
$current = "";
if($letters[$i]==$act_letter)
{
$current = 'current';
$currentbool =true;
}
$hasresult = "";
if($tab[$letters[$i]]>0)
{
$hasresult ='hasagents';
$hasresultbool =true;
}
$reprow = $row;
$reprow = str_replace("{current}",$current,$reprow);
$reprow = str_replace("{hasresult}",$hasresult,$reprow);
$reprow = str_replace("{letter}",$letters[$i],$reprow);
$reprow = str_replace("{url}",$url.$letters[$i],$reprow);
$replacement .= $reprow;
}
/*normal*/
$current = "";
if($currentbool===false)
$current = 'current';
$hasresult = "";
if($hasresultbool===false)
{
$hasresult ='hasagents';
}
$reprow = $row;
$reprow = str_replace("{current}",$current,$reprow);
$reprow = str_replace("{hasresult}",$hasresult,$reprow);
$reprow = str_replace("{letter}","View all",$reprow);
$reprow = str_replace("{url}",$normalurl,$reprow);
$replacement .=$reprow;
return $replacement;
}
function PreparePaginationNumber($row,$cnt_results,$cur_page,$max_visible,$max_on_page,$url,$url_tag=false)
{
$replacement = "";
$count_pages = ceil($cnt_results/$max_on_page);
$start_page = 1;
$end_page = $count_pages;
if($count_pages>$max_visible)
{
if(($max_visible%2)==0)
{
$left = $max_visible/2;
$right  = $left-1;
}
else
{
$left = ($max_visible-1)/2;
$right = $left;
}
$start_page = $cur_page-$left;
if($start_page<1)
$start_page=1;
$end_page = $start_page+$right+$left;
if($end_page>$count_pages)
{
$end_page=$count_pages;
$start_page=$end_page-$left-$right;
}
if($start_page<1)
$start_page=1;
}
for($i=$start_page;$i<=$end_page;$i++)
{
$current = "";
if($i==$cur_page)
{
$current = 'current';
$currentbool =true;
}
$reprow = $row;
$reprow = str_replace("{current}",$current,$reprow);
$reprow = str_replace("{hasresult}",$hasresult,$reprow);
$reprow = str_replace("{number}",$i,$reprow);
if($url_tag!==false)
$reprow = str_replace("{url}",str_replace($url_tag,$i,$url),$reprow);
else
$reprow = str_replace("{url}",$url.$i,$reprow);
$replacement .= $reprow;
}
return $replacement;
}
function MultiDeleteConfirm($question,$send_form,$button_id,$dialog_id='confirm_delete_dialog')
{
global $jqueryscript;
$content .= "<div id='".$dialog_id."'>".$question."</div>";
$content .= $jqueryscript->PrintScript('
jQuery("#'.$dialog_id.'").dialog({
autoOpen: false,
hide:"explode",
buttons: {
"Yes": function() {
jQuery( this ).dialog( "close" );
jQuery("#'.$send_form.'").submit();
},
Cancel: function() {
jQuery( this ).dialog( "close" );
}
}
});
jQuery("#'.$button_id.'").click(function()
{
jQuery("#'.$dialog_id.'").dialog("open");
});
');
return $content;
}
} // END class PresentationClass
?>