<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class Bridge
{
/************************************************************\
*
\************************************************************/
function GeneratePassword($password)
{
global $config;
$bpath = preg_replace("#wpradmin/?#","",$config['basepath']);
require_once($bpath.'wp-includes/class-phpass.php');
$wp_hasher = new PasswordHash(8, TRUE);
return $wp_hasher->HashPassword($password);
}
/************************************************************\
*
\************************************************************/
function ChangePass($login,$password)
{
global $config,$db_data,$dbClass;
$bpath = preg_replace("#wpradmin/?#","",$config['basepath']);
$wpconfig_content = file_get_contents($bpath."wp-config.php");
$req = '#\$table_prefix\s*=\s*[\'|"](.*?)[\'|"]#';
if(preg_match($req,$wpconfig_content,$match))
{
$wp_prefix = $match[1];
$wp_user = $wp_prefix."users";
if($dbClass->TableExists($wp_user))
{
$sql = "SELECT * FROM `".$wp_user."` WHERE user_login='".$login."' LIMIT 1";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordCount()>0)
{
$sql = "UPDATE `".$wp_user."` SET user_pass='".$password."' WHERE ID='".$reCheck->fields['ID']."'";
return $dbClass->query($sql);
}
}
}
return false;
}
} // END class Bridge
?>