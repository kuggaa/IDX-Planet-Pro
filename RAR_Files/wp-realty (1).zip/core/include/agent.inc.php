<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
Class AgentClass {
var $users_base;
var $wprcontact_agents_base;
var $usermeta_base;
/*     * **********************************************************\
*
\*********************************************************** */
function __construct() {
global $config;
$this->users_base = "wp_users";
$this->usermeta_base = "wp_usermeta";
$this->wprcontact_agents_base = $config['table_prefix'] . "wprcontactagents";
}
// Modified to hide a few fields.
var $block_fields_name = array(
"agent_id",
"user_id",
"office_id",
/*
"agent_code",
"office_code",
"agent_comments",
"agent_creation_date",
"agent_modified_date",
*/
);
// Changed 06/31/2012
var $standard_fields_name = array(
"agent_code" => array('field_required' => 0, 'field_caption' => 'Agent MLS ID'),
"office_code" => array('field_required' => 0, 'field_caption' => 'Office MLS ID'),
"agent_title" => array('field_required' => 1, 'field_caption' => 'Agent Title'),
"agent_emailaddress" => array('field_required' => 0, 'field_caption' => 'eMail Address'),
"agent_first_name" => array('field_required' => 1, 'field_caption' => 'First Name'),
"agent_last_name" => array('field_required' => 1, 'field_caption' => 'Last Name'),
"agent_license" => array('field_required' => 0, 'field_caption' => 'Agent License #'),
"agent_comments" => array('field_required' => 0, 'field_caption' => 'Comments'),
"agent_details" => array('field_required' => 0, 'field_caption' => 'Details'),
"agent_creation_date" => array('field_required' => 0, 'field_caption' => 'Creation Date'),
"agent_modified_date" => array('field_required' => 0, 'field_caption' => 'Modified Date'),
"agent_hit_count" => array('field_required' => 0, 'field_caption' => 'Hit Count'),
"agent_url" => array('field_required' => 0, 'field_caption' => 'Agent URL'),
"agent_featured" => array('field_required' => 0, 'field_caption' => 'Featured'),
"agent_active" => array('field_required' => 0, 'field_caption' => 'Active'),
"agent_limits" => array('field_required' => 0, 'field_caption' => 'Listings Limit'),
"agent_cellphone" => array('field_required' => 0, 'field_caption' => 'Mobile Phone')
);
var $tab_select_type = array(
"text" => "Text",
"radio" => "Radio",
"checkbox" => "Checkbox",
"select" => "Select",
"textarea" => "TextArea"
);
var $tab_select_datatype = array(
"int(11)" => 'Integer',
"float" => 'Float',
"char(5)" => 'Char(5)',
"char(20)" => 'Char(20)',
"char(50)" => 'Char(50)',
"char(100)" => 'Char(100)',
"char(200)" => 'Char(200)',
"text" => 'Text',
"longtext" => 'Long Text'
);
/*     * **********************************************************\
* This includes pagination, next prev and numeric sort.
\*********************************************************** */
function GetAgentRoster($param, $request) {
global $config, $dbClass, $UrlClass, $presentationClass;
$template = registry::register('ParseClass');
$agentinfo = false;
if (is_numeric($param['agent_id'])) {
if ($agentinfo = $this->GetAgentInfo($param['agent_id'])) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "agentdetails.php");
/*                 * **********************************************************\
* Agent Listing
\*********************************************************** */
$listing_row = $template->GetTemplateBlock('agentlisting', $content);
$listing_row = $listing_row['content'];
$replacement = "";
$cur_page = 1;
if (is_numeric($_GET['cur_page']))
$cur_page = $_GET['cur_page'];
$all_listing = $this->GetCntAgentListing($agentinfo['agent_id']);
if ($all_listing > 0) {
$max_visible = 10;
$max_on_page = 1;
$last_page = ceil($all_listing / $max_on_page);
$limit_s = ($cur_page - 1) * $max_on_page;
if ($agent_listing = $this->GetAgentListing($agentinfo['agent_id'], $limit_s, $max_on_page)) {
for ($i = 0; $i < count($agent_listing); $i++) {
$row = $listing_row;
$row = $template->MainParse($row, $agent_listing[$i]['listingsdb_id']);
$replacement .= $row;
}
}
/*                     * **********************************************************\
* Number Pagination
\*********************************************************** */
$number_pagination = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "pagination.php");
$number_row = $template->GetTemplateBlock('numberpagination', $number_pagination);
$standardurl = "index.php?page=agentroster&agent_id=" . $agentinfo['agent_id'] . "&cur_page=";
//prevpage
if ($cur_page > 1)
$number_pagination = str_replace("{prevpage}", $standardurl . ($cur_page - 1), $number_pagination);
else
$number_pagination = str_replace("{prevpage}", $standardurl . $cur_page, $number_pagination);
//prev10page
if ($cur_page - 10 > 1)
$number_pagination = str_replace("{prev10page}", $standardurl . ($cur_page - 10), $number_pagination);
else
$number_pagination = str_replace("{prev10page}", $standardurl . $cur_page, $number_pagination);
//nextpage
if ($cur_page < $last_page)
$number_pagination = str_replace("{nextpage}", $standardurl . ($cur_page + 1), $number_pagination);
else
$number_pagination = str_replace("{nextpage}", $standardurl . $last_page, $number_pagination);
//next10page
if ($cur_page + 10 < $last_page)
$number_pagination = str_replace("{next10page}", $standardurl . ($cur_page + 10), $number_pagination);
else
$number_pagination = str_replace("{next10page}", $standardurl . $last_page, $number_pagination);
$number_pagination = str_replace("{firstpage}", $standardurl . "1", $number_pagination);
$number_pagination = str_replace("{lastpage}", $standardurl . $last_page, $number_pagination);
$row_pagination = $presentationClass->PreparePaginationNumber($number_row['content'], $all_listing, $cur_page, $max_visible, $max_on_page, $standardurl);
$number_pagination = $template->ReplaceTemplateBlock('numberpagination', $row_pagination, $number_pagination);
//$pagination_content = $pagination_content['content'];
} else
$number_pagination = "";
$content = str_replace("{agentlisting_number_pagination}", $number_pagination, $content);
$content = $template->ReplaceTemplateBlock('agentlisting', $replacement, $content);
$content = $template->MainParse($content, $agentinfo['agent_id']);
}
}
if ($agentinfo === false) {
$content = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "agentroster.php");
// Get the settings
preg_match('/\\{agent_settings ([^}]*)?}?/', $content, $matches);
// Remove the tag
$content = str_replace($matches[0], '', $content);
$tag_params_raw = explode(' ', $matches[1]);
$tag_params = array();
foreach ($tag_params_raw as $value) {
$param_parts = explode('=', $value);
$tag_params[$param_parts[0]] = $param_parts[1];
}
$letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$current_letter = false;
if (strpos($letters, $_GET['letter']) !== false)
$current_letter = $_GET['letter'];
$cur_page = 1;
if (is_numeric($_GET['cur_page']))
$cur_page = $_GET['cur_page'];
$all_agents_serious = $this->GetCntAgents();
$all_agents = $this->GetCntAgents($current_letter);
$max_visible = 10;
$max_on_page = isset($tag_params['perpage']) ? $tag_params['perpage'] : 5;
$last_page = ceil($all_agents / $max_on_page);
$limit_s = ($cur_page - 1) * $max_on_page;
//Set to false if you don't want to show initial results on the main roster page//
// Switch "$rand_results" for random loading of agents versus a-z.//
//$rand_results = "Order By RAND()";
$rand_results = " Order by a.agent_last_name,a.agent_first_name ";
$show_results_on_roster_load = true;
$max_results_on_roster_load = isset($tag_params['perpage']) ? $tag_params['perpage'] : 5;
$rows = "";
if ($show_results_on_roster_load == false && !$current_letter && $cur_page == 1 && !is_numeric($_GET['cur_page']) && !is_numeric($_GET['view_all'])) {
$max_on_page = 0;
}
if ($show_results_on_roster_load && !$current_letter && $cur_page == 1 && !is_numeric($_GET['cur_page']) && !is_numeric($_GET['view_all']))
$max_on_page = $max_results_on_roster_load;
if (is_numeric($_GET['view_all'])) {
$rand_results = " Order by a.agent_last_name,a.agent_first_name ";
$max_on_page = 1000;
$max_visible = 1000;
}
$sort = isset($tag_params['sort']) ? $tag_params['sort'] : false;
$dir = isset($tag_params['orderdir']) ? $tag_params['orderdir'] : 'ASC';
$orderby = isset($tag_params['orderby']) ? $tag_params['orderby'] : 'a.agent_last_name,a.agent_first_name';
if ($agents = $this->GetAgents($current_letter, $limit_s, $max_on_page, $rand_results, $sort)) {
require_once($config['wpradmin_basepath'] . "include/controlpanel.inc.php");
$controlClass = registry::register('controlpanelClass');
$spacechar_array = $controlClass->GetControlPanelFields();
$spacechar = $spacechar_array['controlpanel_space_character'];
for ($i = 0; $i < count($agents); $i++) {
$template_row = $template->GetTemplateBlock('agents', $content);
$tmp = $template_row['content'];
$tmp = $template->MainParse($tmp, $agents[$i]['agent_id']);
if ($i % 2 == 0)
$odd = 0;
else
$odd = 1;
$tmp = $template->ReplaceTag("{row_num_even_odd}", $odd, $tmp);
//$tmp = preg_replace($reg_agent_name,$agentname,$tmp);
$rows .= $tmp;
}
}
$content = $template->ReplaceTemplateBlock('agents', $rows, $content);
/*             * **********************************************************\
* Letter Pagination
\*********************************************************** */
$content_pagination = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "pagination_new.php");
$letter_row = $template->GetTemplateBlock('letterpagination', $content_pagination);
$letter_tab = $this->GetAgentByLetter('agent_last_name');
$burl = "index.php?page=agentroster&letter=";
$lInfo = FindPage('wp-realty agentroster');
$burl = '/'.$lInfo['post_name'].'/letter-';
$nurl = "index.php?page=agentroster&view_all=1";
$row_pagination = $presentationClass->PreparePaginationLetter($letter_tab, $letter_row['content'], $current_letter, $burl, $nurl);
$content_pagination = $template->ReplaceTemplateBlock('letterpagination', $row_pagination, $content_pagination);
/*             * **********************************************************\
* Number Pagination
\*********************************************************** */
if ($all_agents > 0) {
$number_pagination = $template->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "pagination.php");
$number_row = $template->GetTemplateBlock('numberpagination', $number_pagination);
$lInfo = FindPage('wp-realty agentroster');
if ($current_letter !== false)
$burl = '/'.$lInfo['post_name'].'/letter-' . $current_letter . "?cur_page=";
else
$burl = '/'.$lInfo['post_name']."?cur_page=";
//prevpage
if ($cur_page > 1)
$number_pagination = str_replace("{prevpage}", "index.php?page=agentroster&cur_page=" . ($cur_page - 1), $number_pagination);
else
$number_pagination = str_replace("{prevpage}", "index.php?page=agentroster&cur_page=" . $cur_page, $number_pagination);
//prev10page
if ($cur_page - 10 > 1)
$number_pagination = str_replace("{prev10page}", "index.php?page=agentroster&cur_page=" . ($cur_page - 10), $number_pagination);
else
$number_pagination = str_replace("{prev10page}", "index.php?page=agentroster&cur_page=" . $cur_page, $number_pagination);
//nextpage
if ($cur_page < $last_page)
$number_pagination = str_replace("{nextpage}", "index.php?page=agentroster&cur_page=" . ($cur_page + 1), $number_pagination);
else
$number_pagination = str_replace("{nextpage}", "index.php?page=agentroster&cur_page=" . $last_page, $number_pagination);
//next10page
if ($cur_page + 10 < $last_page)
$number_pagination = str_replace("{next10page}", "index.php?page=agentroster&cur_page=" . ($cur_page + 10), $number_pagination);
else
$number_pagination = str_replace("{next10page}", "index.php?page=agentroster&cur_page=" . $last_page, $number_pagination);
$number_pagination = str_replace("{firstpage}", "index.php?page=agentroster&cur_page=1", $number_pagination);
$number_pagination = str_replace("{lastpage}", "index.php?page=agentroster&cur_page=" . $last_page, $number_pagination);
$row_pagination = $presentationClass->PreparePaginationNumber($number_row['content'], $all_agents, $cur_page, $max_visible, $max_on_page, $burl);
} else
$row_pagination = "";
$number_pagination = $template->ReplaceTemplateBlock('numberpagination', $row_pagination, $number_pagination);
$content = str_replace('{active_agent_rows}', $all_agents, $content);
$content = str_replace('{agent_letter_pagination}', $content_pagination, $content);
$content = str_replace('{agent_number_pagination}', $number_pagination, $content);
}
return $content;
}
/*     * **********************************************************\
*
\*********************************************************** */
function GetCntAgentListing($agent_id) {
global $dbClass, $config;
$sql = "SELECT count(*) as count FROM `" . $config['table_prefix'] . "listingsdb` WHERE agent_id='" . $agent_id . "'";
$reCnt = $dbClass->query($sql);
if ($reCnt->RecordCount() > 0) {
return $reCnt->fields['count'];
} else
return 0;
}
/*     * **********************************************************\
*
\*********************************************************** */
function GetAgentListing($agent_id, $limit_s = false, $limit = false) {
global $dbClass, $config;
if ($limit_s !== false AND $limit !== false)
$sql = "SELECT * FROM `" . $config['table_prefix'] . "listingsdb` WHERE agent_id='" . $agent_id . "' LIMIT " . $limit_s . "," . $limit;
else
$sql = "SELECT * FROM `" . $config['table_prefix'] . "listingsdb` WHERE agent_id='" . $agent_id . "'";
$reC = $dbClass->query($sql);
if ($reC->RecordCOunt() > 0) {
$ret = array();
$cnt = 0;
while (!$reC->EOF) {
$ret[$cnt] = $reC->fields;
$reC->MoveNext();
$cnt++;
}
return $ret;
} else
return false;
}
/*     * **********************************************************\
*
\*********************************************************** */
function GetCntAgents($letter = false) {
global $dbClass, $config;
if ($letter !== false)
$sql = "SELECT count(*) as count FROM `" . $config['table_prefix'] . "agents`  WHERE `agent_last_name` LIKE '" . $letter . "%'";
else
$sql = "SELECT count(*) as count FROM `" . $config['table_prefix'] . "agents`";
$reCnt = $dbClass->query($sql);
if ($reCnt->RecordCount() > 0) {
return $reCnt->fields['count'];
} else
return 0;
}
/*     * **********************************************************\
* Number Pagination
\*********************************************************** */
function GetAgentByLetter($field) {
global $config, $dbClass;
$letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$ret_array = array();
for ($i = 0; $i < strlen($letters); $i++) {
$sql = "SELECT count(*) as count FROM `" . $config['table_prefix'] . "agents` WHERE `" . $field . "` LIKE '" . $letters[$i] . "%'";
$reCnt = $dbClass->query($sql);
if ($reCnt->RecordCount() > 0) {
$ret_array[$letters[$i]] = $reCnt->fields['count'];
} else
$ret_array[$letters[$i]] = 0;
}
return $ret_array;
}
function GetAgents($letter = false, $limit_s = false, $limit = false, $rand_results = false, $sort = false, $dir = false, $orderby = false) {
global $dbClass, $config;
if ($letter !== false)
$sql = "SELECT a.*,u.user_username,u.user_password,u.user_level FROM `" . $config['table_prefix'] . "agents` a LEFT JOIN `" . $config['table_prefix'] . "users` u ON a.user_id = u.user_id WHERE a.agent_last_name LIKE '" . $letter . "%'";
else {
$sql = "SELECT a.*,u.user_username,u.user_password,u.user_level FROM `" . $config['table_prefix'] . "agents` a LEFT JOIN `" . $config['table_prefix'] . "users` u ON a.user_id = u.user_id";
if ($sort) {
//echo 'sort -> '.$sort;
switch ($sort) {
case 'rand':
$sql .= ' ORDER BY RAND()';
break;
case 'alpha':
$sql .= ' ORDER BY a.agent_last_name,a.agent_first_name';
break;
default:
$sql .= ' ORDER BY RAND()';
}
} else {
if ($orderby) {
$sql .= ' ORDER BY ' . $orderby . ' ' . $dir;
}
else{
$sql .= ' ORDER BY RAND()';
}
}
}
if ($letter) {
$sql .= " Order by a.agent_last_name,a.agent_first_name";
}
if ($limit_s !== false AND $limit !== false) {
$sql .= " LIMIT " . $limit_s . "," . $limit;
}
//echo $sql;
$reAgents = $dbClass->Query($sql);
if ($reAgents->RecordCount() > 0) {
$ret_tab = array();
$cnt = 0;
while (!$reAgents->EOF) {
$ret_tab[$cnt] = $reAgents->fields;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "agentimages` WHERE agent_id='" . $reAgents->fields['agent_id'] . "'";
$reImages = $dbClass->query($sql);
if ($reImages->RecordCount() > 0) {
$cnt_img = 1;
while (!$reImages->EOF) {
$ret_tab[$cnt]['images'][$reImages->fields['image_rank']]['thumb'] = $config['adm_baseurl'] . $config["img_dir"] . "/agent_images/" . $reImages->fields['image_thumbname'];
$ret_tab[$cnt]['images'][$reImages->fields['image_rank']]['photo'] = $config['adm_baseurl'] . $config["img_dir"] . "/agent_images/" . $reImages->fields['image_filename'];
$reImages->MoveNext();
$cnt_img++;
}
}
$reAgents->MoveNext();
$cnt++;
}
return $ret_tab;
}
return false;
}
function getIdFromAgentCode($agent_code) {
global $dbClass, $config;
$sql = "SELECT agent_id FROM `" . $config['table_prefix'] . "agents` WHERE agent_code='" . $agent_code . "' ";
$reInfo = $dbClass->query($sql);
if ($reInfo->RecordCount() > 0) {
return $reInfo->fields['agent_id'];
} else {
return false;
}
}
function GetAgentInfo($agent_id) {
global $dbClass, $config;
//$sql = "SELECT a.*,u.user_id,u.user_username,u.user_password,u.user_level FROM `".$config['table_prefix']."agents` a, `".$config['table_prefix']."users` u WHERE a.agent_id='".$agent_id."' AND u.user_id=a.user_id";
$sql = "SELECT a.* FROM `" . $config['table_prefix'] . "agents` a WHERE a.agent_id='" . $agent_id . "' ";
$reInfo = $dbClass->query($sql);
if ($reInfo->RecordCount() > 0) {
$ret_tab = $reInfo->fields;
foreach ($ret_tab as $k => $v) {
$nname = str_replace("agent_", "", $k);
$ret_tab[$nname] = $v;
}
$sql = "SELECT * FROM `" . $config['table_prefix'] . "agentimages` WHERE agent_id='" . $agent_id . "'";
$reImages = $dbClass->query($sql);
if ($reImages->RecordCount() > 0) {
while (!$reImages->EOF) {
$ret_tab['images'][$reImages->fields['image_rank']]['thumb'] = $config['adm_baseurl'] . $config["img_dir"] . "/agent_images/" . $reImages->fields['image_thumbname'];
$ret_tab['images'][$reImages->fields['image_rank']]['photo'] = $config['adm_baseurl'] . $config["img_dir"] . "/agent_images/" . $reImages->fields['image_filename'];
$reImages->MoveNext();
}
}
$ret_tab['name'] = $ret_tab['first_name'] . " " . $ret_tab['last_name'];
$ret_tab['permalink'] = strtolower(str_replace(' ', '-', $ret_tab['name']));
return $ret_tab;
}
return false;
}
function ReplaceAgentFieldTags($agent_id, $param) {
global $config, $dbClass;
$return = false;
if (isset($param['fieldvalue'])) {
$field = $param['fieldvalue'];
if ($temp_fields = $this->GetAgentInfo($agent_id)) {
foreach ($temp_fields as $key => $value) {
$re[strtolower($key)] = $value;
}
if (isset($re[$field])) {
$return = $re[$field];
}
}
} elseif (isset($param['field'])) {
$field = $param['field'];
if ($temp_fields = $this->GetAgentFields()) {
foreach ($temp_fields as $key => $value) {
$re[strtolower($key)] = $value;
}
if (isset($re[$field])) {
$return = $re[$field];
if ($return == "") {
$return = $field;
}
}
}
}
return $return;
}
function GetAgentFields() {
global $config, $dbClass;
$sql = "SELECT * FROM `" . $config['table_prefix'] . "agentfields`";
$reFields = $dbClass->query($sql);
if ($reFields->RecordCount() > 0) {
$ret_array = array();
while (!$reFields->EOF) {
$nname = $reFields->fields['agentfields_field_name'];
$nname = str_replace("agent_", "", $nname);
$ret_array[$nname] = $reFields->fields['agentfields_field_caption'];
$reFields->MoveNext();
}
return $ret_array;
}
return false;
}
/* BACKEND */
function CheckRequiredField($request, $edit_id = false) {
global $config, $dbClass, $presentationClass;
if ($request['user_username'] == '' AND $edit_id === false)
return "You must enter a username";
if ($edit_id === false) {
$sql = "SELECT * FROM `" . $config['table_prefix'] . "users` WHERE user_username='" . $request['user_username'] . "' LIMIT 1";
$reCheck = $dbClass->query($sql);
if ($reCheck->RecordCount() > 0)
return "Login already exists";
}else {
/* $sql = "SELECT * FROM `" . $config['table_prefix'] . "users`
WHERE user_username='" . $request['user_username'] . "' AND user_id!='" . $request['user_id'] . "'
LIMIT 1";
$reCheck = $dbClass->query($sql);
if ($reCheck->RecordCount() > 0)
return "Login already exists"; */
}
if ($edit_id === false OR $request['user_password'] != '') {
if ($request['user_password'] != $request['user_password_reply'])
return "You need to type two identical passwords";
if (strlen($request['user_password']) < $config['min_length_pass'])
return "Password is too short";
}
return false;
}
function AddAgentBackEnd($post_vars, $get_vars) {
global $dbClass, $presentationClass, $UrlClass, $jqueryscript, $array_numbers, $config, $log_user_id;
$content = "";
$error_info = "";
require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
$usersClass = registry::register('usersClass');
$actual_user_info = $usersClass->GetUserInfo($log_user_id);
if ($actual_user_info['user_level'] == 0)
return false;
if (isset($post_vars['addagent_submit'])) {
//$post_vars = $dbClass->DataFiltersArray($_POST);
require_once($config['wpradmin_basepath'] . 'include/fields.inc.php');
$fieldsClass = registry::register('fieldsClass');
$errors2 = $this->CheckRequiredField($post_vars);
$errors = $fieldsClass->CheckRequiredField($post_vars, "agentfields", "agentfields");
if ($errors === false AND $errors2 === false) {
require_once($config['wpradmin_basepath'] . "include/bridge.inc.php");
$bridgeClass = registry::register('Bridge');
$post_vars['user_password'] = $bridgeClass->GeneratePassword($post_vars['user_password']);
if ($last_id = $this->InsertNewAgent($post_vars)) {
$url = $UrlClass->AddUrlValues(array('page' => 'agents', 'cpage' => 'editagents', 'action' => 'edit_agent', 'edit_id' => $last_id));
//header("location: $url");
$content = $presentationClass->OperationSuccessfull("Agent has been added");
} else
$content .= $presentationClass->OperationFailed("Agent add failed");
}
else {
if ($errors2 !== false) {
$content .= $presentationClass->OperationFailed($errors2);
}
if ($errors !== false) {
$error_info = "Field required: ";
for ($i = 0; $i < count($errors); $i++) {
$error_info .= str_replace("agents_", "", $errors[$i]) . ", ";
}
$error_info = substr($error_info, 0, -2);
$content .= $presentationClass->OperationFailed($error_info);
}
}
$content .= $this->ShowAddEditAgentTable($post_vars, $actual_user_info, 'edit');
return $content;
}
$request = $post_vars;
$content .= $this->ShowAddEditAgentTable($post_vars, $actual_user_info);
return $content;
}
function InsertNewAgent($request_vars) {
global $dbClass, $config, $log_user_id;
$sql = "SELECT * FROM " . $config['table_prefix'] . "agentfields";
$reFields = $dbClass->Query($sql);
$sql = "INSERT INTO " . $config['table_prefix'] . "agents SET ";
while (!$reFields->EOF) {
if ($reFields->fields['agentfields_field_type'] == "checkbox") {
$value = implode("|", $request_vars[$reFields->fields['agentfields_field_name']]);
} else
$value = $request_vars[$reFields->fields['agentfields_field_name']];
if(!isset($request_vars[$reFields->fields['agentfields_field_name']]) || $request_vars[$reFields->fields['agentfields_field_name']] == ''){
    
}
else{
    $sql .= $reFields->fields['agentfields_field_name'] . "='" . $value . "',";
}

$reFields->MoveNext();
}

$sql = substr($sql, 0, -1);
//$sql .= ",listingsdb_creation_date='".time()."'";
if ($dbClass->Query($sql) !== false) {
$lastID = $dbClass->LastID();
$sql = "INSERT INTO `" . $config['table_prefix'] . "users` SET
user_username='" . $request_vars['user_username'] . "',
user_password='" . $request_vars['user_password'] . "',
user_level='" . $request_vars['user_level'] . "'";
$dbClass->Query($sql);
$user_id = $dbClass->LastID();
$sql = "UPDATE `" . $config['table_prefix'] . "agents` SET user_id='" . $user_id . "' WHERE agent_id='" . $lastID . "'";
$dbClass->Query($sql);
return $lastID;
}
return false;
}
/*     * **********************************************************\
*
\*********************************************************** */
function DeleteAgentImage($del_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "agentimages WHERE  agentimage_id='" . $del_id . "'";
$reImages = $dbClass->Query($sql);
if ($reImages->recordCount() > 0) {
if ($reImages->fields['image_thumbname'] != "") {
@unlink($config['agent_images'] . $reImages->fields['image_thumbname']);
}
@unlink($config['agent_images'] . $reImages->fields['image_filename']);
$sql = "DELETE FROM " . $config['table_prefix'] . "agentimages WHERE agentimage_id='$del_id'";
return $dbClass->Query($sql);
} else
return false;
}
/*     * **********************************************************\
*
\*********************************************************** */
function GetAgentImage($edit_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "agentimages WHERE  agentimage_id='" . $edit_id . "'";
$reImages = $dbClass->Query($sql);
if ($reImages->recordCount() > 1) {
return $reImages->fields;
} else
return false;
}
/*     * **********************************************************\
*
\*********************************************************** */
function SaveAgentFieldOrder($column, $fields) {
global $config, $dbClass;
if (count($fields) > 0) {
for ($i = 0; $i < count($fields); $i++) {
$sql = "UPDATE `" . $config['table_prefix'] . "agentfields` SET agentfields_rank_col='" . $column . "', agentfields_rank='" . $i . "' WHERE agentfields_field_name='" . $fields[$i] . "'";
$dbClass->Query($sql);
}
return true;
}
}
/*     * **********************************************************\
*
\*********************************************************** */
function ShowAddEditAgentTable($request, $user_info = false, $mode = '', $edit_id = '') {
global $dbClass, $config, $presentationClass, $jqueryscript, $UrlClass, $log_user_id, $lang;
require_once($config['wpradmin_basepath'] . "include/images.inc.php");
$imagesClass = registry::register('ImagesClass');
$content = "";
$actual_page_id = "addagent";
$selected = false;
if ($mode == 'edit') {
$actual_page_id = "editagents";
if ($request['content_action'] == 'upload_images') {
require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
$imagesClass = registry::register('ImagesClass');
if ($files = $imagesClass->UploadImages(2)) {
if ($imagesClass->UploadAgentImages($edit_id, $files)) {
$content .= $presentationClass->OperationSuccessfull('Upload Images Success');
} else
$content .= $presentationClass->OperationFailed('Upload Images Failed');
} else
$content .= $presentationClass->OperationFailed('Upload Images Failed');
$selected = 1;
}
if ($request['content_action'] == 'edit_images') {
for ($i = 0; $i < count($request['image_id']); $i++) {
$sql = "UPDATE " . $config['table_prefix'] . "agentimages SET
image_caption = '" . $request['caption'][$i] . "',
image_rank = '" . $i . "'
WHERE agentimage_id='" . $request['image_id'][$i] . "'";
$dbClass->Query($sql);
}
$content .= $presentationClass->OperationSuccessfull($lang['images_update']);
$selected = 1;
}
if ($_GET['content_action'] == 'delete_image') {
if (is_numeric($_GET['del_id']) AND $this->GetAgentImage($_GET['del_id'])) {
if ($this->DeleteAgentImage($_GET['del_id'])) {
$content .= $presentationClass->OperationSuccessfull('Delete Image Success');
} else
$content .= $presentationClass->OperationFailed('Delete Image Failed');
}
$selected = 1;
}
}
require_once($config['wpradmin_basepath'] . 'include/forms.inc.php');
$formsClass = registry::register('FormsClass');
$sql = "SELECT * FROM " . $config['table_prefix'] . "agentfields ORDER by agentfields_rank_col,agentfields_rank";
$reFields = $dbClass->Query($sql);
$agent_tabs = "";
if ($reFields->recordCount() > 0) {
$agent_tab = array();
$right_col = "username: ";
if (is_numeric($edit_id)) {
$left_col = $formsClass->create_text('user_username', $request['user_username'], array('disabled' => 'disabled'));
} else
$left_col = $formsClass->create_text('user_username', $request['user_username']);
$agent_tab[0][] = array("<strong>" . $right_col . "</strong>", $left_col);
$user_type_select = array(1 => 'Agent', 2 => 'Super Agent', 3 => 'Admin');
$right_col = "user type: ";
if ($request['user_level'] == 4) {
$left_col = "<i>Administrator</i>";
} else {
if (($request['user_level'] == 3 AND is_numeric($edit_id)) OR $user_info['user_level'] < 3)
$left_col = $formsClass->create_select('user_level', $request['user_level'], array('disabled' => 'disabled'), $user_type_select);
else
$left_col = $formsClass->create_select('user_level', $request['user_level'], '', $user_type_select);
}
$agent_tab[0][] = array("<strong>" . $right_col . "</strong>", $left_col);
$right_col = "password: ";
$left_col = $formsClass->create_password('user_password', '');
$agent_tab[0][] = array("<strong>" . $right_col . "</strong>", $left_col);
$right_col = "password (reply): ";
$left_col = $formsClass->create_password('user_password_reply', '');
$agent_tab[0][] = array("<strong>" . $right_col . "</strong>", $left_col);
while (!$reFields->EOF) {
if ($dbClass->ColumnExists($config['table_prefix'] . "agents", $reFields->fields['agentfields_field_name']) !== false) {
if ($reFields->fields['agentfields_field_caption'] != "")
$right_col = $reFields->fields['agentfields_field_caption'];
else {
$right_col = str_replace("agent_", "", $reFields->fields['agentfields_field_name']);
$right_col = str_replace("_", " ", $right_col);
}
$elements = "";
if (strpos($reFields->fields['agentfields_field_elements'], "|") !== false) {
$elements_temp = explode("|", $reFields->fields['agentfields_field_elements']);
$elements = array();
for ($i = 0; $i < count($elements_temp); $i++) {
if ($reFields->fields['agentfields_field_type'] == 'checkbox')
$elements[$elements_temp[$i]] = $elements_temp[$i] . "<br/>";
else
$elements[$elements_temp[$i]] = $elements_temp[$i];
}
}
$params = false;
if ($reFields->fields['agentfields_field_type'] == 'text' OR $reFields->fields['agentfields_field_type'] == 'textarea') {
$params['class'] = "large";
}
if ($reFields->fields['agentfields_tip'] != "") {
$params['title'] = $reFields->fields['agentfields_tip'];
}
$left_col = $formsClass->GenerateField($reFields->fields['agentfields_field_type'], $reFields->fields['agentfields_field_name'], $request[$reFields->fields['agentfields_field_name']], $elements, $request, 'normal', $params);
$agent_tab[$reFields->fields['agentfields_rank_col']][] = array("<strong>" . $right_col . "</strong>", $left_col);
}
$reFields->MoveNext();
}
$agent_tabs .= $formsClass->startform();
$success_info = $presentationClass->OperationSuccessfull('The order of the fields has been saved');
$agent_tabs .= $presentationClass->BlockTableSortable($agent_tab[0], 2);
$agent_tabs .= $presentationClass->BlockTableSortable($agent_tab[1], 2);
$agent_tabs .= $jqueryscript->SaveOrder("sd_column", "save_order", $config['adm_baseurl'] . "ajax.php?f=ajax_fields_sort.php?type=agent", $success_info);
if ($mode == 'edit')
$agent_tabs .= $formsClass->create_submit($actual_page_id . '_submit', 'Edit', array('id' => $actual_page_id . '_submit'));
else
$agent_tabs .= $formsClass->create_submit('addagent_submit', 'Add Agent', array('id' => 'addagent_submit'));
$agent_tabs .= "<div style='clear:both'></div><div><button onclick='return false' id='save_order'>Save Field Order</button></div>";
$agent_tabs .= $formsClass->endform();
}
if ($mode == 'edit') {
$editagent_agent_tab_name = $actual_page_id . "_agent_tab";
$editagent_images_tab_name = $actual_page_id . "_images_tab";
$headers = array(
$editagent_agent_tab_name => "Agent Details",
$editagent_images_tab_name => "Images",
);
$images_tab = $imagesClass->GenerateUploadImagesFormNormal(5, $edit_id, 'upload_agentimage');
$images_tab .= $this->AgentImagesForm($edit_id, $actual_page_id);
$data[$editagent_agent_tab_name] = $agent_tabs;
$data[$editagent_images_tab_name] = $images_tab;
$jquery_tabs_id = "jqt_" . $actual_page_id;
$content .= $presentationClass->JqueryTabsWithDataNew($data, $headers, array('id' => $jquery_tabs_id, 'class' => 'box grid_16 round_all tabs'), $selected);
} else {
$content .= $agent_tabs; //$presentationClass->StandardTableWithData($agent_tab);
}
return $content;
}
/*     * **********************************************************\
*
\*********************************************************** */
function AgentImagesForm($agent_id, $actual_page_id) {
global $dbClass, $config, $presentationClass, $UrlClass, $formsClass, $jqueryscript;
$sql = "SELECT * FROM " . $config['table_prefix'] . "agentimages WHERE agent_id='$agent_id' ORDER BY image_rank";
$reImages = $dbClass->Query($sql);
$action_url = $UrlClass->AddUrlValues(array('page' => 'agents', 'cpage' => 'editagents', $actual_page_id . 'action' => 'edit_agent', 'edit_id' => $agent_id));
//$content = $formsClass->startform($action_url);
if ($reImages->recordCount() > 0) {
$content = $formsClass->startform();
$view_tab = array();
$tabRANK = array();
for ($i = 0; $i < $reImages->recordCount(); $i++) {
$tabRANK[$i] = $i;
}
while (!$reImages->EOF) {
$delurl = $UrlClass->ReplaceUrlValues(array('content_action' => 'delete_image', 'del_id' => $reImages->fields['agentimage_id']));
$tables = array();
$tables[] = $formsClass->create_hidden('image_id[]', $reImages->fields['agentimage_id']) .
"<strong>" . $reImages->fields['image_filename'] . "</strong><br/>";
$tables[] = "<img src='" . $config['baseurl'] . $config['img_dir'] . "/agent_images/" . $reImages->fields['image_thumbname'] . "'>";
//$tables[] = $formsClass->create_select('rank[]',$reImages->fields['listingsimages_rank'],'',$tabRANK);
$tables[] = $formsClass->create_text('caption[]', $reImages->fields['image_caption']);
$tables[] = "<a href='$delurl' class='delbutton' onclick='return false;' name='Delete image?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
$right .= $presentationClass->BlockTable($tables);
$view_tab[] = $tables;
$reImages->MoveNext();
}
$headers = array('Name', 'Thumb', 'Caption', '');
$content .= $presentationClass->StandardTableWithDataNew($view_tab, $headers, false, array('id' => 'editimages_datatable', 'style' => 'wpr_form'), true);
$content .= $formsClass->create_hidden('content_action', 'edit_images');
$content .= $formsClass->create_submit('editsubmit', 'Edit');
$content .= $formsClass->endform();
}
return $content;
}
/*     * **********************************************************\
*
\*********************************************************** */
function UpdateAgent($request_vars, $agent_id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "agentfields";
$reFields = $dbClass->Query($sql);
$sql = "UPDATE " . $config['table_prefix'] . "agents SET ";
while (!$reFields->EOF) {
if ($dbClass->ColumnExists($config['table_prefix'] . "agents", $reFields->fields['agentfields_field_name'])) {
if ($reFields->fields['agentfields_field_type'] == "checkbox" AND is_array($request_vars[$reFields->fields['agentfields_field_name']])) {
$value = implode("|", $request_vars[$reFields->fields['agentfields_field_name']]);
} else
$value = $request_vars[$reFields->fields['agentfields_field_name']];
if(!isset($request_vars[$reFields->fields['agentfields_field_name']]) || $request_vars[$reFields->fields['agentfields_field_name']] == ''){
    
}
else{
    $sql .= $reFields->fields['agentfields_field_name'] . "='" . $value . "',";
}

}
$reFields->MoveNext();
}
$sql = substr($sql, 0, -1);
//$sql .= ",class_id='".$request_vars['class_id']."',	listingsdb_last_modified='".time()."'";
$sql .= " WHERE agent_id='" . $agent_id . "'";
if ($dbClass->Query($sql) !== false) {
if ($request_vars['user_password'] != "" OR is_numeric($request_vars['user_level'])) {
$sql = "UPDATE `" . $config['table_prefix'] . "users` SET ";
if ($request_vars['user_password'] != "" AND is_numeric($request_vars['user_level']))
$sql .= "user_password='" . $request_vars['user_password'] . "',user_level='" . $request_vars['user_level'] . "'";
elseif ($request_vars['user_password'] != "")
$sql .= "user_password='" . $request_vars['user_password'] . "' ";
else
$sql .= "user_level='" . $request_vars['user_level'] . "'";
$sql .= " WHERE user_id='" . $request_vars['user_id'] . "'";
$dbClass->Query($sql);
}
return true;
}
return false;
}
/*     * **********************************************************\
*
\*********************************************************** */
function DeleteAgent($del_id, $actual_user_info) {
global $config, $dbClass, $user_level;
if ($info = $this->GetAgentInfo($del_id)) {
if ($info['user_level'] == 4)
return false;
if ($info['user_id'] != $actual_user_info['user_id'] AND $info['user_level'] == 3)
return false;
$this->DeleteAgentImages($del_id);
$sql = "DELETE FROM " . $config['table_prefix'] . "agents WHERE agent_id='$del_id'";
if ($dbClass->query($sql)) {
require_once($config['wpradmin_basepath'] . "include/users.inc.php");
$users = registry::register('usersClass');
$users->DeleteUser($info['user_id']);
return true;
}
}
return false;
}
function GetAgentImages($id) {
global $dbClass, $config;
$sql = "SELECT * FROM " . $config['table_prefix'] . "agentimages WHERE agent_id='$id' ORDER BY image_rank";
return $dbClass->GetResults($sql);
}
function DeleteAgentImages($id) {
global $config;
if ($imagesTab = $this->GetAgentImages($id)) {
for ($i = 0; $i < count($imagesTab); $i++) {
$this->DeleteAgentImage($imagesTab[$i]['image_id']);
}
}
}
function DeleteAgents($del_tab, $actual_user_info) {
$true = 0;
for ($i = 0; $i < count($del_tab); $i++) {
if ($this->DeleteAgent($del_tab[$i], $actual_user_info))
$true++;
}
if ($true == $i)
return true;
else
return false;
}
function EditAgentBackEnd($post_vars, $get_vars, $user_id = false, $test = false) {
global $dbClass, $config, $presentationClass, $UrlClass, $jqueryscript, $user_level, $log_user_id, $formsClass;
$errors = false;
$actual_page_id = "editagents";
require_once($config['wpradmin_basepath'] . 'include/users.inc.php');
$usersClass = registry::register('usersClass');
$actual_user_info = $usersClass->GetUserInfo($log_user_id);
if ($actual_user_info['user_level'] == 0)
return false;
require_once($config['wpradmin_basepath'] . 'include/fields.inc.php');
$fieldsClass = registry::register('fieldsClass');
if (isset($post_vars[$actual_page_id . '_submit'])) {
$post_vars = $dbClass->DataFiltersArray($post_vars);
if ($info = $this->GetAgentInfo($get_vars['edit_id'])) {
$post_vars['user_id'] = $info['user_id'];
} else
return false;
$errors2 = $this->CheckRequiredField($post_vars, $get_vars['edit_id']);
$errors = $fieldsClass->CheckRequiredField($post_vars, "agentfields", "agentfields");
if ($errors === false AND $errors2 === false) {
if ($post_vars['user_password'] != '') {
require_once($config['wpradmin_basepath'] . "include/bridge.inc.php");
$bridgeClass = registry::register('Bridge');
$post_vars['user_password'] = $bridgeClass->GeneratePassword($post_vars['user_password']);
}
if ($this->UpdateAgent($post_vars, $get_vars['edit_id'])) {
$content = $presentationClass->OperationSuccessfull("Agent edited");
} else
$content = $presentationClass->OperationFailed("Agent edit failed");
}
else {
if ($errors2 !== false) {
$content .= $presentationClass->OperationFailed($errors2);
}
if ($errors !== false) {
$error_info = "Field required: ";
for ($i = 0; $i < count($errors); $i++) {
$error_info .= $errors[$i] . ", ";
}
$error_info = substr($error_info, 0, -2);
$content .= $presentationClass->OperationFailed($error_info);
}
}
}
if (!isset($get_vars['action']) OR $get_vars['action'] == 'delete_agent') {
$content = $presentationClass->SecondHeader('All Agents');
//multi delete
if (isset($post_vars['delete_agents'])) {
if (count($post_vars['del_id'])) {
if ($this->DeleteAgents($post_vars['del_id'], $actual_user_info))
$content .= $presentationClass->OperationSuccessfull('Delete agents success');
else
$content .= $presentationClass->OperationSuccessfull('Delete agents failed');
}
}
if ($get_vars['action'] == 'delete_agent' AND is_numeric($get_vars['del_id'])) {
if ($this->DeleteAgent($get_vars['del_id'], $actual_user_info))
$content .= $presentationClass->OperationSuccessfull('Delete agent success');
else
$content .= $presentationClass->OperationSuccessfull('Delete agent failed');
}
if ($agents = $this->GetAgents()) {
$headers = array("ID", "Agent Name", array("name" => "", "align" => 'right'));
$tab = array();
for ($i = 0; $i < count($agents); $i++) {
$editurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=edit_agent&edit_id=" . $agents[$i]['agent_id'];
$deleteurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=delete_agent&del_id=" . $agents[$i]['agent_id'];
if ($agents[$i]['agent_first_name'] != "" AND $agents[$i]['agent_last_name'])
$agent_caption = $agents[$i]['agent_first_name'] . " " . $agents[$i]['agent_last_name'];
else
$agent_caption = $agents[$i]['user_username'];
$checkbox = "<input type='checkbox' value='" . $agents[$i]['agent_id'] . "' name='del_id[]'>";
if (($actual_user_info['user_level'] < 4 AND $agents[$i]['user_level'] < 4) OR ( $actual_user_info['user_level'] == 4)) {
$tab[] = array($checkbox . $agents[$i]['agent_id'], $agent_caption, "<a href='$editurl'>
<img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a> <a href='$deleteurl' class='delbutton' name='Delete this agent?' onclick='return false'>
<img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>");
} else {
$tab[] = array($checkbox . $agents[$i]['agent_id'], $agent_caption, "");
}
}
$content .= "<form method='post' id='delete_agents_form'>";
$content .= $formsClass->create_submit('', 'Delete checked agents', array('id' => 'delete_agents', 'onclick' => 'return false;', 'type' => ''));
$content .= $presentationClass->StandardTableWithDataNew($tab, $headers, false, array('id' => $actual_page_id . '_datatable'), false);
$content .= "<input type='hidden' name='delete_agents' value='1' /></form>";
$content .= $presentationClass->MultiDeleteConfirm("Delete checked agents?", "delete_agents_form", "delete_agents");
} else
$content .= "No agents";
}
else {
if ($get_vars['action'] == 'edit_agent' AND is_numeric($get_vars['edit_id'])) {
$content .= "<h3>Edit Agent</h3>";
$backurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id;
$content .= "<a href='$backurl'><button class='skin_colour round_all'><span>Back</span></button></a>";
$sql = "SELECT a.*,u.user_username,u.user_password,u.user_level FROM " . $config['table_prefix'] . "agents a
LEFT JOIN " . $config['table_prefix'] . "users u ON u.user_id = a.user_id
WHERE agent_id='" . $dbClass->DataFilters($get_vars['edit_id']) . "'";
$reAgents = $dbClass->Query($sql);
if ($reAgents->recordCount() > 0) {
if ($actual_user_info['user_level'] < 4 and $reAgents->fields['user_level'] == 4) {
header("Location: " . $backurl);
die();
}
if ($errors !== false) {
$request = $post_vars;
$content .= $this->ShowAddEditAgentTable($request, $actual_user_info, 'edit', $get_vars['edit_id']);
} else {
$request = $reAgents->fields;
foreach ($request as $key => $values) {
$post_vars[$key] = $values;
}
$content .= $this->ShowAddEditAgentTable($post_vars, $actual_user_info, 'edit', $get_vars['edit_id']);
}
} else {
header("Location: " . $backurl);
die();
}
}
}
$return = $content;
return $return;
}
/*     * **********************************************************\
* Agent Fields Back End
\*********************************************************** */
function EditAgentFieldsBackEnd($post_vars, $get_vars) {
global $dbClass, $presentationClass, $formsClass, $UrlClass, $config, $jqueryscript;
require_once($config['wpradmin_basepath'] . "/include/fields.inc.php");
$fieldsClass = registry::register('fieldsClass');
$page_name = "editagentfields";
$backurl = $config['adm_baseurl'] . "index.php?apage=" . $page_name;
$tablename = "agentfields";
$field_prefix = "agentfields";
$agent_table = "agents";
$field_name_prefix = "agent_";
if (!isset($get_vars['action']) OR ( $get_vars['action'] == 'delete_field')) {
if ($get_vars['action'] == 'delete_field' AND is_numeric($get_vars['del_id'])) {
if ($field_info = $fieldsClass->FieldExists($tablename, $field_prefix . "_id", $get_vars['del_id'])) {
if ($fieldsClass->DeleteField($field_info[$field_prefix . '_field_name'], $agent_table, $tablename, $this->block_fields_name)) {
$content .= $presentationClass->OperationSuccessfull("Agent Field delete");
} else {
$content .= $presentationClass->OperationFailed("Agent Field delete failed");
}
}
}
$content .= $formsClass->startform();
$tab_fields = $fieldsClass->GetFields($tablename, $this->block_fields_name);
if ($tab_fields !== false) {
if (isset($post_vars['send_form'])) {
foreach ($post_vars as $key => $value) {
for ($i = 0; $i < count($value); $i++) {
$new_array[$i][$key] = $value[$i];
}
}
for ($i = 0; $i < count($tab_fields); $i++) {
$field_vars = $new_array[$i];
$new_name = $field_name_prefix . $field_vars[$field_prefix . '_field_newname'];
$field_name = $field_vars[$field_prefix . '_field_name'];
//change name
$colExists = $dbClass->ColumnExists($config['table_prefix'] . $agent_table, $new_name, $colInfo);
//$field_vars[$field_prefix.'_rank'] = $field_vars[$field_prefix.'_rank'];
// echo $new_name. '<br>';
// echo $field_name. '<br>';
// echo $colExists. '<br>';
// die();
if ($new_name != $field_name AND $colExists === false AND ( !array_key_exists($field_name, $this->standard_fields_name))) {
if ($dbClass->ChangeColumn($config['table_prefix'] . "agents", $field_name, array('new_column_name' => $new_name))) {
$field_vars[$field_prefix . '_field_name'] = $new_name;
$fieldsClass->DeleteFieldInfo($field_name, $tablename);
$fieldsClass->UpdateFieldsInfo($field_vars, $tablename, $field_prefix);
}
} else {
if ($colExists !== false) {
$fieldsClass->UpdateFieldsInfo($field_vars, $tablename, $field_prefix);
}
}
}
$content .= $presentationClass->OperationSuccessfull("Agent Fields edited");
}
}
$tab_fields = $fieldsClass->GetFields($agent_table, $this->block_fields_name);
if ($tab_fields !== false) {
$newfieldurl = $backurl . "&action=add_new_field";
$content .= "<a href='$newfieldurl'>Add new field</a>";
$pre_table_head = array('Name', 'Change name', 'Type', 'Caption', 'Elements', 'Required', '');
$pre_table = array();
for ($i = 0; $i < count($tab_fields); $i++) {
if ($field_info = $fieldsClass->FieldExists($tablename, $field_prefix . "_field_name", $tab_fields[$i])) {
$field_information = $field_info;
} else {
$field_information[$field_prefix . '_field_name'] = $tab_fields[$i];
$field_information[$field_prefix . '_field_caption'] = "";
$field_information[$field_prefix . '_field_elements'] = "";
$field_information[$field_prefix . '_field_required'] = 0;
$field_information[$field_prefix . '_rank'] = 0;
$field_information[$field_prefix . '_field_type'] = 'text';
$field_information[$field_prefix . '_id'] = 0;
}
if ($field_information[$field_prefix . '_field_type'] == '') {
}
if ($field_information[$field_prefix . '_field_required'] == 1) {
$required_check = true;
} else
$required_check = false;
$field_name = str_replace($field_name_prefix, "", $field_information['agentfields_field_name']);
if (!in_array($field_information[$field_prefix . '_field_datatype'], $fieldsClass->tab_select_datatype)) {
if ($dbClass->ColumnExists($config['table_prefix'] . "agents", $field_information['agentfields_field_name'], $params)) {
$field_information['agentfields_field_datatype'] = $params['type'];
}
}
$pre_table['table'][$i][] = $field_name . $formsClass->create_hidden($field_prefix . '_field_name[]', $field_information[$field_prefix . '_field_name'], '');
if (!array_key_exists($field_information['agentfields_field_name'], $this->standard_fields_name))
$pre_table['table'][$i][] = $formsClass->create_text($field_prefix . '_field_newname[]', $field_name, '');
else
$pre_table['table'][$i][] = $formsClass->create_text('', $field_name, array('disabled' => 'disabled'));
$pre_table['table'][$i][] = $formsClass->create_select($field_prefix . '_field_type[]', $field_information[$field_prefix . '_field_type'], '', $fieldsClass->tab_select_type);
$pre_table['table'][$i][] = $formsClass->create_text($field_prefix . '_field_caption[]', $field_information[$field_prefix . '_field_caption'], '');
$pre_table['table'][$i][] = $formsClass->create_text($field_prefix . '_field_elements[]', $field_information[$field_prefix . '_field_elements'], '');
$pre_table['table'][$i][] = $formsClass->create_select($field_prefix . '_field_required[]', $field_information[$field_prefix . '_field_required'], '', array(0 => 'No', 1 => 'Yes'));
$edit_url = $config['adm_baseurl'] . "index.php?apage=editagentfields&action=edit_field&edit_id=" . $field_information['agentfields_id'];
$del_url = $config['adm_baseurl'] . "index.php?apage=editagentfields&action=delete_field&del_id=" . $field_information['agentfields_id'];
$options_col = "<a href='$edit_url'><img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a>";
if (!array_key_exists($field_information['agentfields_field_name'], $this->standard_fields_name))
$options_col .= "<a href='$del_url' class='delbutton' onclick='return false' name='Delete this field?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
$pre_table['table'][$i][] = $options_col;
$pre_table['rank'][$i] = $field_information[$field_prefix . '_rank'];
}
}
array_multisort($pre_table['rank'], $pre_table['table']);
$content .= $presentationClass->StandardTableWithDataNew($pre_table['table'], $pre_table_head, false, array('id' => 'sort', 'class' => 'wpr_form'));
$content .= $formsClass->create_hidden('send_form', 'yes');
$content .= $formsClass->create_submit('editsubmit', 'Edit', array('id' => 'editsubmit'));
$content .= $formsClass->endform();
} else {
if (isset($post_vars['add_new_field_submit'])) {
$errors = $fieldsClass->CheckAddEditField($post_vars, $tablename, $field_name_prefix);
if ($errors == "") {
if (!in_array($post_vars[$field_prefix . '_field_datatype'], $this->tab_select_datatype)) {
$post_vars[$field_prefix . '_field_datatype'] == 'text';
}
$dbClass->ChangeDebugMode(false);
$field_name = $field_name_prefix . $post_vars[$field_prefix . '_field_name'];
if ($dbClass->AddColumn($config['table_prefix'] . $agent_table, $field_name, $post_vars[$field_prefix . '_field_datatype'])) {
$post_vars[$field_prefix . '_field_name'] = $field_name;
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix);
$url = $config['adm_baseurl'] . "index.php?apage=" . $page_name;
header("Location: " . $url);
die();
} else {
$content = $presentationClass->OperationFailed("Add field failed");
}
$dbClass->ChangeDebugMode(true);
}
}
if (isset($post_vars['edit_field_submit'])) {
if ($fieldinfo = $fieldsClass->GetFieldInfo($get_vars['edit_id'], $tablename, $field_name_prefix)) {
$errors = $fieldsClass->CheckAddEditField($post_vars, $tablename, $field_name_prefix, $get_vars['edit_id']);
if ($errors == "") {
if (!in_array($post_vars[$field_prefix . '_field_datatype'], $this->tab_select_datatype)) {
$post_vars[$tablename . '_field_datatype'] == 'text';
}
$new_name = $field_name_prefix . $post_vars[$field_prefix . '_field_name'];
if ($new_name != $fieldinfo[$field_prefix . '_field_name']) {
if ($dbClass->ChangeColumn($config['table_prefix'] . $agent_table, $fieldinfo[$field_prefix . '_field_name'], array('new_column_name' => $new_name))) {
$post_vars[$field_prefix . '_field_name'] = $fieldinfo[$field_prefix . '_field_name'];
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix, '', $new_name);
}
} else {
$post_vars[$field_prefix . '_field_name'] = $fieldinfo[$field_prefix . '_field_name'];
$fieldsClass->UpdateFieldsInfo($post_vars, $tablename, $field_prefix, '', $new_name);
}
$content .= $presentationClass->OperationSuccessfull("Agent Fields has been edited");
}
}
}
if ($get_vars['action'] == 'add_new_field') {
if ($errors != "")
$content .= $presentationClass->OperationFailed($errors);
$content .= "<h3>Add New Field</h3>";
$content .= "<a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a><br>";
$content .= $fieldsClass->AddEditField($post_vars, $tablename, $field_name_prefix);
}elseif ($get_vars['action'] == 'edit_field') {
if ($errors != "") {
$content .= $presentationClass->OperationFailed($errors);
}
$content .= "<h3>Edit Field</h3>";
$content .= "<a href='$backurl'><button class='skin_colour round_all'><span>Back</span></button></a><br>";
if ($field_info = $fieldsClass->GetFieldInfo($get_vars['edit_id'], $tablename, $field_name_prefix)) {
$content .= $fieldsClass->AddEditField($field_info, $tablename, $field_name_prefix, $get_vars['edit_id'], $this->standard_fields_name);
}
}
}
return $content;
}
/*     * **********************************************************\
* Use by: wprrets module
* Purpose: return key value array, agentfields_field_name  as key & agentfields_field_caption  as value
\*********************************************************** */
function getKeyValueArray() {
global $dbClass, $config;
$sql = "SELECT agentfields_field_name, agentfields_field_caption FROM `" . $config['table_prefix'] . "agentfields` ORDER BY agentfields_field_name, agentfields_field_caption ";
$reC = $dbClass->query($sql);
$arr = array();
if ($reC->RecordCount() > 0) {
while (!$reC->EOF) {
$arr[$reC->fields['agentfields_field_name']] = !empty($reC->fields['agentfields_field_caption']) ? $reC->fields['agentfields_field_caption'] : $reC->fields['agentfields_field_name'];
$reC->MoveNext();
}
}
return $arr;
}
/*     * **********************************************************\
* Use by: wprrets cronjob module
* Purpose: Insert / update agent data
\*********************************************************** */
function InsertUpdateAgents($arrAgentData, $arrRETS2WPR_DirectTransfer, $retsUniqueField, $wpr_agent_agent_id_field) {
global $dbClass, $config;
/* Make Numerical Field List - */
$sql = 'SELECT agentfields_field_name FROM `' . $config['table_prefix'] . 'agentfields` ' . 'WHERE agentfields_datatype LIKE "int%" OR  agentfields_datatype LIKE "decimal%" ';
$reC = $dbClass->query($sql);
$numericalField = array();
/* Any listing found mark for remove? */
if ($reC->RecordCount() > 0) {
while (!$reC->EOF) {
$numericalField[] = $reC->fields['agentfields_field_name'];
$reC->MoveNext();
}
}
/* Make Date Field List */
$sql = 'SELECT agentfields_field_name FROM `' . $config['table_prefix'] . 'agentfields` ' . 'WHERE agentfields_datatype LIKE "DateTime" ';
$reC = $dbClass->query($sql);
$dateField = array();
if ($reC->RecordCount() > 0) {
while (!$reC->EOF) {
$dateField[] = $reC->fields['agentfields_field_name'];
$reC->MoveNext();
}
}
$cnt = 0;
/* Loop through each data and perform insert / updates */
foreach ($arrAgentData as $arrFieldNValue) {
/* Check for existing listing */
$sql = 'SELECT ' . $wpr_agent_agent_id_field . ' FROM `' . $config['table_prefix'] . 'agents` ' . 'WHERE ' . $wpr_agent_agent_id_field . ' = "' . $arrFieldNValue[$retsUniqueField] . '" ';
$reC = $dbClass->query($sql);
// debugMsg('<br>'. $sql);
/* Perform updates? */
$doUpdate = false;
if ($reC->RecordCount() > 0) {
$doUpdate = true;
}
if ($doUpdate) {
/* Update listingsdb for last data updates */
$sql = 'UPDATE ' . $config['table_prefix'] . 'agents ' . ' SET ';
} else {
/* Insert into listingsdb */
$sql = 'INSERT INTO ' . $config['table_prefix'] . 'agents '
. ' SET ';
}
/* Direct field to field tranfer */
foreach ($arrRETS2WPR_DirectTransfer as $retsFieldName => $wprFieldName) {
if ($doUpdate && $wprFieldName == $wpr_agent_agent_id_field)
continue;
if (in_array($wprFieldName, $numericalField)) {
$sql .= $wprFieldName . ' = "' . floatval(preg_replace('/[^\d.]/', "", $arrFieldNValue[$retsFieldName])) . '",';
} elseif (in_array($wprFieldName, $dateField)) {
if ($arrFieldNValue[$retsFieldName] == '')
$sql .= $wprFieldName . ' = NULL,';
else
$sql .= $wprFieldName . ' = "' . $arrFieldNValue[$retsFieldName] . '",';
}
else {
$sql .= $wprFieldName . ' = "' . $arrFieldNValue[$retsFieldName] . '",';
}
}
$sql .= ' agent_active = "Yes" ';
if ($doUpdate) {
$sql .= 'WHERE ' . $wpr_agent_agent_id_field . ' = "' . $arrFieldNValue[$retsUniqueField] . '" ';
}
//debugMsg("<br><br>". $sql. "<br>");
$ret = $dbClass->query($sql);
if ($ret !== false)
$cnt++;
}
return $cnt;
}
}
// END Class AgentClass
?>