<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class Help{
function ShowHelp($getvars)
{
global $config;
if($getvars['ac']=='localpath')
{
$content .= "<div class='wpr_form'>
<label>Local Path:</label>
<input type='text' value='".$config['adm_baseurl']."' size='70' ></div>";
}else
{
$content = '<h3>Display Search & View Listings</h3>
{wp-realty advsearch}<br/>
{wp-realty search}<br/>
{wp-realty searchresults}<br/>
{wp-realty listingdetails}<br/>
';
$content .= '<h3>Display Agents/Offices/Users</h3>
{wp-realty register}<br/>
{wp-realty myaccount}<br/>
{wp-realty agentroster}<br/>
{wp-realty officeroster}<br/>
{wp-realty userroster}<br/>
';
}
return $content;
}
}
?>