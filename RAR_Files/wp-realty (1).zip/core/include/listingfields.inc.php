<?php

/*
 * Commercial Codebase by WP Realty - RETS PRO Development Team.
 * Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
 * License: http://retspro.com/faq/license/
 */

class ListingFields {

    var $standard_fields_name = array(
        "listingsdb_id" => array(),
        "listingsdb_title" => array('field_required' => 1, 'field_caption' => 'Listing Title'),
        "listingsdb_featured" => array('field_required' => 0, 'field_caption' => 'Featured'), // This will eventually be moved to its own table.
        "Address" => array('field_required' => 0, 'field_caption' => 'Address'),
        "City" => array('field_required' => 0, 'field_caption' => 'City'),
        "State" => array('field_required' => 0, 'field_caption' => 'State'),
        "Zip" => array('field_required' => 0, 'field_caption' => 'Zip'),
        "Country" => array('field_required' => 0, 'field_caption' => 'Country'),
        "Price" => array('field_required' => 0, 'field_caption' => 'Price'),
        "MLS" => array('field_required' => 0, 'field_caption' => 'MLS #')
    );
    /*     * **********************************************************\
     * Visible but you can't change the field name, only caption.
      \*********************************************************** */
    var $nochange_fields_name = array(
//"MLS",
        "listingsdb_title",
            /*
              "listingsdb_active",
              "listingsdb_url_title",
              "listingsdb_expiration",
             */
    );
    /*     * **********************************************************\
     * These items are hidden from viewing or editing.
     * They are associated with RETS updtes and should not change.
      \*********************************************************** */
    var $block_fields_name = array(
        "listingsdb_id",
        /*
          "user_id",
          "agent_id",
          "office_id",
          "class_id",
          "listingsdb_featured",
          "agent_code",
          "office_code",
         */
        "listingsdb_is_photo_downloaded",
        "listingsdb_photo_last_downloaded",
        "listingsdb_is_mark_for_remove",
        "listingsdb_last_modified",
        "listingsdb_creation_date",
    );
    /*     * **********************************************************\
     * These items are hidden from useage in shortcode.
      \*********************************************************** */
    var $block_shortcode_name = array(
        "listingsdb_id",
        "user_id",
        /*
          "listingsdb_featured",
          "agent_id",
          "agent_code",
          "office_id",
          "office_code",
          "listingsdb_is_photo_downloaded",
          "listingsdb_photo_last_downloaded",
          "listingsdb_is_mark_for_remove",
         */
        "listingsdb_last_modified",
        "listingsdb_creation_date",
    );
    /*     * **********************************************************\
     * New formats recently added.
      \*********************************************************** */
    var $tab_select_type = array(
        "text" => "Text",
        "radio" => "Radio",
        "checkbox" => "Checkbox",
        "select" => "Select",
        "daterange" => "Min/Max Date",
        "textarea" => "TextArea"
    );
    /*     * **********************************************************\
     * There needs to be VARCHAR, DATE and DATETIME
      \*********************************************************** */
    var $tab_select_datatype = array(
        "int(11)" => 'Integer',
        "float" => 'Float',
        "char(5)" => 'Char(5)',
        "char(20)" => 'Char(20)',
        "char(50)" => 'Char(50)',
        "char(100)" => 'Char(100)',
        "char(200)" => 'Char(200)',
        "text" => 'Text',
        "longtext" => 'Long Text'
    );
    public $price_field;

    function __construct($initialize = true) {
        global $config;
        if ($initialize) {
            require_once($config['wpradmin_basepath'] . "include/controlpanel.inc.php");
            $control = registry::register('controlpanelClass');
            $this->price_field = strtolower($control->GetPriceField());
            self::$field_caption_to_name_cache = array();
        }
    }

    function GetListingDetails($content, $listing_id) {
        global $config;
//die('here');
        require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
        $template = registry::register('parseClass');
//parse only agent info
        if ($listingInfo = $this->GetListingInfo($listing_id)) {
//die('here');
            $agent_section = $template->GetTemplateBlock('agent_section', $content);
            if (!empty($listingInfo['agent_code'])) {
                require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
                $agentClass = registry::register('AgentClass');
                $agent_id = $agentClass->getIdFromAgentCode($listingInfo['agent_code']);
                if ($agent_id)
                    $replacement = $template->MainParse($agent_section['content'], $agent_id, false, array('agent', 'featuredagent', 'agent_link', 'agent_thumbnail'));
                else
                    $replacement = "";
            } else
                $replacement = "";
            $content = $template->ReplaceTemplateBlock('agent_section', $replacement, $content);
            return $content;
        } else
            return false;
    }

    function GetListingInfo($listing_id) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsdb WHERE listingsdb_id='$listing_id'";
//$sql = "SELECT * FROM ".$config['table_prefix']."listingsdb WHERE MLS LIKE '$listing_id'";
//echo $sql;
# Dinesh : Tuesday, July 09, 2013
# MasterDb flag added
//echo $sql;
        $reInfo = $dbClass->query($sql, true);
//$reInfo = $dbClass->Query($sql);
        if ($reInfo->RecordCount() > 0) {
//var_dump($reInfo->fields);
            return $reInfo->fields;
        }
        return false;
    }

    function GetListingFieldsInfoByName($name) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_field_name='" . $name . "'";
        $reInfo = $dbClass->query($sql);
        if ($reInfo->RecordCount() > 0) {
            return $reInfo->fields;
        } else
            return false;
    }

    function GetShortcodeListingFields() {
        global $dbClass, $config;
        require_once($config['wpradmin_basepath'] . "include/controlpanel.inc.php");
        $block_names = $this->block_shortcode_name;
        $controlpanelClass = registry::register('controlpanelClass');
        $settings = $controlpanelClass->GetControlPanelFields();
        if ($settings['controlpanel_wprets'] == 0) {
            $tmp = array();
            for ($i = 0; $i < count($block_names); $i++) {
                if ($block_names[$i] != 'listingsdb_id')
                    $tmp[] = $block_names[$i];
            }
            $block_names = $tmp;
        }
        $return = $dbClass->GetColumns($config['table_prefix'] . "listingsdb", $block_names, false, true);
        $newR = array();
        natcasesort($return);
        foreach ($return as $v) {
            $newR[] = $v;
        }
        return $newR;
    }

    function GetListingFields() {
        global $dbClass, $config;
        return $dbClass->GetColumns($config['table_prefix'] . "listingsdb", $this->block_fields_name, false, true);
    }

    function GetListingFieldsForeach() {
        global $dbClass, $config;
        $res = $dbClass->GetColumns($config['table_prefix'] . "listingsdb", $this->block_fields_name, false, true);
        if ($res !== false) {
            $new_table = array();
            for ($i = 0; $i < count($res); $i++) {
                $new_table[$res[$i]] = $res[$i];
            }
            natcasesort($new_table);
            return $new_table;
        }
        return false;
    }

    function UpdateListingFieldsInfo($request_vars, $tab_fields = '', $change_name = false) {
        global $dbClass, $config;
//echo '<br>UpdateListingFieldsInfo<br>';
        if (!is_array($tab_fields)) {
//die('reached false tab fields');
            $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_field_name = '" . $request_vars['listingfields_field_name'] . "'";
//die($sql);
            $reCheck = $dbClass->Query($sql);
            if ($reCheck->recordCount() == 0) {
//die('is insert');
                // Fix up the int type fields - MM 1-16-17
                $required = $request_vars['listingfields_field_required'] ? $request_vars['listingfields_field_required'] : 0;
                $rank = $request_vars['listingfields_rank'] ? $request_vars['listingfields_rank'] : 0;
                $section_rank = $request_vars['listingfields_section_rank'] ? $request_vars['listingfields_section_rank'] : 0;
                
                $sql = "INSERT INTO " . $config['table_prefix'] . "listingsfields
SET listingfields_field_caption='" . $request_vars['listingfields_field_caption'] . "',
listingfields_field_type='" . $request_vars['listingfields_field_type'] . "',
listingfields_field_elements='" . $request_vars['listingfields_field_elements'] . "',
listingfields_field_required='" . $required . "',
listingfields_rank='" . $rank . "',
listingfields_section='" . $request_vars['listingfields_section'] . "',
listingfields_tip='" . $request_vars['listingfields_tip'] . "',
listingfields_section_rank='" . $section_rank . "',
listingfields_datatype='" . $request_vars['listingfields_field_datatype'] . "',
listingfields_field_name = '" . $request_vars['listingfields_field_name'] . "'
";
//echo $sql;
                /* $sql = "INSERT INTO ".$config['table_prefix']."listingsfields (".implode(", ", array_keys($request_vars)).") "
                  .	"VALUES ('".implode("', '", array_values($request_vars))."')"; */
            } else {
                $sql = "UPDATE " . $config['table_prefix'] . "listingsfields
SET ";
                if ($change_name !== false)
                    $sql .= "listingfields_field_name = '" . $change_name . "',";
                $sql .= "listingfields_field_caption='" . $request_vars['listingfields_field_caption'] . "',
listingfields_field_type='" . $request_vars['listingfields_field_type'] . "',
listingfields_field_elements='" . $request_vars['listingfields_field_elements'] . "',
listingfields_field_required='" . $request_vars['listingfields_field_required'] . "',
listingfields_rank='" . $request_vars['listingfields_rank'] . "',
listingfields_section='" . $request_vars['listingfields_section'] . "',
listingfields_tip='" . $request_vars['listingfields_tip'] . "',
listingfields_section_rank='" . $request_vars['listingfields_section_rank'] . "'
WHERE listingfields_field_name = '" . $request_vars['listingfields_field_name'] . "'
";
            }
//die($sql);
            $dbClass->Query($sql);
        } else {
            for ($i = 0; $i < count($tab_fields); $i++) {
                $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_field_name = '" . $request_vars['listingfields_field_name'][$i] . "'";
                $reCheck = $dbClass->Query($sql);
                if ($reCheck->recordCount() == 0) {
                    $sql = "INSERT INTO " . $config['table_prefix'] . "listingsfields
SET listingfields_field_caption='" . $request_vars['listingfields_field_caption'][$i] . "',
listingfields_field_type='" . $request_vars['listingfields_field_type'][$i] . "',
listingfields_field_required='" . $request_vars['listingfields_field_required'][$i] . "',
listingfields_rank='" . $i . "',
listingfields_field_name = '" . $request_vars['listingfields_field_name'][$i] . "'
";
                } else {
                    $sql = "UPDATE " . $config['table_prefix'] . "listingsfields
SET listingfields_field_caption='" . $request_vars['listingfields_field_caption'][$i] . "',
listingfields_field_type='" . $request_vars['listingfields_field_type'][$i] . "',
listingfields_field_required='" . $request_vars['listingfields_field_required'][$i] . "',
listingfields_rank='" . $i . "',
WHERE listingfields_field_name = '" . $request_vars['listingfields_field_name'][$i] . "'
";
                }
                echo 'sql ' . $sql;
                $dbClass->Query($sql);
            }
        }
    }

    function DeleteListingField($name) {
        global $dbClass, $config;
        $name = $dbClass->DataFilters($name);
        if (!in_array($name, $this->block_fields_name) AND ! (in_array($name, $this->nochange_fields_name))) {
            if ($dbClass->ColumnExists($config['table_prefix'] . "listingsdb", $name)) {
                if ($dbClass->DeleteColumn($config['table_prefix'] . "listingsdb", $name)) {
                    $this->DeleteListingFieldInfo($name);
                    return true;
                } else
                    return false;
            } else
                return false;
        } else
            return false;
    }

    function DeleteListingFieldInfo($name) {
        global $dbClass, $config;
        $sql = "DELETE FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_field_name='" . $name . "'";
        return $dbClass->Query($sql);
    }

    function CheckRequiredField($request_vars, $caption = true) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_field_required=1";
        $reFields_req = $dbClass->Query($sql);
        $errors = false;
        while (!$reFields_req->EOF) {
            if ($request_vars[$reFields_req->fields['listingfields_field_name']] == "" AND
                    $reFields_req->fields['listingfields_field_type'] != 'select' AND
                    $reFields_req->fields['listingfields_field_type'] != 'checkbox') {
                if ($reFields_req->fields['listingfields_field_caption'] != "")
                    $errors[] = $reFields_req->fields['listingfields_field_caption'];
                else
                    $errors[] = $reFields_req->fields['listingfields_field_name'];
            }
            if ($request_vars[$reFields_req->fields['listingfields_field_name']] == "select" AND $reFields_req->fields['listingfields_field_type'] == 'select') {
                if ($reFields_req->fields['listingfields_field_caption'] != "")
                    $errors[] = $reFields_req->fields['listingfields_field_caption'];
                else
                    $errors[] = $reFields_req->fields['listingfields_field_name'];
            }
            $reFields_req->MoveNext();
        }
        return $errors;
    }

    function InsertNewListing($request_vars) {
        
        global $dbClass, $config, $log_user_id;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields";
        $reFields = $dbClass->Query($sql);
        $sql = "INSERT INTO " . $config['table_prefix'] . "listingsdb SET ";
        while (!$reFields->EOF) {
            if ($reFields->fields['listingfields_field_type'] == "checkbox") {
                $value = implode("|", $request_vars[$reFields->fields['listingfields_field_name']]);
            } 
            if ($reFields->fields['listingfields_field_name'] == 'user_id' && empty($request_vars[$reFields->fields['listingfields_field_name']]))
                $request_vars[$reFields->fields['listingfields_field_name']] = $log_user_id;
            if ($reFields->fields['listingfields_field_name'] == 'agent_id' && empty($request_vars[$reFields->fields['listingfields_field_name']]))
                $request_vars[$reFields->fields['listingfields_field_name']] = $request_vars['agent_id'];
            if ($reFields->fields['listingfields_field_name'] == 'class_id' && empty($request_vars[$reFields->fields['listingfields_field_name']]))
                $request_vars[$reFields->fields['listingfields_field_name']] = $request_vars['class_id'];
            $value = $request_vars[$reFields->fields['listingfields_field_name']];
            
            if(!isset($request_vars[$reFields->fields['listingfields_field_name']]) || $request_vars[$reFields->fields['listingfields_field_name']] == ''){
                
            }
            else{
                $sql .= $reFields->fields['listingfields_field_name'] . "='" . $value . "',";
            }
            
            $reFields->MoveNext();
        }
        $sql = substr($sql, 0, -1);
        $sql .= ",listingsdb_creation_date='" . date('Y-m-d') . "'";
//return $sql;
        if ($dbClass->Query($sql) !== false) {
            return $dbClass->LastID();
        }
        return false;
    }

    function UpdateListing($request_vars, $listing_id) {
        global $dbClass, $config, $post_safe;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields";
        $reFields = $dbClass->Query($sql);
        $sql = "UPDATE " . $config['table_prefix'] . "listingsdb SET ";
        while (!$reFields->EOF) {
            if ($dbClass->ColumnExists($config['table_prefix'] . "listingsdb", $reFields->fields['listingfields_field_name'])) {
                if ($reFields->fields['listingfields_field_type'] == "checkbox" AND is_array($request_vars[$reFields->fields['listingfields_field_name']])) {
                    $value = implode("|", $request_vars[$reFields->fields['listingfields_field_name']]);
                } //else
                    //echo 'key ' . $reFields->fields['listingfields_field_name'] . ' value= ' . $request_vars[$reFields->fields['listingfields_field_name']] . '<br>';
                if ($reFields->fields['listingfields_field_name'] == 'agent_id' && empty($request_vars[$reFields->fields['listingfields_field_name']]))
                    $request_vars[$reFields->fields['listingfields_field_name']] = $request_vars['agent_id'];
                if ($reFields->fields['listingfields_field_name'] == 'class_id' && empty($request_vars[$reFields->fields['listingfields_field_name']]))
                    $request_vars[$reFields->fields['listingfields_field_name']] = $request_vars['class_id'];
                $value = $request_vars[$reFields->fields['listingfields_field_name']];
                if(!isset($request_vars[$reFields->fields['listingfields_field_name']]) || $request_vars[$reFields->fields['listingfields_field_name']] == ''){
                    
                }
                else{
                    $sql .= $reFields->fields['listingfields_field_name'] . "='" . $value . "',";
                }
            }
            $reFields->MoveNext();
        }
        $sql = substr($sql, 0, -1);
        $sql .= ",listingsdb_last_modified='" . date('Y-m-d') . "'";
        $sql .= " WHERE listingsdb_id='" . $listing_id . "'";
//die($sql);
        if ($dbClass->Query($sql) !== false)
            return true;
        return false;
    }

    /*     * **********************************************************\
     * SONAL
      \*********************************************************** */

    function ListingImagesForm($listing_id, $actual_page_id) {
        global $dbClass, $config, $presentationClass, $UrlClass, $formsClass, $jqueryscript;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsimages WHERE listingsdb_id='$listing_id' ORDER BY listingsimages_rank";
        $reImages = $dbClass->Query($sql);
        $action_url = $UrlClass->AddUrlValues(array('page' => 'editlistings', $actual_page_id . 'action' => 'edit_listing', 'edit_id' => $listing_id));
//$content = $formsClass->startform($action_url);
        if ($reImages->recordCount() > 0) {
//$content = $formsClass->startform($config['wpr_baseurl']."include/ajax_functions.php?page=$actual_page_id",array('id'=>'editimg_form'));
            $content = $formsClass->startform();
            $view_tab = array();
            $tabRANK = array();
            for ($i = 0; $i < $reImages->recordCount(); $i++) {
                $tabRANK[$i] = $i;
            }
            while (!$reImages->EOF) {
                $delurl = $UrlClass->ReplaceUrlValues(array('content_action' => 'delete_image', 'del_id' => $reImages->fields['listingsimages_id']));
                $tables = array();
                $tables[] = $formsClass->create_hidden('image_id[]', $reImages->fields['listingsimages_id']) .
                        "<strong>" . $reImages->fields['listingsimages_file_name'] . "</strong><br/>";
                $tables[] = "<img src='" . $config['baseurl'] . $config['img_dir'] . "/listing_images/" . $reImages->fields['listingsimages_thumb_file_name'] . "'>";
//$tables[] = $formsClass->create_select('rank[]',$reImages->fields['listingsimages_rank'],'',$tabRANK);
                $tables[] = $formsClass->create_text('caption[]', $reImages->fields['listingsimages_caption']);
                $tables[] = $formsClass->create_textarea('description[]', $reImages->fields['listingsimages_description']);
                $tables[] = "<a href='$delurl' class='delbutton' onclick='return false;' name='Delete image?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
                $right .= $presentationClass->BlockTable($tables);
                $left = "<img src='" . $config['baseurl'] . $config['img_dir'] . "/listing_images/" . $reImages->fields['listingsimages_file_name'] . "'>";
                $view_tab[] = $tables;
                $reImages->MoveNext();
            }
            $headers = array('Name', 'Thumb', 'Caption', 'Description', '');
            $content .= $presentationClass->StandardTableWithDataNew($view_tab, $headers, false, array('id' => 'editimages_datatable', 'style' => 'wpr_form'), true);
//$content .= $formsClass->create_hidden('edit_id',$listing_id,'');
//$content .= $formsClass->create_hidden('action_url',$action_url);
            $content .= $formsClass->create_hidden('content_action', "edit_images");
            $content .= $formsClass->create_submit('editsubmit', 'Save');
            $content .= $formsClass->endform();
        }
        return $content;
    }

    /*     * **********************************************************\
     * SONAL
      \*********************************************************** */

    function GetListingImage($edit_id) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsimages WHERE  listingsimages_id='" . $edit_id . "'";
        $reImages = $dbClass->Query($sql);
        if ($reImages->recordCount() > 0) {
            return $reImages->fields;
        } else
            return false;
    }

    /*     * **********************************************************\
     * Deletes the physical image and listingimages table
      \*********************************************************** */

    function DeleteListingImage($del_id) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsimages WHERE  listingsimages_id='" . $del_id . "'";
        $reImages = $dbClass->Query($sql);
        if ($reImages->recordCount() > 0) {
            @unlink($config['listing_images'] . $reImages->fields['listingsimages_file_name']);
            if ($reImages->fields['listingsimages_thumb_file_name'] != "") {
                @unlink($config['listing_images'] . $reImages->fields['listingsimages_thumb_file_name']);
            }
            $sql = "DELETE FROM " . $config['table_prefix'] . "listingsimages WHERE listingsimages_id='$del_id'";
            $ret = $dbClass->Query($sql);
            return $ret;
        } else
            return false;
    }

    /*     * **********************************************************\
     * Deletes the physical images and listingimages table
      \*********************************************************** */

    function DeleteListingImages($del_id) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsimages WHERE  listingsdb_id='" . $del_id . "'";
        $reImages = $dbClass->Query($sql);
        if ($reImages->recordCount() > 0) {
            $tab_id = "";
            while (!$reImages->EOF) {
                if (@unlink($config['listing_images'] . $reImages->fields['listingsimages_file_name'])) {
                    $tab_id .= $reImages->fields['listingsimages_id'] . ",";
                }
                if ($reImages->fields['listingsimages_thumb_file_name'] != "") {
                    @unlink($config['listing_images'] . $reImages->fields['listingsimages_thumb_file_name']);
                }
                $reImages->MoveNext();
            }
            if ($tab_id != "") {
                $tab_id = substr($tab_id, 0, -1);
                $sql = "DELETE FROM " . $config['table_prefix'] . "listingsimages WHERE listingsimages_id IN ($tab_id)";
                $dbClass->Query($sql);
            }
            return true;
        } else
            return false;
    }

    /*     * **********************************************************\
     *
      \*********************************************************** */

    function ShowAddEditListingTable($request, $mode = '', $edit_id = '', $user_id = false) {
        global $dbClass, $config, $presentationClass, $jqueryscript, $UrlClass, $log_user_id, $lang;
        require_once($config['wpradmin_basepath'] . "include/images.inc.php");
        $imagesClass = registry::register('ImagesClass');
        $content = "";
        $action_url = $UrlClass->ReplaceUrlValues(array('page' => 'addlisting'));
//$post_vars = $dbClass->DataFiltersArray($_POST);
        $actual_page_id = "addlisting";
//to jquery.tabs
        $selected = false;
        if ($mode == 'edit') {
            if ($user_id === false)
                $actual_page_id = "editlistings";
            else
                $actual_page_id = "editmylistings";
            $action_url = $UrlClass->AddUrlValues(array('page' => $actual_page_id, $actual_page_id . 'action' => 'edit_listing', 'edit_id' => $edit_id));
            if ($request['content_action'] == 'upload_images') {
                require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
                $imagesClass = registry::register('ImagesClass');
                if ($files = $imagesClass->UploadImages()) {
                    if ($imagesClass->UploadListingImages($edit_id, $log_user_id, $files)) {
                        $content .= $presentationClass->OperationSuccessfull('Upload Images Success');
                    } else
                        $content .= $presentationClass->OperationFailed('Upload Images Failed');
                } else
                    $content .= $presentationClass->OperationFailed('Upload Images Failed');
                $selected = 1;
            }
            if ($request['content_action'] == 'edit_images') {
                for ($i = 0; $i < count($request['image_id']); $i++) {
                    $sql = "UPDATE " . $config['table_prefix'] . "listingsimages SET
listingsimages_caption = '" . $request['caption'][$i] . "',
listingsimages_description = '" . $request['description'][$i] . "',
listingsimages_rank = '" . $i . "'
WHERE listingsimages_id='" . $request['image_id'][$i] . "'";
                    $dbClass->Query($sql);
                }
                $content .= $presentationClass->OperationSuccessfull($lang['images_update']);
                $selected = 1;
            }
            if ($_GET['content_action'] == 'delete_image') {
                if (is_numeric($_GET['del_id']) AND $this->GetListingImage($_GET['del_id'])) {
                    if ($this->DeleteListingImage($_GET['del_id'])) {
                        $content .= $presentationClass->OperationSuccessfull('Delete Image Success');
                    } else
                        $content .= $presentationClass->OperationFailed('Delete Image Failed');
                }
                $selected = 1;
            }
        }
        require_once($config['wpradmin_basepath'] . 'include/forms.inc.php');
        require_once($config['wpradmin_basepath'] . 'include/images.inc.php');
        $formsClass = registry::register('FormsClass');
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields ORDER by listingfields_rank_col,listingfields_rank";
        $reFields = $dbClass->Query($sql);
        $listing_tabs = "";
        if ($reFields->recordCount() > 0) {
            $listing_tab = array();
            require_once($config['wpradmin_basepath'] . 'include/class.inc.php');
            $pclassClass = registry::register('pclassClass');
            $temp_tab_class = $pclassClass->GetClasses();
            for ($i = 0; $i < count($temp_tab_class); $i++) {
                $tab_class[$temp_tab_class[$i]['class_id']] = $temp_tab_class[$i]['class_name'];
            }
            $listing_tab[0][] = array("<b>Class:</b>", $formsClass->create_select('class_id', $request['class_id'], '', $tab_class));
//agent select
            require_once($config['wpradmin_basepath'] . 'include/agent.inc.php');
            $tab_agent['0'] = "choose";
            $AgentClass = registry::register('AgentClass');
            if ($temp_tab_agent = $AgentClass->GetAgents()) {
                for ($i = 0; $i < count($temp_tab_agent); $i++) {
                    $tab_agent[$temp_tab_agent[$i]['agent_id']] = $temp_tab_agent[$i]['agent_first_name'] . " " . $temp_tab_agent[$i]['agent_last_name'];
                }
            }
            $listing_tab[0][] = array("<b>Agent:</b>", $formsClass->create_select('agent_id', $request['agent_id'], '', $tab_agent));
            while (!$reFields->EOF) {
                if ($reFields->fields['listingfields_field_name'] == 'class_id')
                    $reFields->MoveNext();
                if ($reFields->fields['listingfields_field_name'] == 'agent_id')
                    $reFields->MoveNext();
//echo $reFields->fields['listingfields_field_name'].'<br>';
                if ($dbClass->ColumnExists($config['table_prefix'] . "listingsdb", $reFields->fields['listingfields_field_name']) !== false) {
                    if ($reFields->fields['listingfields_field_caption'] != "")
                        $right_col = $reFields->fields['listingfields_field_caption'];
                    else {
                        $right_col = str_replace("listingsdb_", "", $reFields->fields['listingfields_field_name']);
                        $right_col = str_replace("_", " ", $right_col);
                    }
                    $elements = "";
                    if (strpos($reFields->fields['listingfields_field_elements'], "|") !== false) {
                        $elements_temp = explode("|", $reFields->fields['listingfields_field_elements']);
                        $elements = array();
                        for ($i = 0; $i < count($elements_temp); $i++) {
                            if ($reFields->fields['listingfields_field_type'] == 'checkbox')
                                $elements[$elements_temp[$i]] = $elements_temp[$i] . "<br/>";
                            else
                                $elements[$elements_temp[$i]] = $elements_temp[$i];
                        }
                    }
                    $params = false;
                    if ($reFields->fields['listingfields_field_type'] == 'text' OR $reFields->fields['listingfields_field_type'] == 'textarea') {
// is_array($params) || $params=array(); //Sonal
                        $params['class'] = "large";
                    }
                    if ($reFields->fields['listingfields_tip'] != "") {
// is_array($params) || $params=array(); //Sonal
                        $params['title'] = $reFields->fields['listingfields_tip'];
                    }
                    $left_col = $formsClass->GenerateField($reFields->fields['listingfields_field_type'], $reFields->fields['listingfields_field_name'], $request[$reFields->fields['listingfields_field_name']], $elements, $request, 'normal', $params);
//$rank = rand(0,2);
//$listing_tab[$rank][] = array("<strong>".$right_col."</strong>",$left_col);
                    $listing_tab[$reFields->fields['listingfields_rank_col']][] = array("<strong>" . $right_col . "</strong>", $left_col);
                }
                $reFields->MoveNext();
            }
            $listing_tabs .= $formsClass->startform(false, array('id' => $actual_page_id . '_form'));
            $listing_tabs .= $formsClass->create_hidden('edit_id', $edit_id, '');
            $listing_tabs .= $formsClass->create_hidden('action_url', $action_url);
            $listing_tabs .= "<div><button onclick='return false' id='save_order' style='float:right'>Save order field</button><div style='clear:both'></div></div>";
            $success_info = $presentationClass->OperationSuccessfull('The order of the fields has been saved');
            $listing_tabs .= $presentationClass->BlockTableSortable($listing_tab[0], 3);
            $listing_tabs .= $presentationClass->BlockTableSortable($listing_tab[1], 3);
            $listing_tabs .= $presentationClass->BlockTableSortable($listing_tab[2], 3);
            $listing_tabs .= $jqueryscript->SaveOrder("sd_column", "save_order", $config['adm_baseurl'] . "ajax.php?f=ajax_fields_sort.php", $success_info);
            if ($mode == 'edit')
                $listing_tabs .= $formsClass->create_submit($actual_page_id . '_submit', 'Edit', array('id' => $actual_page_id . '_submit'));
            else
                $listing_tabs .= $formsClass->create_submit('addlisting_submit', 'add', array('id' => 'addlisting_submit'));
            $listing_tabs .= $formsClass->endform();
        }
        if ($mode == 'edit') {
            $editlisting_listing_tab_name = $actual_page_id . "_listing_tab";
            $editlisting_images_tab_name = $actual_page_id . "_images_tab";
            $headers = array(
                $editlisting_listing_tab_name => "Listing Details",
                $editlisting_images_tab_name => "Images",
            );
            $action_url = $UrlClass->AddUrlValues(array('page' => $actual_page_id, $actual_page_id . 'action' => 'edit_listing', 'edit_id' => $edit_id));
//$action_ajax = $config['wpr_baseurl']."include/ajax_functions.php?page=$actual_page_id";
            $images_tab = $imagesClass->GenerateUploadImagesFormNormal(5, $edit_id, 'upload_listing', $actual_page_id, $action_url, 0, 2);
            $images_tab .= "<br/>";
            $images_tab .= $this->ListingImagesForm($edit_id, $actual_page_id);
            $data[$editlisting_listing_tab_name] = $listing_tabs;
            $data[$editlisting_images_tab_name] = $images_tab;
            $jquery_tabs_id = "jqt_" . $actual_page_id;
            $content .= $presentationClass->JqueryTabsWithDataNew($data, $headers, array('id' => $jquery_tabs_id, 'class' => 'box grid_16 round_all tabs', 'grabber' => false), $selected);
        } else {
            /* $headers = array(
              "addlisting_listing_tab"=>"Listing Details",
              );
              $data['addlisting_listing_tab'] = $listing_tabs; */
            $content .= $listing_tabs;
//$presentationClass->StandardTableWithData($listing_tab);
        }
        return $content;
    }

    function AddListingBackEnd($post_vars, $get_vars) {
        global $dbClass, $presentationClass, $UrlClass, $jqueryscript, $array_numbers, $config;
        $content = "";
        $error_info = "";
        if (isset($post_vars['addlisting_submit'])) {
//$post_vars = $dbClass->DataFiltersArray($_POST);
            $errors = $this->CheckRequiredField($post_vars);
            if ($errors === false) {
                if ($last_id = $this->InsertNewListing($post_vars)) {
                    $url = $config['adm_baseurl'] . 'index.php?apage=editmylistings&action=editlisting&edit_id=' . $last_id;
                    $content = $presentationClass->OperationSuccessfull("Listing has been added");
//header("Location: $url");
//die();
                } else
                    $content = $presentationClass->OperationFailed("Listing add failed");
            }
            else {
                $error_info = "Field required: ";
                for ($i = 0; $i < count($errors); $i++) {
                    $error_info .= str_replace("listingsdb_", "", $errors[$i]) . ", ";
                }
                $error_info = substr($error_info, 0, -2);
                $content .= $presentationClass->OperationFailed($error_info);
            }
        }
        $request = $post_vars;
        $content .= $this->ShowAddEditListingTable($post_vars);
        return $content;
    }

    function SaveListingFieldOrder($column, $fields) {
        global $config, $dbClass;
        if (count($fields) > 0) {
            for ($i = 0; $i < count($fields); $i++) {
                $sql = "UPDATE `" . $config['table_prefix'] . "listingsfields` SET listingfields_rank_col='" . $column . "', listingfields_rank='" . $i . "' WHERE listingfields_field_name='" . $fields[$i] . "'";
                $dbClass->Query($sql);
            }
            return true;
        }
    }

    function DeleteListing($del_id) {
        global $config, $dbClass, $user_level;
        $this->DeleteListingImages($del_id);
        $sql = "DELETE FROM " . $config['table_prefix'] . "listingsdb WHERE listingsdb_id='$del_id'";
        return $dbClass->query($sql);
    }

//*************************
//EDIT LISTING BACKEND
//*************************
    function CheckAccess($user_level, $user_id, $listing_id) {
        global $dbClass, $config;
        if ($user_level >= 2)
            return true;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsdb WHERE listingsdb_id='" . $listing_id . "' AND user_id='" . $user_id . "'";
        $reCheck = $dbClass->query($sql);
        if ($reCheck->RecordCount() > 0) {
            return true;
        }
        return false;
    }

    function DeleteListings($del_tab, $user_level, $log_user_id) {
        $true = 0;
        for ($i = 0; $i < count($del_tab); $i++) {
            if ($this->CheckAccess($user_level, $log_user_id, $del_tab[$i])) {
                if ($this->DeleteListing($del_tab[$i]))
                    $true++;
            }
        }
        if ($true == $i)
            return true;
        else
            return false;
    }

    function GetListingsCount($query = false, $user_id = false) {
        global $config, $dbClass;
        if ($user_id === false) {
            $sql = "SELECT count(*) as count FROM " . $config['table_prefix'] . "listingsdb";
            if ($query !== false) {
                $sql .= " WHERE listingsdb_title LIKE '%" . $query . "%'";
            }
        } else {
            $sql = "SELECT count(*) as count FROM " . $config['table_prefix'] . "listingsdb WHERE user_id='" . $user_id . "'";
            if ($query !== false) {
                $sql .= " AND listingsdb_title LIKE '%" . $query . "%'";
            }
        }
        $reCount = $dbClass->query($sql);
        return $reCount->fields['count'];
    }

    function GetListings($query = false, $start_range = 1, $user_id = false, $max_on_page = 10) {
        global $dbClass, $config;
        if ($user_id === false)
            $actual_page_id = "editlistings";
        else
            $actual_page_id = "editmylistings";
        if ($user_id === false) {
            $sql = "SELECT *  FROM " . $config['table_prefix'] . "listingsdb";
            if ($query !== false) {
                $sql .= " WHERE listingsdb_title LIKE '%" . $query . "%'";
            }
        } else {
            $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsdb WHERE user_id='" . $user_id . "'";
            if ($query !== false) {
                $sql .= " AND listingsdb_title LIKE '%" . $query . "%'";
            }
        }
        $sql = $sql . " LIMIT " . ($start_range - 1) * $max_on_page . "," . $max_on_page;
        $reListings = $dbClass->Query($sql);
        if ($reListings->recordCount() > 0) {
            $tab = array();
            while (!$reListings->EOF) {
                $editurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=editlisting&edit_id=" . $reListings->fields['listingsdb_id'];
                $deleteurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id . "&action=deletelisting&edit_id=" . $reListings->fields['listingsdb_id'];
                $checkbox = "<input type='checkbox' value='" . $reListings->fields['listingsdb_id'] . "' name='del_id[]'>";
                $tab[] = array($checkbox . $reListings->fields['listingsdb_id'], "<a href='" . $editurl . "'>" . $reListings->fields['listingsdb_title'] . "</a>", "<a href='$editurl'><img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a> <a href='$deleteurl' class='delbutton' name='Delete this listing?' onclick='return false'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>");
                $reListings->MoveNext();
            }
            return $tab;
        } else
            return false;
    }

    function GenerateHugeTable($tab, $listing_count, $start_page = 1, $max_on_page = 10) {
        global $presentationClass, $formsClass;
        $headers = array(
            array('name' => "ID", 'width' => '50'),
            array('name' => "Title", 'width' => '750'),
            array('name' => "", 'align' => 'right', 'width' => '50'));
        $content .= $presentationClass->StandardTableWithDataHuge($tab, $headers, array('class' => 'tablehuge'), $listing_count, $start_page, $max_on_page);
        return $content;
    }

    function EditListingsBackEnd($post_vars, $get_vars, $user_id = false, $test = false) {
        global $dbClass, $config, $presentationClass, $UrlClass, $jqueryscript, $user_level, $log_user_id, $formsClass;
        $errors = false;
        if ($user_id === false) {
            $actual_page_id = "editlistings";
            $notactual_page_id = "editmylistings";
            $user_add = "";
        } else {
            $actual_page_id = "editmylistings";
            $notactual_page_id = "editlistings";
            $user_add = "+'&mode=my'";
        }
        if (isset($post_vars[$actual_page_id . '_submit']) AND $this->CheckAccess($user_level, $log_user_id, $post_vars['edit_id'])) {
            $post_vars = $dbClass->DataFiltersArray($post_vars);
            $errors = $this->CheckRequiredField($post_vars);
            if ($errors === false) {
                if ($this->UpdateListing($post_vars, $get_vars['edit_id'])) {
                    $content = $presentationClass->OperationSuccessfull("Listing edited");
                } else
                    $content = $presentationClass->OperationFailed("Listing edit failed");
            }
            else {
                $error_info = "Field required: ";
                for ($i = 0; $i < count($errors); $i++) {
                    $error_info .= $errors[$i] . ", ";
                }
                $error_info = substr($error_info, 0, -2);
                $content .= $presentationClass->OperationFailed($error_info);
            }
        }
        if (!isset($get_vars['action']) OR $get_vars['action'] == 'deletelisting') {
            if ($user_id === false)
                $content = $presentationClass->SecondHeader('All Listings');
            else
                $content = $presentationClass->SecondHeader('My Listings');
//multi delete
            if (isset($post_vars['delete_listings'])) {
                if (count($post_vars['del_id'])) {
                    if ($this->DeleteListings($post_vars['del_id'], $user_level, $log_user_id))
                        $content .= $presentationClass->OperationSuccessfull('Delete listings success');
                    else
                        $content .= $presentationClass->OperationSuccessfull('Delete listings failed');
                }
            }
            if ($get_vars['action'] == 'deletelisting' AND is_numeric($get_vars['edit_id']) AND $this->CheckAccess($user_level, $log_user_id, $get_vars['edit_id'])) {
                if ($this->DeleteListing($get_vars['edit_id']))
                    $content .= $presentationClass->OperationSuccessfull('Delete listing success');
                else
                    $content .= $presentationClass->OperationSuccessfull('Delete listing failed');
            }
            $listing_count = $this->GetListingsCount(false, $user_id);
            if ($tab = $this->GetListings(false, 1, $user_id)) {
                $query = '';
                $content .= "<form method='post' id='delete_listings_form'>";
                $content .= '<div class="box_wp round_all">';
                $content .= $formsClass->create_submit('', 'Delete checked listings', array('id' => 'delete_listings', 'onclick' => 'return false;', 'type' => ''));
                $content .= '</div>';
                $content .= '
<div class="box_wp dataTables_wrapper">
<div class="fg-toolbar ui-toolbar ui-widget-header ui-corner-tl ui-corner-tr ui-helper-clearfix">
<div class="dataTables_filter">
<label>
Search:
<input type="text" id="search_field" value=' . $query . '>
</label>
</div>
</div>
</div>';
                $content .= "<div id='tablehuge'>";
                $content .= $this->GenerateHugeTable($tab, $listing_count);
                $content .= "</div>";
                $content .= "<input type='hidden' name='delete_listings' value='1' /></form>";
                $content .= $presentationClass->MultiDeleteConfirm("Delete checked listings?", "delete_listings_form", "delete_listings");
                $url = $config['adm_baseurl'] . "ajax.php?f=getlistings.php";
                $script = "
jQuery('.fg-button').live('click',function()
{
if(jQuery(this).hasClass('ui-state-disabled')==false)
{
var value = jQuery(this).text();
if(value=='First' || value=='Previous' || value=='Next' || value=='Last')
{
var tmp = jQuery(this).attr('id').split('_');
value = tmp[1];
}
var query = jQuery('#search_field').attr('value');
$.ajax({
type: 'POST',
url: '" . $url . "',
data: 'page='+value+'&query='+query" . $user_add . ",
success:function(data)
{
if(data!='')
{
jQuery('#tablehuge').html(data);
jQuery( 'select, input:checkbox, input:radio, input:file').livequery(function(){
jQuery(this).uniform();
});
}
}
});
}
});
jQuery('#search_field').live('keyup',function()
{
var query = jQuery(this).attr('value');
$.ajax({
type: 'POST',
url: '" . $url . "',
data: 'page=1&query='+query" . $user_add . ",
success:function(data)
{
if(data!='')
{
jQuery('#tablehuge').html(data);
jQuery( 'select, input:checkbox, input:radio, input:file').livequery(function(){
jQuery(this).uniform();
});
}
}
});
});
";
                $jqueryscript->AddJqueryScriptEnd($script);
            } else
                $content .= "No listings";
        }
        else {
            if ($get_vars['action'] == 'editlisting' AND is_numeric($get_vars['edit_id']) AND $this->CheckAccess($user_level, $log_user_id, $get_vars['edit_id'])) {
                if ($_SERVER['HTTP_REFERER'] == $config['adm_baseurl'] . "index.php?apage=addlisting") {
                    $content .= $presentationClass->OperationSuccessfull("Listing is added");
                }
                $content .= "<h3>Edit Listing</h3>";
                $backurl = $config['adm_baseurl'] . "index.php?apage=" . $actual_page_id;
                $content .= "<div class='tophref'><a href='$backurl'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a></div>";
                $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsdb WHERE listingsdb_id='" . $dbClass->DataFilters($get_vars['edit_id']) . "'";
                $reListing = $dbClass->Query($sql);
                if ($reListing->recordCount() > 0) {
                    if ($errors !== false) {
                        $request = $post_vars;
                        $content .= $this->ShowAddEditListingTable($request, 'edit', $get_vars['edit_id'], $user_id);
                    } else {
                        $request = $reListing->fields;
                        foreach ($request as $key => $values) {
                            $post_vars[$key] = $values;
                        }
                        $content .= $this->ShowAddEditListingTable($post_vars, 'edit', $get_vars['edit_id'], $user_id);
                    }
                } else {
                    header("Location: " . $backurl);
                    die();
                }
            }
        }
        $return = $content;
        return $return;
    }

//*************************
//EDIT LISTING FIELDS BACKEND UL LISTS
//*************************
    function GetSectionCode($section, $listing_id, $params = array()) {
        global $dbClass, $config;
//die($params['masterdb']);
        $sql = "SELECT 	* FROM `" . $config['table_prefix'] . "listingsfields` WHERE listingfields_section='" . $section . "' ORDER BY listingfields_section_rank";
        $reC = $dbClass->query($sql, $params['masterdb']);
        if ($reC->RecordCount() > 0) {
            $ret = "<ul id='" . $section . "'>";
            while (!$reC->EOF) {
                $field_name = $reC->fields['listingfields_field_name'];
# RemoteDb flag passed
                $params['field'] = $field_name;
                $value = $this->ReplaceListingFieldTags($listing_id, $params);
                if ($value != "") {
                    $caption = $this->SearchFieldCaption($field_name);
                    $ret .= "<li class='" . $field_name . "'><span>" . $caption . ":</span> " . $value . "</li>";
                }
                $reC->MoveNext();
            }
            $ret .= "</ul>";
            return $ret;
        }
        return "";
    }

    function SearchFieldCaption($field) {
        global $dbClass, $config;
        $sql = "SELECT listingfields_field_caption FROM `" . $config['table_prefix'] . "listingsfields` WHERE listingfields_field_name='" . $field . "' AND listingfields_field_caption!=''";
        $info = $dbClass->GetOneRow($sql, $config["masterdb_bool"]);
        if ($info !== false) {
            return $info['listingfields_field_caption'];
        }
        return $field;
    }

    function GetListingFieldSection($blog_id = 0, $masterdb = false) {
        global $dbClass, $config;
        $sql = "SELECT 	controlpanel_listing_template_section FROM `" . $config['table_prefix'] . "controlpanel` WHERE blog_id='" . $blog_id . "'";
        $reC = $dbClass->query($sql, $masterdb);
        if ($reC->RecordCount() > 0) {
            if ($reC->fields['controlpanel_listing_template_section'] != "") {
                $tmp = explode(",", $reC->fields['controlpanel_listing_template_section']);
                $ret_array = array();
                if (count($tmp) > 0) {
                    for ($i = 0; $i < count($tmp); $i++) {
                        $x = trim($tmp[$i]);
                        $ret_array[$x] = $x;
                    }
                    return $ret_array;
                }
            }
        }
        return false;
    }

/////////////////////////////////////////////////////
//New, more OO sub entrypoint leaving EditListingFieldsBackEnd as a depricated alias for core.inc compat
////////////////////////////////////////////////////
    private $PostVars;
    private $GetVars;

    private function ListingFieldsAdminController($postVars, $getVars) {
        $this->GetVars = $getVars;
        $this->PostVars = $postVars;
        if (!isset($this->GetVars['action'])) {//This is a new session
            $content = '';
            if (isset($this->GetVars['result'])) {
                if ($this->GetVars['result'] != 'failed')
                    $content .= $this->OperationResultsShow(true, 'Listing field "' . $this->GetVars['result'] . '" successfully added');
                else
                    $content .= $this->OperationResultsShow(false, 'Add Listing field FAILED!');
            }
            $content .= $this->ListListingFieldsShow();
            return $content;
        }
        elseif ($this->GetVars['action'] == 'add_new_field') {//Anything to do with adding field
            return $this->AddListingFieldController();
        } elseif ($this->GetVars['action'] == 'edit_field') {//Anything to do with editing field
            return $this->EditListingFieldController();
        } elseif ($this->GetVars['action'] == 'delete_field' && is_numeric($this->GetVars['del_id'])) {
            return $this->DeleteFieldController();
        }
        return $this->OperationResultsShow(false, 'Unsupported Operation!');
    }

    private function AddListingFieldController() {
        global $config, $dbClass;
        if ($this->PostVars['isform'] == 'true') {
            $errors = $this->CheckAddEditField($this->PostVars);
            if ($errors == "") {
                if (!in_array($this->PostVars['listingfields_field_datatype'], $this->tab_select_datatype)) {
                    $this->PostVars['listingfields_field_datatype'] == 'text';
                }
//$dbClass->ChangeDebugMode(false);
                $field_name = $this->PostVars['listingfields_field_name'];
                if ($dbClass->AddColumn($config['table_prefix'] . "listingsdb", $field_name, $this->PostVars['listingfields_field_datatype'])) {
                    $this->PostVars['listingfields_field_name'] = $field_name;
                    $this->UpdateListingFieldsInfo($this->PostVars);
                    $url = $config['adm_baseurl'] . "index.php?apage=listingfields&result=" . $field_name;
                    header("Location: " . $url);
// die();
                } else {
                    $url = $config['adm_baseurl'] . "index.php?apage=listingfields&result=failed";
                    header("Location: " . $url);
                }
//$dbClass->ChangeDebugMode(true);
            }
        } else {//just show the add edit form
            return $this->AddEditListingField(array());
        }
    }

    private function EditListingFieldController() {
        global $dbClass, $config;
        $success = false;
        if ($this->PostVars['isform'] == 'true') {
            if ($fieldinfo = $this->GetFieldInfo($this->GetVars['edit_id'])) {
                $errors = $this->CheckAddEditField($this->PostVars, $this->GetVars['edit_id']);
                if ($errors == "") {
                    if (!in_array($this->PostVars['listingfields_field_datatype'], $this->tab_select_datatype)) {
                        $this->PostVars['listingfields_field_datatype'] == 'text';
                    }
//$new_name = 'listingsdb_'.$post_vars['listingfields_field_name'];
                    $new_name = $this->PostVars['listingfields_field_name'];
                    if ($new_name != $fieldinfo['listingfields_field_name'] AND ( !in_array($fieldinfo['listingfields_field_name'], $this->nochange_fields_name))) {
                        if ($dbClass->ChangeColumn($config['table_prefix'] . "listingsdb", $fieldinfo['listingfields_field_name'], array('new_column_name' => $new_name))) {
                            $this->PostVars['listingfields_field_name'] = $fieldinfo['listingfields_field_name'];
                            $this->UpdateListingFieldsInfo($this->PostVars, '', $new_name);
                            $success = true;
                        } else {
                            $success = true;
                        }
                    } else {
                        $this->PostVars['listingfields_field_name'] = $fieldinfo['listingfields_field_name'];
                        $this->UpdateListingFieldsInfo($this->PostVars);
                        $success = true;
                    }
                    if ($success) {
                        $url = $config['adm_baseurl'] . "index.php?apage=listingfields&action=edit_field&edit_id=" . $this->GetVars['edit_id'] . "&result=success";
                        header("Location: " . $url);
                    } else {
                        $url = $config['adm_baseurl'] . "index.php?apage=listingfields&action=edit_field&edit_id=" . $this->GetVars['edit_id'] . "&result=fail";
                        header("Location: " . $url);
                    }
//$content = $this->OperationResultsShow(true,'Listing field "'.$fieldinfo['listingfields_field_name'].'" successfully edited');
                }
            }
        } else {
            $content = '';
            if (isset($this->GetVars['result'])) {
                if ($this->GetVars['result'] == 'success')
                    $content .= $this->OperationResultsShow(true, 'Listing field successfully edited');
                else
                    $content .= $this->OperationResultsShow(false, 'Listing field edit FAILED!');
            }
            $content .= $this->AddEditListingField($this->GetFieldInfo($this->GetVars['edit_id']), $this->GetVars['edit_id']);
            return $content;
        }
    }

    private function DeleteFieldController() {
        global $config, $dbClass, $presentationClass;
        $sql = "SELECT listingfields_field_name FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_id='" . $this->GetVars['del_id'] . "'";
        $reCheck = $dbClass->query($sql);
        if ($reCheck->recordcount() > 0) {
            if ($this->DeleteListingField($reCheck->fields['listingfields_field_name'])) {
                $content = $this->OperationResultsShow(true, 'Listing Field "' . $reCheck->fields['listingfields_field_name'] . '" deleted');
            } else {
                $content = $this->OperationResultsShow(false, 'Listing Field "' . $reCheck->fields['listingfields_field_name'] . '" delete failed');
            }
        } else {
            $content = $this->OperationResultsShow(true, "Listing Field does not exist");
        }
        return $content . $this->ListListingFieldsShow();
    }

    private function ListListingFieldsShow() {
        global $config, $dbClass, $formsClass, $UrlClass, $presentationClass;
        $tab_fields = $this->GetListingFields();
//This will be the new field form invocation button link
        $newfieldurl = $config['adm_baseurl'] . "index.php?apage=listingfields&action=add_new_field";
        $content = "<button onclick='window.location.assign(\"$newfieldurl\")'  type='button' class='skin_colour round_all'><span><a href='$newfieldurl'>Add new field</a></span></button>";
        $content .= $formsClass->startform($config['adm_baseurl'] . "index.php?apage=listingfields&action=add_new_field");
        $pre_table_head = array('Name', 'Change name', 'Type', 'Caption', 'Required', '');
        $pre_table = array();
        for ($i = 0; $i < count($tab_fields); $i++) {
            $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_field_name='" . $tab_fields[$i] . "' LIMIT 1";
            $recordSet = $dbClass->Query($sql);
            if ($recordSet->recordCount() > 0) {
                $field_information = $recordSet->fields;
            } else {
                $field_information['listingfields_field_name'] = $tab_fields[$i];
                $field_information['listingfields_field_caption'] = "";
                $field_information['listingfields_field_elements'] = "";
                $field_information['listingfields_field_required'] = 0;
                $field_information['listingfields_rank'] = 0;
                $field_information['listingfields_section'] = "";
                $field_information['listingfields_tip'] = "";
                $field_information['listingfields_section_rank'] = 0;
                $field_information['listingfields_field_type'] = 'text';
            }
            if ($field_information['listingfields_field_type'] == '') {
                
            }
            if ($field_information['listingfields_field_required'] == 1) {
                $required_check = true;
            } else
                $required_check = false;
//$field_name = str_replace("listingsdb_","",$field_information['listingfields_field_name']);
            $field_name = $field_information['listingfields_field_name'];
            if (!in_array($field_information['listingfields_field_datatype'], $this->tab_select_datatype)) {
// $params='';
                if ($dbClass->ColumnExists($config['table_prefix'] . "listingsdb", $field_information['listingfields_field_name'], $params)) {
                    $field_information['listingfields_field_datatype'] = $params['type'];
                }
            }
            $edit_url = $config['adm_baseurl'] . "index.php?apage=listingfields&action=edit_field&edit_id=" . $field_information['listingfields_id'];
            $del_url = $config['adm_baseurl'] . "index.php?apage=listingfields&action=delete_field&del_id=" . $field_information['listingfields_id'];
            $options_col = "<a href='$edit_url'><img src='" . $config['wpradmin_baseurl'] . "images/pencil-small.png'></a>";
            if (!in_array($field_information['listingfields_field_name'], $this->nochange_fields_name))
                $options_col .= "<a href='$del_url' class='delbutton' onclick='return false' name='Delete this field?'><img src='" . $config['wpradmin_baseurl'] . "images/cross-button.png'></a>";
            $pre_table['table'][$i][] = $field_name . $formsClass->create_hidden('listingfields_field_name[]', $field_information['listingfields_field_name']);
            if (!in_array($field_information['listingfields_field_name'], $this->nochange_fields_name))
                $pre_table['table'][$i][] = $formsClass->create_text('listingfields_field_newname[]', $field_name, '');
            else
                $pre_table['table'][$i][] = $formsClass->create_text('', $field_name, array('disabled' => 'disabled'));
            $pre_table['table'][$i][] = $formsClass->create_select('listingfields_field_type[]', $field_information['listingfields_field_type'], '', $this->tab_select_type);
            $pre_table['table'][$i][] = $formsClass->create_text('listingfields_field_caption[]', $field_information['listingfields_field_caption'], '');
            $pre_table['table'][$i][] = $formsClass->create_select('listingfields_field_required[]', $field_information['listingfields_field_required'], '', array(0 => 'No', 1 => 'Yes'));
            $pre_table['table'][$i][] = $options_col;
//$pre_table['rank'][$i] = $field_information['listingfields_rank'];
        }
//array_multisort($pre_table['rank'],$pre_table['table']);
        $content .= $presentationClass->StandardTableWithDataNew($pre_table['table'], $pre_table_head, false, array('id' => 'listingfields_datatable', 'class' => 'wpr_form'));
        $content .= $formsClass->create_hidden('send_form', 'yes');
//$content .= $formsClass->create_submit('editsubmit','Edit',array('id'=>'editsubmit'));
        $edit_url = $UrlClass->AddUrlValues(array('page' => 'listingfields'));
        $content .= $formsClass->create_hidden('action_url', $edit_url);
        $content .= $formsClass->endform();
        return $content;
//return 'stub for full fields list';
    }

    private function ListingFieldExists($fieldID) {
        global $config, $dbClass;
        $sql = "SELECT listingfields_field_name FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_id='" . $fieldID . "'";
        $reCheck = $dbClass->query($sql);
        if ($reCheck->recordcount() > 0) {
            return true;
        }
        return false;
    }

    private function OperationResultsShow($result = false, $resultText = 'Operation Failed - Unspecified -> Contact Support') {
        global $presentationClass;
        if ($result) {
            return $presentationClass->OperationSuccessfull($resultText);
        } else {
            return $presentationClass->OperationFailed($resultText);
        }
    }

////////////////////////////////////////////////
//Entry point for the listingfields functions - now just an alias to preserve compat with core.inc
/////////////////////////////////////////////////
    function EditListingFieldsBackEnd($post_vars, $get_vars) {
        return $this->ListingFieldsAdminController($post_vars, $get_vars);
    }

    function GetFieldInfo($fid) {
        global $dbClass, $config;
        $sql = "SELECT * FROM " . $config['table_prefix'] . "listingsfields WHERE listingfields_id='" . $fid . "' LIMIT 1";
        $recordSet = $dbClass->Query($sql);
        if ($recordSet->recordCount() > 0) {
            $field_information = $recordSet->fields;
//$field_information['field_name'] = str_replace("listingsdb_","",$field_information['listingfields_field_name']);
            return $field_information;
        }
        return false;
    }

    function CheckAddEditField($request, $edit_id = false) {
        echo '<br>checkAddEditField<br>';
        //var_dump($request);
        global $dbClass, $config;
        $request = $dbClass->DataFiltersArray($request);
        $errors = "";
        if ($request['listingfields_field_name'] != "") {
//$field_name = "listingsdb_".$request['listingfields_field_name'];
            $field_name = $request['listingfields_field_name'];
            $request['listingfields_field_name'] = $field_name;
            if ($edit_id === false) {
                if ($dbClass->ColumnExists($config['table_prefix'] . "listingsdb", $field_name) !== false) {
                    $errors .= "Field already exists<br>";
                }
            } else {
                $fieldinfo = $this->GetFieldInfo($edit_id);
                if ($fieldinfo['listingfields_field_name'] != $field_name) {
                    if ($dbClass->ColumnExists($config['table_prefix'] . "listingsdb", $field_name) !== false) {
                        $errors .= "Field already exists<br>";
                    }
                }
            }
        } else {
            $errors .= "You must fill field name!<br>";
        }
        return $errors;
    }

    function AddEditListingField($request, $edit_id = false) {
        global $formsClass, $presentationClass, $config;
        $section_tab = array("" => "choose");
        if ($tmp = $this->GetListingFieldSection()) {
            $section_tab = array_merge($section_tab, $tmp);
        }
        if ($edit_id)
            $content = $formsClass->startform($config['adm_baseurl'] . "index.php?apage=listingfields&action=edit_field&edit_id=" . $edit_id);
        else
            $content = $formsClass->startform($config['adm_baseurl'] . "index.php?apage=listingfields&action=add_new_field"); /////////////////////////////////////////////Add Field Button - Submit new
        if ($edit_id === false OR ! in_array($request['listingfields_field_name'], $this->nochange_fields_name)) {
            $data_add[] = array("Field Name:", $formsClass->create_text('listingfields_field_name', $request['listingfields_field_name'], ''));
        } else
            $data_add[] = array("Field Name:", $formsClass->create_text('listingfields_field_name', $request['listingfields_field_name'], array('disabled' => 'disabled')));
        $data_add[] = array("Field Caption:", $formsClass->create_text('listingfields_field_caption', $request['listingfields_field_caption'], ''));
        $data_add[] = array("Field Type:", $formsClass->create_select('listingfields_field_type', $request['listingfields_field_type'], '', $this->tab_select_type));
        if ($edit_id === false)
            $data_add[] = array("Field DataType:", $formsClass->create_select('listingfields_field_datatype', $request['listingfields_field_datatype'], '', $this->tab_select_datatype));
        $data_add[] = array("Field Elements:", $formsClass->create_textarea('listingfields_field_elements', $request['listingfields_field_elements'], ''));
        $data_add[] = array("Field Section:", $formsClass->create_select('listingfields_section', $request['listingfields_section'], '', $section_tab));
        $data_add[] = array("Field Section Rank:", $formsClass->create_text('listingfields_section_rank', $request['listingfields_section_rank'], array('class' => 'small')));
        $data_add[] = array("Field Tip:", $formsClass->create_textarea('listingfields_tip', $request['listingfields_tip'], ''));
        $checked = false;
        if ($request['listingfields_field_required'] == '1')
            $checked = true;
        $data_add[] = array("Field Required:", $formsClass->create_checkbox('listingfields_field_required', '1', '', $checked));
        $content .= $presentationClass->BlockTable($data_add);
//$action_url = $UrlClass->AddUrlValues(array('page'=>$page_name,'action'=>'add_new_field'));
        $content .= $formsClass->create_hidden('isform', 'true');
        if ($edit_id !== false)
            $content .= $formsClass->create_submit('edit_field_submit', "Edit field");
        else
            $content .= $formsClass->create_submit('add_new_field_submit', "Add field", array(value => 'true'));
        $content .= $formsClass->endform();
//var_dump($content);
        return $content;
    }

# MasterDb parameter added

    function SearchField($field, $masterdb = false) {
        global $dbClass, $config;
# Field comparision was taking place with `listingfields_field_caption`, changed to listingfields_field_name
        $sql = "SELECT listingfields_field_name FROM `" . $config['table_prefix'] . "listingsfields` WHERE listingfields_field_name='" . $field . "'";
        $info = $dbClass->GetOneRow($sql, $masterdb);
        if ($info === false) {
            if (!$dbClass->ColumnExists($config['table_prefix'] . "listingsdb", $field)) {
                if ($dbClass->ColumnExists($config['table_prefix'] . "listingsdb", "listingsdb_" . $field)) {
                    return "listingsdb_" . $field;
                } else
                    return false;
            } else
                return $field;
        } else
            return $info['listingfields_field_name'];
    }

    function ParsePrice($price) {
        global $config;
        if ($price > 0 && strlen($price) > 0) {
            $tab_number_format_style = array(
                1 => "1,000",
                2 => "1.000,00",
                3 => "1 000.00",
                4 => "1 000,00",
                5 => "1'000,00",
                6 => "1-000 00");
            switch ($config['number_format_style']) {
                case 1:
                    $ret_price = number_format($price, 0);
                    break;
                case 2:
                    $ret_price = number_format($price, 2, ',', '.');
                    break;
                case 3:
                    $ret_price = number_format($price, 2, '.', ' ');
                    break;
                case 4:
                    $ret_price = number_format($price, 2, ',', ' ');
                    break;
                case 5:
                    $ret_price = number_format($price, 2, ',', '\'');
                    break;
                case 6:
                    $ret_price = number_format($price, 2, ' ', '-');
                    break;
            }
            if ($config['money_format'] == 1) {
                $ret_price = "&#36;" . $ret_price;
            }
            if ($config['money_format'] == 2) {
                $ret_price = $ret_price . "&#36;";
            }
            if ($config['money_format'] == 3) {
                $ret_price = "&#36;" . $ret_price;
            }
//$ret_price .= $tab_number_format_style[$config['number_format_style']][5]."00";
        } else
            $ret_price = '0';
        return $ret_price;
    }

    static private $field_caption_to_name_cache = array();

    function ReplaceListingFieldTags($listing_id, $param, &$rsListing = array()) {
        global $config, $dbClass;
        $return = false;
        if (isset($param['field'])) {
            $param['field'] = strtolower($param['field']);
            if (!array_key_exists($param['field'], self::$field_caption_to_name_cache)) {
                if ($param['field'] == 'class_id' OR $param['field'] == 'class_name') {
                    self::$field_caption_to_name_cache[$param['field']] = $param['field'];
                } else {
# MasterDb parameter added
                    self::$field_caption_to_name_cache[$param['field']] = strtolower($this->SearchField($param['field'], $param['masterdb']));
                }
            }
//echo "<pre> in ReplaceListingFieldTags function <br>";
//print_r($param);
//print_r($rsListing);
//echo "</pre>";
            $field = self::$field_caption_to_name_cache[$param['field']];
//echo "<br>field : ". $field;
            if (empty($rsListing)) {
                $sql = "SELECT l.*,c.* FROM " . $config['table_prefix'] . "listingsdb l
LEFT JOIN " . $config['table_prefix'] . "class c ON l.class_id=c.class_id
WHERE listingsdb_id='$listing_id'";
//echo "<br><br> ==> ". $sql;
                $row = $dbClass->Query($sql, $param['masterdb']);
//print_r($row);
// $row =  $dbClass->Query($sql,isset($param['masterdb'])?$param['masterdb']:false);
                if ($row->recordCount() > 0) {
                    foreach ($row->fields as $key => $value) {
                        if ($value === '0')
                            continue;
                        $rsListing[strtolower($key)] = $value;
                    }
                }
            }
            if (isset($rsListing[$field])) {
// Escaping $ char
                $return = preg_replace('/\$/', '&#36;', $rsListing[$field]);
            }
            if ($field == $this->price_field) {
                $return = $this->ParsePrice($return);
            }
        }
        return $return;
    }

    /** FIELD ZONES */
    function GetListingFieldsToZone() {
        global $dbClass, $config;
        $sql = "SELECT * FROM `" . $config['table_prefix'] . "listingsfields`";
# RemoteDb flag added
        return $dbClass->GetResults($sql, false, $masterdb = true);
    }

    function GetFieldFromSection($section = "") {
        global $dbClass, $config;
        $sql = "SELECT * FROM `" . $config['table_prefix'] . "listingsfields` WHERE listingfields_section='" . $section . "' ORDER BY listingfields_section_rank";
# RemoteDb flag added
        return $dbClass->GetResults($sql, false, $masterdb = true);
//return $dbClass->GetResults($sql);
    }

    function ListingFieldZonesBackEnd($post_vars, $get_vars) {
        global $jqueryscript, $formsClass, $dbClass, $config;
//$sections = array('headline','top_left','top_right','center','feature1','feature2');
        $controlPanel = registry::register('controlpanelClass');
        if (isset($post_vars['listing_template_section_save'])) {
            $controlPanel->UpdateControlPanel($post_vars);
        }
        $settings = $controlPanel->GetControlPanelFields();
        $sections = false;
        if ($settings['controlpanel_listing_template_section'] != "") {
            $tmp_sections = explode(",", $settings['controlpanel_listing_template_section']);
            $not_in = "";
            $sections = array();
            for ($i = 0; $i < count($tmp_sections); $i++) {
                $not_in .= "'" . trim($tmp_sections[$i]) . "',";
                $sections[] = trim($tmp_sections[$i]);
            }
            $not_in = substr($not_in, 0, -1);
        }
        if ($sections === false) {
            $sql = "UPDATE `" . $config['table_prefix'] . "listingsfields` SET listingfields_section ='',listingfields_section_rank='0'";
            $dbClass->Query($sql);
        } else {
            $sql = "UPDATE `" . $config['table_prefix'] . "listingsfields` SET listingfields_section ='',listingfields_section_rank='0' WHERE listingfields_section NOT IN ($not_in)";
            $dbClass->Query($sql);
        }
        if (isset($post_vars['save_zone'])) {
            $sql = "UPDATE `" . $config['table_prefix'] . "listingsfields` SET listingfields_section ='',listingfields_section_rank='0'";
            $dbClass->Query($sql);
            $reg_correct = "#^(\d+)_(\d+)$#";
            $cnt_section = 0;
            $cnt_rank = 0;
            for ($i = 0; $i < count($post_vars['field']); $i++) {
                $field = $post_vars['field'][$i];
                if (preg_match($reg_correct, $field, $match)) {
                    if ($match[2] > $cnt_section) {
                        $cnt_section = $match[2];
                        $cnt_rank = 0;
                    }
                    $sql = "UPDATE `" . $config['table_prefix'] . "listingsfields`
SET listingfields_section ='" . $sections[$match[2]] . "',listingfields_section_rank='" . $cnt_rank . "'
WHERE listingfields_id = '" . $match[1] . "'
";
                    $cnt_rank++;
                    $dbClass->Query($sql);
                }
            }
        }
        $fields = $this->GetFieldFromSection();
        $content = "<form method='post'>";
        $content .= '<div class="box grid_16 round_all">
<h2 class="box_head grad_colour">Create Listing Template Zones:</h2>
<a class="grabber" href="#">&nbsp;</a>
<a class="toggle" href="#">&nbsp;</a>
<div class="toggle_container">
<div class="block">
<div class="wpr-note"><strong>Adding Listing Field Zones Example:</strong>&nbsp;headline,remarks,interior,exterior, etc.&nbsp;<strong>Add your "zones" using comma, seperated values.</strong></div>' .
                "<div style='float:left'>" . $formsClass->create_text('controlpanel_listing_template_section', $settings['controlpanel_listing_template_section'], array('size' => 110)) . "</div><div style='float:right'>" . $formsClass->create_submit('listing_template_section_save', 'Save') . "</div></div></div></div><div style='clear:both'></div></form>";
        $content .= '
<div class="box grid_10">
<h2 class="box_head grad_colour">Available Fields</h2>
<div id="file_tree" class="block" style="overflow: hidden;"><ul class="sections_draggable connectsortable">';
        for ($i = 0; $i < count($fields); $i++) {
            $content .= "<li><input type='hidden' name='field[]' value='" . $fields[$i]['listingfields_id'] . "'>" . $fields[$i]['listingfields_field_name'] . "</li>";
        }
        $content .= '
</ul></div>
</div>
<div class="box grid_6 round_all">
<h2 class="box_head grad_colour">Adding Fields To Zones:</h2>
<a class="grabber" href="#">&nbsp;</a>
<a class="toggle" href="#">&nbsp;</a>
<div class="toggle_container">
<div class="block">
<div class="wpr-note"><strong>Add listing fields from the "Available Fields" by draging the fields into the desired zone.</strong><br><br> Once all your fields are in the zones then A-Z sort them and then drag and drop within the zone to achive desired layout and save.<br><br>To add a zone to your listing details template simply copy and paste the {zone-name}into your template including the brackets {}</div></div></div></div>
<div class="flat_area grid_6" style="float:right">
<form method="post" id="form_zones">
<ul class="block content_accordion no_header">';
        for ($i = 0; $i < count($sections); $i++) {
            $content .= '
<li> <a href="#" class="handle">&nbsp;</a>
<h3 class="bar" >{' . $sections[$i] . '}</h3>
<div class="content">
<a href="#" onclick="return false" class="sortaz">Sort Order A-Z</a>
<ul class="sections_sortable connectsortable" id="section_' . $i . '">';
            if ($s_fields = $this->GetFieldFromSection($sections[$i])) {
                for ($y = 0; $y < count($s_fields); $y++) {
                    $content .= "<li><input type='hidden' name='field[]' value='" . $s_fields[$y]['listingfields_id'] . "'>" . $s_fields[$y]['listingfields_field_name'] . "</li>";
                }
            }
            $content .= '</ul>
</div>
</li>';
        }
        $content .= '</ul>' . $formsClass->create_hidden('save_zone', '1') . '
</form></div>';
        $content .= $formsClass->create_button('', 'Save', array('id' => 'save_zone', 'onclick="return false"'));
        $jqueryscript->AddJqueryScriptEnd('
jQuery(".sections_draggable, .sections_sortable").sortable({
connectWith: ".connectsortable",
opacity: 0.4,
tolerance: "pointer",
placeholder: "place_holder",
revert: true
});
jQuery("#save_zone").click(function()
{
var reg = /section_(\d+)/;
jQuery(".sections_sortable").each(function()
{
if(res = reg.exec(jQuery(this).attr("id")))
{
jQuery("#"+res[0]+" input[type=hidden]").each(function()
{
jQuery(this).attr("value",jQuery(this).attr("value")+"_"+res[1]);
});
}
});
jQuery("#form_zones").submit();
});
jQuery(".sortaz").click(function()
{
var table_reminder = new Array();
var table_sort = new Array();
var sortable_handle = jQuery(this).next(".sections_sortable");
var cnt=0;
sortable_handle.children("li").each(function()
{
table_reminder[jQuery(this).text()] = jQuery(this).html();
table_sort[cnt] = jQuery(this).text();
cnt++;
});
table_sort.sort();
newli = ""
for(i=0;i<table_sort.length;i++)
{
newli += "<li>"+table_reminder[table_sort[i]]+"</li>";
}
sortable_handle.html(newli);
});
');
        $content .= '';
        return $content;
    }

    /*     * **********************************************************\
     * WPRRETS - return key value array, listingfields_field_name
     * as key & listingfields_field_caption as value
      \*********************************************************** */

    function getKeyValueArray() {
        global $dbClass, $config;
        $sql = "SELECT listingfields_field_name, listingfields_field_caption FROM `" . $config['table_prefix'] . "listingsfields` ORDER BY listingfields_field_name ";
        $reC = $dbClass->query($sql);
        $arr = array();
        if ($reC->RecordCount() > 0) {
            while (!$reC->EOF) {
                $arr[$reC->fields['listingfields_field_name']] = $reC->fields['listingfields_field_caption'] ? $reC->fields['listingfields_field_caption'] : $reC->fields['listingfields_field_name'];
                $reC->MoveNext();
            }
        }
        return $arr;
    }

}

// END class ListingFields
?>