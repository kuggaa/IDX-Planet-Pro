<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class loginClass {
var $template_file;
var $remember_expire; //7 days;
function __construct() {
global $config;
$this->template_file = $config['wpradmin_basepath'] . "atheme/login.tpl";
$this->remember_expire = (7 * 24 * 3600);
}
function CheckLogin($md5 = false) {
global $dbClass, $config;
$sess_vars = $dbClass->DataFiltersArray($_SESSION);
if (!isset($sess_vars['wprealty_login']) OR ! isset($sess_vars['wprealty_password'])) {
if (!isset($_COOKIE['wprealty_login']) OR ! isset($_COOKIE['wprealty_password'])) {
return false;
} else {
if ($this->CheckLoginInBase($_COOKIE['wprealty_login'], $_COOKIE['wprealty_password'], $md5)) {
$this->SaveDataInSession($_COOKIE['wprealty_login'], $_COOKIE['wprealty_password']);
$this->SetRememberCookies($_COOKIE['wprealty_login'], $_COOKIE['wprealty_password']);
require_once($config['wpradmin_basepath'] . "include/users.inc.php");
$usersClass = registry::register('usersClass');
$user_id = $usersClass->CheckUserName($_COOKIE['wprealty_login']);
return $usersClass->GetUserInfo($user_id);
} else {
return false;
}
}
} else {
if ($this->CheckLoginInBase($sess_vars['wprealty_login'], $sess_vars['wprealty_password'], $md5)) {
require_once($config['wpradmin_basepath'] . "include/users.inc.php");
$usersClass = registry::register('usersClass');
$user_id = $usersClass->CheckUserName($sess_vars['wprealty_login']);
return $usersClass->GetUserInfo($user_id);
} else {
return false;
}
}
}
function GenerateHash($login, $password) {
global $config, $dbClass;
$sql = "SELECT * FROM " . $config['table_prefix'] . "users WHERE user_username='" . $login . "'";
$reCheck = $dbClass->Query($sql);
if ($reCheck->recordCount() > 0) {
$path = preg_replace('#(wp-content.*)#', '', $config['wpradmin_basepath']);
require_once($path . 'wp-includes/class-phpass.php');
$wp_hasher = new PasswordHash(8, TRUE);
if ($hash_password = $wp_hasher->CheckPassword($password, $reCheck->fields['user_password']))
return $reCheck->fields['user_password'];
} else
return false;
}
function CheckLoginInBase($login, $password, $md5 = true) {
global $dbClass, $config;
if ($md5 === true) {
}
if ($md5 === true)
$sql = "SELECT * FROM " . $config['table_prefix'] . "users WHERE user_username='" . $login . "' AND user_password='" . $this->GenerateHash($login, $password) . "'";
else
$sql = "SELECT * FROM " . $config['table_prefix'] . "users WHERE user_username='" . $login . "' AND user_password='" . $password . "'";
$reCheck = $dbClass->Query($sql);
if ($reCheck->recordCount() > 0) {
return true;
} else
return false;
}
function SaveDataInSession($login, $password = false, $md5 = true) {
$_SESSION['wprealty_login'] = $login;
if ($password !== false) {
if ($md5 === true)
$password = $this->GenerateHash($login, $password);
$_SESSION['wprealty_password'] = $password;
}
//die('here');
}
function GetLoginPost($post_vars, &$info = "", $md5 = false) {
global $dbClass, $config;
//$post_vars = $dbClass->DataFiltersArray($_POST);
$info = "";
if (isset($post_vars['wprealty_submit'])) { // Using a "1" in ajax combined sender
if (isset($post_vars['wprealty_login']) AND isset($post_vars['wprealty_password'])) {
if ($this->CheckLoginInBase($post_vars['wprealty_login'], $post_vars['wprealty_password'], $md5)) {
$this->SaveDataInSession($post_vars['wprealty_login'], $post_vars['wprealty_password'], $md5);
//return var_export($_SESSION);
if (isset($post_vars['wprealty_remember'])) {
$this->SetRememberCookies($post_vars['wprealty_login'], $post_vars['wprealty_password']);
}
return true;
} else {
$info = "Username or password incorrect";
return false;
}
}
} else {
return false;
}
}
function GetRegisterPost(&$info = "", $captcha = false) { // $info is errors using ref to get back errors
global $dbClass, $config;
$post_vars = $dbClass->DataFiltersArray($_POST);
$info = "";
require_once($config['wpradmin_basepath'] . "include/users.inc.php");
$usersClass = registry::register('usersClass');
if (isset($post_vars['register_submit']) && $post_vars['register_submit'] != 0) { // Using "1" in ajax combined sender
if ($info = $usersClass->CheckAddEditUserForm($post_vars, $captcha)) { // Means if no errors on the array
return false;
} else {
return TRUE;
}
} else
return false;
}
function SetRememberCookies($login, $password) {
setcookie('c_wprealty_login', $login, time() + $this->remember_expire);
setcookie('c_wprealty_password', $password, time() + $this->remember_expire);
}
function ShowLoginForm($info = "", $template = false) {
global $formsClass, $dbClass, $config;
if ($template === false or $template == null)
$template_src = $this->template_file;
else
$template_src = $template;
if ($template = @file_get_contents($template_src)) {
$template = str_replace("{loginformstart}", $formsClass->startform($action), $template);
$template = str_replace("{loginform_login}", $formsClass->create_text('wprealty_login', ''), $template);
$template = str_replace("{loginform_password}", $formsClass->create_password('wprealty_password', ''), $template);
$template = str_replace("{loginform_remember}", $formsClass->create_checkbox('wprealty_remember', '1'), $template);
$template = str_replace("{loginform_submit}", $formsClass->create_submit('wprealty_submit', 'Log In!'), $template);
$template = str_replace("{loginform_info}", $info, $template);
$template = str_replace("{loginformend}", $formsClass->endform(), $template);
$template = str_replace("{wpr_baseurl}", $config['wpradmin_baseurl'], $template);
return $template;
} else
$content = "Template not exists";
return $content;
}
function ShowRegisterForm($info = "", $request, $template = false) {
global $formsClass, $dbClass, $config;
if ($template === false)
$template_src = $this->template_file;
else
$template_src = $template;
if ($template = @file_get_contents($template_src)) {
$template = str_replace("{registerformstart}", $formsClass->startform() . $formsClass->create_hidden('request', $request['request']), $template);
$template = str_replace("{registerform_login}", $formsClass->create_text('username', $request['username']), $template);
$template = str_replace("{registerform_inforegister}", $info, $template);
$template = str_replace("{registerform_password}", $formsClass->create_password('password', ''), $template);
$template = str_replace("{registerform_password_again}", $formsClass->create_password('password_rep', ''), $template);
$template = str_replace("{registerform_firstname}", $formsClass->create_text('firstname', $request['firstname']), $template);
$template = str_replace("{registerform_lastname}", $formsClass->create_text('lastname', $request['lastname']), $template);
$template = str_replace("{registerform_email}", $formsClass->create_text('email', $request['email']), $template);
$template = str_replace("{registerform_phone}", $formsClass->create_text('phone', $request['phone']), $template);
$template = str_replace("{registerform_mobile}", $formsClass->create_text('mobile', $request['mobile']), $template);
$template = str_replace("{registerform_fax}", $formsClass->create_text('fax', $request['fax']), $template);
$template = str_replace("{registerform_homepage}", $formsClass->create_text('homepage', $request['homepage']), $template);
$captcha_url = $config['wpr_baseurl'] . "ajax.php?f=captcha.php'";
$captcha_img = "<img src='" . $captcha_url . "' /><br/>";
$template = str_replace("{registerform_captcha}", $captcha_img . $formsClass->create_text('register_captcha', $request['register_captcha']), $template);
$template = str_replace("{registerform_info}", $formsClass->create_textarea('info', $request['info']), $template);
$template = str_replace("{registerform_submit}", $formsClass->create_submit('register_submit', 'Register'), $template);
$template = str_replace("{registerformend}", $formsClass->endform(), $template);
return $template;
} else
$content = "Template not exists";
return $content;
}
function LogOut() {
unset($_SESSION['wprealty_login']);
unset($_SESSION['wprealty_password']);
setcookie('c_wprealty_login', "", time() - $this->remember_expire);
setcookie('c_wprealty_password', "", time() - $this->remember_expire);
}
}
?>