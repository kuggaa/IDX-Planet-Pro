<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
class ContactFormClass{
protected $wprcontact_content_base;
protected $wprcontact_fields_base;
protected $wprcontact_message_base;
protected $wprcontact_affilation_base;
protected $users_base;
protected $wprcontact_smsgateways_base;
protected $wprcontact_agents_base;
protected $tab_field_type = array(
'text'=>'Text',
'name'=>'Name',
'email'=>'E-mail',
'captcha'=>'Captcha',
'textarea'=>'Text Area',
'radio'=>'Radio button',
'checkbox'=>'Checkbox',
'select'=>'Select'
);
/************************************************************\
*
\************************************************************/
function __construct()
{
global $config;
$this->wprcontact_content_base = $config['table_prefix']."wprcontactcontent";
$this->wprcontact_fields_base = $config['table_prefix']."wprcontactfields";
$this->wprcontact_message_base = $config['table_prefix']."wprcontactmessages";
$this->wprcontact_affilation_base = $config['table_prefix']."wprcontactaffiliation";
$this->users_base = $config['table_prefix']."users";
$this->wprcontact_smsgateways_base = $config['table_prefix']."wprcontactsmsgateways";
$this->wprcontact_agents_base  = $config['table_prefix']."wprcontactagents";
}
/************************************************************\
*
\************************************************************/
function GetFormIDByName($name)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_content_base." WHERE form_name='".$name."'";
$reCheck = $dbClass->Query($sql);
if($reCheck->RecordCount()>0){
return $reCheck->fields['id'];
}
else
return false;
}
/************************************************************\
*
\************************************************************/
function GenerateContactForm($params,$listing_id=false)
{
global $config,$dbClass;
require_once($config['wpradmin_basepath']."include/forms.inc.php");
$formsClass = registry::register('FormsClass');
if(!isset($params['id']))
{
if(isset($params['name']))
{
if(!$form_id = $this->GetFormIDByName($params['name']))
return false;
}
else
return false;
}
else
$form_id = $params['id'];
$template  = stripslashes($this->GetPHPtemplate($form_id));
if($template == "")
{
$template = $this->GenerateTemplatePHP($form_id);
$this->SavePHPtemplate($template,$form_id);
}
$request = $_POST;
$validate = "";
if(isset($_POST['formsubmit']))
{
//if errors
$info_errors = "";
if($errors = $this->CheckForm($form_id,$request))
{
$request = $dbClass->stripslashesarray($_POST);
for($i=0;$i<count($errors['empty']);$i++)
$info_errors .= $errors['empty'][$i]." is empty!<br/>";
for($i=0;$i<count($errors['invalid']);$i++)
$info_errors .= $errors['invalid'][$i]." is invalid!<br/>";
$validate .= $info_errors;
} else {
$request = $dbClass->DataFiltersArray($_POST);

$last_message_id = $this->InsertMessageToBase($form_id,$request);
//var_dump($last_message_id.'mmm');
if($last_message_id)
{
unset($request);
$validate .= "Form sent<br/>";
if($this->SendMailToAgent($last_message_id))
{
$validate .= "Mail sent<br/>";
}
if($this->SendSMSToAgent($last_message_id))
{
$validate .= "Mail sent<br/>";
}
}
else
{
$validate .= "Form sent failed";

}
}
}
$template = str_replace("{wprcontactform_".$form_id."_validate}",$validate,$template);
$css = "<style>".$this->GetCSStemplate($form_id)."</style>";
if($form_info = $this->GetContactFormInfo($form_id))
{
if(!isset($request['formsubject']))
$request['formsubject'] = $form_info['generic_subj'];
if(!isset($request['formmessage']))
$request['formmessage'] = $form_info['generic_msg'];
}
$template = str_replace("{wprcontactform_css}",$css,$template);
$template = str_replace("{wprcontactform_submit}",$formsClass->create_submit('formsubmit','Send'),$template);
$template = str_replace("{wprcontactform_message}",$formsClass->create_textarea('formmessage',$request['formmessage'],array('id'=>"form_".$form_id.'_formmessage')),$template);
$template = str_replace("{wprcontactform_subject}",$formsClass->create_text('formsubject',$request['formsubject'],array('id'=>"form_".$form_id.'_formsubject')),$template);
$reg_field = "#{wprcontactform_field_(\w+)}#";
if(preg_match_all($reg_field,$template,$matches))
{
for($i=0;$i<count($matches[0]);$i++)
{
if($field_info = $this->GetContactFormFieldInfo($form_id,$matches[1][$i]))
{
$params = array('id'=>"form_".$form_id."_".$field_info['standard_name']);
if($field_info['field_type']=='name')
{
$replacement = $formsClass->GenerateField('text',"form_".$form_id."_".$field_info['standard_name'],$request["form_".$form_id."_".$field_info['standard_name']],$field_info['field_elements'],$request,'normal',$params);
}
elseif($field_info['field_type']=='email')
{
$replacement = $formsClass->GenerateField('text',"form_".$form_id."_".$field_info['standard_name'],$request["form_".$form_id."_".$field_info['standard_name']],$field_info['field_elements'],$request,'normal',$params);
}
elseif($field_info['field_type']=='captcha')
{
$replacement = "<img src='".$config['wpr_baseurl']."ajax.php?f=captcha.php'>
<br/>".$formsClass->GenerateField('text',"form_".$form_id."_".$field_info['standard_name'],$request["form_".$form_id."_".$field_info['standard_name']],$field_info['field_elements'],$request,'normal',$params);
} else
{
$replacement = $formsClass->GenerateField($field_info['field_type'],"form_".$form_id."_".$field_info['standard_name'],$request["form_".$form_id."_".$field_info['standard_name']],$field_info['field_elements'],$request,'explode',$params);
}
$template = str_replace($matches[0][$i],$replacement,$template);
}
}
}
return $template;
}
/************************************************************\
*
\************************************************************/
function  checkEmail($email) {
if (!preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/" , $email)) {
return false;
}
return true;
}
/************************************************************\
*
\************************************************************/
public function SendMailToAgent($id)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_message_base." WHERE id=".$id;
$reMessage = $dbClass->Query($sql);
if($reMessage->recordCount()>0)
{
if(is_numeric($reMessage->fields['recipient']))
{
$sql_mailto = "SELECT * FROM ".$this->users_base." WHERE user_id=".$reMessage->fields['recipient'];
$reMailto = $dbClass->Query($sql_mailto);
if($reMailto->recordCount()>0)
{
$mailto = $reMailo->fields['email'];
$header = 	"From: ".$reMessage->fields['sender_name']."<".$reMessage->fields['sender_email']."> \n";
}
}
else
$mailto = $reMessage->fields['recipient'];
if(mail($mailto,$reMessage->fields['subject'],$reMessage->fields['message'],$header))
{
return True;
}
else
{
return False;
}
}
else
return False;
}
/************************************************************\
*
\************************************************************/
function SendSMSToAgent($id)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_message_base." WHERE id=".$id;
$reMessage = $dbClass->Query($sql);
if($reMessage->recordCount()>0)
{
if(is_numeric($reMessage->fields['recipient']))
{
$sql_agent = "SELECT * FROM ".$this->wprcontact_agents_base." WHERE agent_id=".$reMessage->fields['recipient'];
$reAgent = $dbClass->Query($sql_agent);
if($reAgent->recordCount()>0)
{
if($reAgent->fields['use_sms']==1)
{
$first = $reAgent->fields['cell_number'];

$sql = "SELECT * FROM ".$this->wprcontact_smsgateways_base." WHERE id=".$reAgent->fields['carrier_id'];
$reCarrier = $dbClass->Query($sql);
if($reCarrier->recordCount()>0)
{
$mailto = $first."@".$reCarrier->fields['domain'];
if(mail($mailto,$subject,$message))
{
return True;
}
}
}
}
}
}
return False;
}
/************************************************************\
*
\************************************************************/
function CheckForm($form_id,$request){
if($fields_info = $this->GetContactFormFieldsInfo($form_id))
{
$errors = array();
for($i=0;$i<count($fields_info);$i++)
{
if($fields_info[$i]['field_type']=='name')
{
if($fields_info[$i]['field_required'] AND $request["form_".$form_id."_".$fields_info[$i]['standard_name']]=="")
$errors['empty'][] = $fields_info[$i]['field_name'];
}
elseif($fields_info[$i]['field_type']=='email')
{
if($fields_info[$i]['field_required'] AND $request["form_".$form_id."_".$fields_info[$i]['standard_name']]=="")
$errors['empty'][] = $fields_info[$i]['field_name'];
elseif(($fields_info[$i]['field_required']) AND ($this->checkEmail($request["form_".$form_id."_".$fields_info[$i]['standard_name']])===false))
$errors['invalid'][] = $fields_info[$i]['field_name'];
}
elseif($fields_info[$i]['field_type']=='captcha')
{
if($fields_info[$i]['field_required'] AND (md5(strtolower($request["form_".$form_id."_".$fields_info[$i]['standard_name']]))!=$_SESSION['captcha']))
{
$errors['invalid'][] = $fields_info[$i]['field_name'];
}
} else
{
if($fields_info[$i]['field_required'] AND $request["form_".$form_id."_".$fields_info[$i]['standard_name']]=="")
$errors['empty'][] = $fields_info[$i]['field_name'];
}
}
$form_info = $this->GetContactFormInfo($form_id);
if($request['formmessage']=="" AND $form_info['message_hide']==0)
$errors['empty'][] = "Message";
if($request['formsubject']=="" AND $form_info['subject_hide']==0)
$errors['empty'][] = "Subject";
if(count($errors['empty'])>0 OR count($errors['invalid'])>0)
return $errors;
else
return false;
}
}
/************************************************************\
*
\************************************************************/
function InsertMessageToBase($form_id,$request){
global $dbClass;
$form_info = $this->GetContactFormInfo($form_id);
$form_fields_info = $this->GetContactFormFieldsInfo($form_id);

$added_fields = "";
$sender_name = array();
$sender_email = "";
for($i=0;$i<count($form_fields_info);$i++)
{
if($form_fields_info[$i]['standard_field']!=3)
{
if($form_fields_info[$i]['standard_field']==1)
$sender_name[] = $request["form_".$form_id."_".$form_fields_info[$i]['standard_name']];
if($form_fields_info[$i]['standard_field']==2)
$sender_email = $request["form_".$form_id."_".$form_fields_info[$i]['standard_name']];
$added_fields .= $form_fields_info[$i]['field_name'].": ".$request["form_".$form_id."_".$form_fields_info[$i]['standard_name']]."\n";
}
}
$sender_name = implode(" ",$sender_name);
if($form_info['message_hide']==1)
$request['formmessage'] = $form_info['generic_msg'];
if($form_info['subject_hide']==1)
$request['formsubject'] = $form_info['generic_subj'];
if($form_info['generic_email']!="")
{
$recipient = $form_info['generic_email'];
}
else
{
if(!$recipient = $this->CheckAffilation($sender_email))
{
if(!is_numeric($form_info['last_userid']))
$form_info['last_userid'] = 0;
/************************************************************\
*
\************************************************************/
$sql = "SELECT * FROM ".$this->wprcontact_agents_base." WHERE agent_id>".$form_info['last_userid']." AND receive_leads='1' LIMIT 1";
$reCheck = $dbClass->Query($sql);
if($reCheck->RecordCount()>0)
{
$agent_id = $reCheck->fields['agent_id'];
} else
{
$sql = "SELECT * FROM ".$this->wprcontact_agents_base." WHERE agent_id>0 AND receive_leads='1' LIMIT 1";
$reCheck = $dbClass->Query($sql);
if($reCheck->RecordCount()>0)
{
$agent_id = $reCheck->fields['agent_id'];
}
else
$agent_id = 'null';
}
if($agent_id!='null')
{
if(!$this->InsertAffilation($sender_email,$agent_id))
$recipient = 'null';
else
{
$recipient = $agent_id;
$sql = "UPDATE ".$this->wprcontact_content_base." SET last_userid='".$recipient."' WHERE id='".$form_id."'";
$dbClass->Query($sql);
}
}
else
$recipient = 'null';
}
}
$message = $added_fields."\n\n".$request['formmessage'];
$sql = "INSERT INTO ".$this->wprcontact_message_base." SET
form_id='$form_id',
sender_name ='$sender_name',
sender_email ='$sender_email',
subject = '".$request['formsubject']."',
message = '".$message."',
sent = '".time()."',
recipient = '$recipient'";

$rs = $dbClass->Query($sql);
//var_dump($dbClass->LastID());
if($rs->res === true)
{
return $dbClass->LastID();
}
else
{
return false;
}

}
/************************************************************\
*
\************************************************************/
function CheckAffilation($sender_email)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_affilation_base." WHERE user_mail='".$sender_email."'";
$reCheck = $dbClass->Query($sql);
if($reCheck->RecordCOunt()>0)
{
return $reCheck->fields['agent_id'];
}
else
return false;
}
/************************************************************\
*
\************************************************************/
function InsertAffilation($sender_email,$agent_id)
{
global $dbClass;
$sql = "INSERT INTO ".$this->wprcontact_affilation_base." SET user_mail='".$sender_email."',agent_id='$agent_id'";
if($dbClass->Query($sql))
return $dbClass->LastID();
else
return false;
}
/************************************************************\
*
\************************************************************/
function GetContactFormFieldInfo($form_id,$field)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_fields_base." WHERE wprcontact_id='$form_id' AND standard_name='$field' LIMIT 1";
$reInfo = $dbClass->Query($sql);
if($reInfo->RecordCount()>0)
{
return $reInfo->fields;
}
else
return false;
}
/************************************************************\
*
\************************************************************/
function GetContactForms()
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_content_base;
$reCF = $dbClass->Query($sql);
if($reCF->RecordCount()>0)
{
$ret_tab = array();
while(!$reCF->EOF)
{
$ret_tab[] = $reCF->fields;
$reCF->MoveNext();
}
if(count($ret_tab))
return $ret_tab;
}
return false;
}
/************************************************************\
*
\************************************************************/
function CreateStandardField()
{
global $dbClass;
$sql = "SELECT * FROM `".$this->wprcontact_fields_base."` WHERE field_type='name' AND wprcontact_id=0";
if(!$dbClass->GetOneRow($sql))
{
$sql = "INSERT INTO `".$this->wprcontact_fields_base."`
SET
field_name='Name',
field_type='name',
field_required='1',
wprcontact_id=0";
$dbClass->Query($sql);
}
$sql = "SELECT * FROM `".$this->wprcontact_fields_base."` WHERE field_type='email' AND wprcontact_id=0";
if(!$dbClass->GetOneRow($sql))
{
$sql = "INSERT INTO `".$this->wprcontact_fields_base."`
SET
field_name='Email',
field_type='email',
field_required='1',
wprcontact_id=0";
$dbClass->Query($sql);
}
}
/************************************************************\
*
\************************************************************/
function AddEditField($request,$cfid=0,$fid=false)
{
global $dbClass;
if($fid===false)
$sql = "INSERT INTO `".$this->wprcontact_fields_base."` SET ";
else
$sql = "UPDATE `".$this->wprcontact_fields_base."` SET ";
$sql .= "field_name='".$request['field_name']."',
standard_name='".$this->CreateStandardName($request['field_name'])."',
field_type='".$request['field_type']."',
field_elements='".$request['field_elements']."',
field_required='".$request['field_required']."',
wprcontact_id='".$cfid."'";
if($fid!==false)
$sql .= " WHERE id='".$fid."'";
return $dbClass->Query($sql);
}
/************************************************************\
*
\************************************************************/
function GenerateFieldsTable($edit_id)
{
global $UrlClass,$presentationClass,$formsClass,$jqueryscript,$config;
if($field_tab = $this->GetContactFormFieldsInfo($edit_id))
{
for($i=0;$i<count($field_tab);$i++)
{
$tab_field[$i][] = $formsClass->create_hidden('field_id[]',$field_tab[$i]['id']).
$formsClass->create_text('field_name[]',$field_tab[$i]['field_name']);
$tab_field[$i][] = $formsClass->create_select('field_type[]',$field_tab[$i]['field_type'],'',$this->tab_field_type);
$tab_field[$i][] = $formsClass->create_text('field_elements[]',$field_tab[$i]['field_elements']);
$tab_field[$i][] = $formsClass->create_select('field_required[]',$field_tab[$i]['field_required'],'',array(0=>'No',1=>'Yes'));
//$editfield_url = $base."&cfaction=editfield&fid=".$field_tab[$i]['id'];
$delfield_url = $base."&cfaction=delfield&fid=".$field_tab[$i]['id'];
$options = "<a href='$delfield_url' class='del_field' onclick='return false'><img src='".$config['wpradmin_baseurl']."images/cross-button.png'></a>";
$tab_field[$i][] = $options;
}
}
$headers = array("Field Name","Field Type","Field Elements","Required");
return $presentationClass->StandardTableWithDataNew($tab_field,$headers,$footer,array('id'=>'contactformtable'),true);
}
/************************************************************\
*
\************************************************************/
function AddEditContactForm($request,$edit_id=false,$select=false){
global $UrlClass,$presentationClass,$formsClass,$jqueryscript,$config;
$content = "";
$back = $config['adm_baseurl']."index.php?apage=cf_forms";
$content .= "<a href='$back' class='top_href'><button class='skin_colour round_all'><img width='24' height='24' src='/wp-content/plugins/wp-realty/core/images/icons/small/white/bended_arrow_left.png'><span>Back</span></button></a>";
if($edit_id!==false)
{
$base = $config['adm_baseurl']."index.php?apage=cf_forms&action=edit_form&edit_id=".$edit_id;
$jq_headers = array(
"formdetails"=>"Form Details",
"formfields"=>"Form Fields",
"templates"=>"Templates"
);
$js_add = '+"&edit_id='.$edit_id.'"';
} else {
$base = $config['adm_baseurl']."index.php?apage=cf_forms&action=add_form";
$jq_headers = array(
"formdetails"=>"Form Details",
"formfields"=>"Form Fields",
);
$js_add = "";
}
$content .= $formsClass->startform();
$tab[] = array("Form name:",$formsClass->create_text('form_name',$request['form_name'],array('id'=>'form_name')));
$tab[] = array("To Address:",$formsClass->create_text('generic_email',$request['generic_email']));
$tab[] = array("CC:",$formsClass->create_text('generic_cc',$request['generic_cc']));
$tab[] = array("Subject:",$formsClass->create_text('generic_subj',$request['generic_subj'],'',false,true));
$tab[] = array("Message:",$formsClass->create_textarea('generic_msg',$request['generic_msg']));
$tab[] = array("TY message:",$formsClass->create_text('thankyoumessage',$request['thankyoumessage']));
$tab[] = array("TY url:",$formsClass->create_text('thankyouurl',$request['thankyouurl']));
$tab[] = array("",$formsClass->create_checkbox('message_hide','1','',$request['message_hide'])." Hide message?");
$tab[] = array("",$formsClass->create_checkbox('subject_hide','1','',$request['subject_hide'])." Hide subject?");
$formdetails .= $presentationClass->StandardTableWithData($tab,false,false,array('class'=>'standardtable2col'));
if($edit_id===false)
{
$sql = $this->CreateStandardField();
}
$addfield = $base."&cfaction=addfield";
$addformfields .= "<table class='cellpadding5'><tr><td>Field Name: </td><td>".$formsClass->create_text('field_name','',array('id'=>'field_name'))."</td>";
$addformfields .= "<td>Field Type: </td><td>".$formsClass->create_select('','',array('id'=>'field_type'),$this->tab_field_type)."</td><tr>";
$addformfields .= "<tr><td>Field Elements: </td><td>".$formsClass->create_text('','',array('id'=>'field_elements'))."</td>";
$addformfields .= "<td>Field Required: </td><td>".$formsClass->create_select('','',array('id'=>'field_required'),array(0=>'No',1=>'Yes'))."</td></tr></table>";
$addformfields .= $formsClass->create_button('','Add field',array('id'=>'add_new_field', 'onclick'=>'return false;'));
$formfields .= $presentationClass->ContentWithHeader('Add new field',$addformfields);
$formfields .= "<div id='replace_div'>".$this->GenerateFieldsTable($edit_id)."</div>";
$formfields .= "<div id='cf_dialog'>Delete this field?</div>";
/************************************************************\
*
\************************************************************/
$jqueryscript->AddJqueryScriptEnd('
jQuery("#cf_dialog").dialog({autoOpen:false});
jQuery(".del_field").live("click",function()
{
var href = jQuery(this).attr("href");
var reg = /delfield&fid=(\d+)/;
if(res = reg.exec(href))
{
jQuery("#cf_dialog").dialog({
autoOpen: false,
hide:"explode",
buttons: {
"Yes": function() {
$.ajax({
type: "POST",
data: "mode=2&field_id="+res[1]'.$js_add.',
url: "'.$config['adm_baseurl'].'ajax.php?f=contactform.php",
success: function(msg){
jQuery("#replace_div").html(msg);
}
});

jQuery( this ).dialog( "close" );
},
Cancel: function() {
jQuery( this ).dialog( "close" );
}
}
});
jQuery("#cf_dialog").dialog("open");
}
});
jQuery("#add_new_field").live("click",function()
{
var field_name = jQuery("#field_name").attr("value");
if(field_name=="")
{
alert("You must fill Field Name");
return false;
} else
{
var field_type = jQuery("#field_type").attr("value");
var field_elements = jQuery("#field_elements").attr("value");
var field_required = jQuery("#field_required").attr("value");
$.ajax({
type: "POST",
data: "mode=1&field_name="+field_name+"&field_type="+field_type+"&field_elements="+field_elements+"&field_required="+field_required'.$js_add.',
url: "'.$config['adm_baseurl'].'ajax.php?f=contactform.php",
success: function(msg){
jQuery("#replace_div").html(msg);
}
});
}
});
');
/************************************************************\
*
\************************************************************/
if($edit_id!==false)
{
$php_temp = $this->GetPHPtemplate($edit_id);
$css_temp = $this->GetCSStemplate($edit_id);
$templates .= "<h6>PHP</h6>
<a href='#' id='generate_php'>Generate</a><br/>";
$templates .= $formsClass->create_textarea('php_template',$php_temp,array('id'=>'php_template','cols'=>70,'rows'=>15));
$templates .= "<h6>CSS</h6><a href='#' id='generate_css'>Generate</a><br/>";
$templates .= $formsClass->create_textarea('css_template',$css_temp,array('id'=>'css_template','cols'=>70,'rows'=>15));
$data['templates'] = $templates;
$content .= $jqueryscript->PrintScript("
jQuery('#generate_php').live('click',function()
{
$.get('".$config['wpr_baseurl']."ajax.php?f=generate_template.php',{form_id:$edit_id,mode:1},function(data)
{
if(data!='')
{
jQuery('#php_template').html(data);
}
});
});

jQuery('#generate_css').live('click',function()
{
$.get('".$config['wpr_baseurl']."ajax.php?f=generate_template.php',{form_id:$edit_id,mode:2},function(data)
{
if(data!='')
{
jQuery('#css_template').html(data);
}
});
});
");
}
$data['formdetails'] = $formdetails;
$data['formfields'] = $formfields;
if($select===false)
{
if(is_numeric($request['active_tab']))
{
$select = $request['active_tab'];
}
}

$content .= $presentationClass->JqueryTabsWithDataNew($data,$jq_headers,array('id'=>'ae_form','class'=>'box grid_16 round_all tabs wpr_form'),$select)."<br/><br/>";
if($edit_id===false)
{
$content .= $formsClass->create_hidden('addform','yes');
$content .= $formsClass->create_submit('addformsubmit','Add form',array('id'=>'formsubmit'));
$content .= $formsClass->create_hidden('action_url',$UrlClass->AddUrlValues(array('page'=>$page_name,'action'=>'add_form')));
}
else
{
$content .= $formsClass->create_hidden('editform','yes');
$content .= $formsClass->create_submit('editformsubmit','Edit form',array('id'=>'formsubmit'));
$content .= $formsClass->create_hidden('action_url',$UrlClass->AddUrlValues(array('page'=>$page_name,'action'=>'edit_contact','edit_id'=>$edit_id)));
}
$content .= $formsClass->create_hidden('active_tab',$selected,array('id'=>'active_tab'));
$content .= $formsClass->endform();
$content .= $jqueryscript->AddJqueryScriptEnd('
jQuery("#formsubmit").click(function()
{
var tmp = jQuery("#ae_form").tabs("option", "selected");
jQuery("#active_tab").attr("value",tmp);
});
');
$content .= $formsClass->endform();
return $content;
}

function AddEditContactFormInfo($request,$edit_id=false){
global $dbClass,$config;
$mes_hide = 0;
$sub_hide = 0;
if(isset($request['message_hide']))
$mes_hide = 1;
if(isset($request['subject_hide']))
$sub_hide = 1;
if($edit_id===false)
$sql = "INSERT INTO ".$this->wprcontact_content_base;
else
$sql = "UPDATE ".$this->wprcontact_content_base;
$sql .= " SET
form_name = '".$request['form_name']."',
generic_email = '".$request['generic_email']."',
generic_cc = '".$request['generic_cc']."',
generic_subj  = '".$request['generic_subj']."',
generic_msg = '".$request['generic_msg']."',
thankyoumessage  = '".$request['thankyoumessage']."',
thankyouurl  = '".$request['thankyouurl']."',
message_hide  = '".$mes_hide."',
subject_hide  = '".$sub_hide."'
";

if($edit_id!==false)
$sql .= " WHERE id='".$edit_id."'";
if($dbClass->Query($sql))
{
if($edit_id===false)
{
if($last_id = $dbClass->LastID())
{
return $last_id;
}
}
else
return true;
}
return false;
}
/************************************************************\
* Add Edit Field Contact Form
\************************************************************/
function AddEditFieldContactForm($request,$cf_id)
{
global $dbClass,$config;
$counter = 0;
//$exist_id = array();
for($i=0;$i<count($request['field_id']);$i++)
{
if($request['field_name'][$i]!="")
{
switch($request['field_type'][$i])
{
case 'captcha':
$standard_field=3;
break;
case 'email':
$standard_field=2;
break;
case 'name':
$standard_field=1;
break;
default:
$standard_field=0;
break;
}
$sql_set = " SET
wprcontact_id = '".$cf_id."',
field_name = '".$request['field_name'][$i]."',
standard_name = '".$this->CreateStandardName($request['field_name'][$i])."',
field_type = '".$request['field_type'][$i]."',
field_elements = '".$request['field_elements'][$i]."',
standard_field = '".$standard_field."',
field_required = '".$request['field_required'][$i]."',
rank = '$counter'";
$sql = "UPDATE ".$this->wprcontact_fields_base.$sql_set." WHERE id='".$request['field_id'][$i]."'";
$dbClass->Query($sql);
$counter++;
}
}
}
/************************************************************\
* Create Standard Name
\************************************************************/
function CreateStandardName($name){
$name = str_replace(' ','_',$name);
$name = strtolower($name);
return $name;
}
/************************************************************\
* Delete Contact Form
\************************************************************/
function DeleteContactForm($id){
global $dbClass;
$sql = "DELETE FROM ".$this->wprcontact_fields_base." WHERE wprcontact_id ='".$id."'";
$dbClass->Query($sql);
$sql = "DELETE FROM ".$this->wprcontact_content_base." WHERE id='".$id."'";
return $dbClass->Query($sql);
}
/************************************************************\
* Get Contact Form Info
\************************************************************/
function GetContactFormInfo($id){
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_content_base." WHERE id='$id'";
$reInfo = $dbClass->Query($sql, false, true);
if($reInfo->recordCount()>0)
{
return $reInfo->fields;
}
else
return false;
}
/************************************************************\
* Get Contact Form Fields Info
\************************************************************/
function GetContactFormFieldsInfo($id=false){
global $dbClass;
if($id===false)
$sql = "SELECT * FROM ".$this->wprcontact_fields_base." WHERE wprcontact_id='0' ORDER By rank";
else
$sql = "SELECT * FROM ".$this->wprcontact_fields_base." WHERE wprcontact_id='$id' ORDER By rank";
$reInfo = $dbClass->Query($sql);
if($reInfo->recordCount()>0)
{
$ret_tab = array();
while(!$reInfo->EOF)
{
$ret_tab[] = $reInfo->fields;
$reInfo->MoveNext();
}
return $ret_tab;
}
else
return false;
}
/************************************************************\
* Get Field Info
\************************************************************/
function GetFieldInfo($fid)
{
global $dbClass;
$sql ="SELECT * FROM ".$this->wprcontact_fields_base." WHERE id='$fid'";
return $dbClass->GetOneRow($sql);
}
/************************************************************\
* Delete Field
\************************************************************/
function DeleteField($fid)
{
global $dbClass;
$sql ="DELETE FROM ".$this->wprcontact_fields_base." WHERE id='$fid'";
return $dbClass->Query($sql);
}
/************************************************************\
* Check Add Edit Field
\************************************************************/
function CheckAddEditField($request)
{
global $lang;
if($request['field_name']=="")
return $lang['cf_field_name_empty'];
return false;
}
/************************************************************\
*
\************************************************************/
function FormsBackEnd($post_vars,$get_vars)
{
global $config,$dbClass,$presentationClass;
$content = "";
$pagename = "cf_forms";
$base = $config['adm_baseurl']."index.php?apage=".$pagename;
$add_href .= $base."&action=add_form";
if($get_vars['action']!='edit_form' && $get_vars['action']!='add_form')
{
if($get_vars['action']=='del_contactform')
{
if($this->DeleteContactForm($get_vars['del_id']))
{
$content .= $presentationClass->OperationSuccessfull("Delete ContactForm success");
}
else
$content .= $presentationClass->OperationFailed("Delete ContactForm failed");
}

$content .= "<a href='$add_href' class='top_href'>Add form</a>";
if($tab_CF = $this->GetContactForms())
{
$headers = array("ID","Form Name","Template Tag","Wordpress Tag",array('name'=>"",'align'=>"right"));
for($i=0;$i<count($tab_CF);$i++)
{
$del_url = $base."&action=del_contactform&del_id=".$tab_CF[$i]['id'];
$edit_url =$base."&action=edit_form&edit_id=".$tab_CF[$i]['id'];
$tab_view[$i][] = $tab_CF[$i]['id'];
$tab_view[$i][] = $tab_CF[$i]['form_name'];
$tag = "form_".$tab_CF[$i]['id'];
$tab_view[$i][] = "{".$tag."}";
$tab_view[$i][] = "[".$tag."]";
$tab_view[$i][] = "<a href='$edit_url' ><img src='".$config['wpradmin_baseurl']."images/pencil-small.png'></a>
<a href='$del_url' class='delbutton' onclick='return false' name='Delete contactform?'><img src='".$config['wpradmin_baseurl']."images/cross-button.png'></a>";
}
$content .= $presentationClass->StandardTableWithDataNew($tab_view,$headers,false,array('id'=>'cf_forms'));
}
else
$content .= "No contactforms";
} else
{
$request = $dbClass->DataFiltersArray($post_vars);
$select = false;
if($get_vars['action']=='add_form')
{
if(isset($request['addform']))
{
if($request['form_name']!="")
{
if($last_id = $this->AddEditContactFormInfo($request))
{
$this->AddEditFieldContactForm($request,$last_id);
header("Location: ".$base);
die();
//$content .= $presentationClass->OperationSuccessfull("Add ContactForm success");
}
else
{
$content .= $presentationClass->OperationFailed("Add ContactForm failed");
}
}
else
{
$content .= $presentationClass->OperationFailed("Must fill FormName field");
}
}
$request = $dbClass->DataFiltersArray($post_vars);
$content .= $this->AddEditContactForm($request,false,$select);
}
if($get_vars['action']=='edit_form')
{
if($data = $this->GetContactFormInfo($get_vars['edit_id']))
{
$edit_href = $config['adm_baseurl']."index.php?apage=cf_forms&action=edit_form&edit_id=".$get_vars['edit_id'];
if(isset($post_vars['editform']))
{
//$request = $_POST;
if($request['form_name']!="")
{
if($this->AddEditContactFormInfo($request,$get_vars['edit_id']))
{
$content .= $presentationClass->OperationSuccessfull("Edit Contact Form success");
$this->AddEditFieldContactForm($request,$get_vars['edit_id']);
$this->SavePHPtemplate($_POST['php_template'],$get_vars['edit_id']);
$this->SaveCSStemplate($request['css_template'],$get_vars['edit_id']);
} else
$content .= $presentationClass->OperationFailed("Edit ContactForm failed");
}
}
else
{
$request = $data;
}
$content .= $this->AddEditContactForm($request,$get_vars['edit_id'],$select);
}
}
}
return $content;
}
/************************************************************\
*
\************************************************************/
function SmsBackEnd($post_vars,$get_vars)
{
global $presentationClass,$formsClass,$config;
$content = "";
if($get_vars['action']=='del_smsgw')
{
if($this->GetSMSGatewayByID($get_vars['del_id']))
{
if($this->DeleteSMSGateways($get_vars['del_id']))
{
$content .= $presentationClass->OperationSuccessfull('Carrier delete successfull');
}
else
$content .= $presentationClass->OperationFailed('Carrier delete failed');
}
}
if(isset($post_vars['addcarrier']))
{
if($this->CheckAddSMSGateways($post_vars['carrier'],$post_vars['domain']))
{
if($this->InsertSMSGateways($post_vars['carrier'],$post_vars['domain']))
$content .= $presentationClass->OperationSuccessfull('Carrier add successfull');
else
$content .= $presentationClass->OperationFailed('Carrier add failed');
} else
$content .= $presentationClass->OperationFailed('Carrier already exists');
}
$tab_smsgateways = $this->GetSMSGateways();
$content .= "<h4>Add SMS Carriers</h4>";
$content .= $formsClass->startform();
$content .= "Carrier: ".$formsClass->create_text('carrier',$request['carrier'])." Domain: ".$formsClass->create_text('domain',$request['domain'])." ".
$formsClass->create_submit('addcarrier','Add');
$content .= $formsClass->endform();
if($tab_smsgateways !==false)
{
for($i=0;$i<count($tab_smsgateways);$i++)
{
$smscontent_tab[$i][] = $tab_smsgateways[$i]['carrier'];
$smscontent_tab[$i][] = $tab_smsgateways[$i]['domain'];
$delhref=$config['adm_baseurl']."index.php?apage=cf_sms&action=del_smsgw&del_id=".$tab_smsgateways[$i]['id'];
$smscontent_tab[$i][] = "<a href='$delhref' onclick='return false' class='delbutton' name='Delete carriers?'><img src='".$config['wpradmin_baseurl']."images/cross-button.png'</a>";
}
$content .= $presentationClass->StandardTableWithDataNew($smscontent_tab,array('Carrier','Domain',''),false,array('id'=>'sms_table'));
}
else
$content .= "No carriers";
return $content;
}
function MessagesBackEnd($post_vars,$get_vars)
{
global $presentationClass;
$messages_content = "<h4>Messages</h4>";
if($message_tab = $this->GetMessage())
{
$content .= $this->GenerateMessageTable($message_tab,true)."<br/>";
}
else
$content .= "No Messages";
return $content;
}
/************************************************************\
*
\************************************************************/
function AgentsBackEnd($post_vars,$get_vars)
{
global $UrlClass,$presentationClass,$dbClass,$jqueryscript,$formsClass,$config;
$content = "<h4>Edit Agents</h4>";
if(isset($post_vars['update_agent']))
{
if($this->UpdateAgent($post_vars))
{
$content .= $presentationClass->OperationSuccessfull('Update Agent successfull');
} else
$content .= $presentationClass->OperationFailed('Update Agent failed');
}
$tab_smsgateways = $this->GetSMSGateways();
if($agent_tab = $this->GetAgents())
{
for($i=0;$i<count($tab_smsgateways);$i++)
{
$tab_smsgateways_select[$tab_smsgateways[$i]['id']] = $tab_smsgateways[$i]['carrier'];
}
for($i=0;$i<count($agent_tab);$i++)
{
if($agent_tab[$i]['user_first_name']!="" OR $agent_tab[$i]['user_last_name']!="")
{
$header = $agent_tab[$i]['user_first_name']." ".$agent_tab[$i]['user_last_name'];
}
else
$header = $agent_tab[$i]['user_username'];
$agent_content .= $formsClass->startform();
$agent_content .= "Receive Leads: ".$formsClass->create_select('receive_leads',$agent_tab[$i]['receive_leads'],'',array(0=>"No",1=>"Yes")).
" Use SMS: ".$formsClass->create_select('use_sms',$agent_tab[$i]['use_sms'],'',array(0=>"No",1=>"Yes"))."<br/>".
"Cell Phone Number: ".$formsClass->create_text('cell_number',$agent_tab[$i]['cell_number']).
" Carrier: ".$formsClass->create_select('carrier_id',$agent_tab[$i]['carrier_id'],'',$tab_smsgateways_select);
$agent_content .= $formsClass->create_hidden('agent_id',$agent_tab[$i]['user_id']);
$agent_content .= $formsClass->create_submit('update_agent','Update');
$agent_content .= $formsClass->create_hidden('action_url',$UrlClass->AddUrlValues(array('page'=>$page_name)));
$agent_content .= $formsClass->endform();
if($message_tab = $this->GetMessage($agent_tab[$i]['user_id']))
{
for($y=0;$y<count($message_tab);$y++)
{
$agent_content .= $this->GenerateMessageTable($message_tab)."<br/>";
}
}
else
$agent_content .= "No leads";
$content .= $presentationClass->ContentWithHeader($header,$agent_content)."<br/>";
}
}
return $content;
}
/************************************************************\
*
\************************************************************/
function GetMessage($agent_id=false,$limit_start=false,$limit_count=false)
{
global $dbClass;
$limit = "";
if($limit_start!==false AND $limit_count!==false)
{
$limit = " LIMIT ".$limit_start.",".$limit_count;
}
if($agent_id!==false)
{
$sql = "SELECT * FROM ".$this->wprcontact_message_base." WHERE recipient='".$agent_id."'".$limit;
} else
$sql = "SELECT * FROM ".$this->wprcontact_message_base.$limit;
$reMessage = $dbClass->Query($sql);
if($reMessage->recordCount()>0)
{
$ret_tab = array();
while(!$reMessage->EOF)
{
$ret_tab[] = $reMessage->fields;
$reMessage->MoveNext();
}
return $ret_tab;
}
else
return false;
}
/************************************************************\
*
\************************************************************/
function GenerateMessageTable($data,$recipient=false)
{
global $dbClass,$presentationClass,$config;
$date = date("d/m/Y  H:i",$data['sent']);
$display = array();
$headers = array("Date Sent","Sender Name","Sender Email","Recipient","Subject","Message","");

for($i=0;$i<count($data);$i++)
{
$display[$i][] = $date;
$display[$i][] = $data[$i]['sender_name'];
$display[$i][] = $data[$i]['sender_email'];
$recipient = $data[$i]['recipient'];
if(is_numeric($data[$i]['recipient']))
{
$sql = "SELECT * FROM ".$this->users_base." WHERE user_id='".$data['recipient']."'";
$reS = $dbClass->Query($sql);
if($reS->recordCount()>0)
$recipient = $reS->fields['email'];
}
$display[$i][] = $recipient;
$display[$i][] = $data[$i]['subject'];
$display[$i][] = $data[$i]['message'];
$delurl = $config['adm_baseurl']."index.php?apage=cf_message&action=del_message&delid=".$data[$i]['id'];
$display[$i][] = "<a href='#' class='show_message' id='show_".$data[$i]['id']."'>Show</a> | <a href='".$delurl."' name='Delete this message?' onclick='return false;' class='delbutton'>Delete</a>";
}
$content = $presentationClass->StandardTableWithDataNew($display,$headers,false,array('id'=>'messages_table'));
return $content;
}
/************************************************************\
*
\************************************************************/
function UpdateAgent($request)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_agents_base." WHERE agent_id='".$request['agent_id']."'";
$reCheck = $dbClass->Query($sql);
$sql_set = "SET receive_leads='".$request['receive_leads']."',
use_sms='".$request['use_sms']."',
carrier_id='".$request['carrier_id']."',
cell_number='".$request['cell_number']."'";
if($reCheck->recordCount()>0)
{
$sql_update = "UPDATE ".$this->wprcontact_agents_base." ".$sql_set." WHERE agent_id='".$request['agent_id']."'";
}
else
{
$sql_update = "INSERT INTO ".$this->wprcontact_agents_base." ".$sql_set.",agent_id='".$request['agent_id']."'";
}
return $dbClass->Query($sql_update);
}
/************************************************************\
*
\************************************************************/
function GetAgents()
{
global $dbClass;
$sql = "SELECT ".$this->users_base.".user_id,".$this->users_base.".user_firstname,".$this->users_base.".user_lastname,".$this->users_base.".user_username,
".$this->wprcontact_agents_base.".*
FROM ".$this->users_base." LEFT JOIN ".$this->wprcontact_agents_base." ON ".$this->users_base.".user_id=".$this->wprcontact_agents_base.".agent_id WHERE ".$this->users_base.".user_level>0";
$reAgents = $dbClass->Query($sql);
if($reAgents->recordCount()>0)
{
$ret_tab = array();
while(!$reAgents->EOF)
{
$ret_tab[] = $reAgents->fields;
$reAgents->MoveNext();
}
return $ret_tab;
}
else
return false;
}
/************************************************************\
*
\************************************************************/
function CheckAddSMSGateways($carrier,$domain)
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_smsgateways_base." WHERE carrier='$carrier' AND domain='$domain'";
$reCheck = $dbClass->Query($sql);
if($reCheck->recordCount()>0)
return false;
else
return true;
}
/************************************************************\
*
\************************************************************/
function InsertSMSGateways($carrier,$domain)
{
global $dbClass;
$sql = "INSERT INTO ".$this->wprcontact_smsgateways_base." SET carrier='$carrier',domain='$domain'";
return  $dbClass->Query($sql);
}

function DeleteSMSGateways($del_id)
{
global $dbClass;
$sql = "DELETE FROM ".$this->wprcontact_smsgateways_base." WHERE id='$del_id'";
return $dbClass->Query($sql);
}

function GetSMSGatewayByID($id)
{
global $dbClass;
$sql = "SELECT *  FROM ".$this->wprcontact_smsgateways_base." WHERE id='$id'";
return $dbClass->GetOneRow($sql);
}
function GetSMSGateways()
{
global $dbClass;
$sql = "SELECT * FROM ".$this->wprcontact_smsgateways_base." ORDER BY carrier";
$reSMS = $dbClass->Query($sql);
if($reSMS->recordCount()>0)
{
$ret_tab = array();
while(!$reSMS->EOF)
{
$ret_tab[] = $reSMS->fields;
$reSMS->MoveNext();
}
return $ret_tab;
}
else
return false;
}

function GenerateTemplatePHP($form_id){
global $config,$dbClass;
/*require_once($config['basepath']."include/forms.inc.php");
$formsClass = registry::register('FormsClass');*/
$content = "{wprcontactform_css}\n";
$content .= "<form method='post' action='' id='form_".$form_id."'>\n";
$content .= "{wprcontactform_".$form_id."_validate}<table>\n";
$captcha = "";
if($form_fields_info = $this->GetContactFormFieldsInfo($form_id)){
for($i=0;$i<count($form_fields_info);$i++)
{
if($form_fields_info[$i]['field_type']!='captcha')
{
$content .= "<tr><td>".$form_fields_info[$i]['field_name']."</td><td>{wprcontactform_field_".$form_fields_info[$i]['standard_name']."}</td></tr>\n";
} else
$captcha = "<tr><td>".$form_fields_info[$i]['field_name']."</td><td>{wprcontactform_field_".$form_fields_info[$i]['standard_name']."}</td></tr>\n";
}
}
if($form_info = $this->GetContactFormInfo($form_id))
{
if($form_info['subject_hide']==0)
$content .= "<tr><td>Subject</td><td>{wprcontactform_subject}</td></tr>\n";
if($form_info['message_hide']==0)
$content .= "<tr><td>Message</td><td>{wprcontactform_message}</td></tr>\n";
}
$content .= $captcha;
$content .= "<tr><td colspan='2'>{wprcontactform_submit}</td></tr>\n";
$content .= "</table></form>\n";
return $content;
}

function GetPHPtemplate($form_id){
global $config;
$content = "";
$path = $config['basepath'].$config['template_dir']."/forms/form_$form_id.php";
if(file_exists($path)){
return stripslashes(file_get_contents($path));
} else {
$f = fopen($path,"w");
fclose($f);
return $content;
}
}

function GetCSStemplate($form_id){
global $config;
$content = "";
$path = $config['basepath'].$config['template_dir']."/forms/form_$form_id.css";
if(file_exists($path)){
return stripslashes(file_get_contents($path));
} else {
$f = fopen($path,"w");
fclose($f);
return $content;
}
}

function SavePHPtemplate($template,$form_id){
global $config;
$path = $config['basepath'].$config['template_dir']."/forms/form_$form_id.php";
$f = fopen($path,"w");
fwrite($f,$template);
fclose($f);
}

function SaveCSStemplate($template,$form_id){
global $config;
$path = $config['basepath'].$config['template_dir']."/forms/form_$form_id.css";
$f = fopen($path,"w");
fwrite($f,$template);
fclose($f);
}

function GenerateTemplateCSS($form_id){
global $config,$dbClass;
$content = "";
if($form_fields_info = $this->GetContactFormFieldsInfo($form_id)){
for($i=0;$i<count($form_fields_info);$i++)
{
$content .= "/***** ".$form_fields_info[$i]['standard_name']."******/\n"."#form_".$form_id."_".$form_fields_info[$i]['standard_name']."{\n}\n";
}
}
if($form_info = $this->GetContactFormInfo($form_id))
{
$content .= "/***** ".$form_info['name']."******/\n"."#form_".$form_id."{\n}\n";
if($form_info['subject_hide']==0)
$content .= "/***** ".$form_info['name']."******/\n"."#form_".$form_id."_formsubject{\n}\n";
if($form_info['message_hide']==0)
$content .= "/***** ".$form_info['name']."******/\n"."#form_".$form_id."_formmessage{\n}\n";
}
return $content;
}
}// END class ContactFormClass
?>