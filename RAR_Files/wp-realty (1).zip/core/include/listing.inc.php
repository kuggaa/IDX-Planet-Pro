<?php

/*
 * Commercial Codebase by WP Realty Development Team.
 * Copyright - WP Realty - 2009 - 2012 - All Rights Reserved
 * License: http://wprealty.org/faq/license/
 */
if (!function_exists('doubleQuoteCleaner')) {

    function doubleQuoteCleaner(&$field_value) {
        $field_value = addslashes(str_replace('","', ', ', trim($field_value, '"')));
    }

}

Class ListingClass {

    public $interesting_listings = array();
    public $remote_db = FALSE;

    /* FUNCTION RELATED TO CANADA RETS Start Here */
    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: create mls# queue table
      \*********************************************************** */

    function CreateMLSQueueTable() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS " . $config['table_prefix'] . "mls_data_dwn_queue (
ListingKey varchar(50) NOT NULL,
Resource varchar(50) NOT NULL,
Class varchar(50) NOT NULL,
LastDownloadTryDatetime timestamp NULL default NULL,
PRIMARY KEY  (ListingKey),
KEY ResourceClass (Resource,Class)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: TRUNCATE the MLSQueueTable
      \*********************************************************** */

    function TruncateMLSQueueTable() {
        global $dbClass, $config;
        $sql = "DROP TABLE IF EXISTS `" . $config['table_prefix'] . "mls_data_dwn_queue` ";
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: create table to store active mls#
      \*********************************************************** */

    function CreateActiveMLSTable() {
        global $dbClass, $config;
        $sql = "CREATE TABLE IF NOT EXISTS " . $config['table_prefix'] . "active_mls_number (
ListingKey varchar(50) NOT NULL,
PRIMARY KEY  (ListingKey)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: TRUNCATE the ActiveMLSTable
      \*********************************************************** */

    function TruncateActiveMLSTable() {
        global $dbClass, $config;
        $sql = "TRUNCATE TABLE `" . $config['table_prefix'] . "active_mls_number` ";
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Insert MLS# for download
      \*********************************************************** */

    function InsertMLSNumberInDownloadQueue($arrMls, $rets_resource, $rets_class, $rets_mls_field_name) {
        global $dbClass, $config;
        /* Loop through each data and perform insert / updates */
        $c = 0;
        $arrData = array();
        foreach ($arrMls as $data) {
            $arrData[] = "'" . $data[$rets_mls_field_name] . "', '" . $rets_resource . "', '" . $rets_class . "'";
            $c++;
            if ($c >= 2000) {
                /* Sql */
                $sql = 'REPLACE INTO ' . $config['table_prefix'] . 'mls_data_dwn_queue (ListingKey, Resource, Class) VALUES ' .
                        "(" . implode("),(", $arrData) . ")";
//debugMsg('<br>'. $sql);
                $ret = $dbClass->query($sql);
                unset($arrData);
                $arrData = array();
                $c = 0;
            }
        }
        if (count($arrData) > 0) {
            /* Sql */
            $sql = 'REPLACE INTO ' . $config['table_prefix'] . 'mls_data_dwn_queue (ListingKey, Resource, Class) VALUES ' .
                    "(" . implode("),(", $arrData) . ")";
//debugMsg('<br>'. $sql);
            $ret = $dbClass->query($sql);
        }
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Remove delete listing from queue
      \*********************************************************** */

    function RemoveDeletedListingFromQueue($rets_resource, $rets_class) {
        global $dbClass, $config;
        /* Sql */
        $sql = " DELETE FROM " . $config['table_prefix'] . "mls_data_dwn_queue " .
                " WHERE ListingKey NOT IN (SELECT ListingKey FROM " . $config['table_prefix'] . "active_mls_number) " .
                " 		AND Resource = '" . $rets_resource . "' " .
                "		AND Class = '" . $rets_class . "'";
//debugMsg('<br>'. $sql);
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Remove downloaded batch listing from queue
      \*********************************************************** */

    function RemoveDwnBatchListingFromQueue($rets_resource, $rets_class, $arrBatchListingKey, $arrListingKeyInserted) {
        global $dbClass, $config;
        /* Sql */
        $sql = " UPDATE " . $config['table_prefix'] . "mls_data_dwn_queue " .
                " SET LastDownloadTryDatetime = CURRENT_TIMESTAMP() " .
                " WHERE ListingKey IN ('" . implode("','", $arrBatchListingKey) . "') " .
                " 		AND Resource = '" . $rets_resource . "' " .
                "		AND Class = '" . $rets_class . "'";
//debugMsg('<br>'. $sql);
        $ret = $dbClass->query($sql);
        /* Sql */
        $sql = " DELETE FROM " . $config['table_prefix'] . "mls_data_dwn_queue " .
                " WHERE ListingKey IN ('" . implode("','", $arrListingKeyInserted) . "') " .
                " 		AND Resource = '" . $rets_resource . "' " .
                "		AND Class = '" . $rets_class . "'";
//debugMsg('<br>'. $sql);
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Return list of mls to be downloaded
      \*********************************************************** */

    function GetMLSNumberForDownload($Resource, $Class, $limit = 100) {
        global $dbClass, $config;
        /* SQL */
        $sql = " SELECT ListingKey FROM " . $config['table_prefix'] . "mls_data_dwn_queue " .
                " WHERE Resource = '" . $Resource . "' AND Class = '" . $Class . "'" .
                "	AND (LastDownloadTryDatetime IS NULL OR LastDownloadTryDatetime < TIMESTAMPADD(HOUR, -5, CURRENT_TIMESTAMP())) " . /* ListingKey should not process in last 5 hours */
                " ORDER BY LastDownloadTryDatetime ASC " .
                " LIMIT " . intval($limit);
        return $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Insert active MLS# for clearn job
      \*********************************************************** */

    function InsertActiveMLSNumber($arrMls, $rets_mls_field_name) {
        global $dbClass, $config;
        /* Loop through each data and perform insert / updates */
        $c = 0;
        $arrData = array();
        foreach ($arrMls as $data) {
            $arrData[] = "'" . $data[$rets_mls_field_name] . "'";
            $c++;
            if ($c >= 2000) {
                /* Sql */
                $sql = 'REPLACE INTO ' . $config['table_prefix'] . 'active_mls_number (ListingKey) VALUES ' .
                        "(" . implode("),(", $arrData) . ")";
//debugMsg('<br>'. $sql);
                $ret = $dbClass->query($sql);
                unset($arrData);
                $arrData = array();
                $c = 0;
            }
        }
        /* Sql */
        $sql = 'REPLACE INTO ' . $config['table_prefix'] . 'active_mls_number (ListingKey) VALUES ' .
                "(" . implode("),(", $arrData) . ")";
//debugMsg('<br>'. $sql);
        $ret = $dbClass->query($sql);
    }

    /* FUNCTION RELATED TO CANADA RETS End Here */
    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: TRUNCATE the listingdb & listingsimages table,
     * physical image cleanup done by cronjob only
      \*********************************************************** */

    function TRUNCATE() {
        global $dbClass, $config;
        $sql = "TRUNCATE TABLE `" . $config['table_prefix'] . "listingsdb` ";
        $ret = $dbClass->query($sql);
        $sql = "TRUNCATE TABLE `" . $config['table_prefix'] . "listingsimages` ";
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Perform Listing Insert / Updates
      \*********************************************************** */

    function InsertUpdateListing($arrListing, $arrRETSFieldDwled, $listing_owner, $wp_realty_class, $retsUniqueField, $wprUniqueField, $arrRETS2WPR_DirectTransfer, $arrFieldConcatMapping, $arrConcatenate, $arrListingTitleField, $arrDataValidation = array()) {
        global $dbClass, $config, $controlpanel_config2;
        /* Make Numerical Field List - */
        $sql = 'SELECT listingfields_field_name FROM `' . $config['table_prefix'] . 'listingsfields` ' . 'WHERE listingfields_datatype LIKE "int%" OR  listingfields_datatype LIKE "decimal%" ';
        $reC = $dbClass->query($sql);
        $numericalField = array();
        /* Any listing found mark for remove? */
        if ($reC->RecordCount() > 0) {
            while (!$reC->EOF) {
                $numericalField[] = $reC->fields['listingfields_field_name'];
                $reC->MoveNext();
            }
        }
        /* Make Date Field List */
        /* Loop through each data and perform insert / updates */
        $sql = 'SELECT listingfields_field_name FROM `' . $config['table_prefix'] . 'listingsfields` ' . 'WHERE listingfields_datatype LIKE "DateTime" ';
        $reC = $dbClass->query($sql);
        $dateField = array();
        if ($reC->RecordCount() > 0) {
            while (!$reC->EOF) {
                $dateField[] = $reC->fields['listingfields_field_name'];
                $reC->MoveNext();
            }
        }
// Going to collect it for valid data
        $arrListingKey = array();
//debugMsg("<br>Lising to be inserted : ". count($arrListing));
        $this->interesting_listings['new_listings'] = array();
        $this->interesting_listings['updated_listings'] = array();
        /* Loop through each listing data and save in database */
        foreach ($arrListing as $arrFieldNValue) {
// Dinesh Sailor : Friday, July 19, 2013
// This is required for CREA [Canada RETS]
            $isValidData = true;
            foreach ($arrDataValidation as $dataFieldName => $validationType) {
                if (in_array($dataFieldName, $arrFieldNValue)) {
                    switch ($validationType[0]) {
                        /* Validation base on date */
                        case 'Date':
                            $dataValue = $arrFieldNValue[$dataFieldName];
                            $dataValue = substr($dataValue, 0, 10);
                            list($dd, $mm, $yyyy) = explode('/', $dataValue);
                            $reFormatedValue = date($validationType[1], mktime(0, 0, 0, $mm, $dd, $yyyy));
                            if ($dataValue != $reFormatedValue)
                                $isValidData = false;
                            break;
                    }
                }
            }
// Only if valid data
            if ($isValidData) {
                $arrListingKey[] = $arrFieldNValue[$retsUniqueField];
//Define the price history vars
                $listing_id_for_ins = false;
                $mls_for_ins = false;
                $price_for_ins = false;
                /* Check for existing listing */
                $sql = 'SELECT listingsdb_id FROM `' . $config['table_prefix'] . 'listingsdb` ' . 'WHERE ' . $wprUniqueField . ' = "' . $arrFieldNValue[$retsUniqueField] . '" ';
                $reC = $dbClass->query($sql);
//debugMsg('<br>'. $sql);
//debugMsg('<br>'. $reC->RecordCount());
                /* Perform updates? */
                $doUpdate = false;
                if ($reC->RecordCount() > 0) {
                    $doUpdate = true;
                    $listing_id_for_ins = $reC->fields['listingsdb_id']; //Price history update mode listing id
                }
                if ($doUpdate) {
                    /* Update listingsdb for last data updates */
                    $sql = 'UPDATE ' . $config['table_prefix'] . 'listingsdb ' . ' SET ';
                } else {
                    /* Insert into listingsdb */
                    $sql = 'INSERT INTO ' . $config['table_prefix'] . 'listingsdb '
                            . ' SET '
                            . '	user_id 	= "' . $listing_owner . '", '
                            . '	class_id 	= "' . $wp_realty_class . '", ';
                }
                /* Direct field to field tranfer */
                foreach ($arrRETS2WPR_DirectTransfer as $retsFieldName => $wprFieldName) {
//Price history values
                    if ($wprFieldName == 'MLS') {
                        $mls_for_ins = $arrFieldNValue[$retsFieldName]; //Price history mls var
                        if ($doUpdate) {
                            $this->interesting_listings['updated_listings'][] = $mls_for_ins;
                        } else {
                            $this->interesting_listings['new_listings'][] = $mls_for_ins;
                        }
                    }
//Debugging note $controlpanel_config2
                    if ($wprFieldName == $controlpanel_config2['controlpanel_price_field'])
                        $price_for_ins = $arrFieldNValue[$retsFieldName]; //Price history current price var
//End Price history values
                    if (in_array($wprFieldName, $numericalField)) {
                        $sql .= $wprFieldName . ' = "' . floatval(preg_replace('/[^\d.]/', "", $arrFieldNValue[$retsFieldName])) . '",';
                    } elseif (in_array($wprFieldName, $dateField)) {
                        if ($arrFieldNValue[$retsFieldName] == '')
                            $sql .= $wprFieldName . ' = NULL,';
                        else
                            $sql .= $wprFieldName . ' = "' . $arrFieldNValue[$retsFieldName] . '",';
                    }
                    else {
                        $sql .= $wprFieldName . ' = "' . $arrFieldNValue[$retsFieldName] . '",';
                    }
                }
                /* Concatenate Fields */
                foreach ($arrFieldConcatMapping as $fKey => $wprFieldName) {
                    $arrFieldList = explode(",", $arrConcatenate[$fKey]['field_list']);
                    $formattedValue = $arrConcatenate[$fKey]['field_format'];
                    foreach ($arrFieldList as $dkey => $retsFieldName) {
                        $formattedValue = str_replace($retsFieldName, trim($arrFieldNValue[$retsFieldName]), $formattedValue);
                    }
                    $sql .= $wprFieldName . ' = "' . trim(str_replace('  ', ' ', $formattedValue)) . '",';
                }
                /* Title Field */
                $title = "";
                foreach ($arrListingTitleField as $aKey => $retsFieldName) {
                    $title .= $arrFieldNValue[$retsFieldName] . " ";
                }
                $title = trim($title);
                $sql .= '	listingsdb_title="' . $title . '",	';
                $sql .= '	listingsdb_is_photo_downloaded = "No", ';
                $sql .= '	listingsdb_is_mark_for_remove = "No" ';
                if ($doUpdate) {
                    $sql .= 'WHERE ' . $wprUniqueField . ' = "' . $arrFieldNValue[$retsUniqueField] . '" ';
                }
//debugMsg("<br><br>". $sql. "<br>");
                if ($this->remote_db) {
                    $ret = $this->remote_db->query($sql);
                } else {
                    $ret = $dbClass->query($sql);
                }
//Price history handler
                if ($controlpanel_config2['controlpanel_price_history_active_bool']) {//Runs only when price history is activated in CP
                    if (!$doUpdate) {//new listing
                        $listing_id_for_ins = $dbClass->LastID(); // get the listing id back from db after the insert
                        $this->insert_historical_price($listing_id_for_ins, $price_for_ins, $mls_for_ins); //Insert price record
                    } else {//Listing itself is updated, but is it a changed price? Here we check and either insert or ignore
                        if ($this->is_updated_price($listing_id_for_ins, $price_for_ins))//See the function below
                            $this->insert_historical_price($listing_id_for_ins, $price_for_ins, $mls_for_ins); //Insert price record
                    }
                }
//End Price history handler
            }
// Invalid data
            else {
// nothing to do
            }
        } // Foreach loop end here
        return $arrListingKey;
    }

//Inserts a historical price record into the pricehistory table. These will become a class next ed
    function insert_historical_price($listingid, $current_price, $mlsid) {
        global $dbClass, $config;
        $sql_price_history_ins = "INSERT INTO " . $config['table_prefix'] . "pricehistory SET
listing_id = '" . $listingid . "',
mls_id = '" . $mlsid . "',
updated_price = '" . $current_price . "'";
        echo '<br>' . $sql_price_history_ins . '<br>';
        $ret = $dbClass->query($sql_price_history_ins);
//echo $ret;
    }

//Called on updates only. Determines whether the current price matches the last recorded price or no history exists (rare)
//returns true if the price has changed and false if the current price is the same as the last recorded price
    function is_updated_price($listingid, $current_price) {
        global $dbClass, $config;
//Logic below - search for historical price records - return 1 ordered by the autoincrementing primary key h_id descending
//Last in First out
        $sql = "SELECT updated_price FROM " . $config['table_prefix'] . "pricehistory WHERE listing_id = '" . $listingid . "' ORDER BY h_id DESC LIMIT 1";
        $ret = $dbClass->query($sql);
        if ($ret->RecordCount() > 0) {//there is a history
            if ($current_price != $ret->fields['updated_price'])
                return true; //Price has changed
            return false; //Price same
        }
        return true; //No history found
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Mark all listing as removed
      \*********************************************************** */

    function markAllListingRemoved() {
        global $dbClass, $config;
        $sql = 'UPDATE ' . $config['table_prefix'] . 'listingsdb ' . ' SET listingsdb_is_mark_for_remove = "Yes" ';
        return $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Mark listing for not to remove, base on active mls
      \*********************************************************** */

    function markListingForNotToRemove($arrMls, $wpr_mls_field_name, $rets_mls_field_name, $wp_realty_class) {
        global $dbClass, $config;
        /* Loop through each data and perform insert / updates */
        $c = 0;
        $arrIds = array();
        foreach ($arrMls as $data) {
            $arrIds[] = $data[$rets_mls_field_name];
            $c++;
            if ($c >= 2000) {
                /* Sql */
                $sql = 'UPDATE ' . $config['table_prefix'] . 'listingsdb ' . '	SET listingsdb_is_mark_for_remove = "No" ' . ' WHERE ' . $wpr_mls_field_name . " IN ('" . implode("','", $arrIds) . "') AND class_id = '" . $wp_realty_class . "'";
//debugMsg('<br>'. $sql);
                $ret = $dbClass->query($sql);
                unset($arrIds);
                $arrIds = array();
                $c = 0;
            }
        }
        /* Sql */
        $sql = 'UPDATE ' . $config['table_prefix'] . 'listingsdb ' . '	SET listingsdb_is_mark_for_remove = "No" ' . ' WHERE ' . $wpr_mls_field_name . " IN ('" . implode("','", $arrIds) . "') AND class_id = '" . $wp_realty_class . "'";
//debugMsg('<br>'. $sql);
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Mark listing for not to remove, base on active mls
      \*********************************************************** */

    function markListingForNotToRemoveInMaster($wpr_mls_field_name, $wp_realty_class) {
        global $dbClass, $config;
        /* Sql */
        $sql = ' UPDATE ' . $config['table_prefix'] . 'listingsdb ' .
                ' SET listingsdb_is_mark_for_remove = "No" ' .
                ' WHERE ' . $wpr_mls_field_name . " IN (SELECT ListingKey FROM " . $config['table_prefix'] . "active_mls_number) AND class_id = '" . $wp_realty_class . "'";
//debugMsg('<br>'. $sql);
        $ret = $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob 
     * Purpose:Perform listing cleaup base on listingsdb_is_mark_for_remove status
      \*********************************************************** */

    function DoListingCleanup($ListingPhotoRoot, $wpr_mls_field_name, $wp_realty_class) {
        global $dbClass, $config, $controlpanel_config2;
        /* Dinesh : Saturday, December 08, 2012 */
        $sql = 'SELECT ' . $wpr_mls_field_name . ' FROM ' . $config['table_prefix'] . 'listingsdb WHERE listingsdb_is_mark_for_remove = "Yes" AND class_id = "' . $wp_realty_class . '" ';
//echo '<br> cleanup find sql '.$sql.'<br>';
        /* change by kuba */
//$sql = 'SELECT '.$mls_field.' FROM '. $config['table_prefix']. 'listingsdb ' . ' WHERE listingsdb_is_mark_for_remove = "Yes" ';
//$sql = 'SELECT MLS FROM '. $config['table_prefix']. 'listingsdb '
//	.	'	WHERE listingsdb_is_mark_for_remove = "Yes" ';
        $reC = $dbClass->query($sql);
        /* Any listing found mark for remove? */
        if ($reC->RecordCount() > 0) {
            /* Save current directory */
            $curDir = getcwd();
            $arrMlsNum = array();
            while (!$reC->EOF) {
                $arrMlsNum[] = $reC->fields[$wpr_mls_field_name];
                /* Photo folder */
                $foldMls = $ListingPhotoRoot . $reC->fields[$wpr_mls_field_name];
                /* Remove all photos */
                if (is_dir($foldMls)) {
                    chdir($foldMls);
                    $arrFileName = glob("*.*");
                    foreach ($arrFileName as $key => $fname) {
                        @unlink($fname);
                    }
                    chdir("..");
                    rmdir($foldMls);
                }
                $reC->MoveNext();
            }
            /* Change to back to original directory */
            chdir($curDir);
            /* Perform table cleanup */
            /* delete listings images */
            $sql = 'DELETE FROM ' . $config['table_prefix'] . 'listingsimages WHERE listingsdb_id IN (SELECT listingsdb_id FROM ' . $config['table_prefix'] . 'listingsdb WHERE listingsdb_is_mark_for_remove = "Yes" AND class_id = "' . $wp_realty_class . '" )';
            $ret = $dbClass->query($sql);
            /* delete listings  */
            $sql = 'DELETE FROM ' . $config['table_prefix'] . 'listingsdb WHERE listingsdb_is_mark_for_remove = "Yes" AND class_id = "' . $wp_realty_class . '" ';
            $ret = $dbClass->query($sql);
//Price history delete records when a listing is removed
            if ($controlpanel_config2['controlpanel_price_history_active_bool']) {//Runs only when price history is activated in CP
                $sql = "DELETE FROM " . $config['table_prefix'] . "pricehistory WHERE ";
                foreach ($arrMlsNum as $mlsnum) {
                    $sql .= "mls_id = '" . $mlsnum . "' OR ";
                }
                $sql = substr($sql, 0, -4);
                echo '<br>del sql ' . $sql . '<br>';
                $ret = $dbClass->query($sql);
            }
//Price history delete records when a listing is removed
            return $arrMlsNum;
        }
        return false;
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob 
     * Purpose: Get Listing for photo download
      \*********************************************************** */

    function getPendingListingForPhotoDwn($sysid_field, $photo_count_field, $mls_field, $limit) {
        global $dbClass, $config;
        $sql = 'SELECT listingsdb_id, user_id, ' . $sysid_field . ' AS sysid_field, ' . $mls_field . ' AS MLS_NUM, ' . ( $photo_count_field ? $photo_count_field . ' AS photo_count ' : ' -1 AS photo_count ')
                . ' FROM ' . $config['table_prefix'] . 'listingsdb '
                . '	WHERE (listingsdb_is_photo_downloaded = "No" OR listingsdb_is_photo_downloaded IS NULL)'
                . '		AND (listingsdb_photo_last_downloaded < CURDATE() OR listingsdb_photo_last_downloaded IS NULL) '
                . ($photo_count_field ? 'AND ' . $photo_count_field . ' > 0 ' : '')
                . ' LIMIT ' . $limit;
//echo $sql;
        return $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Delete photos
      \*********************************************************** */

    function deletePhotosById($listingsdb_id) {
        global $dbClass, $config;
        $sql = 'DELETE FROM ' . $config['table_prefix'] . 'listingsimages ' . ' WHERE listingsdb_id = "' . $listingsdb_id . '"';
        return $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Add photo record
      \*********************************************************** */

    function addPhotosById($userdb_id, $listingsdb_id, $listingsimages_file_name, $listingsimages_thumb_file_name, $listingsimages_rank) {
        global $dbClass, $config;
        $sql = 'INSERT INTO ' . $config['table_prefix'] . 'listingsimages '
                . '	(user_id, listingsdb_id, listingsimages_file_name, listingsimages_thumb_file_name, listingsimages_rank, listingsimages_caption, listingsimages_description, listingsimages_active) '
                . ' VALUES ("' . $userdb_id . '", "' . $listingsdb_id . '", "' . $listingsimages_file_name . '", "' . $listingsimages_thumb_file_name . '", "' . $listingsimages_rank . '", "", "", "Yes")';
        return $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Add photo record
      \*********************************************************** */

    function addMultiPhotosById($userdb_id, $listingsdb_id, $xmlRow, $wpr_field_mapping) {
        global $dbClass, $config;
        /* Loop through each row and perform insert or updates */
        $myData = $xmlRow->DATA;
        $rank = 0;
        foreach ($myData as $data) {
            /* Correct data and create value array */
//$data = addslashes($data);
            $data = preg_replace('/^[^\t]*\\t/', "", $data);
            $data = preg_replace('/\\t[^\t]*$/', "", $data);
// $data = str_replace(',', ", ", $data); // Added to space comma saved data.
            $arrValues = explode("\t", $data);
            /* Create field value array */
            array_walk($arrValues, 'doubleQuoteCleaner');
            $arrFieldNValue = array_combine(array_keys($wpr_field_mapping), $arrValues);
            /* Insert into listingsimages */
            $sql = 'INSERT INTO ' . $config['table_prefix'] . 'listingsimages '
                    . ' SET '
                    . '	user_id 	= "' . $userdb_id . '", '
                    . '	listingsdb_id 	= "' . $listingsdb_id . '", ';
            /* Direct field to field tranfer */
            foreach ($arrFieldNValue as $fieldName => $fieldValue) {
                $sql .= $fieldName . ' = "' . $fieldValue . '", ';
            }
            $sql .= '	listingsimages_rank="' . $rank++ . '", ';
            $sql .= '	listingsimages_active = "Yes" ';
//debugMsg($sql);
            $ret = $dbClass->query($sql);
        }
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Mark photo downloaded
      \*********************************************************** */

    function markPhotoDownloaded($listingsdb_id) {
        global $dbClass, $config;
        /* Update listingsdb for last data updates */
        $sql = 'UPDATE ' . $config['table_prefix'] . 'listingsdb '
                . ' SET listingsdb_photo_last_downloaded = NOW(), '
                . '	listingsdb_is_photo_downloaded = "Yes" '
                . 'WHERE listingsdb_id = "' . $listingsdb_id . '"';
        return $dbClass->query($sql);
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Mark photo downloaded tried
      \*********************************************************** */

    function markPhotoDownloadTried($listingsdb_id) {
        global $dbClass, $config;
        /* Update listingsdb for last data updates */
        $sql = 'UPDATE ' . $config['table_prefix'] . 'listingsdb '
                . ' SET listingsdb_photo_last_downloaded = NOW() '
                . 'WHERE listingsdb_id = "' . $listingsdb_id . '"';
        return $dbClass->query($sql);
    }

    function GeMlsTab($mls_field) {
        global $dbClass, $config;
        $sql = "SELECT $mls_field as MLS FROM `" . $config['table_prefix'] . "listingsdb`";
        $reMLS = $dbClass->query($sql);
        $ret_array = array();
        if ($reMLS->RecordCount() > 0) {
            while (!$reMLS->EOF) {
                $ret_array[] = $reMLS->fields['MLS'];
                $reMLS->MoveNext();
            }
        }
        return $ret_array;
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Return unqiue agent code
      \*********************************************************** */

    function getUniqueAgentCode($wpr_agent_id_field, $limit = '') {
        global $dbClass, $config;
        $sql = "SELECT DISTINCT $wpr_agent_id_field as AgentCode FROM `" . $config['table_prefix'] . "listingsdb`";
        if (intval($limit) > 0)
            $sql .= ' LIMIT ' . intval($limit);
        $rs = $dbClass->query($sql);
        $arrAgentCode = array();
        if ($rs->RecordCount() > 0) {
            while (!$rs->EOF) {
                $arrAgentCode[] = $rs->fields['AgentCode'];
                $rs->MoveNext();
            }
        }
        return $arrAgentCode;
    }

    /*     * **********************************************************\
     * Use by: wprrets module -> cronjob
     * Purpose: Return unqiue office code
      \*********************************************************** */

    function getUniqueOfficeCode($wpr_office_id_field, $limit = '') {
        global $dbClass, $config;
        $sql = "SELECT DISTINCT $wpr_office_id_field as OfficeCode FROM `" . $config['table_prefix'] . "listingsdb`";
        if (intval($limit) > 0)
            $sql .= ' LIMIT ' . intval($limit);
        $rs = $dbClass->query($sql);
        $arrOfficeCode = array();
        if ($rs->RecordCount() > 0) {
            while (!$rs->EOF) {
                $arrOfficeCode[] = $rs->fields['OfficeCode'];
                $rs->MoveNext();
            }
        }
        return $arrOfficeCode;
    }

}

?>