<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
error_reporting(E_ALL);
class controlpanelClass{
/************************************************************\
*
\************************************************************/
function GetControlPanelFields($blog_id=0,$masterdb=false)
{
global $config,$dbClass;
$sql = "SELECT * FROM ".$config['table_prefix']."controlpanel WHERE blog_id='".$blog_id."'";
$reS = $dbClass->Query($sql,$masterdb);
if($reS->recordCount()>0)
{
return $reS->fields;
}
else
return false;
}
/************************************************************\
*
\************************************************************/
function GetControlPanelOnlyData($blog_id=0,$masterdb=false){
if($res = $this->GetControlPanelFields($blog_id,$masterdb))
{
$tab_fields = array();
foreach($res as $key=>$value)
{
if(strpos($key,'controlpanel_')!==false)
{
$tab_fields[$key] = $value;
}else
continue;
}
return $tab_fields;
}
return false;
}
/************************************************************\
*
\************************************************************/
function GetPriceField($blog_id=0)
{
global $dbClass,$config;
$row = $dbClass->Query("SELECT controlpanel_price_field FROM ".$config['table_prefix']."controlpanel WHERE blog_id=$blog_id LIMIT 1",true);
if($row->RecordCount()>0)
return $row->fields['controlpanel_price_field'];
return false;
}
// Added for date format for date range search.
function GetDateFormatField($blog_id=0)
{
global $dbClass,$config;
$row = $dbClass->Query("SELECT controlpanel_date_format FROM ".$config['table_prefix']."controlpanel WHERE blog_id=$blog_id LIMIT 1",true);
if($row->RecordCount()>0)
return $row->fields['controlpanel_date_format'];
return false;
}
/************************************************************\
* WordPress Rewrite Rules
\************************************************************/
function WordpressRewriteRules($updateoptions){
global $dbClass;
$spacechar = $updateoptions['controlpanel_space_character'];
if($dbClass->TableExists('wp_options'))
{
$option="rewrite_rules";
$row = $dbClass->Query("SELECT option_value FROM wp_options WHERE option_name = '$option' LIMIT 1");
$srtingdata=$row->fields['option_value'];
if($spacechar=="/")
$replacements=array("listing-([0-9]*)-","office-([0-9]*)-","agent-([0-9]*)-","letter-([A-Z]*)","user-([0-9]*)-");
if($spacechar=="-")
$replacements=array("listing/([0-9]*)/","office/([0-9]*)/","agent/([0-9]*)/","letter/([A-Z]*)","user/([0-9]*)/");
$replaceby = array("listing$spacechar([0-9]*)$spacechar","office$spacechar([0-9]*)$spacechar","agent$spacechar([0-9]*)$spacechar","user$spacechar([0-9]*)$spacechar");
$srtingnew=str_replace($replacements, $replaceby, $srtingdata);
$row = $dbClass->Query("UPDATE wp_options set option_value='$srtingnew' WHERE option_name='$option'");
}
}
function UpdateControlPanel($updateoptions,$blog_id=0)
{
global $dbClass,$config;
$columns = $dbClass->GetColumns($config['table_prefix']."controlpanel");
$sql = "UPDATE ".$config['table_prefix']."controlpanel SET ";
/*$defualtCheck =false;
$defualtValuesArray = array();
$defaultkeyArrays =  array('controlpanel_mls_field_name','controlpanel_remote_photocount','controlpanel_remote_numeric','controlpanel_remote_photonumber_prefix','controlpanel_remote_custom_mls1_from','controlpanel_remote_custom_mls1_to','controlpanel_remote_custom_mls2_from','controlpanel_remote_custom_mls2_to','controlpanel_remote_custom_mls3_from','controlpanel_remote_custom_mls3_to','controlpanel_remote_numeric_thumb','controlpanel_remote_photonumber_prefix_thumb','controlpanel_remote_custom_mls1_from_thumb','controlpanel_remote_custom_mls1_to_thumb','controlpanel_remote_custom_mls2_from_thumb','controlpanel_remote_custom_mls2_to_thumb','controlpanel_remote_custom_mls3_from_thumb','controlpanel_remote_custom_mls3_to_thumb','controlpanel_images_cache_bool','controlpanel_images_cache_time','controlpanel_remote_checkphoto_bool','controlpanel_remote_numeric_bool','controlpanel_photocount','controlpanel_remote_numeric_bool_thumb');
if($updateoptions['controlpanel_remote_checkphoto_bool_default_path'] == 1)
{
$defualtCheck =true;
$defualtValuesArray = array();
$sqlSelectDefaul ="DESCRIBE ".$config['table_prefix']."controlpanel ";
$results = $dbClass->Query($sqlSelectDefaul);
if($results->RecordCOunt()>0)
{
while(!$results->EOF)
{
//$ret_tab = array();
$ret_tab = $results->fields;
$defualtValuesArray[$ret_tab['Field']] = $ret_tab['Default'];
$results->movenext();
}
//return $ret_tab;
}
}*/
if(count($updateoptions)>0)
{
foreach($updateoptions as $key => $value)
{
if(array_search($key,$columns))
{
$sql .= "$key='".$value."',";
}
/*if($defualtCheck && in_array($key, $defaultkeyArrays))
{
$sql .= "$key='".$defualtValuesArray[$key]."',";
}
else
{
} */
}
$sql = substr($sql,0,-1);
$sql .= " WHERE blog_id='".$blog_id."'";
return $dbClass->Query($sql);
}
else
return false;
}
/************************************************************\
*
\************************************************************/
function UpdateBlogSettings($blog_id,$mu_option=0,$replace=false)
{
global $dbClass,$config;
$sql = "SELECT * FROM `".$config['table_const_prefix']."controlpanel` WHERE blog_id='".$blog_id."'";
$settings = $dbClass->query($sql);
if($settings->recordCount()==0)
{
$sql = "INSERT INTO `".$config['table_const_prefix']."controlpanel` SET controlpanel_mu_option='".$mu_option."',blog_id='".$blog_id."'";
return $dbClass->Query($sql);
}elseif($replace!==false)
{
$sql = "UPDATE `".$config['table_const_prefix']."controlpanel` SET controlpanel_mu_option='".$mu_option."' WHERE blog_id='".$blog_id."'";
return $dbClass->Query($sql);
}else
return false;
}
/************************************************************\
*
\************************************************************/
function ControlPanelBackEnd($post_vars,$get_vars)
{
global $jqueryscript,$dbClass,$config,$presentationClass,$formsClass,$UrlClass;
//update options
if(isset($_POST['controlpanelsubmit']))
{
if(is_numeric($config['blog_id']))
{
if($post_vars['controlpanel_mu_option']==0)
{
if($post_vars['info_confirm']=='1')
{
if($this->UpdateBlogSettings($config['blog_id'],0,true))
{
require_once($config['wpradmin_basepath']."include/install.inc.php");
$installC = new installClass($config['basepath']);
$installC->DeleteDataTables();
$installC->DeleteWPR();
echo "Closing Window";
echo "<script type='text/javascript'>
if(parent.location!=window.location)
parent.location.reload();
</script>";
die();
}
}else
{
$return = "<form method='post'>
<input type='checkbox' name='info_confirm' value='1'> Yes, I want to completely remove the plugin from blog<br/>
<input type='hidden' name='controlpanel_mu_option' value='0'>
<input type='hidden' name='controlpanelsubmit' value='1'>
<input type='submit' value='Confirm'>
</form>";
return $return;
}
}
}
$controlpanelonlydata = $this->GetControlPanelOnlyData();
$post_vars = $dbClass->DataFiltersArray($_POST);
$updateoptions = array();
foreach($post_vars as $key=>$value)
{
if(strpos($key,'controlpanel_')!==false)
{
$updateoptions[$key] = $value;
unset($controlpanelonlydata[$key]);
}
}
foreach($controlpanelonlydata as $key => $value)
{
if(strpos($key,'bool')!==false OR $key=='controlpanel_wprets')
{
$updateoptions[$key] = 0;
}
}
if($this->UpdateControlPanel($updateoptions))
{
$this->WordpressRewriteRules($updateoptions);
$info_content = $presentationClass->OperationSuccessfull('Configuration Saved');
}
else
$info_content = $presentationClass->OperationFailed('Error');
}
$controlpaneldata = $this->GetControlPanelFields();
$headers = array(
//"general"=>"General",
"template"=>"Template",
"images"=>"Upload/Images",
"numbers"=>"Numbers",
"maps"=>"Maps",
"externaldatabase"=>"External Database Settings",
"remotephotos"=>"Listing Photo Setting",
"seo"=>"SEO"
);
$selected = false;
if(is_numeric($post_vars['active_tab']))
$selected = $post_vars['active_tab'];
$tabs['template'] = $this->TemplateSettings($controlpaneldata);
$tabs['remotephotos'] = $this->RemotePhotosSettings($controlpaneldata);
$tabs['numbers'] = $this->NumbersSetting($controlpaneldata);
$tabs['externaldatabase'] = $this->ExternalDatabaseSettings($controlpaneldata);
$tabs['maps'] = $this->MapsSetting($controlpaneldata);
$tabs['images'] = $this->UploadImagesSetting($controlpaneldata);
$tabs['seo'] = $this->SEOSettings($controlpaneldata);
if(is_numeric($config['blog_id']))
{
$headers['mu'] = "MU Settings";
$tabs['mu'] = $this->MUSettings($controlpaneldata);
}
$content .= $info_content;
$content .= $formsClass->startform();
$content .= $presentationClass->JqueryTabsWithDataNew($tabs,$headers,array('id'=>'siteconf_tab','class'=>'box grid_16 round_all tabs wpr_form','grabber'=>false,'toggle'=>false),$selected);
$content .= "<br/>".$formsClass->create_submit('controlpanelsubmit','Save',array('id'=>'saveconfiguration'));
$content .= $formsClass->create_hidden('active_tab',$selected,array('id'=>'active_tab'));
$content .= $formsClass->endform();
$content .= $jqueryscript->AddJqueryScriptEnd('
jQuery("#saveconfiguration").click(function()
{
var tmp = jQuery("#siteconf_tab").tabs("option", "selected");
jQuery("#active_tab").attr("value",tmp);
});
');
return $content;
}
/************************************************************\
* SEO SETTINGS TAB
\************************************************************/
function SEOSettings($controlpaneldata)
{
global $formsClass,$presentationClass;
//require_once("listingfields.inc.php");
//  $tab_fields = ListingFields::GetListingFieldsForeach();
//$tab_type = array("+"=>"default(+)","-"=>"hyphen(-)","_"=>"hyphen(_)", "/"=>"hyphen(/)" );
$tab_type = array("-"=>"hyphen(-)", "/"=>"slash(/)" );
$tab_url = array(0=>"Standard URL", 1=>"Search Engine Friendly");
$table_seosetting = array();
//$table_seosetting[] = array("URL Type",$formsClass->create_select('controlpanel_url_type',$controlpaneldata['controlpanel_url_type'], false, $tab_url));
$table_seosetting[] = array("Space Character:", $formsClass->create_select('controlpanel_space_character',$controlpaneldata['controlpanel_space_character'], false, $tab_type));
$table_seosetting[] = array("Default Page Title:", $formsClass->create_text('controlpanel_default_page_title',$controlpaneldata['controlpanel_default_page_title'],array('size'=>'70')));
$table_seosetting[] = array("Default META Description:", $formsClass->create_text('controlpanel_default_meta',$controlpaneldata['controlpanel_default_meta'], array('size'=>'70')));
$table_seosetting[] = array("Default META Keywords:", $formsClass->create_text('controlpanel_keyword_default_META',$controlpaneldata['controlpanel_keyword_default_META'],array('size'=>'70')));
$table_seosetting[] = array("Listing Details Page URL:",
$formsClass->create_text('controlpanel_listing_page_url',$controlpaneldata['controlpanel_listing_page_url'],array('size'=>'70')));
$table_seosetting[] = array("Listing Details Page Title:",
$formsClass->create_text('controlpanel_listing_page_title',$controlpaneldata['controlpanel_listing_page_title'],array('size'=>'70')));
$table_seosetting[] = array("Listing Details META Keywords:",
$formsClass->create_text('controlpanel_META_keywords_listing',$controlpaneldata['controlpanel_META_keywords_listing'],array('size'=>'70')));
$table_seosetting[] = array("Listing Details META Description: &nbsp; &nbsp;",
$formsClass->create_text('controlpanel_META_Description',$controlpaneldata['controlpanel_META_Description'],array('size'=>'70')));
$table = $presentationClass->SEOTableHelp(array('class'=>'controlpaneltable'));
$return = $table."<br>".$presentationClass->ControlPanelHeader("Search Engine Optimization  Settings").$presentationClass->StandardTableWithData($table_seosetting,false,false,array('class'=>'controlpaneltable'));
//$return .= "<br/>".$table;
return $return;
}
/************************************************************\
* Remote Photos Settings Tab
\************************************************************/
function RemotePhotosSettings($controlpaneldata)
{
global $formsClass,$presentationClass,$jqueryscript, $config;
require_once("listingfields.inc.php");
$ListingFields = registry::register('ListingFields');
$tab_fields = $ListingFields->GetListingFieldsForeach();
$tab_fields_choose = array_merge(array(""=>"choose"),$tab_fields);
$tab_012 = array("0","1","2","3","4","5","6","7","8","9","10","11","12");
//$tab_013 = array("listingsdb_PhotoCount"); snh
$tab_numeric = array(
"0"=>"01..09",
"1"=>"1..9",
"2"=>"a...z",
"3"=>"A...Z",
"4"=>"0..9",
"5"=>"0..09",
"6"=>"00..09",
"7"=>"2..10", // comma here?
);
$tab_prefix = array(
""=>"none",
"_"=>"_",
"-"=>"-"
);
// This is used to specify the type of image display.
$tab_format = array(
"0"=>"DEFAULT",
"1"=>"WPR-RETS Image Path",
"3"=>"Full RETS Image Path",
"4"=>"RETS Image File Name",
"5"=>"Cloud Image Storage"
);
$tab_time = array();
for($i=0;$i<14;$i++)
$tab_time[$i] = ($i+1);
$table_remotephotos = array();
/*
$table_remotephotos[] = array("Use The WPR-RETS Image Path:",
$formsClass->create_checkbox('controlpanel_wprets',1,array('id'=>'controlpanel_wprets'),$controlpaneldata['controlpanel_wprets']));
*/
$tr_option = "class='tr_hide'";
$table_remotephotos[] = array('tr'=>$tr_option,'content'=>array("Select Listing Photo Format:",
$formsClass->create_select('controlpanel_wprets',$controlpaneldata['controlpanel_wprets'],false,$tab_format)));
if($controlpaneldata['controlpanel_wprets']==1)
{
$tr_option = "class='tr_hide' style='display:none'";
}else
$tr_option = "class='tr_hide'";
// Render MLS Field Name
$table_remotephotos[] = array("tr"=>$tr_option,'content'=>array("MLS Number Field Name:",
$formsClass->create_select('controlpanel_mls_field_name',$controlpaneldata['controlpanel_mls_field_name'],false,$tab_fields)));
// Render Photo Count Field Name
$table_remotephotos[] = array("tr"=>$tr_option,'content'=>array("Photo Count Field:",
$formsClass->create_select('controlpanel_photocount',$controlpaneldata['controlpanel_photocount'],false,$tab_fields_choose)));
// Render Remote Photo Count Enable
$table_remotephotos[] = array("tr"=>$tr_option,'content'=>array("Use Remote Photo Count?:",
$formsClass->create_select('controlpanel_remote_photocount',$controlpaneldata['controlpanel_remote_photocount'],false,$tab_012).
$formsClass->create_checkbox('controlpanel_remote_checkphoto_bool',1,'',
$controlpaneldata['controlpanel_remote_checkphoto_bool'])."&nbsp;&nbsp;Checking to see if photo exists can dramatically decrease performance"
));
// Render Photo Numbering Format Select
$table_remotephotos[] = array('tr'=>$tr_option,'content'=>array("Photo Numbering Format:",
$formsClass->create_select('controlpanel_remote_numeric',$controlpaneldata['controlpanel_remote_numeric'],false,$tab_numeric).
$formsClass->create_checkbox('controlpanel_remote_numeric_bool',1,'',
$controlpaneldata['controlpanel_remote_numeric_bool'])."&nbsp;&nbsp;Skip numeration for first photo?"
));
$table_remotephotos[] = array('tr'=>$tr_option,'content'=>array("Photo Number Prefix:",$formsClass->create_select('controlpanel_remote_photonumber_prefix',$controlpaneldata['controlpanel_remote_photonumber_prefix'],false,$tab_prefix)));
//RYAN C
$tr_option2 = 'id="addit_path" ';
$checked = true;
if(empty($controlpaneldata['controlpanel_remote_path_addit'])){ $tr_option2 .= 'style="display:none"'; $checked = false;}
//END RYAN C
$table_remotephotos[] = array("tr"=>$tr_option,"content"=>array("Primary Photo Path:", $formsClass->create_text('controlpanel_remote_path',$controlpaneldata['controlpanel_remote_path'],array('size'=>'70')),$formsClass->create_checkbox('controlpanel_remote_path_addit_bool',1,'',/*$controlpaneldata['controlpanel_remote_path_addit_bool']*/$checked)."&nbsp;&nbsp;Use additional path?"));
//RYAN C
$table_remotephotos[] = array("tr"=>$tr_option2,"content"=>array("Addit. Photo Path:", $formsClass->create_text('controlpanel_remote_path_addit',$controlpaneldata['controlpanel_remote_path_addit'],array('size'=>'70'))));
//END RYAN C
//var_dump($config);
$ajaxURL = $config['baseurl']."ajax.php?f=ajax_remote_image_additional_url.php";
$js = "jQuery('#controlpanel_wprets').click(function()
{
//if(jQuery(this).is(':checked')==false)
if(jQuery(this).is(':checked')==1)
{
jQuery('.tr_hide').show();
}else
jQuery('.tr_hide').hide();
});
$('[name=\"controlpanel_remote_path_addit_bool\"]').click(function()
{
//ajax check/add setting to table
//return 0 on failed
//return 1 on checked successfully
//return 2 on not found, add successfully
$.ajax({
type: 'POST',
url: '".$ajaxURL."',
data: 'func=addaddit',
dataType: 'html'
}).done(function(data) {
var isconfiged = false;
if(data == 1 || data == 2){ isconfiged = true; }
if(isconfiged)
{
//alert($(this).html());
if($(\"#addit_path\").is(':visible')){ $(\"#addit_path\").hide(); }
else{ $(\"#addit_path\").show(); }
}
else
{
alert('something that shouldnt have happened, happened.');
}
});
//alert('test');
})";
$jqueryscript->AddJqueryScriptEnd($js);
/************************************************************\
*
\************************************************************/
$table_remotephotos[] = array('tr'=>$tr_option,'content'=>array("Custom MLS_1:",
"Start: ".$formsClass->create_text('controlpanel_remote_custom_mls1_from',$controlpaneldata['controlpanel_remote_custom_mls1_from'],array('size'=>'3')).
"Length: ".$formsClass->create_text('controlpanel_remote_custom_mls1_to',$controlpaneldata['controlpanel_remote_custom_mls1_to'],array('size'=>'3'))));
$table_remotephotos[] = array('tr'=>$tr_option,'content'=>array("Custom MLS_2:",
"Start: ".$formsClass->create_text('controlpanel_remote_custom_mls2_from',$controlpaneldata['controlpanel_remote_custom_mls2_from'],array('size'=>'3')).
"Length: ".$formsClass->create_text('controlpanel_remote_custom_mls2_to',$controlpaneldata['controlpanel_remote_custom_mls2_to'],array('size'=>'3'))));
$table_remotephotos[] = array('tr'=>$tr_option,'content'=>array("Custom MLS_3:",
"Start: ".$formsClass->create_text('controlpanel_remote_custom_mls3_from',$controlpaneldata['controlpanel_remote_custom_mls3_from'],array('size'=>'3')).
"Length: ".$formsClass->create_text('controlpanel_remote_custom_mls3_to',$controlpaneldata['controlpanel_remote_custom_mls3_to'],array('size'=>'3'))));
/************************************************************\
* Thumbnail Photo Numbering Format
\************************************************************/
$table_remotephotos_thumb = array();
$table_remotephotos_thumb[] = array("Photo Numbering Format:",
$formsClass->create_select('controlpanel_remote_numeric_thumb',$controlpaneldata['controlpanel_remote_numeric_thumb'],false,$tab_numeric).
$formsClass->create_checkbox('controlpanel_remote_numeric_bool_thumb',1,'',$controlpaneldata['controlpanel_remote_numeric_bool_thumb']).
"&nbsp;Skip numeration for first photo?"
);
/************************************************************\
* Thumbnail Photo Number Prefix
\************************************************************/
$table_remotephotos_thumb[] = array("Photo Number Prefix:",$formsClass->create_select('controlpanel_remote_photonumber_prefix_thumb',$controlpaneldata['controlpanel_remote_photonumber_prefix_thumb'],false,$tab_prefix));
$table_remotephotos_thumb[] = array("Thumb Photo Path:",
$formsClass->create_text('controlpanel_remote_path_thumb',$controlpaneldata['controlpanel_remote_path_thumb'],array('size'=>'70')));
/************************************************************\
*
\************************************************************/
$table_remotephotos_thumb[] = array("Custom MLS_1:",
"Start: ".$formsClass->create_text('controlpanel_remote_custom_mls1_from_thumb',$controlpaneldata['controlpanel_remote_custom_mls1_from_thumb'],array('size'=>'3')).
"Length: ".$formsClass->create_text('controlpanel_remote_custom_mls1_to_thumb',$controlpaneldata['controlpanel_remote_custom_mls1_to_thumb'],array('size'=>'3')));
$table_remotephotos_thumb[] = array("Custom MLS_2:",
"Start: ".$formsClass->create_text('controlpanel_remote_custom_mls2_from_thumb',$controlpaneldata['controlpanel_remote_custom_mls2_from_thumb'],array('size'=>'3')).
"Length: ".$formsClass->create_text('controlpanel_remote_custom_mls2_to_thumb',$controlpaneldata['controlpanel_remote_custom_mls2_to_thumb'],array('size'=>'3')));
$table_remotephotos_thumb[] = array("Custom MLS_3:",
"Start: ".$formsClass->create_text('controlpanel_remote_custom_mls3_from_thumb',$controlpaneldata['controlpanel_remote_custom_mls3_from_thumb'],array('size'=>'3')).
"Length: ".$formsClass->create_text('controlpanel_remote_custom_mls3_to_thumb',$controlpaneldata['controlpanel_remote_custom_mls3_to_thumb'],array('size'=>'3')));
/************************************************************\
*
\************************************************************/
$table_images_cache = array();
$table_images_cache[] = array("Do you want to cache images?: ",$formsClass->create_select('controlpanel_images_cache_bool',$controlpaneldata['controlpanel_images_cache_bool'],'',array(0=>'No',1=>'Yes')));
$table_images_cache[] = array("Refresh image cache every?&nbsp;:",$formsClass->create_select('controlpanel_images_cache_time',$controlpaneldata['controlpanel_images_cache_time'],'',$tab_time)."&nbsp;days");
$return = $presentationClass->ControlPanelHeader("Will you be using custom photo settings? &nbsp;Yes!").
$presentationClass->ControlPanelHeaderCheck("Set To default Local Path"."&nbsp;&nbsp;&nbsp;").
$formsClass->create_checkbox('controlpanel_remote_checkphoto_bool_default',1,'',$controlpaneldata['controlpanel_remote_checkphoto_bool_default']).
$presentationClass->StandardTableWithData($table_remotephotos,false,false,array('class'=>'controlpaneltable'));
$return .= "<div $tr_option>".$presentationClass->ControlPanelHeader("Listing Thumb Setting").$presentationClass->StandardTableWithData($table_remotephotos_thumb,false,false,array('class'=>'controlpaneltable'))."</div>";
$return .= "<br/><div $tr_option>".$presentationClass->ControlPanelHeader("Image Caching"."&nbsp;&nbsp;&nbsp;").$presentationClass->ControlPanelHeaderSide("*This option is used only when hot-linking to remote images and should not be used otherwise").$presentationClass->StandardTableWithData($table_images_cache,false,false,array('class'=>'controlpaneltable'))."</div>";
return $return;
}
/************************************************************\
*
\************************************************************/
function ExternalDatabaseSettings($controlpaneldata)
{
global $formsClass,$presentationClass,$jqueryscript,$config;
$table_exdatabase = array();
//controlpanel_masterdb_user 	controlpanel_masterdb_pass 	controlpanel_masterdb_db 	controlpanel_masterdb_server 	controlpanel_masterdb_bool
$external_check = "";
$tab_YN = array('0'=>'No','1'=>"Yes");
$external_check .= "<button id='check_external' onclick='return false;' style='float:none'>Check external connection</button>";
$jqueryscript->AddJqueryScriptEnd('
jQuery("#check_external").click(function()
{
var user = jQuery("#user").attr("value");
var pass = jQuery("#pass").attr("value");
var db = jQuery("#db").attr("value");
var server = jQuery("#server").attr("value");
$.ajax({
type: "POST",
data: "user="+user+"&pass="+pass+"&db="+db+"&server="+server,
url: "'.$config['adm_baseurl'].'ajax.php?f=check_external.php",
success: function(msg){
if(msg==1)
alert("The external connection works");
else
alert("The external connection dasn\'t work");
}
});
});
');
$table_exdatabase[] = array("Use External Listings Database?",$formsClass->create_select('controlpanel_masterdb_bool',$controlpaneldata['controlpanel_masterdb_bool'],'',$tab_YN));
$table_exdatabase[] = array("User:",$formsClass->create_text('controlpanel_masterdb_user',$controlpaneldata['controlpanel_masterdb_user'],array('id'=>'user')));
$table_exdatabase[] = array("Password:",$formsClass->create_text('controlpanel_masterdb_pass',$controlpaneldata['controlpanel_masterdb_pass'],array('id'=>'pass')));
$table_exdatabase[] = array("Database Name:",$formsClass->create_text('controlpanel_masterdb_db',$controlpaneldata['controlpanel_masterdb_db'],array('id'=>'db')));
$table_exdatabase[] = array("Server/IP:",$formsClass->create_text('controlpanel_masterdb_server',$controlpaneldata['controlpanel_masterdb_server'],array('id'=>'server')));
return $presentationClass->ControlPanelHeader("External Database Settings").$presentationClass->StandardTableWithData($table_exdatabase,false,false,array('class'=>'controlpaneltable')).$external_check;
}
/************************************************************\
*
\************************************************************/
function TemplateSettings($controlpaneldata)
{
global $formsClass,$presentationClass,$config;
$table = array();
//controlpanel_masterdb_user 	controlpanel_masterdb_pass 	controlpanel_masterdb_db 	controlpanel_masterdb_server 	controlpanel_masterdb_bool
require_once($config['wpradmin_basepath'].'/include/template.inc.php');
require_once($config['wpradmin_basepath'].'/include/searchengine.inc.php');
$tab_dirs = array();
$templateClass = registry::register('templateClass');
if($dirs = $templateClass->GetTemplateDir())
{
for($i=0;$i<count($dirs);$i++)
{
$tab_dirs[$dirs[$i]] = $dirs[$i];
}
}
$tab_YN = array('0'=>'No','1'=>"Yes");
$tab_files = $templateClass->GetTemplateFile($config['basepath']."template/".$controlpaneldata['controlpanel_template_dir']);
$tab_php = $tab_files['php'];
asort($tab_php);
$table[] = array("Template Name:",$formsClass->create_select('controlpanel_template_dir',$controlpaneldata['controlpanel_template_dir'],'',$tab_dirs));
//$table[] = array("Frontend template:",$formsClass->create_select('controlpanel_frontend_template',$controlpaneldata['controlpanel_frontend_template'],'',$tab_htmls));
$table[] = array("Listing Detail Template:",$formsClass->create_select('controlpanel_listing_template',$controlpaneldata['controlpanel_listing_template'],'',$tab_php));
$table[] = array("Print Listing Template:",$formsClass->create_select('controlpanel_listing_template_printer',$controlpaneldata['controlpanel_listing_template_printer'],'',$tab_php));
//$table[] = array("Listing Favorite Template:",$formsClass->create_select('controlpanel_favorites_template',$controlpaneldata['controlpanel_favorites_template'],'',$tab_htmls));
$table[] = array("RSS Template:",$formsClass->create_select('controlpanel_rss_template',$controlpaneldata['controlpanel_rss_template'],'',$tab_php));
$table[] = array("RSS Last Modified Limit:",$formsClass->create_text('controlpanel_rss_limit_lastmodified',$controlpaneldata['controlpanel_rss_limit_lastmodified'],''));
$table[] = array("RSS Featured Limit:",$formsClass->create_text('controlpanel_rss_limit_featured',$controlpaneldata['controlpanel_rss_limit_featured'],''));
$searchengine = registry::register('SearchEngineClass');
if($tab_searchengines_temp = $searchengine->GetSearchEngines())
{
for($i=0;$i<count($tab_searchengines_temp);$i++)
{
$tab_searchengines[$tab_searchengines_temp[$i]['id']] = $tab_searchengines_temp[$i]['name'];
}
$table[] = array("Main Search Engine:",$formsClass->create_select('controlpanel_main_searchengine',$controlpaneldata['controlpanel_main_searchengine'],'',$tab_searchengines));
}
else
$table[] = array("Main Search Engine:","No searchengines");
return $presentationClass->ControlPanelHeader("Template Settings").$presentationClass->StandardTableWithData($table,false,false,array('class'=>'controlpaneltable'));
}
/************************************************************\
*
\************************************************************/
function UploadImagesSetting($controlpaneldata)
{
global $formsClass,$presentationClass,$config;
$table = array();
$tab_YN = array('0'=>'No','1'=>"Yes");
$tab_thumb_by = array(
"width"=>"Width",
"height"=>"Height",
"bestfit"=>"Best Fit",
"both"=>"Both");
$table[] = array("Allowed Image Extensions:",$formsClass->create_text('controlpanel_img_allowed_ext',$controlpaneldata['controlpanel_img_allowed_ext']));
$table[] = array("Allowed Image File Types:",$formsClass->create_text('controlpanel_img_allowed_file_types',$controlpaneldata['controlpanel_img_allowed_file_types']));
$table[] = array("Create Thumbnails Option:",$formsClass->create_select('controlpanel_img_create_thumb',$controlpaneldata['controlpanel_img_create_thumb'],'',$tab_YN));
$table[] = array("Thumbnail Width:",$formsClass->create_text('controlpanel_img_thumb_width',$controlpaneldata['controlpanel_img_thumb_width']));
$table[] = array("Thumbnail Height:",$formsClass->create_text('controlpanel_img_thumb_height',$controlpaneldata['controlpanel_img_thumb_height']));
if(empty($controlpaneldata['controlpanel_img_thumb_quality']))
$controlpaneldata['controlpanel_img_thumb_quality'] = 75;
$table[] = array("Thumbnail Quality:",$formsClass->create_text('controlpanel_img_thumb_quality',$controlpaneldata['controlpanel_img_thumb_quality']).'% (75 suggested)');
$table[] = array("Display Thumbs by:",$formsClass->create_select('controlpanel_img_resize_thumb_by',$controlpaneldata['controlpanel_img_resize_thumb_by'],'',$tab_thumb_by));
return $presentationClass->ControlPanelHeader("Upload/Images Settings").$presentationClass->StandardTableWithData($table,false,false,array('class'=>'controlpaneltable upimagesettings'));
}
/************************************************************\
* Number Settings
\************************************************************/
function NumbersSetting($controlpaneldata)
{
global $formsClass,$presentationClass,$config;
$table = array();
$tab_number_format_style  = array(
1=>"1,000",
2=>"1.000,00",
3=>"1 000.00",
4=>"1 000,00",
5=>"1'000,00",
6=>"1-000 00");
$tab_money_format = array(1=>"$1",2=>"1$",3=>"$ 1");
$tab_date_format = array(1=>"mm/dd/yyyy",2=>"yyyy/dd/mm",3=>"dd/mm/yyyy",4=>"yyyy/mm/dd");
$table[] = array("Monetary Format:",$formsClass->create_select('controlpanel_number_format_style',$controlpaneldata['controlpanel_number_format_style'],'',$tab_number_format_style));
$table[] = array("Monetary Symbol:",$formsClass->create_select('controlpanel_money_format',$controlpaneldata['controlpanel_money_format'],'',$tab_money_format));
$table[] = array("Date Display Format:",$formsClass->create_select('controlpanel_date_format',$controlpaneldata['controlpanel_date_format'],'',$tab_date_format));
require_once($config['wpradmin_basepath']."include/listingfields.inc.php");
$ListingFields = registry::register('ListingFields');
$tab_fields = $ListingFields->GetListingFieldsForeach();
$tab_fields_choose = array_merge(array(""=>"choose"),$tab_fields);
$table[] = array("Select A Price Field:",$formsClass->create_select('controlpanel_price_field',$controlpaneldata['controlpanel_price_field'],'',$tab_fields_choose));
$table[] = array("Max Search Results:", $formsClass->create_text('controlpanel_max_search_results',$controlpaneldata['controlpanel_max_search_results']));
return $presentationClass->ControlPanelHeader("Numbers Settings").$presentationClass->StandardTableWithData($table,false,false,array('class'=>'controlpaneltable numbersettings'));
}
/************************************************************\
*
\************************************************************/
function MapsSetting($controlpaneldata)
{
global $formsClass,$presentationClass,$config;
$table = array();
require_once($config['wpradmin_basepath']."include/listingfields.inc.php");
$ListingFields = registry::register('ListingFields');
$tab_fields = $ListingFields->GetListingFieldsForeach();
$tab_fields_choose = array_merge(array(""=>"choose"),$tab_fields);
//$table[] = array("Google API key: ",$formsClass->create_text('controlpanel_googlemapskey',$controlpaneldata['controlpanel_googlemapskey'],''),"<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>GET Google API Key</a>");
//$table[] = array("Walk Score ID:",$formsClass->create_text('controlpanel_walkscorekey',$controlpaneldata['controlpanel_walkscorekey'],''),"<a href='http://www.walkscore.com/request-tile-key.php' target='_blank'>GET Walk Score ID Key</a>");
$table[] = array("Walk Score :",$formsClass->create_select('controlpanel_walkscore',$controlpaneldata['controlpanel_walkscore'],'',array(0=>'Off',1=>'On')));
$table[] = array("Street view :",$formsClass->create_select('controlpanel_streetview',$controlpaneldata['controlpanel_streetview'],'',array(0=>'Off',1=>'On')));
$table[] = array("Address Field:",$formsClass->create_select('controlpanel_map_address',$controlpaneldata['controlpanel_map_address'],'',$tab_fields_choose));
$table[] = array("City Field:",$formsClass->create_select('controlpanel_map_city',$controlpaneldata['controlpanel_map_city'],'',$tab_fields_choose));
$table[] = array("State Field:",$formsClass->create_select('controlpanel_map_state',$controlpaneldata['controlpanel_map_state'],'',$tab_fields_choose));
$table[] = array("Zip Field:",$formsClass->create_select('controlpanel_map_zip',$controlpaneldata['controlpanel_map_zip'],'',$tab_fields_choose));
$table[] = array("Country Field:",$formsClass->create_select('controlpanel_map_country',$controlpaneldata['controlpanel_map_country'],'',$tab_fields_choose));
$table[] = array("Latitude Field:",$formsClass->create_select('controlpanel_map_lat',$controlpaneldata['controlpanel_map_lat'],'',$tab_fields_choose));
$table[] = array("Longitude Field:",$formsClass->create_select('controlpanel_map_lng',$controlpaneldata['controlpanel_map_lng'],'',$tab_fields_choose));
return $presentationClass->ControlPanelHeader("Maps Settings").$presentationClass->StandardTableWithData($table,false,false,array('class'=>'controlpaneltable'));
}
/************************************************************\
*
\************************************************************/
function MUSettings($controlpaneldata)
{
global $formsClass,$presentationClass,$config;
$table = array();
$mu_mode = array(0=>'Share Main Domain',1=>'Setup New Install');
$table[] = array("MU Mode:",$formsClass->create_select('controlpanel_mu_option',1,'',$mu_mode));
$content = $presentationClass->ControlPanelHeader("MU Settings").$presentationClass->StandardTableWithData($table,false,false,array('class'=>'controlpaneltable'));
return $content;
}
}
?>