<?php

/*
 * Commercial Codebase by WP Realty - RETS PRO Development Team.
 * Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
 * License: http://retspro.com/faq/license/
 */
$bypass = FALSE;// this is a switch to bypass a markerSrc pass
class ShortCodeClass {

    private $parser = false;

    function CheckShortCodeType($type) {
        switch ($type) {
            case '':
                break;
        }
    }

    function parseSingleTag($matches) {
        global $config;
//return $matches[0].'123';
        if ($this->parser == false) {
            require_once($config['wpradmin_basepath'] . 'include/parse.inc.php');
            $this->parser = registry::register('parseClass');
        }
        return $this->parser->MainParse($matches[0], $_GET['listing_id']);
    }

    function GenerateShortCode($listing_id, $params, $rss_subscribe_return = false) {
//var_dump($params);
        $polyToPage = '';
        $markersToPage = '';
        
        global $dbClass, $config, $_get_safe, $bypass;
        if (isset($params['wpsc']) && $params['wpsc'] === true) {
            if (isset($params['values']) && strpos($params['values'], '{') !== false) {
                $params['values'] = preg_replace_callback('/(\\{.*?\\})/', array(
                    $this,
                    'parseSingleTag'
                        ), $params['values']);
//echo '<br>sc parsed= '.$params['values'];
                unset($params['wpsc']);
            }
        }
        $options_tab = array(
            "type" => false,
            "fields" => false,
            "values" => false,
            "orderdir" => false,
            "featured" => false,
            "remote" => false,
            "orderby" => false,
            "count" => false,
            "template" => false,
            "sort_type" => false,
            "rss_temp" => false,
            "rss" => false,
            "pagination" => false,
            "polygon" => false,
            "exclude" => false,
            "remove" => false,
            'kit_search' => false
        );
        $options = $this->Set_Tags_Values($params, $options_tab);
        //var_dump($options);die();
        if (($options['sort_type'] === false) OR ( strtoupper($options['sort_type'] == "LOCAL"))) {
            $options['sort_type'] = 0;
        } else {
            $options['sort_type'] = 1;
        }
        $user_sort = false;
//var_dump($options); echo '<br>';
//var_dump($params);
        if (isset($params['get']['sortedby']) || isset($params['orderby'])) {
            $options['sort_type'] = 1;
            $user_sort = true;
            if (isset($params['orderby']))
                $options['orderby'] = $params['orderby'];
            if (isset($params['get']['sortedby']))
                $options['orderby'] = $params['get']['sortedby'];
            if (isset($params['get']['orderdir'])) {
                $options['orderdir'] = $params['get']['orderdir'];
            } elseif (isset($params['orderdir'])) {
                $options['orderdir'] = $params['orderdir'];
            } else {
                $options['orderdir'] = 'DESC';
            }
        }
//echo $options['orderby'];
//echo 'sortedby '.$params['get']['sortedby'];
        if (is_numeric($options['count'])) {
            $limit = $options['count'];
        } else
            $limit = 3;
//featured ID tab
        $featured_id = "";
        if ($options['featured'] == True) {
            $sql = "select listingsdb_id from " . $config['table_prefix'] . "listingsdb where listingsdb_featured='yes'";
            $row = $dbClass->Query($sql, $params['masterdb']);
            while (!$row->EOF) {
                $featured_id.=$row->fields['listingsdb_id'] . ",";
                $row->MoveNext();
            }
            if ($featured_id == "") {
                return false;
            } else
                $featured_id = substr($featured_id, 0, -1);
        }
        $id_listings = array();
        if (($options['fields'] !== false) AND ( $options['values'] !== false)) {
            $fields = explode("|", $options['fields']);
            $values = explode("|", html_entity_decode($options['values']));
            if (count($fields) == 1) {
                if (preg_match("/(.*?)(?:\((\d+)\))/", $fields[0], $match))
                    $field = $match[1];
                else
                    $field = $fields[0];
                $sql = "SELECT listingsdb_id FROM " . $config['table_prefix'] . "listingsdb WHERE (";
                for ($i = 0; $i < count($values); $i++) {
                    $lis_field = strtolower($field);
                    if (preg_match('/(\d+)-(\d+)/', $values[$i], $tags_found)) {
                        $sql .= "(" . $lis_field . "+0>='" . $tags_found[1] . "') AND (" . $lis_field . "+0<='" . $tags_found[2] . "')";
                    } else {
                        $searchvalue = str_replace(array("\xe2\x80\x93", chr(150)), array('-', '-'), $values[$i]);
                        $sql .= "(" . $lis_field . " LIKE \"" . $searchvalue . "\") ";
                    }
                    if ($i < count($values) - 1)
                        $sql .= " OR ";
                }
                $sql .= ')';
                if ($options['featured'] === True) {
                    $sql .= " AND listingsdb_id IN (" . $featured_id . ") ";
                }
// polygon
                
                if($options['polygon']){
                    $polyToPage .= '<script>var mapPolygon = [';
                    $polypoints = explode('|', $options['polygon']);
                    
                    $sql .= " AND ST_CONTAINS(ST_GEOMFROMTEXT('POLYGON((";
                    
                    foreach($polypoints as $point){
                        list($lat, $lng) = explode(':', $point);
                        $sql .= $lng.' '.$lat.', ';
                        $polyToPage .= '{lat: '.$lat.', lng: '.$lng.'}, ';
                    }
                    $sql = substr($sql, 0, -2);
                    $polyToPage = substr($polyToPage, 0, -2);
                    $polyToPage .= '];</script>';
                    $sql .= "))'), point(longitude, latitude))";
                }
 // end polygon
                
// Exclude multi field value combinations
                if($options['remove']){
                    $fieldsSrc = explode('::', $options['remove']);
                    foreach($fieldsSrc as $fieldSrc){
                        list($field, $values_src) = explode(':', $fieldSrc);
                        $values = explode(',', $values_src);
                        foreach($values as $value){
                            $sql .= " AND ".$field." != '".trim($value)."'";
                        }
                    }
                }
// end exclude multi fields
                
// exclude based on field values
                if($options['exclude']){
                    list($field, $values_src) = explode(':', $options['exclude']);
                    $values = explode(',', $values_src);
                    foreach($values as $value){
                        $sql .= " AND ".$field." != '".trim($value)."'";
                    }
                }
// end exclude
                
// Assure current listing is not served in sc on a details page
                if (preg_match('%.*/listing-details/listing-([a-zA-z0-9]*)-.*%', $_SERVER['REQUEST_URI'], $regs)) {
                        $current_listing = $regs[1];
                        $sql .= " AND MLS != '".$current_listing."'";
                }
// end block current listing 
                
// Toronto kitchens
                if($options['kit_search']){
                    
                }
                
                if ($options['sort_type'] == 0) {
                    $sql.= " ORDER by rand() ";
                } else {
//$sql .= " ORDER by ".$options['orderby'];
//$sql .= " ".$options['orderdir'];
///////////////////////////////////////*
                    if (strpos(strtoupper($options['orderby']), "PRICE") !== False) {
                        $sql .= " ORDER by (" . $options['orderby'] . "+0) ";
                    } else {
                        $sql .= " ORDER by listingsdb_" . $options['orderby'];
                    }
                    if ($options['orderdir'] != false)
                        $sql .= " " . $options['orderdir'];
////////////////////////////////////////////////////////////*/
                }
                if (is_numeric($options['pagination'])) {
                    $cur_page = 1;
                    global $last_sc_num;
                    if ($last_sc_num > 0)
                        $add_num = "_" . $last_sc_num;
                    else
                        $add_num = "";
                    global $get_safe; //u hack
                    if (is_numeric($get_safe['sc_curpage' . $add_num]))
                        $cur_page = $get_safe['sc_curpage' . $add_num];
                    $sql_count = $sql;
                    $sql_count .= " LIMIT 0," . $limit;
                    $limit = $options['pagination'];
                    $reAllListing = $dbClass->query($sql_count, $params['masterdb']);
                    $all_listing = $reAllListing->RecordCount();
                    $sql .= " LIMIT " . ($cur_page - 1) * $limit . "," . $limit;
                } else
                    $sql .= " LIMIT 0," . $limit;
//echo $sql;die();
//easyecho($sql, __FILE__, __LINE__);
                $resID = $dbClass->Query($sql, $params['masterdb']);
                if ($resID === false)
                    return false;
                if ($resID->recordCount() > 0) {
                    for ($i = 0; $i < $resID->recordCount(); $i++) {
                        $id_listings[$i] = $resID->fields['listingsdb_id'];
                        $resID->MoveNext();
                    }
                }
            // This means more than 1 field
            } elseif (count($fields) > 1) {
                $values_position = 0;
                $sql = "SELECT listingsdb_id
FROM " . $config['table_prefix'] . "listingsdb
WHERE ";
                if(isset($params['field_relation']) && $params['field_relation'] == 'OR'){
                        $sql .= '(';
                    }
                for ($i = 0; $i < count($fields); $i++) {
                    if (preg_match("/(.*?)(?:\((\d+)\))/", $fields[$i], $match)) {
                        $field = $match[1];
                        $values_count = $match[2];
                    } else {
                        $field = $fields[$i];
                        $values_count = 1;
                    }
                    
                    
                    
                    $sql .= "(";
                    for ($y = 0; $y < $values_count; $y++) {
                        $lis_field = strtolower($field);
                        if (preg_match('/(\d+)-(\d+)/', $values[$values_position], $tags_found)) {
                            $sql .= "(" . $lis_field . "+0>='" . $tags_found[1] . "') AND (" . $lis_field . "+0<='" . $tags_found[2] . "')";
                        } else {
                            if (preg_match('/%.*?%/i', $values[$values_position])) {//Wildcard match
                                $sql .= "(" . $lis_field . " LIKE '" . $values[$values_position] . "') ";
                            } else {
                                $searchvalue = str_replace(array("\xe2\x80\x93", chr(150)), array('-', '-'), $values[$values_position]);
                                $sql .= "(" . $lis_field . " =\"" . $searchvalue . "\") ";
//$sql .= "(".$lis_field." ='".$values[$values_position]."') ";
                            }
                        }
                        if ($y < $values_count - 1)
                            $sql.=" OR ";
                        $values_position++;
                    }
                    $sql .= ")";
                    if ($i < count($fields) - 1){
                        if(isset($params['field_relation']) && $params['field_relation'] == 'OR')
                            $sql .= " OR ";
                        else 
                            $sql .= " AND ";
                    }
                    else{
                        // close OR parens
                        if(isset($params['field_relation']) && $params['field_relation'] == 'OR')
                        {
                            $sql .= ')';
                        }
                    }
                        
                }
                if ($options['featured'] === True) {
                    $sql .= " AND listingsdb_id IN (" . $featured_id . ") ";
                    

                    
                }
                
                // polygon
                //echo $options['polygon'];die();
                if($options['polygon']){
                    $polyToPage .= '<script>var mapPolygon = [';
                    $polypoints = explode('|', $options['polygon']);
                    $sql .= ' AND';
                    $sql .= " ST_CONTAINS(ST_GEOMFROMTEXT('POLYGON((";
                    
                    foreach($polypoints as $point){
                        list($lat, $lng) = explode(':', $point);
                        $sql .= $lng.' '.$lat.', ';
                        $polyToPage .= '{lat: '.$lat.', lng: '.$lng.'}, ';
                    }
                    $polyToPage = substr($polyToPage, 0, -2);
                    $polyToPage .= '];</script>';
                    $sql = substr($sql, 0, -2);
                    $sql .= "))'), point(longitude, latitude))";
                    //echo $polyToPage;
                }
 // end polygon
 // 
 // Exclude multi field value combinations
                if($options['remove']){
                    $fieldsSrc = explode('::', $options['remove']);
                    foreach($fieldsSrc as $fieldSrc){
                        list($field, $values_src) = explode(':', $fieldSrc);
                        $values = explode(',', $values_src);
                        foreach($values as $value){
                            $sql .= " AND ".$field." != '".trim($value)."'";
                        }
                    }
                }
// end exclude multi fields
 // 
 // exclude based on field values
                if($options['exclude']){
                    list($field, $values_src) = explode(':', $options['exclude']);
                    $values = explode(',', $values_src);
                    foreach($values as $value){
                        $sql .= " AND ".$field." != '".trim($value)."'";
                    }
                }
// end exclude
 // Assure current listing is not served in sc on a details page
                if (preg_match('%.*/listing-details/listing-([a-zA-z0-9]*)-.*%', $_SERVER['REQUEST_URI'], $regs)) {
                        $current_listing = $regs[1];
                        $sql .= " AND MLS != '".$current_listing."'";
                }
// end block current listing                
                if ($options['orderby'] === false) {
                    $sql.= " ORDER by rand() ";
                } else {
//die('here');
//$sql .= " ORDER by ".$options['orderby'];
//if($options['orderdir']!=false) $sql .= " ".$options['orderdir'];
                    if (strpos(strtoupper($options['orderby']), "PRICE") !== False || strpos(strtoupper($options['orderby']), "PRICE") !== False) {
                        $sql .= " ORDER by (" . $options['orderby'] . "+0) ";
                    } else {
                        $sql .= " ORDER by " . $options['orderby'];
                    }
                    if ($options['orderdir'] != false)
                        $sql .= " " . $options['orderdir'];
                }
                if (is_numeric($options['pagination'])) {
                    $cur_page = 1;
                    global $last_sc_num;
                    if ($last_sc_num > 0)
                        $add_num = "_" . $last_sc_num;
                    else
                        $add_num = "";
                    global $get_safe; //u hack
                    if (is_numeric($get_safe['sc_curpage' . $add_num]))
                        $cur_page = $get_safe['sc_curpage' . $add_num];
                    $sql_count = $sql;
                    $sql_count .= " LIMIT 0," . $limit;
                    $limit = $options['pagination'];
                    $reAllListing = $dbClass->query($sql_count, $params['masterdb']);
                    $all_listing = $reAllListing->RecordCount();
                    $sql .= " LIMIT " . ($cur_page - 1) * $limit . "," . $limit;
                } else
                    $sql .= " LIMIT 0," . $limit;
//echo $sql;die();
                $resID = $dbClass->Query($sql, $params['masterdb']);
                if ($resID->recordCount() > 0) {
                    for ($i = 0; $i < $resID->recordCount(); $i++) {
                        $id_listings[$i] = $resID->fields['listingsdb_id'];
                        $resID->MoveNext();
                    }
                }
            }
        } else {
            $sql = "SELECT listingsdb_id FROM " . $config['table_prefix'] . "listingsdb";
            if ($options['featured'] == True) {
                $sql .= " WHERE listingsdb_id IN (" . $featured_id . ") ";
            }
            
// polygon
                
                if($options['polygon']){
                    $polyToPage .= '<script>var mapPolygon = [';
                    $polypoints = explode('|', $options['polygon']);
                    if ($options['featured'] == True)
                        $sql .= ' AND';
                    else
                        $sql .= ' WHERE';
                    $sql .= " ST_CONTAINS(ST_GEOMFROMTEXT('POLYGON((";
                    
                    foreach($polypoints as $point){
                        list($lat, $lng) = explode(':', $point);
                        $sql .= $lng.' '.$lat.', ';
                        $polyToPage .= '{lat: '.$lat.', lng: '.$lng.'}, ';
                    }
                    $polyToPage = substr($polyToPage, 0, -2);
                    $polyToPage .= '];</script>';
                    $sql = substr($sql, 0, -2);
                    $sql .= "))'), point(longitude, latitude))";
                    //echo $polyToPage;
                }
 // end polygon
 
                
// Exclude multi field value combinations
                if($options['remove']){
                    $fieldsSrc = explode('::', $options['remove']);
                    foreach($fieldsSrc as $fieldSrc){
                        list($field, $values_src) = explode(':', $fieldSrc);
                        $values = explode(',', $values_src);
                        foreach($values as $value){
                            $sql .= " AND ".$field." != '".trim($value)."'";
                        }
                    }
                }
// end exclude multi fields
                
 // exclude based on field values
                if($options['exclude']){
                    list($field, $values_src) = explode(':', $options['exclude']);
                    $values = explode(',', $values_src);
                    foreach($values as $value){
                        $sql .= " AND ".$field." != '".trim($value)."'";
                    }
                }
// end exclude
 // Assure current listing is not served in sc on a details page
                if (preg_match('%.*/listing-details/listing-([a-zA-z0-9]*)-.*%', $_SERVER['REQUEST_URI'], $regs)) {
                        $current_listing = $regs[1];
                        $sql .= " AND MLS != '".$current_listing."'";
                }
// end block current listing            
            if ($options['orderby'] === false) {
//die('no sort');
//$sql.= " ORDER by rand() ";
            } else {
                if (strpos(strtoupper($options['orderby']), "PRICE") !== False) {
//$sql .= " ORDER by (".$options['orderby']."+0) ";
                    $sql .= " ORDER BY " . $options['orderby'];
                } else {
                    $sql .= " ORDER by listingsdb_" . $options['orderby'];
                }
                if ($options['orderdir'] != false)
                    $sql .= " " . $options['orderdir'];
            }
            if (is_numeric($options['pagination'])) {
                $cur_page = 1;
                global $last_sc_num;
                if ($last_sc_num > 0)
                    $add_num = "_" . $last_sc_num;
                else
                    $add_num = "";
                if (is_numeric($_GET['sc_curpage' . $add_num]))
                    $cur_page = $_GET['sc_curpage' . $add_num];
                $sql_count = $sql;
                $sql_count .= " LIMIT 0," . $limit;
                $limit = $options['pagination'];
                $reAllListing = $dbClass->query($sql_count, $params['masterdb']);
                $all_listing = $reAllListing->RecordCount();
                $sql .= " LIMIT " . ($cur_page - 1) * $limit . "," . $limit;
            } else
                $sql .= " LIMIT 0," . $limit;
            //die($polyToPage);
 //die('sql multi '.$sql);
 //echo 'sql multi ' . $sql;
// if($options['sort_type']==0) $sql.= " LIMIT ".$limit;
            $resID = $dbClass->Query($sql, $params['masterdb']);
            $result_count = $resID->recordCount(); // mm
            if ($resID->recordCount() > 0) {
                for ($i = 0; $i < $resID->recordCount(); $i++) {
                    $id_listings[$i] = $resID->fields['listingsdb_id'];
                    $resID->MoveNext();
                }
            }
        }
        $template = "";
        if (count($id_listings) > 0) {
            if ($rss_subscribe_return === true) {
//var_dump($id_listings);
                return $id_listings;
            }
            if ($options['rss'] === 'yes') {
                $data = serialize($options);
                $data = base64_encode($data);
                $template .= "<br/><a href='" . $config['wpr_baseurl'] . "index.php?page=rss&type=rss_subscribe&data=" . $data . "' style='text-decoration:none'><img src ='" . $config['wpradmin_baseurl'] . "images/rss.png'> Subscribe</a>";
            }
            if ($options['template'] !== false) {
                $template .= $this->Show_Listings_Standard($id_listings, $options['template']);
            } else {
                $template .= $this->Show_Listings_Standard($id_listings);
            }
            
            $map_info = \Mbx\System\GetModuleConfig('MapSearch');
            $marker_field_hack = '';
            if($map_info["classField"]){
                $marker_field_hack = ', latitude, longitude, '.$map_info["classField"];
            }
            
            // temp - output some js vals
            //echo 'spmark '.$map_info['specialMarkerField'];die();
            if(isset($map_info['specialMarkerField']) && $map_info['specialMarkerField'] != ''){
                $sql = 'SELECT listingsdb_id, latitude, longitude, '.$map_info["classField"].', '.$map_info['specialMarkerField'].' FROM '.$config['table_prefix'].'listingsdb WHERE';
            }
            else{
                $sql = 'SELECT listingsdb_id'.$marker_field_hack.' FROM '.$config['table_prefix'].'listingsdb WHERE';
            }
            
            foreach($id_listings as $lid){
                $sql .= " listingsdb_id = ".$lid.' OR';
            }
            $sql = substr($sql, 0, -3);
            //echo $sql;die();
            $parseClass = registry::register('parseClass');
            
            $resID = $dbClass->Query($sql, WPR_USING_EXTERNAL_DB);
            $result_count = $resID->recordCount(); // mm
            
            if ($result_count > 0 && !$bypass) {
                
                $markersToPage .= "<script>var markersSrc = [";
                $bypass = TRUE;
                for ($i = 0; $i < $result_count; $i++) {
                   
                    $link = $parseClass->MainParse('{full_link_to_listing}', $resID->fields['listingsdb_id']);
                    
                    $lid = $resID->fields['listingsdb_id'];
                    $lat = $resID->fields['latitude'];
                    $lng = $resID->fields['longitude'];
                    $img = $resID->fields[$map_info["classField"]];
                    $override_img = $resID->fields[$map_info["specialMarkerField"]];
                    
                    $marker_image = isset($override_img) && $override_img != '' ? $override_img : $img;
                    
                    if(!$lat){
                        $resID->MoveNext();
                        continue;
                    }
                        
                    
                    $markersToPage .= '{';
                    $markersToPage .= 'link: "'.$link.'", ';
                    $markersToPage .= 'lid: '.$lid.', ';
                    $markersToPage .= 'lat: '.$lat.', ';
                    $markersToPage .= 'lng: '.$lng.', ';
                    $markersToPage .= 'img: "'.$marker_image.'"';
                    $markersToPage .= '}, ';
                    //echo $markersToPage;die();
                    $id_listings[$i] = $resID->fields['listingsdb_id'];
                    $resID->MoveNext();
                }
                
                $markersToPage = substr($markersToPage, 0, -2);
                $markersToPage .= "];</script>";
                //echo $markersToPage;
            }
            //$markersToPage = '<script>var markersSrc = [{a:1, b:2.3}, {a:2, b:4.5}] ';
            
//echo $all_listing;
            if ($options['pagination'] !== false && $all_listing > $options['pagination']) {
                global $presentationClass, $UrlClass, $last_sc_num;
                require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
                $parseClass = registry::register('parseClass');
                $max_on_page = $options['pagination'];
                $max_visible = 10;
                $last_page = ceil($all_listing / $max_on_page);
                $number_pagination = $parseClass->GetTemplate($config['basepath'] . $config['template_dir'] . '/' . "pagination_sc.php");
                $number_row = $parseClass->GetTemplateBlock('numberpagination', $number_pagination);
                $add_num = "";
                if ($last_sc_num > 0)
                    $add_num = "_" . $last_sc_num;
                $standardurl = $UrlClass->ReplaceUrlValues(array('sc_curpage' . $add_num => '[sc_curpage]'));
                if (isset($params['get']['sortedby']))
                    $standardurl . '&amp;sortedby=' . $options['orderby'] . '&amp;sorteddir=' . $options['orderdir'];
//echo 'stdURL '.$standardurl;
//prevpage
                if ($cur_page > 1)
                    $number_pagination = str_replace("{prevpage}", str_replace('[sc_curpage]', $cur_page - 1, $standardurl), $number_pagination);
                else
                    $number_pagination = str_replace("{prevpage}", str_replace('[sc_curpage]', $cur_page, $standardurl), $number_pagination);
//nextpage
                if ($cur_page < $last_page)
                    $number_pagination = str_replace("{nextpage}", str_replace('[sc_curpage]', $cur_page + 1, $standardurl), $number_pagination);
                else
                    $number_pagination = str_replace("{nextpage}", str_replace('[sc_curpage]', $last_page, $standardurl), $number_pagination);
                $number_pagination = str_replace("{firstpage}", str_replace('[sc_curpage]', 1, $standardurl), $number_pagination);
                $number_pagination = str_replace("{lastpage}", str_replace('[sc_curpage]', $last_page, $standardurl), $number_pagination);
                $row_pagination = $presentationClass->PreparePaginationNumber($number_row['content'], $all_listing, $cur_page, $max_visible, $max_on_page, $standardurl, '[sc_curpage]');
                $number_pagination = $parseClass->ReplaceTemplateBlock('numberpagination', $row_pagination, $number_pagination);
                $template = $number_pagination . $template;
                
                $last_sc_num++;
                //die($polyToPage);
            }
            $template .= $polyToPage;
            //$template .= $markersToPage;
            echo $markersToPage;
            //die($markersToPage);
            return $template;
        }
        else {
            return false;
        }
    }

// Remote db flag
//parse gallery template
//image = an array of all images for this listing
    function Show_Gallery($images, $template = "") {
//var_dump($images);
        global $config, $presentationClass;
        require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
        $parseClass = registry::register('parseClass');
//if ($config['wordpress_plugin'] == true)
//$temp_dir = $config['template_dir'] . "/sc_templates";
// else
        $temp_dir = $config['template_dir'];
        if ($template != "")
            $template = $parseClass->GetTemplate($config['basepath'] . $temp_dir . "/" . $template);
        else
            $template = $parseClass->GetTemplate($config['basepath'] . $temp_dir . "/" . 'image_gallery_template.php');
        $ret = '';
//if repeat_image_row template block is found
        if ($repeat_row_params = $parseClass->GetTemplateBlock("repeat_image_row", $template)) {
//if image template tag is found
            if (strstr($repeat_row_params['content'], '{image_url}') !== FALSE) {
//loop through all images
                foreach ($images as $image) {
//replace "repeat_image_row" template block
                    $ret .= $parseClass->ReplaceTag("{image_url}", $image, $repeat_row_params['content']);
                }
            }
        }
        $template = $parseClass->ReplaceTemplateBlock("repeat_image_row", $ret, $template);
        return do_shortcode($template);
//return $template;
    }

//END Remote db flag
    function Show_Listings_Standard($listings, $template = "") {
        global $config, $presentationClass;
        require_once($config['wpradmin_basepath'] . "include/parse.inc.php");
        $parseClass = registry::register('parseClass');
        if ($config['wordpress_plugin'] == true)
            $temp_dir = $config['template_dir'] . "/sc_templates";
        else
            $temp_dir = $config['template_dir'];
        if ($template != "")
            $template = $parseClass->GetTemplate($config['basepath'] . $temp_dir . "/" . $template);
        else
            $template = $parseClass->GetTemplate($config['basepath'] . $temp_dir . "/" . 'embed_template.php');
        if ($repeat_in_row_params = $parseClass->GetTemplateBlock("repeat_in_row", $template)) {
            if (!is_numeric($repeat_in_row_params['repeat'])) {
                $repeat_in_row_params['repeat'] = false;
            }
            $repeat_row = $parseClass->GetTemplateBlock("repeat_row", $repeat_in_row_params['content']);
            $counter = 0;
            $rows_in_repeat = "";
            $rows = "";
            for ($i = 0; $i < count($listings); $i++) {
                $rows .= $parseClass->MainParse($repeat_row['content'], $listings[$i], true);
//$rows .= $parseClass->MainParse($tmp,$offices[$i]['office_id']);
                if ($i % 2 == 0)
                    $odd = 0;
                else
                    $odd = 1;
                $rows = $parseClass->ReplaceTag("{row_num_even_odd}", $odd, $rows);
                if ($counter == $repeat_in_row_params['repeat'] - 1) {
                    $rows_in_repeat .= $parseClass->ReplaceTemplateBlock("repeat_row", $rows, $repeat_in_row_params['content']);
                    $rows = "";
                    $counter = 0;
                } elseif ($i == count($listings) - 1) {
                    /*
                      for($y=0;$y<$repeat_in_row_params['repeat']*ceil(count($listings)/$repeat_in_row_params['repeat'])-count($listings);$y++)
                      $rows .=  $parseClass->ReplaceTemplateBlock("repeat_row","",$repeat_in_row_params['content']);
                     */
                    $rows_in_repeat .= $parseClass->ReplaceTemplateBlock("repeat_row", $rows, $repeat_in_row_params['content']);
                } else
                    $counter++;
            }
            $repeat_in_row_params['content'] = $parseClass->ReplaceTemplateBlock("repeat_row", $rows_in_repeat, $repeat_in_row_params['content']);
            $template = $parseClass->ReplaceTemplateBlock("repeat_in_row", $repeat_in_row_params['content'], $template);
        }
        else {
            if ($repeat_row = $parseClass->GetTemplateBlock("repeat_row", $template)) {
                for ($i = 0; $i < count($listings); $i++) {
                    $rows .= $parseClass->MainParse($repeat_row['content'], $listings[$i], true);
                    if ($i == -1) {
                        echo $rows;
                        die();
                    }
                }
                $template = $parseClass->ReplaceTemplateBlock("repeat_row", $rows, $template);
//echo $template;die();
            } else {
                for ($i = 0; $i < count($listings); $i++) {
                    $rows .= $parseClass->MainParse($template, $listings[$i], true);
                }
                $template = $rows;
            }
        }
        
        // 
        
        return $template;
    }

    function Set_Tags_Values($params, $options_tab) {
        foreach ($options_tab as $key => $value) {
            if (isset($params[$key])) {
                if ($params[$key] != "")
                    $return_tab[$key] = $params[$key];
                else
                    $return_tab[$key] = false;
            } else
                $return_tab[$key] = false;
        }
        return $return_tab;
    }

}

?>