<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
require_once("install.inc.php");
class wpr_installClass extends installClass
{
var $basepath;
var $baseurl;
function __construct($include_path,$basepath,$baseurl)
{
$this->include_path = $include_path;
$this->basepath = $basepath;
$this->baseurl = $baseurl;
}
function GetBasePath()
{
return $this->basepath;
}
function GetBaseUrl()
{
return $this->baseurl;
}
}
?>