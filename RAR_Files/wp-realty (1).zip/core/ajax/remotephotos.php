<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

global $config;

error_reporting(E_ALL^E_NOTICE);

//require_once('../config.php');

require_once($config['wpradmin_basepath'].'include/images.inc.php');

$imagesClass = new ImagesClass();

if(!isset($_GET['tab_images']) OR !isset($_GET['checkphoto']))

{

    die();

} else {

    $standard_width = false;

    $standard_height = false; 

    if(is_numeric($_GET['width']))

        $standard_width = $_GET['width'];

        

    if(is_numeric($_GET['height']))

        $standard_height = $_GET['height'];        

    

    $tab_images = $_GET['tab_images'];

    $images = "";



    for($i=1;$i<count($tab_images);$i++)

    {

        $url = $tab_images[$i];

        if($_GET['checkphoto']==1) 

        {

            if($url = $imagesClass->ChooseOptionUrlExists($url))

            {

                if($standard_height===false OR $standard_width===false)

                {

                    $infoImage = getimagesize($url);

                }

                if($standard_width)

                {

                    $width = $standard_width;

                }

                else

                {

                    $width = $imageInfo[1];

                }

                if($standard_height)

                    $height = $standard_height;

                else

                    $height = $imageInfo[2];                    

                $images .= "<img src='$url' width='".$width."' height='".$height."' />";

            }

        }

        else

            $images .= "<img src='$url' width='".$standard_width."' height='".$standard_height."'/>";

    }      

    echo $images;

}

?>