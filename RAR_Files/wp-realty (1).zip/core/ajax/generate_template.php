<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

error_reporting(E_ALL^E_NOTICE);

//require_once("../config.php");

require_once($config['wpradmin_basepath']."include/contactform.inc.php");

$cf_class =  new ContactFormClass();

if(is_numeric($_GET['form_id']) AND $_GET['mode']==1)

{

    echo $cf_class->GenerateTemplatePHP($_GET['form_id']);

}

elseif(is_numeric($_GET['form_id']) AND $_GET['mode']==2)

{

    echo $cf_class->GenerateTemplateCSS($_GET['form_id']);

}

?>