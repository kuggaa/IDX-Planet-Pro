<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

session_start();

error_reporting(E_ALL);

header('Content-Type: image/png');

//require_once('config.php');

global $config;

$path_background = $config['wpradmin_basepath']."images/captcha.png";

$chars         = 'ABCDEFGHIJKLMNPQRSTUWXYZ123456789';

$liczba_znakow = rand(4,6);

$cap           = imagecreatefrompng($path_background);

$color         = imagecolorallocate($cap, 250, 250, 250);

$linie         = imagecolorallocate($cap, 205, 205, 205);

for($x = 1; $x <= 50; $x++)        // powtarzamy 50 razy - rysujemy 50 linii

 imageline(                        // funkcja rysująca linię

  $cap,                            // uchwyt obrazka

  0,                               // współrzędna X początku linii

  rand(-100,imagesy($cap)+100),    // współrzędna Y początku linii

  imagesx($cap),                   // współrzędna X końca linii

  rand(-100,imagesy($cap)+100),    // współrzędna Y końca linii

  $linie                           // kolor linii

 );

$face = $config['wpradmin_basepath']."include/verdana.ttf";

$rand_text = "";

for($x = 0; $x < $liczba_znakow; $x++)

{

 //$face = $czcionki[array_rand($czcionki)];

	$znak = $chars[rand(0,strlen($chars)-1)];

	$rand_text .=  $znak;

	//$captcha .= $znak;	

	$char_len = (round(imagesx($cap) / $liczba_znakow+1)-10)*($x)+20;

	

	imagettftext(                      // funkcja pisząca tekst

		$cap,                             // uchwyt obrazka

		rand(15, 25),                     // rozmiar czcionki

		rand(-15, 15),                    // naczylenie znaku

		$char_len,        // odległość między znakami

		rand(20, 40),                     // położenie względem górnej krawędzi obrazka

		$color,

		$face,

		$znak

	);

}

$_SESSION['captcha'] = md5(strtolower($rand_text));

$_SESSION['text'] = strtolower($rand_text);

imagejpeg($cap);

?>