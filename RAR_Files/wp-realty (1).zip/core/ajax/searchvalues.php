<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

error_reporting(E_ALL^E_NOTICE);

global $dbClass;

global $config;

//include("../config.php");

$elements_db = $config['table_prefix']."listingsdbelements"; 

$name_field = $_GET['field'];

$number = $_GET['number'];

$max_size  = 25;

$display = "<td>";

$display .= "</td>";

$display .= "<td><input type='text' name='field_".$number."' id='field_".$number."' value=''></td>";

    if($dbClass->ColumnExists($config['table_prefix']."listingsdb",$name_field,$tmp,true))

    {

        $sql = "SELECT ".$name_field." FROM ".$config['table_prefix']."listingsdb ORDER BY ".$name_field;

        $reField = $dbClass->query($sql,true);        

        if($reField->RecordCount()>0)

        {

            if(strpos(trim(strtoupper($name_field)),"MLS")===False AND strpos(trim(strtoupper($name_field)),"LISTINGSDB_ID")===False)

            {

                $return = array();

                while(!$reField->EOF)

                {

                    if(!in_array($reField->fields[$name_field],$return) AND $reField->fields[$name_field]!="" AND $reField->fields[$name_field]!=Null)

                        $return[] = $reField->fields[$name_field];

                    $reField->MoveNext();

                }

            }

            

            if(strpos(trim(strtoupper($name_field)),"MLS")===False AND strpos(trim(strtoupper($name_field)),"LISTINGSDB_ID")===False AND count($return)>0)

            {

                $display .= "<td><select id='selectval_".$number."'>";

                $numeric = True;

                $numeric_select="";

                for($i=0;$i<count($return);$i++)

                {

                    if(!is_numeric($return[$i]))

                    {

                        $numeric = False;

                    }

                     if(strlen($return[$i])>$max_size)

                    {

                        $option= substr($return[$i],0,$max_size);

                        $option .= "...";

                    }

                    else

                        $option = $return[$i];
// mm 10-9-15 changed to escaped double quotes on the value
                    $display .= "<option value=\"".$return[$i]."\" >".strtolower($option)."</option>";

                    $numeric_select .= "<option value='".$return[$i]."' >".$return[$i]."</option>";   

                    $data .= $return[$i]." ";

                }

                if($numeric==True)

                {

                    $val=1;

                }

                else

                    $val=0;

                $display .= "</select></td>";

            }

            

            if(strpos(trim(strtoupper($name_field)),"MLS")===False)

            {

                   $display .= "<td><a href='#' id='aval_".$number."' class='avalclass'><img src='".$config['wpradmin_baseurl']."images/add-icon.png' border='0'></a></td>";

            }

            else

                $display .= "<td></td>";

         }

    }        

$display .= "

    <td>&nbsp;<a href='#' id='adel_".$number."' class='adelclass'><img src='".$config['wpradmin_baseurl']."images/delete-icon.png' border='0'></a></td>

    <input type='hidden' name='isnumeric_".$number."' id='isnumeric_".$number."' value='".$val."'>

    ";

echo $display;

?>