<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

session_start();

error_reporting(E_ALL^E_NOTICE);

global $config,$dbClass;

//require_once('../config.php');



require_once($config['wpradmin_basepath']."include/login.inc.php");

$loginClass = new loginClass();



if(!$user_info = $loginClass->CheckLogin()){

    echo "access_denied";

    die();

}



if($user_info['user_level']==0)

{

    echo "access_denied";

    die();

}



if($_POST['mode']==1)

{

    if(is_numeric($_POST['num']))

    {

        require_once($config['wpradmin_basepath']."include/presentation.inc.php");

        require_once($config['wpradmin_basepath']."include/searchengine.inc.php");

        $se = new SearchEngineClass;

        $opt = $se->GenerateFieldBox(array('field_name'=>$_POST['field'],'id'=>0,'field_in_table'=>$_POST['field']),$_POST['num']);

        $co = PresentationClass::CreateItemSE($opt[0],$opt[1]);

        echo $co;

    }

}

elseif($_POST['mode']==2)

{

    require_once($config['wpradmin_basepath']."include/searchengine.inc.php");

    $se = new SearchEngineClass;

		// $field_value = base64_decode($_POST['fieldvalue']);

    $field_value = $_POST['fieldvalue'];

    $field_value = str_replace("\n","|",$field_value);

    $co = $se->FieldPreview($_POST['fieldtype'],$_POST['fieldcaption'],$_POST['fieldheight'],$_POST['fieldwidth'],$field_value);    

    echo $co; 

}

elseif($_POST['mode']==3)

{

//    $field_value = base64_decode($_POST['value']);

    $field_value = $_POST['value'];

    echo str_replace('|',"\n",$field_value);

    

}

elseif($_POST['mode']==4)

{

    if(is_numeric($_POST['num']))

    {

        require_once($config['wpradmin_basepath']."include/searchengine.inc.php");

        $se = new SearchEngineClass;

        echo $se->GenerateTabContent($_POST['num']);    

    }

}

?>