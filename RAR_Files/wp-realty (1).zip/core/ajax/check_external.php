<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

    global $config;

    //require_once("../config.php");

    require_once($config['wpradmin_basepath']."include/dbClass.inc.php");

    $db_check = new dbClass();

    if($connection = $db_check->ConnectBase($_POST["server"],$_POST["user"],$_POST["pass"],$_POST["db"]))

    {

        echo "1";

        die();

    }

?>