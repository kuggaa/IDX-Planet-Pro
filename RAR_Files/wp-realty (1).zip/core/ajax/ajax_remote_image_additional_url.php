<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
session_start();
//error_reporting(E_ALL^E_NOTICE);

global $config,$dbClass;
//require_once('../config.php');
require_once($config['wpradmin_basepath']."include/login.inc.php");
$loginClass = new loginClass();
if(!$user_info = $loginClass->CheckLogin()){
    echo "access_denied";
    die();
}
    
if($user_info['user_level']==0)
{
    //echo $loginClass->ShowLoginForm("Access denied");
    echo "access_denied";
    die();
}


switch($_POST['func'])
{
	case 'addaddit':
		
		if($dbClass->ColumnExists($config['table_prefix']."controlpanel","controlpanel_remote_path_addit")) echo 1; //found
		else	
			if($dbClass->AddColumn($config['table_prefix']."controlpanel","controlpanel_remote_path_addit","varchar(150)")) echo 2; //added
		
	break;
	
	default:
		
	break;

}
?>