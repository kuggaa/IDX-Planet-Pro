<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

error_reporting(E_ALL^E_NOTICE);

global $dbClass;

global $config;

$post_vars = $dbClass->DataFiltersArray($_POST);

/************************************************************\

*

\************************************************************/

if($post_vars['mode']==1)

{

    if($post_vars['field_name']!="")

    {

        require_once($config['wpradmin_basepath']."include/contactform.inc.php");

        require_once($config['wpradmin_basepath']."include/presentation.inc.php");

        $contactform = new ContactFormClass;

        $presentation = new PresentationClass;

        $edit_id = false;

        if(is_numeric($_POST['edit_id']))

            $edit_id = $_POST['edit_id'];

        $contactform->AddEditField($post_vars,$edit_id);

        echo $contactform->GenerateFieldsTable($edit_id);

    }

}

elseif($post_vars['mode']==2)

{

    if(is_numeric($post_vars['field_id']))

    {

        require_once($config['wpradmin_basepath']."include/contactform.inc.php");

        $contactform = new ContactFormClass;

        $edit_id = false;

        if(is_numeric($_POST['edit_id']))

            $edit_id = $_POST['edit_id'];        

        $contactform->DeleteField($post_vars['field_id']);

        echo $contactform->GenerateFieldsTable($edit_id);                

    }

}

?>