<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

session_start();

error_reporting(E_ALL^E_NOTICE);

global $config,$dbClass;

//require_once('../config.php');

require_once($config['wpradmin_basepath']."include/login.inc.php");

$loginClass = new loginClass();

if(!$user_info = $loginClass->CheckLogin()){

    echo "access_denied";

    die();

}



/************************************************************\

*

\************************************************************/

if($user_info['user_level']==0)

{

    echo "access_denied";

    die();

}



/************************************************************\

*

\************************************************************/

if(is_numeric($_POST['page']) OR $_POST['page']=='Previous'  OR $_POST['page']=='Next'  OR $_POST['page']=='First'  OR $_POST['page']=='Last')

{

    require_once($config['wpradmin_basepath']."include/listingfields.inc.php");

    $listing = new ListingFields;

    $query = false;

    if($_POST['query']!='')

    {

        $query = $_POST['query']; 

    }

    $user_id=false;

    if($_POST['mode']=='my')

        $user_id = $user_info['user_id'];

    $tab = $listing->GetListings($query,$_POST['page'],$user_id);

    $listing_count = $listing->GetListingsCount($query,$user_id);

    $page = $_POST['page']; 

    $content = "";

    $content .= $listing->GenerateHugeTable($tab,$listing_count,$_POST['page']);

    echo $content;

}

?>