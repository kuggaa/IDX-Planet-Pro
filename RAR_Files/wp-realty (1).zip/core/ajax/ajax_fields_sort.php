<?php
/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/
session_start();
//error_reporting(E_ALL^E_NOTICE);

global $config,$dbClass;
//require_once('../config.php');
require_once($config['wpradmin_basepath']."include/login.inc.php");
$loginClass = new loginClass();
if(!$user_info = $loginClass->CheckLogin()){
    echo "access_denied";
    die();
}
    
if($user_info['user_level']==0)
{
    //echo $loginClass->ShowLoginForm("Access denied");
    echo "access_denied";
    die();
}
$i = 0;
if($_POST['type']=='agent')
{//die('test');
    require_once($config['wpradmin_basepath']."include/agent.inc.php");
    $class = new AgentClass();
    $true=0;
    for($i=0;$i<3;$i++)
    {        
        if(strlen($_POST['fields'.$i])>0)
        {            
            $fields = explode('|',$_POST['fields'.$i]);
            if(count($fields)>0)
            {				//var_dump($fields);								//i = 0, 1, 2				//fields = 
                if($class->SaveAgentFieldOrder($i,$fields))
                {					//echo "access_denied";					//die();
                    $true++;    
                }
            }
        }           
    }    
}
elseif($_POST['type']=='office')
{
    require_once($config['wpradmin_basepath']."include/office.inc.php");
    $class = new OfficeClass();
    $true=0;
    for($i=0;$i<3;$i++)
    {        
        if(strlen($_POST['fields'.$i])>0)
        {            
            $fields = explode('|',$_POST['fields'.$i]);
            if(count($fields)>0)
            {
                if($class->SaveOfficeFieldOrder($i,$fields))
                {
                    $true++;    
                }
            }
        }           
    }    
}
elseif($_POST['type']=='user')
{
    require_once($config['wpradmin_basepath']."include/users.inc.php");
    $class = new UsersClass();
    $true=0;
    for($i=0;$i<3;$i++)
    {        
        if(strlen($_POST['fields'.$i])>0)
        {            
            $fields = explode('|',$_POST['fields'.$i]);
            if(count($fields)>0)
            {
                if($class->SaveUserFieldOrder($i,$fields))
                {
                    $true++;    
                }
            }
        }           
    }    
} else {
    require_once($config['wpradmin_basepath']."include/listingfields.inc.php");
    $listingFields = new ListingFields();
    $true=0;
    for($i=0;$i<3;$i++)
    {
        if(strlen($_POST['fields'.$i])>0)
        {
            $fields = explode('|',$_POST['fields'.$i]);
            if(count($fields)>0)
            {
                if($listingFields->SaveListingFieldOrder($i,$fields))
                {
                    $true++;    
                }
            }
        }           
    }
}
if($true==$i)
    echo "true";
?>