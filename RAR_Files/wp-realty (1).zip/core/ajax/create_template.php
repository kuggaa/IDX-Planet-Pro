<?php

/*
* Commercial Codebase by WP Realty - RETS PRO Development Team.
* Copyright - WP Realty - RETS PRO - 2009 - 2016 - All Rights Reserved
* License: http://retspro.com/faq/license/
*/

global $config;

error_Reporting(E_ALL^E_NOTICE);

//include("../config.php");

$file_name = trim($_GET['file']);

$file_content = $_GET['content'];

if($file_name!="")

{

    $e=True;

    $file_src = $config['basepath'].$config['template_dir'].'/sc_templates/'.$file_name.".php";

    if(!is_dir($config['basepath'].$config['template_dir'].'/sc_templates/'))

    {

        if(!mkdir($config['basepath'].$config['template_dir'].'/sc_templates/',0755))

        {

            echo "3";

            $e = False;

        }

    }

    

    if($e==True)

    {

        if(!file_exists($file_src))

        {

            if($file_content!="")

            {

                $f = fopen($file_src,"w");

                if($f!==False)

                {

                    fwrite($f,$file_content);

                    fclose($f);

                    echo $file_name.".php";

                }

                else

                    echo "4";

            } 

            else

            {

                echo "2";

            }

        }

        else

            echo "1";

    }

}

else

{

    echo "0";

}

?>