<?php
namespace Mbx\Page;
//include_once "config.php";
$siteroot = preg_replace('#(wp-content.*)#','',$config["wpradmin_baseurl"]);

define('WPR_MOD_TPL_DIR', $config["baseurl"].$config["template_dir"]);

define('MBX_WPR_AJAX_URL', $siteroot.'wpradmin/mbx/'); // Marked to remove

define('ADMIN_GLOBAL_CSS_FILE', $siteroot.'wpradmin/mbx/System/UI/css/all-rpadmin.css');

define('MBX_AJAX', FALSE);

include_once 'System/MbxConfig.php';

include_once 'System/functions.php';

include_once 'System/Entities.php';

include_once 'System/mbx_pdo.php';

function PageComposer(){
    $data = $_GET;
    if('System' == $data['apage'] || 'UserAuth' == $data['apage'] || $data['apage'] == 'WprCrm'){
        $targetfile = MBX_BASE_SYSTEM_PATH.$data['apage'].'/Page.php';
    }
    else{
        $targetfile = WPR_MODULES_PATH.$data['apage'].'/Page.php';
    }
    
    $ns = '\\'.$data['apage'].'\\'; // Namespace builder
    //echo $targetfile;
    //die();
    if(file_exists($targetfile)){
        include_once $targetfile;
        $targetfunc = $ns.$data['Feature'];
        
        if(is_callable($targetfunc)){
            $init_wpr = '<script>WPR = WPR || {};</script>';
            $jq = '<script src="'.WPR_ADMIN_SITE_ROOT.'mbx/System/scripts/jquery-1.12.1.min.js"></script>';
            $jq_isolate = '<script>WPR.jq = jQuery.noConflict(true);</script>';
            $framework_js = '<script src="'.WPR_ADMIN_SITE_ROOT.'mbx/System/scripts/Framework.js"></script>';
            $system_js = '<script src="'.WPR_ADMIN_SITE_ROOT.'mbx/System/scripts/System.js"></script>';
            $thispage = $targetfunc($data);
            $thispage->page_content = $init_wpr.$jq.$jq_isolate.$framework_js.$system_js.$thispage->page_content;
            return $thispage;
        }
        // Some sort of append any js
    }
    return new PageReturn('Page Not Found', 'The page you have requested does not exist.');
}

class PageReturn{
    public $header;
    public $page_content;
    
    public function __construct($header = '', $content = '') {
        $this->header = $header;
        $this->page_content = $content;
    }
}

