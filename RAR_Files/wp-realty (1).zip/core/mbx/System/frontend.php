<?php
namespace Mbx\System;

include_once 'api_functions.php';

/**
 * Main System API controller
 * 
 * Routes API calls to functions
 * 
 * @param mixed $data
 * @return mixed
 */
function SystemApi($data){
    switch($data['action']){
        case 'GetAdminMenuLinks':
            //return MBX_BASE_SYSTEM_PATH.'System';
            $adminLinks = array();
            $adminModules = array();
            $adminModules[] = MBX_BASE_SYSTEM_PATH.'System';
            $adminModules[] = MBX_BASE_SYSTEM_PATH.'WprCrm';
            $installed_modules = array_merge($adminModules, glob(WPR_MODULES_PATH . '*', GLOB_ONLYDIR));
            //var_dump($installed_modules);
            //var_dump(count($installed_modules));
            foreach ($installed_modules as $module) {
                //return file_get_contents($module . '/Page.php');
                if(file_exists($module . '/Page.php')){
                    //return $module . '/Page.php';
                    include_once $module . '/Page.php';
                    
                    $modName = basename($module);
                    //return $modName;
                    $funcName = '\\'.$modName.'\\GetAdminLinks';
                    //var_dump($funcName());
                    if(is_callable($funcName)){
                        //echo '<br>'.$funcName.'<br>';
                        $adminLinks = array_merge($adminLinks, $funcName());
                    }
                }  
            }
            //var_dump($funcName);
            return $adminLinks;
        case 'GetModuleSettings':
            return GetModuleConfig($data['module_name']);
        case 'SetModuleSettings':
            return SetModuleConfig($data);
        case 'GetFeatureInstState':
            return GetFeatureInstState($data);
        case 'UploadFile':
            return UploadFileAsync($data);
        case 'InstallUpdate':
            return InstallUpdate($data);
        case 'InstallModule':
            return InstallModule($data);
        case 'UninstallModule':
            return UninstallModule($data);
        case 'DeleteModule':
            return DeleteModule($data);
        case 'DeleteUpdate':
            return DeleteUpdate($data);
        case 'GetDistinctList':
            return GetDistinctList($data);
        case 'GetTableFieldsFiltered':
            return GetTableFields($data);
        case 'GetTableFieldsRaw':
            return GetTableFields($data, FALSE);
        case 'GetSavedSearches':
            return GetSavedSearches($data);
        case 'GetFavorites':
            return GetFavorites($data);
        
        default:
            return NULL;
    }
}

