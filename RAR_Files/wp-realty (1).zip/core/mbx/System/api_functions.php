<?php
namespace Mbx\System;

/**
 * Returns the installed and available FeatureModules and Updates for display
 * 
 * @param mixed[] $data
 * @return \Mbx\System\ModulesState
 */
function GetFeatureInstState($data){
    $InstalledModules = array();
    $installed_module_paths = glob(WPR_MODULES_PATH . '*', GLOB_ONLYDIR);
    foreach ($installed_module_paths as $path) {
        $InstalledModules[] = MbxGetModuleFromGlob($path);
    }
    
    $AvailableModules = array();
    $available_module_paths = glob(WPR_MODULES_REPO . '*.zip');
    foreach ($available_module_paths as $path) {
        $AvailableModules[] = str_replace('.zip', '', MbxGetModuleFromGlob($path));
    }
    
    $available_update_paths = glob(MBX_UPDATE_SRC_DIR . '*.zip');
    foreach ($available_update_paths as $path) {
        $AvailableModules[] = str_replace('.zip', '-Update', MbxGetModuleFromGlob($path));
    }
    
    $AvailableModulesDisplay = array_values(array_diff($AvailableModules, $InstalledModules));
    foreach($InstalledModules as &$module){
        $ver = '';
        //error_log(WPR_MODULES_PATH.$module.'/version.txt'."\n");
        if(file_exists(WPR_MODULES_PATH.$module.'/version.txt')){
            $ver = file_get_contents(WPR_MODULES_PATH.$module.'/version.txt');
        }
        $module = $module.' '.$ver;
    }
    
    return new ModulesState($InstalledModules, $AvailableModulesDisplay);
}

/**
 * Uploads FeatureModule zip files via ajax
 * 
 * Returns either the installed features state or an error message
 * 
 * @param mixed[] $data
 * @return mixed
 */
function UploadFileAsync($data){
    /*if(strpos($_FILES["feature-file"]["name"], 'UpdPkg') !== FALSE){
        if(strpos($_FILES["feature-file"]["name"], 'Core') === 0)return TRUE;
        if(strpos($_FILES["feature-file"]["name"], 'System') === 0)return TRUE;
        if(strpos($_FILES["feature-file"]["name"], 'UserAuth') === 0)return TRUE;
    }*/
//return 'click';new_file_name
    switch($data['type']){
        case 'Feature':
            $target_file = WPR_MODULES_REPO . basename($_FILES["feature-file"]["name"]);
    
            if (move_uploaded_file($_FILES["feature-file"]["tmp_name"], $target_file)) {
                //echo "The file ". basename( $_FILES["feature-file"]["name"]). " has been uploaded.";
                if(class_exists('\ZipArchive')){
                    $zip = new \ZipArchive;
                    if($zip->open($target_file)){
                        if(!$zip->locateName('installer.php', \ZipArchive::FL_NODIR)){
                            unlink($target_file);
                        }
                    }
                    else{
                        unlink($target_file);
                    }
                }

            } else {
                //echo "Sorry, there was an error uploading your file.";
            }
            return GetFeatureInstState($data);
        case 'Update':
            $target_file = MBX_UPDATE_SRC_DIR . basename(strtolower(substr($_FILES["feature-file"]["name"], 0, -11).'.zip'));
    
            if (move_uploaded_file($_FILES["feature-file"]["tmp_name"], $target_file)) {
                //echo "The file ". basename( $_FILES["feature-file"]["name"]). " has been uploaded.";
                if(class_exists('\ZipArchive')){
                    $zip = new \ZipArchive;
                    if($zip->open($target_file)){
                        if(!$zip->locateName('updater.php', \ZipArchive::FL_NODIR)){
                            unlink($target_file);
                        }
                    }
                    else{
                        unlink($target_file);
                    }
                }

            } else {
                //echo "Sorry, there was an error uploading your file.";
            }
            return GetFeatureInstState($data);
            // Give the modules a shot at it
        default :
            //return $_FILES[0]['name']; // $data['new_file_name']
            if(!empty($_FILES))
            {
                if(isset($data['module'])){
                    $api = WPR_MODULES_PATH.$data['module'].'/api_functions.php';
                    
                    if(file_exists($api))
                        include_once($api);
                    else 
                        return 'failed - api file '.$api.' does not exist';
                    
                    $upload_function = '\\'.$data['module'].'\\API\\FileUpload';/////////// Here is your function name and namespace
                    //return $upload_function($data);
                    if(is_callable($upload_function))
                        return $upload_function($data);
                    else 
                        return 'failed - module '.$data['module'].' has no FileUpload() function to handle this upload';
                }
                else{
                    return 'failed - no module specified to handle upload';
                }
            }
            else{
                return 'failed - no file';
            }
            return $targetFile;
            if(!empty($data['module'])){
                
            }
    }

    
    
}
// $data['component'] is implemented as the name part of the name.ext for convenience for now
/**
 * Installs an MBX or system update
 * 
 * @param mixed[] $data
 * @return GetFeatureInstState ModulesState
 */
function InstallUpdate($data){
    $target_file = MBX_UPDATE_SRC_DIR.strtolower(substr($data['component'], 0, -7)).'.zip';
    
    $dir = WPR_ADMIN_PATH.'/'.strtolower(substr($data['component'], 0, -7));
    
    $extracted = FALSE;
    
    if(class_exists('\ZipArchive')){
        $zip = new \ZipArchive;
        
        if ($zip->open($target_file) === TRUE) {
            
            $zip->extractTo(WPR_ADMIN_PATH);
            $zip->close();
            $extracted = TRUE;
        }
    }
    else{
        exec("`which unzip` $target_file -d ".WPR_ADMIN_PATH, $ret_val);
                $extracted = TRUE;
    }
    
    unlink($target_file);
    
    if($extracted){
        if(file_exists($dir.'/updater.php')){
            //echo $dir.'/installer.php2';
            include_once $dir.'/updater.php';
            $instFunc = '\\'.$data['module'].'\\Update';
            if(is_callable($instFunc)){
                //echo $instFunc;
                $instFunc($data['keepCustom']);
            }
        }
    }
    return GetFeatureInstState($data);
    
}

/**
 * Installs a FeatureModule
 * 
 * @param mixed[] $data
 * @return GetFeatureInstState ModulesState
 */
function InstallModule($data){
    $target_file = WPR_MODULES_REPO.$data['module'].'.zip';
    $dir = WPR_MODULES_PATH.$data['module'];
    $extracted = FALSE;
    
    if(class_exists('\ZipArchive')){
        $zip = new \ZipArchive;
        //echo WPR_MODULES_REPO.$data['module'].'.zip';
        if ($zip->open($target_file) === TRUE) {
            //echo WPR_MODULES_REPO.$data['module'].'.zip';
            $zip->extractTo(WPR_MODULES_PATH);
            $zip->close();
            $extracted = TRUE;
            

            
        }
    }
    else{
        exec("`which unzip` $target_file -d ".WPR_MODULES_PATH, $ret_val);
                $extracted = TRUE;
    }
    
    if($extracted){
        if(file_exists($dir.'/installer.php')){
            //echo $dir.'/installer.php2';
            include_once $dir.'/installer.php';
            $instFunc = '\\'.$data['module'].'\\Install';
            if(is_callable($instFunc)){
                //echo $instFunc;
                $instFunc($data['keepCustom']);
            }
        }
        else{
            MbxRemoveDir($dir);
        }
    }
    
    return GetFeatureInstState($data);
}

/**
 * Uninstalls a FeatureModule
 * 
 * @param mixed[] $data
 * @return GetFeatureInstState ModulesState
 */
function UninstallModule($data){
    $dir = WPR_MODULES_PATH.$data['module'];
    if(file_exists($dir.'/uninstaller.php')){
        include_once $dir.'/uninstaller.php';
        $uinstFunc = '\\'.$data['module'].'\\Uninstall';
        if(is_callable($uinstFunc)){
            $uinstFunc($data['keepCustom']);
        }
    }
    MbxRemoveDir($dir);
    
    return GetFeatureInstState($data);
}

/**
 * Deletes a FeatureModule zip from the ModulesRepository
 * 
 * @param mixed[] $data
 * @return GetFeatureInstState ModulesState
 */
function DeleteModule($data){
    unlink(WPR_MODULES_REPO.$data['module'].'.zip');
    
    return GetFeatureInstState($data);
}

/**
 * Deletes an MBX or system update from the Updates directory
 * 
 * @param mixed[] $data
 * @return GetFeatureInstState ModulesState
 */
function DeleteUpdate($data){
    $target_file = MBX_UPDATE_SRC_DIR.strtolower(substr($data['component'], 0, -7)).'.zip';
    //return $target_file;
    unlink($target_file);
    
    return GetFeatureInstState($data);
}

/**
 * Returns a distinct list of values for 1 column of a table
 * 
 * @param mixed[] $data
 * @return GetFeatureInstState ModulesState
 */
function GetDistinctList($data){
    $sql = 'SELECT DISTINCT '.$data['fieldname'].' FROM '.WPR_TABLE_PFX.$data['tablename'].' ORDER BY :orderby ASC';
    $paramArr = array(':orderby' => $data['fieldname']);
    
    if($data['tablename'] == 'listingsdb')
        $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
    else 
        $db = \Mbx\DataStore\MbxGetDb();
    
    
    $returnArr = array();
    try{
        $rawresults = $db->GetRows($sql, $paramArr);
    } catch (Exception $ex) {
        return array(array('Invalid Fieldname', 'Invalid Fieldname'));
    }
    
    
    if(!count($rawresults))
        return NULL;
    
    foreach($rawresults as $result){
        if('' == $result[$data['fieldname']] || NULL == $result[$data['fieldname']]) continue;
        $returnArr[] = array($result[$data['fieldname']], ucwords(strtolower($result[$data['fieldname']])));
    }
    sort($returnArr);
    return $returnArr;
}

/**
 * Returns a list of column names for a table.
 * 
 * Filtered option removes values containing underscores
 * 
 * @param mixed[] $data
 * @param bool $filtered
 * @return GetFeatureInstState ModulesState
 */
function GetTableFields($data, $filtered = TRUE){
    $sql = 'SHOW columns FROM '.WPR_TABLE_PFX.$data['tablename'];
    
    if($data['tablename'] == 'listingsdb')
        $db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
    else 
        $db = \Mbx\DataStore\MbxGetDb();
    
    $res = $db->GetRows($sql, array());
    
    $fields = array();
    
    foreach ($res as $fld){
        
        if($filtered && strpos($fld['Field'], '_') === FALSE) // Rework filter
           $fields[] = $fld['Field'];   
        else 
           $fields[] = $fld['Field'];
    }
    sort($fields);
    return $fields;
}

function GetSavedSearches($data){
    $retval = '';
    $sql = "SELECT * FROM ".WPR_TABLE_PFX."searchfavorite WHERE user_id = :uid ORDER BY name";
    $db = \Mbx\DataStore\MbxGetDb();
    $searches = $db->GetRows($sql, array(':uid' => $data['uid']));
    if($searches && count($searches)){
        // There are saved searches, so lets list them in alpha order
        
        foreach($searches as $search){
            $retval .= '<h4>'.$search['name'].'</h4>';
            if(!is_null($search['matches'])){
                $retval .= '<div>'.renderListingArray($search['matches']).'</div>';
            }
            else{
                $retval .= '<div>No New Matches</div>';
            }
        }
        
        return $retval;
    }
    else{
        //return $data;
        return '<div>No Saved Searches</div>';
    }
}

function GetFavorites($data){
    $sql = "SELECT * FROM ".WPR_TABLE_PFX."userfavoritelistings WHERE user_id = :uid";
    $db = \Mbx\DataStore\MbxGetDb();
    $res = $db->GetRows($sql, array(':uid' => $data['uid']));
    if($res && count($res)){
        $srcarr = array();
        foreach($res as $fav){
            $srcarr[] = $fav['mls_id'];
        }
        return renderListingArray(json_encode($srcarr));
    }
    else{
        return '<div>No Saved Properties</div>';
    }
}

function renderListingArray($json_array){
    $matches = json_decode($json_array);
    // We do this to maintain compat with legacy core which needs listing id
    $sql = "SELECT listingsdb_id FROM ".WPR_TABLE_PFX."listingsdb WHERE ";
    foreach($matches as $match){
        $sql .= "MLS = '".$match."' OR ";
    }
    $sql = substr($sql, 0, -4);
    ///echo $sql;
    $listings_src_db = \Mbx\DataStore\MbxGetDb(WPR_USING_EXTERNAL_DB);
    $match_ids = $listings_src_db->GetSingleFieldList($sql, array());
    //echo var_export($match_ids);
    $SingleResultView = file_get_contents(WPR_TEMPLATE_PATH.'/Modules/System/SingleResultView.html');
    
    include_once WPR_INCLUDE_PATH.'parse.inc.php';
    $parser = new \parseClass();
    
    $templated_listings = '';
    
    foreach($match_ids as $id){
        //return $id;
        $templated_listings .= $parser->MainParse($SingleResultView, $id, WPR_USING_EXTERNAL_DB);
    }
    return $templated_listings;
}

/**
 * DTO class representing installed modules state
 */
class ModulesState{
    /**
     * Installed FeatureModules list
     * 
     * @var string[] 
     */
    public $installed;
    /**
     * Available FeatureModules and MBX/system updates
     * @var string[] 
     */
    public $available;
    
    /**
     * Assigns class variables
     * 
     * @param string[] $installed
     * @param string $available
     */
    public function __construct($installed, $available) {
        $this->installed = $installed;
        $this->available = $available;
    }
}