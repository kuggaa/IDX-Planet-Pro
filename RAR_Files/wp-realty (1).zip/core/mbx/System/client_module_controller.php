<?php
namespace Mbx;
//echo 'client module controller<br>';
//echo WPR_MODULES_PATH.'<br>';
    include_once MBX_SYS_SVCS_PATH.'/System/mod_client.php';
    include_once MBX_SYS_SVCS_PATH.'/UserAuth/mod_client.php';
    include_once MBX_SYS_SVCS_PATH.'/WprCrm/mod_client.php';


    $installed_modules = glob(WPR_MODULES_PATH . '*', GLOB_ONLYDIR);
    
    $config_text = '';
    $dom_text = '';
    if(is_callable('\Mbx\System\SetDom'))
        $dom_text .= \Mbx\System\SetDom();
    
    $dom_text .= \Mbx\UserAuth\SetDom();
    
    if(is_callable('\Mbx\WprCrm\SetDom'))
        $dom_text .= \Mbx\WprCrm\SetDom();
    
    if(is_callable('\Mbx\System\SetAppConfig'))
        $dom_text .= \Mbx\System\SetAppConfig();
    if(is_callable('\Mbx\UserAuth\SetAppConfig'))
        $dom_text .= \Mbx\UserAuth\SetAppConfig();
    if(is_callable('\Mbx\WprCrm\SetAppConfig'))
        $dom_text .= \Mbx\WprCrm\SetAppConfig();
    
    foreach ($installed_modules as $module) {
        if(file_exists($module . '/mod_client.php'))
        {
            include_once $module . '/mod_client.php';
            
            $mod_name = System\MbxGetModuleFromGlob($module);
            
            $set_dom_func_name = '\\'.$mod_name.'\\SetDom';
            
            if(is_callable($set_dom_func_name))
            {
                $dom_text .= $set_dom_func_name();
            }
            
            
            $set_config_func_name = '\\'.$mod_name.'\\SetAppConfig';
            
            // Poll for initial setup script values WPR and WPR.ajaxurl are guaranteed defined. return ";" delimited lines of valid javascript
            if(is_callable($set_config_func_name))
            {
                $config_text .= $set_config_func_name();
            }
        }
    }
    $outerpop = '<div id="modal-outer"></div>'; // A little hack until the core settles a little better
    $mbx_toolbar = '<div id="MbxToolbar">test</div>';
    define('MBX_CLIENT_CONFIG', $config_text);
    define('MBX_DOM_INJECTION', $dom_text.$outerpop.$mbx_toolbar);




/**
 * Injects javascript after content
 * 
 * Called internally on page load in WP loop
 */
function WprInjectConfig() {
    $client_config = '<script type="text/javascript">';
    $client_config .= 'WPR = {};WPR.ajaxurl="'.MBX_WPR_AJAX_URL.'index.php";';
    $client_config .= MBX_CLIENT_CONFIG;
    $client_config .= '</script>';
    echo $client_config;
    //echo '---------------------------------------------------------------------------------';
}
if(!defined('WPR_IS_WP') || WPR_IS_WP == TRUE)
    add_action( 'wp_footer', '\\Mbx\\WprInjectConfig' );

/**
 * Injects DOM elements after content
 * 
 * Generally intended to inject hidden elements. Called internally on page load in WP loop
 */
function WprInjectDomElements(){
    echo MBX_DOM_INJECTION;
}
if(!defined('WPR_IS_WP') || WPR_IS_WP == TRUE)
    add_action( 'wp_footer', '\\Mbx\\WprInjectDomElements' );