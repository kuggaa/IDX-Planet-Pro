<?php
namespace Mbx\Entity;

class MbxEntity{
    public $Id;
    /* @var $DataArray array */
    public $DataArray = NULL;
    public $EntityName = NULL;
    
    private function __construct () {}
}

class MbxList{
    public $Id;
}

class MbxDataEntity extends MbxEntity{
    
}

interface IWprController{
    
}

interface IMbxHooks{
    public static function GetInstance();
}
// More Specialized

// Base CRM

class MbxEmailAddress extends MbxDataEntity{
    public $EmailPart;
    public $NamePart;
}

class MbxMailingList extends MbxList{
    /* @var $addressArray MbxEmailAddress[] */
    public $addressArray;
}

include_once(dirname(__FILE__).'/Orm.php');