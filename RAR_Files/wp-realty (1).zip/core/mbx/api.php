<?php
namespace Mbx\System\API;

use Mbx\System;

define('MBX_SYSTEM_BASEPATH', dirname(__FILE__));
//define('WPR_MODULES_PATH', dirname(__FILE__).'Modules/');

include_once MBX_SYSTEM_BASEPATH.'/System/mbx_pdo.php';
include_once 'System/functions.php';
include_once 'System/Entities.php';
include_once 'System/Json.php';
include_once 'System/HooksController.php';
include_once 'System/module_settings.php';


function ApiController($data_values = FALSE){
    //header("Content-type: application/json");
    //var_dump($data_values);
    $data;
    if($data_values){
        $data = $data_values;
    }
    elseif(!empty($_POST)){ // Dont forget to fix all this
        //$data = System\MbxGetArrayFromQuerystringEx();
        $data = $_POST;
        if($_FILES) // Shameless hack
            $data = $data + $_GET;
    }
    else{
        //$data = System\MbxGetArrayFromQuerystringEx(MBX_QUERYSTRING_GET);
        $data = $_GET;
    }
    
    if(empty($data['controller']))
    {
        echo 'No controller specified';
        die();
    }
    //error_log(WPR_LOCAL_DB_NAME);
    // Add the user id to the data object
    $data['uid'] = System\WprGetUserId();
    
    if(file_exists(dirname(__FILE__).'/'.$data['controller'].'/frontend.php'))
    {
        include_once dirname(__FILE__).'/'.$data['controller'].'/frontend.php';
        $init_func = '\Mbx\\'.$data['controller'].'\\'.$data['controller'].'Api';
        $raw_return = $init_func($data);
    }
    elseif(file_exists(dirname(__FILE__).'/'.'Modules/'.$data['controller'].'/frontend.php'))
    {
        include_once dirname(__FILE__).'/'.'Modules/'.$data['controller'].'/frontend.php';
        $FQNsToApi = '\\'.$data['controller'].'\\'.$data['controller'].'Api';
        // Execute
        $raw_return = $FQNsToApi($data);
    }
    else 
    {
        echo 0;
        die();
    }
    
    if(!empty($raw_return)){
        if(defined('MBX_CODE_API') && MBX_CODE_API){
            return $raw_return;
        }
        else{
            echo json_encode(array('objectName' => $data['controller'], 'module' => $data['module_name'] ? $data['module_name'] : $data['controller'], 'objectContents' => $raw_return));
        }
    }
    die();
    
}

// This is sort of a hackish way to bridge between JSON API for use from code
// internally to support actions originating in Hooks
if(defined('MBX_CODE_API') && MBX_CODE_API){
    // Just load the file for now - leave for caller
}
else 
    ApiController();
