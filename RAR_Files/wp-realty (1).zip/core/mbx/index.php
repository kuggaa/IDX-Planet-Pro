<?php
namespace Mbx;
header('Access-Control-Allow-Origin: *');

include_once dirname(dirname(__FILE__)).'/config.php';
include_once dirname(__FILE__).'/System/MbxConfig.php';

define('MBX_AJAX', TRUE);

include_once 'api.php';

