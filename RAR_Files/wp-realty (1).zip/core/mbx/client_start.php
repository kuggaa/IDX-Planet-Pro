<?php
//echo 'client start<br>';
$siteroot = preg_replace('#(wp-content.*)#','',$config["wpradmin_baseurl"]);

define('MBX_WPR_AJAX_URL', $siteroot.'wpradmin/mbx/');

define('MBX_AJAX', FALSE);

include_once 'System/MbxConfig.php';

include_once 'System/functions.php';

include_once 'System/Entities.php';

include_once 'System/mbx_pdo.php';

include_once 'System/module_settings.php';

include 'System/client_module_controller.php';

