<?php
namespace Mbx;

$siteroot = preg_replace('#(wp-content.*)#','',$config["wpradmin_baseurl"]);

define('MBX_WPR_AJAX_URL', $siteroot.'wpradmin/mbx/');

define('MBX_AJAX', FALSE);

include_once 'System/MbxConfig.php';

include_once 'System/functions.php';

function ModsWithAdmin(){
    $adminMods = array();
    $adminMods[] = 'System';
    $adminMods[] = 'WprCrm';
    $installed_modules = glob(WPR_MODULES_PATH . '*', GLOB_ONLYDIR);
    foreach ($installed_modules as $module) {
        if(file_exists($module . '/Page.php'))
            $adminMods[] = System\MbxGetModuleFromGlob($module);
    }
    //var_dump($adminMods);
    return $adminMods;
}