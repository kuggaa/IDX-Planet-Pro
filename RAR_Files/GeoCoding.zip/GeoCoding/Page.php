<?php
namespace GeoCoding;

include_once (dirname(__FILE__).'/Mbx/Models/Address.php');

function Main(){
    $return = file_get_contents(WPR_TEMPLATE_PATH.'/Modules/GeoCoding/admin/Geocoding.html');
    $return = str_replace('{cron-cmd-line}', WPR_MODULES_PATH.'GeoCoding/GeoCron.php', $return);
    $return = str_replace('{cron-url}', WPR_MOD_URL.'GeoCoding/GeoCron.php', $return);
    $return .= "<script type='text/javascript' src='".MBX_WPR_AJAX_URL."System/scripts/Framework.js'></script>";
    $return .= "<script type='text/javascript' src='".MBX_WPR_AJAX_URL."Modules/GeoCoding/Mbx/script/admin-script.js'></script>";
    $return .= '<script>WPR.GeoCoding = WPR.GeoCoding || {};WPR.GeoCoding.cronUrl = "'.WPR_MOD_URL.'GeoCoding/GeoCron.php";</script>';
    return new \Mbx\Page\PageReturn('Geocoding Setup', $return);
}

function GetAdminLinks(){
    $links = array();
    $links[] = array(
        'href' => WPR_ADMIN_SITE_ROOT.'index.php?apage=GeoCoding&Feature=Main',
        'icon' => WPR_ICONS_BASEURL.'small/color/map.png',
        'text' => 'GeoCode Settings',
        'menu' => 'maps');
    return $links;
}

