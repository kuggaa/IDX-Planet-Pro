<?php
include_once dirname(dirname(dirname(dirname(__FILE__)))).'/config.php';
include_once dirname(dirname(dirname(__FILE__))).'/System/MbxConfig.php';
include_once dirname(dirname(dirname(__FILE__))).'/System/functions.php';
include_once dirname(dirname(dirname(__FILE__))).'/System/Entities.php';
include_once dirname(dirname(dirname(__FILE__))).'/System/mbx_pdo.php';
include_once dirname(dirname(dirname(__FILE__))).'/System/module_settings.php';
include_once dirname(__FILE__).'/Mbx/GeoCodingClient.php';

$settings = \Mbx\System\GetModuleConfig('GeoCoding');

function DoTigerBatch(){
    $sin = \GeoCoding\Client\Batches::GetInstance();
    $sin->Process();
    return $sin->unCodables;
}

function DoTigerSingle(){
    return \GeoCoding\Client\RunTigerSingles();
}

function DoGoogle($listings = FALSE){
    if(!$listings){
        $listings = GeoCoding\Client\GetUncodedListings(2500);
    }
    $sin = \GeoCoding\Client\Batches::GetInstance();
    $sin->UpdateGeoCode($listings, TRUE);
}


function processImmutables(){
    global $settings;
    define('GEO_CODING_GOOGLE_API_KEY', $settings['google_api_key']);
    // Define the stages we will use to geocode
    define('GEO_CODING_STAGE_1', $settings['stage_1']);
    define('GEO_CODING_STAGE_2', $settings['stage_2']);
    // This is really stage 3.
    define('GEO_CODING_LASTCHANCE_CENTER_FIELD', $settings['lastchance_center']);
    define('GEO_CODING_LASTCHANCE_LAST_FIELD', $settings['lastchance_last']);
    define('GEO_CODING_CODING_MODE', $settings['coding_mode']);
}

define('GEO_CODING_LOG_FILE', MBX_LOGS_PATH.'geocoding.log');



set_time_limit(3600);



$stage_2_listings = [];
$last_chance_listings = [];
processImmutables();
switch($settings['stage_1']){
    case "tigerb":
        $stage_2_listings = DoTigerBatch();
        DoGoogle();
        break;
    case 'tigers':
        $listings = GeoCoding\Client\GetUncodedListings(2500);
        $stage_2_listings = \GeoCoding\Client\RunTigerSingles($listings);
        DoGoogle($stage_2_listings);
        break;
    case 'google':
        $listings = GeoCoding\Client\GetUncodedListings(2500);
        $sin = \GeoCoding\Client\Batches::GetInstance();
        $sin->UpdateGeoCode($listings, TRUE);
        break;
}