$(document).ready(function(){
    $('#RunCron').live('click', function(){
    //$('body').on('click', '#RunCron', function(){ // 1.7+
        //$( "#cronResult" ).load( WPR.GeoCoding.cronUrl ); // Will only display after server closes conn - page end
        $( "#cronResult" ).attr('src', WPR.GeoCoding.cronUrl);
    });
    
    WPR.GeoCoding = WPR.GeoCoding || {};
    WPR.GeoCoding.settings = WPR.GeoCoding.settings || {};
    
    GetModuleConfig('GeoCoding', populateForm);
    
    $('body').live('MbxAdminFormLoaded', function(){
        WPR.SetupSelects();
    });
    
    $( "#UpdateConfig").unbind( "click" );
    $('#UpdateConfig').click(function(e){
        saveConfig(this);
    })
    
    
});


