<?php
namespace GeoCoding\Client;


define('TIGER_BASEURL', 'http://geocoding.geo.census.gov/geocoder/');// address – locations

define('AREA_CENTER_ZIP', 'Zip');
define('AREA_CENTER_CITY', 'City');
define('MAPSEARCH_INIT_LAT', 28.489997965086314);
define('MAPSEARCH_INIT_LNG', -81.35369869873051);



class SingleAddress extends \Mbx\Entities\Address{
    private $benchmark;
    private $format;
    private $vintage;
    private $lid;
    
    public static function GetInstance($street, $city, $state, $zip){
        return new SingleAddress($street, $city, $state, $zip);
    }
    
    public function SetConfig($benchmark = 'Public_AR_Current', $format = 'json', $vintage = 'ACS2015_Current'){
        $this->benchmark = $benchmark;
        $this->format = $format;
        $this->vintage = $vintage;
    }
    
    public function setLid($lid){
        $this->lid = $lid;
    }
    
    
    public function DoGeoCodeRequest(){
        $params = array
	(
		'street' => $this->street,
		'city' => $this->city,
		'state' => $this->state,
		'zip' => $this->zip,
		'benchmark' => $this->benchmark,
		'format' => $this->format,
                'vintage' => $this->vintage
	);
        
        $rest = TIGER_BASEURL.'locations/address?'.http_build_query($params);
        
        $ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $rest);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	$result = curl_exec($ch);
        //echo $result;
        echo curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
        
        $result_arr = json_decode($result, true);
        echo '<pre>';
        //var_dump($result_arr['result']['addressMatches'][0]);
        echo '</pre>';
        
        $this->latitude = $result_arr['result']['addressMatches'][0]['coordinates']['y'];
        $this->longitude = $result_arr['result']['addressMatches'][0]['coordinates']['x'];
        echo 'Coded '.$this->street.', '.$this->city.', '.$this->state.' '.$this->zip.' using TIGER single address API <br>';
        if($this->latitude && $this->longitude){
            echo 'to lat: '.$this->latitude.' lng: '.$this->longitude.'<br><br>';
            return TRUE;
        }
        else{
            echo 'Coding Failed.<br><br>';
            return FALSE;
        }
        
        
    }
    
    public function UpdateListing(){
        if(!$this->latitude || !$this->longitude){
            return false;
        }

        $sql = 'UPDATE '.WPR_TABLE_PFX.'listingsdb';
        $sql .= ' SET longitude = :lng, latitude = :lat';
        $sql .= ' WHERE listingsdb_id = :lid';
        $paramArr = array(':lat' => $this->latitude, ':lng' => $this->longitude, ':lid' => $this->lid);
        $db = \Mbx\DataStore\MbxGetDb();
        $db->UpdateRow($sql, $paramArr);
    }
}

class Batch{
    private $benchmark;
    private $format;
    private $csv_file_path;
    private $file_id;
    private $vintage;
    
    
    private function __construct($csv_file_path, $file_id) {
        $this->csv_file_path = $csv_file_path;
        $this->file_id = $file_id;
    }
    
    public static function GetInstance($csv_file_path, $file_id){
        return new Batch($csv_file_path, $file_id);
    }
    
    public function SetConfig($benchmark = 'Public_AR_Current', $format = 'json', $vintage = 'ACS2015_Current'){
        $this->benchmark = $benchmark;
        $this->format = $format;
        $this->vintage = $vintage;
    }
    
    public function DoRequest(){
        //die('doing request');
        $csv_file = '';
        
        if (function_exists('curl_file_create')) {
            $csv_file = curl_file_create($this->csv_file_path); 
        }
        else {
            $csv_file = '@' . realpath($this->csv_file_path);
        }
        
        $params = array
	(
		'benchmark' => $this->benchmark,
                'vintage' => $this->vintage,
		'addressFile' => $csv_file
	);
//die(TIGER_BASEURL.'locations/addressbatch');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_VERBOSE, true);
	curl_setopt($ch, CURLOPT_URL, TIGER_BASEURL.'locations/addressbatch');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,30); 
        curl_setopt($ch, CURLOPT_TIMEOUT, 120); //timeout in seconds
	
	$result = curl_exec($ch);
        echo curl_getinfo($ch, CURLINFO_HTTP_CODE);
        var_dump(curl_getinfo($ch));
      die();  
        if(curl_errno($ch))
            {
            die(curl_error($ch));
                error_log(curl_error($ch).' @ '.TIGER_BASEURL.'locations/addressbatch file= '.$this->csv_file_path, 3, GEO_CODING_LOG_FILE);
                echo 'Curl error: ' . curl_error($ch);
                ob_flush();
            }
	curl_close ($ch);
        
        echo $result;////////// See what it does
        ob_flush();
        // If the file fails to process
        if(
            $result == ''
            || \strpos($result, 'Weblogic') !== FALSE
            || $result == NULL
          )
        {
           return FALSE;
        }
        
        $outFile = fopen(GEO_TEMP_DIR.'GeoCodeRes'. $this->file_id.'.csv', 'w');
	fwrite($outFile, $result);
	fclose($outFile);
        return TRUE;
    }
}

class Batches{
    private $matchFields = array();
    public $unCodables = array();
    private $googleCounter = 0;
    
    private function __construct() {
        ;
    }
    
    public static function GetInstance(){
        return new Batches();
    }
    
    public function Process(){
        // Clean the dir
        RemoveGeoFiles();
        // Make the source files to send
        MakeGeoSrcFiles();
        // Get an array of the source files
        $source_files = glob(GEO_TEMP_DIR.'GeoCodeSrc*');
        // Attempt to process the batches
        $this->ProcessBatches($source_files);
        // Check for any files that failed to process the first time
        $remaining_source_files = glob(GEO_TEMP_DIR.'GeoCodeSrc*');
        // If there are any try again. need a log and notify here in the event of a second failure
        if(count($remaining_source_files))
            $this->ProcessBatches($remaining_source_files);
        // Process the uncodables
        //var_dump(GetFailedCodingListings());
        echo '<br> running Google Backup coding<br>';
        $this->UpdateGeoCode(GetFailedCodingListings(), TRUE);
        
        
        //$this->UpdateDb();
        
        
    }
    
    private function UpdateDb($single = FALSE, $filename = ''){
        $toGoogle = array();
        
        $GeoCoded_files = !$single ? glob(GEO_TEMP_DIR.'GeoCodeRes*') : array($filename);
        $longitude = 0;
        $latitude = 0;
        $googleCounter = 0;
        
        foreach ($GeoCoded_files as $file) {
            $file_content = array_map('str_getcsv', file($file));
            $this->UpdateGeoCode($file_content);
        }
        
        echo '<br>UnCodables '.count($this->unCodables).' so far<br>';
    }
    
    public function UpdateGeoCode($rows, $isLastChance = FALSE, $lastchance_center = '', $lastchance_last = ''){
        if($isLastChance){
            $conf = \Mbx\System\GetModuleConfig('GeoCoding');
            define('GEOCODE_USE_GOOGLE', $conf['use-google']);echo '<br>conf - use google'.$conf['use-google'].' const '.GEOCODE_USE_GOOGLE.'<br>';
            define('GOOGLE_MAPS_API_KEY', $conf['google-api-key']); // 'AIzaSyBLYbg0QksTa4W3iV4B-T_ebhSynsmGI2c'
        }
        
        $db = \Mbx\DataStore\MbxGetDb();
        
        foreach ($rows as $row){
            
            if(!$isLastChance && ($row[2] == "No_Match" || $row[2] == 'Tie')){
                $this->unCodables[] = $row;
                $latitude = NULL;
                $longitude = NULL;
                echo '<br>$row[2] (Match Result) = '.$row[2].'<br>';
                //continue;
            }
            elseif($isLastChance){
                list($longitude, $latitude) = $this->SecondChanceGeoCoding($row);
                echo 'lat -> '.$latitude.' lng -> '.$longitude.'<br>';
            }
            else{
                list($longitude, $latitude) = explode(',',$row[5]);
            }
            
            // Update the listing
                $sql = 'UPDATE '.WPR_TABLE_PFX.'listingsdb';
                $sql .= ' SET longitude = :lng, latitude = :lat';
                $sql .= ' WHERE listingsdb_id = :lid';
                echo '<br>PDO '.$sql.'<br>Params<br><pre>';
                $paramArr = array(':lat' => $latitude, ':lng' => $longitude, ':lid' => $isLastChance ? $row['listingsdb_id'] : $row[0]);
                var_dump($paramArr);
                echo '</pre><br>';
                $db->UpdateRow($sql, $paramArr);
        }
    }
    
    public function SecondChanceGeoCoding($row){
        $longitude;
        $latitude;
        
        /*$internalCoded = $this->DoInternalGeoCoding($row);
        if($internalCoded[0] != NULL && $internalCoded[1] != NULL){
            return $internalCoded;
        }*/
        
        if(1){
            //Send to Google
            //list($street, $city, $state, $zip) = explode(', ', $row[1]);
            $street = $row['Address'];
            $city = $row['City'];
            $state = $row['State'];
            $zip = $row['Zip'];
            //list($num, $road) = explode(' ', $street, 2);
            $addr = \Mbx\Entities\Address::GetInstance($street, $city, $state, $zip);
            echo $street;
            $checked_address = GoogleGeocodeAddress($addr);
            
            echo '<br>--- '.$street.' coded by google<br>';
            $coords = $checked_address->GetGeoCode();
            $latitude = $coords['lat'];
            $longitude = $coords['lng'];
            $this->googleCounter++;
            return array($longitude, $latitude);
        }
        else{
            return array(NULL, NULL);
        }
    }
    
    private function DoInternalGeoCoding($row){
        list($street, $city, $state, $zip) = explode(', ', $row[1]);
        $coords = $this->GetAreaCenter(MAPSEARCH_GEO_LASTCHANCE_FIRST_FIELD == 'Zip' ? $zip : $city);
        $latitude = $coords['lat'];
        $longitude = $coords['lng'];

        if(!$latitude || !$longitude){
            echo '<br>Empty Result<br>';
            list($street, $city, $state, $zip) = explode(', ', $row[1]);
            $coords = $this->GetAreaCenter(MAPSEARCH_GEO_LASTCHANCE_FIRST_FIELD == 'Zip' ? $city : $zip);
            $latitude = $coords['lat'];
            $longitude = $coords['lng'];

            if(!$latitude || !$longitude){ // This needs changed as it serves no purpose beyond slapping a geocode on a few outliers
                echo 'Zip and City Encoding failed - skip encoding leave for next cron - maybe eventually a match - very small group';
                $latitude = NULL;
                $longitude = NULL;
            }
        }
        
        return array($longitude, $latitude);
    }
    
    private function GetAreaCenter($value, $field = 'Zip'){
        if(isset($this->matchFields[$value])){
            return array('lat' => $this->matchFields[$value]['lat'], 'lng' => $this->matchFields[$value]['lng']);
        }
        
        $sql = 'SELECT latitude, longitude FROM '.WPR_TABLE_PFX.'listingsdb';
        $sql .= ' WHERE '.$field.' = :val AND latitude != 0 ORDER BY rand() LIMIT 10';
        $param_arr = array(':val' => $value);
        
        $db = \Mbx\DataStore\MbxGetDb();
        $result = $db->GetRows($sql, $param_arr);
        echo '<br>GetCenter val = '.$value.'<br>';
        var_dump($result);
        if($result){
            $counter = 0;
            $latitudeSum = 0;
            $latitudeAvg = 0;
            $longitudeSum = 0;
            $longitudeAvg = 0;
            
            // This will exclude null results for try again after cities and zips are checked for all unCodables once as zips might trigger cities
            foreach ($result as $listing) {
                if($listing['latitude'] != NULL && $listing['longitude'] != NULL){
                    $latitudeSum += $listing['latitude'];
                    $longitudeSum += $listing['longitude'];
                    $counter++;
                }
            }
            
            if($counter !=0){
                $latitudeAvg = $latitudeSum / $counter;
                $longitudeAvg = $longitudeSum / $counter;

                $this->matchFields[$value] = array('lat' => $latitudeAvg, 'lng' => $longitudeAvg);

                return array('lat' => $latitudeAvg, 'lng' => $longitudeAvg);
            }
        }
        return FALSE;
    }
    
    private function ProcessBatches($source_files){
        foreach ($source_files as $file) {
            // Func needs renamed - returns everything after last /
            $file_name = \Mbx\System\MbxGetModuleFromGlob($file);
            // neat cheap way to parse the filename to leave the file #
            $id = str_replace(array('GeoCodeSrc', '.csv'), '', $file_name);
            // Start the batch
            $batch = Batch::GetInstance($file, $id);
            // Must be called even if going default for now
            $batch->SetConfig();
            // Finally do the work of getting the batch GeoCoded
            $result = $batch->DoRequest();
            if($result){
                // delete the source file
                unlink($file);
                $res_file = str_replace('GeoCodeSrc', 'GeoCodeRes', $file);
                $this->UpdateDb(TRUE, $res_file);
                unlink($res_file);
                echo '<br>db updated '.$res_file.'<br>';
            }
            
            sleep(60);
        }
        
    }
}