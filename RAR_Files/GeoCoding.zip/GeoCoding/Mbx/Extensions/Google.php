<?php
namespace GeoCoding\Client;

define('GOOGLE_BASE_URL', 'https://maps.googleapis.com/maps/api/geocode/json');


function GoogleGeocodeAddress(\Mbx\Entities\Address $address){

        // Do the full address
        $preppedAddress = str_replace (" ", "+", $address->ToUrlEncAddressString('full'));
        echo '<br>Coding this -> '.$preppedAddress.'<br>';
        $response = GoogleCurl($preppedAddress);
        //var_dump($response);
        // If not lets try just the street - helps with very new construction
        if ($response['status'] != 'OK') {
            $address->SetGeoCode(NULL, NULL);
            //return $address;
            $streetonly = str_replace (" ", "+", $address->ToUrlEncAddressString('street'));
            $response = GoogleCurl($streetonly);

            // Finally we try the lastchance field
            if ($response['status'] != 'OK'){
                if (GEO_CODING_LASTCHANCE_LAST_FIELD == 'none'){
                    $address->SetGeoCode(NULL, NULL);
                    return $address;
                }
                $finalrun = str_replace (" ", "+", $address->ToUrlEncAddressString(GEO_CODING_LASTCHANCE_LAST_FIELD));
                $response = GoogleCurl($finalrun);
                if ($response['status'] != 'OK'){
                    $address->SetGeoCode(NULL, NULL);
                    return $address;
                }
            }
        }
    
    
    $geometry = $response['results'][0]['geometry'];
    $address->SetGeoCode($geometry['location']['lat'], $geometry['location']['lng']);
    
    return $address;
}

function GoogleCurl($preppedAddress){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, GOOGLE_BASE_URL.'?address='.$preppedAddress.'&key='.GEO_CODING_GOOGLE_API_KEY);
    echo GOOGLE_BASE_URL.'?address='.$preppedAddress.'&key='.GEO_CODING_GOOGLE_API_KEY;
    echo '<br>';
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data =  json_decode(curl_exec($ch), true);
    curl_close($ch);
    return $data;
}

