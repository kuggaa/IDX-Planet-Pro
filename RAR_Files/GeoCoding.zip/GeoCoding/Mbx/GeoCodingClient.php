<?php
namespace GeoCoding\Client;

include_once 'Models/Address.php';
include_once 'Extensions/Tiger.php';
include_once 'Extensions/Google.php';


define('GEO_TEMP_DIR', WPR_MODULES_PATH.'GeoCoding/Mbx/tmp/');

function GetUncodedListings($limit = FALSE, $offset = FALSE){
    $sql = 'SELECT listingsdb_id, Address, City, State, Zip FROM '.WPR_TABLE_PFX.'listingsdb';
    $sql .= ' WHERE longitude = 0 OR latitude = 0 OR longitude IS NULL OR latitude IS NULL ORDER BY rand()';//  WHERE longitude IS NULL OR latitude IS NULL
    //$sql .= ' OR longitude = 0 OR latitude = 0 ORDER BY rand()';
    if($limit){
        $sql .= ' LIMIT '.$limit;
    }
    if($offset){
        $sql .= ' OFFSET '.$offset;
    }
    
    $db = \Mbx\DataStore\MbxGetDb();
    
    return $db->GetRows($sql, array());
}

function GetFailedCodingListings(){
    $sql = 'SELECT listingsdb_id, Address, City, State, Zip FROM '.WPR_TABLE_PFX.'listingsdb';
    $sql .= ' WHERE longitude IS NULL OR latitude IS NULL LIMIT 2500';//  WHERE longitude IS NULL OR latitude IS NULL
    $sql .= ' OR longitude = 0 OR latitude = 0 ORDER BY rand()';
    //echo '<br>-------------------------------------------- Failed listing count sql '.$sql.'<br>';
    $db = \Mbx\DataStore\MbxGetDb();
    //echo '<br>-------------------------------------------- Failed listing count '.$sql.'<br>';
    $rows = $db->GetRows($sql, array());
    echo '<br>'.count($rows).' failed listings to handle<br>';
    
    return $rows;
}

function MakeGeoSrcFiles($records_per_file = 1000){
    $offset = 0;
    $filesArr = array();
    while($unEncListings = GetUncodedListings(1000, $offset)){
        echo '<br><pre>';
        var_dump(count($unEncListings));
        echo '</pre<br>';
        
        $rows_in_file = 0;
        $filetext = '';

        foreach ($unEncListings as $index => $listing) {
            $filetext .= '"'.$listing['listingsdb_id'].'","'.$listing['Address'].'","'.$listing['City'].'","'.$listing['State'].'","'.$listing['Zip'].'"'."\n";
            //$filetext .= $listing['listingsdb_id'].','.$listing['Address'].','.$listing['City'].','.$listing['State'].','.$listing['Zip']."\n";
            $rows_in_file++;

            if(($rows_in_file) == $records_per_file){
                $filesArr[] = substr($filetext, 0, -1);
                $rows_in_file = 0;
                $filetext = '';
            }
        }

        if($filetext !== '')
            $filesArr[] = substr($filetext, 0, -1);
        
        $offset = $offset + 1000;
    }
    //$unEncListings = GetUncodedListings();
    //echo '<br><pre>';
    //var_dump(count($unEncListings));
    //echo '</pre<br>';
    //$filesArr = array();
    /*$rows_in_file = 0;
    $filetext = '';
    
    foreach ($unEncListings as $index => $listing) {
        $filetext .= '"'.$listing['listingsdb_id'].'","'.$listing['Address'].'","'.$listing['City'].'","'.$listing['State'].'","'.$listing['Zip'].'"'."\n";
        //$filetext .= $listing['listingsdb_id'].','.$listing['Address'].','.$listing['City'].','.$listing['State'].','.$listing['Zip']."\n";
        $rows_in_file++;
        
        if(($rows_in_file) == $records_per_file){
            $filesArr[] = substr($filetext, 0, -1);
            $rows_in_file = 0;
            $filetext = '';
        }
    }
    
    if($filetext !== '')
        $filesArr[] = substr($filetext, 0, -1);*/
    
    // Write the files - todo add some clearing of the dir
    foreach($filesArr as $index => $file_content){
        $outFile = fopen(GEO_TEMP_DIR.'GeoCodeSrc'.$index.'.csv', 'w');
	fwrite($outFile, $file_content);
	fclose($outFile);
    }
}

function RemoveGeoFiles(){
    $strays = glob(GEO_TEMP_DIR.'*');
    foreach ($strays as $stray) {
        if(file_exists($stray))
             unlink($stray);
    }
}

function RunTigerSingles(){
    $rows = \GeoCoding\Client\GetUncodedListings(2500);
    $uncodables = array();
    foreach($rows as $row){
        //$address = new SingleAddress($row['Address'], $row['City'], $row['State'], $row['Zip']);
        $address = SingleAddress::GetInstance($row['Address'], $row['City'], $row['State'], $row['Zip']);
        $address->SetConfig();
        if($address->DoGeoCodeRequest()){
            $address->setLid($row['listingsdb_id']);
            $address->UpdateListing();
        }
        else{
            $uncodables[] = $row;
        }
        
    }
    return $uncodables;
}