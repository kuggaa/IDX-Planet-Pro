<?php
namespace Mbx\Entities;

class Address{
    
    protected $street;
    protected $city;
    protected $state;
    protected $zip;
    protected $latitude;
    protected $longitude;
    


    protected function __construct($street, $city, $state, $zip) {
        $this->street = $street;
        $this->city = $city;
        $this->state = $state;
        $this->zip = $zip;
        $this->latitude = FALSE;
        $this->longitude = FALSE;
    }
    
    public static function GetInstance($street, $city, $state, $zip){
        return new Address($street, $city, $state, $zip);
    }
    
    public function GetGeoCode(){
        if(empty($this->latitude) || empty($this->longitude))
            return FALSE;
        
        return array('lat' => $this->latitude, 'lng' => $this->longitude);
    }
    
    public function SetGeoCode($latitude, $longitude){
        $this->latitude = $latitude;
        $this->longitude = $longitude;
        return TRUE;
    }
    
    public function ToAddressString($kind = 'full'){
        switch($kind){
            case 'full':
                return $this->street.', '.$this->city.', '.$this->state.' '.$this->zip;
            case 'street':
                list($num, $street) = explode(' ', $this->street, 2);
                echo '<br>searching '.$street.', '.$this->city.', '.$this->state.' '.$this->zip.'<br>';
                return $this->street.', '.$this->city.', '.$this->state.' '.$this->zip;
            case 'zip':
                return $this->zip;
            case 'city':
                return $this->city.', '.$this->state;
        }
        
    }
    
    public function ToUrlEncAddressString($kind = 'full'){
        return urlencode($this->ToAddressString($kind));
    }
}

