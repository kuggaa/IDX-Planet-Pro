<?php
namespace GeoCoding;

function Uninstall($keepCustom = FALSE){
    if(!$keepCustom){
        $template_dirs = glob(TPL_ROOT . '*', GLOB_ONLYDIR);
        foreach ($template_dirs as $tpl){
            \Mbx\System\MbxRemoveDir($tpl.'/Modules/GeoCoding');
        }
        
        $drop_settings_table = "DROP TABLE IF EXISTS `".WPR_TABLE_PFX."geocoding_settings`;";
        $db = \Mbx\DataStore\MbxGetDb();
        $db->TableOp($drop_settings_table);
    }
}

