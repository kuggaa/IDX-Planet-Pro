<?php
namespace GeoCoding;

include_once '../../../config.php';
define('ASSETS_TPLS', dirname(__FILE__).'/assets/templates/');

function Install(){
    $template_dirs = glob(TPL_ROOT . '*', GLOB_ONLYDIR);
    //var_dump($template_dirs);
    foreach ($template_dirs as $tpl){
        $tpldir = $tpl.'/Modules/GeoCoding/admin';
        if(!file_exists($tpldir)){
            mkdir($tpldir, 0777, TRUE);
        }
        copy(ASSETS_TPLS.'admin/Geocoding.html', $tpldir.'/Geocoding.html');
    }
    
    $db = \Mbx\DataStore\MbxGetDb();
    
    // Add the lat lng flds to listingsdb - Upgrade path
    $db_cols = array();
    // First get the flds in the db
    $sql = 'SHOW columns FROM '.WPR_TABLE_PFX.'listingsdb';
    $res = $db->GetRows($sql, array());
    
    foreach ($res as $fld){
        
        if(strpos($fld['Field'], '_') === FALSE)
           $db_cols[] = $fld['Field'];     
    }
    
    $new = FALSE;
    // Check the lat
    if(!in_array('latitude', $db_cols)){
        // Add the lat fld
        $new = TRUE;
        $sql = 'ALTER TABLE '.WPR_TABLE_PFX.'listingsdb ADD COLUMN latitude float(10,6) NULL DEFAULT 0';
        $db->TableOp($sql);
    }
    // Check the lng
    if(!in_array('longitude', $db_cols)){
        // Add the lng fld
        $new = TRUE;
        $sql = 'ALTER TABLE '.WPR_TABLE_PFX.'listingsdb ADD COLUMN longitude float(10,6) NULL DEFAULT 0';
        $db->TableOp($sql);
    }
    // Update if necessary
    if($new){
        $sql = 'UPDATE '.WPR_TABLE_PFX.'listingsdb SET latitude = 0, longitude = 0';
        $db->UpdateRow($sql, array());
    }
    
    try {
        $create_settings_table = "CREATE TABLE `".WPR_TABLE_PFX."geocoding_settings` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `configKey` varchar(64) NOT NULL,
            `value` varchar(128) NOT NULL,
            PRIMARY KEY (`id`)
          );";
        
        $db->TableOp($create_settings_table);
        
    } catch (\PDOException $ex) {
        echo $ex->getMessage();
    }
}

