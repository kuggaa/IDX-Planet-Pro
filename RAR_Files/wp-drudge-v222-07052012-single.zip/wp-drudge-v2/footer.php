
	<?php wpd_get_ad('footer') ?>
  
	</div> <!-- end #main-content -->
	
    <div id="footer">  
		<?php 
		/*
		Footer text from the settings page, footer menu, and attribution text
		*/
		$footer_text = stripslashes(get_key('wpd_display_footext'));
		if ( $footer_text != '' ) echo '<p>' . $footer_text . '</p>';
		
		wp_nav_menu( array( 'theme_location' => 'footer', 'menu_class' => 'navigation', 'before' => '<li>', 'after' => '</li>', 'container' => 'none', 'fallback_cb' => false ) ); 
		
		if (get_key('wpd_display_wpdlink') != 'yes') : 
		?>
		<p class="attribution"><a href="http://wpdrudge.com?page=user" target="_blank">Powered by the WP-Drudge WordPress theme</a></p>
		<?php endif; ?>
	</div>
   
     
	</div>
	
	<?php wp_footer() ?>
	
	<?php if (get_key('wpd_display_fbcomments') == 'yes') : ?>
	<div id="fb-root"></div>
	<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
	<?php endif; ?>
	
</body>
</html>