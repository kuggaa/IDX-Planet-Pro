<?php get_header(); ?>

<div id="content-wrap">

	<div id="single-wide">
	
		<h1 class="the-title">404 error: that page could not be found</h1>
		
		<a class="home-link" href="<?php bloginfo('url') ?>">&laquo; Back home</a>
	
	</div>

</div>

<?php get_footer(); ?>

