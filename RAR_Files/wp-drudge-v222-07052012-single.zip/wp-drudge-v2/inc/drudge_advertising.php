<?php 
/*
This file controls the built-in advertising system
*/

add_action( 'init', 'create_post_type_advertisement' );
function create_post_type_advertisement() {
	register_post_type( 
		'wpdrudge_ad',
		array(
			'labels' => array (
				'name' => 'WPD Ads',
				'singular_name' => 'WP-Drudge Ads',
				'add_new' => 'Add a new Ad',
				'add_new_item' => 'Add a new Ad',
				'edit_item' => 'Edit Ad',
				'new_item' => 'New Ad',
				'view_item' => 'View Ad',
				'not_found' => 'No Ads found',
			),
			'description' => 'WP-Drudge ads for display on the site',
			'public' => false,
			'publicly_queryable' => false,
			'show_ui' => true,
			'menu_position' => 5,
			'supports' => array (
				'title', 'custom-fields', 'thumbnail'
			),
			'has_archive' => false,
			'menu_icon' => get_bloginfo('template_url') . '/images/icons/wpd-ad-icon.png'
		)
	);
}

$wpd_ad_metas = array (
	'wpd_ad_type' => array(
		'name' 			=> 'wpd_ad_type',
		'title' 		=> 'Advertisement type',
		'description' 	=> 'Select the advertisement type',
		'type'			=> 'radio',
		'default'		=> '',
		'options'		=> array(
			'code' 		=> 'Code snippet',
			'image' 	=> 'Linked image'
		)
	),
	'wpd_ad_code' => array(
		'name' 			=> 'wpd_ad_code',
		'title' 		=> 'Advertisement code',
		'description' 	=> 'Enter the HTML for this advertisement. Help with this can be found at <a href="http://wpdrudge.com/docs/adding-advertising-to-the-site" target="_blank">the WP-Drudge Docs page</a>.',
		'type'			=> 'textarea',
		'default'		=> ''
	),
	'wpd_ad_link' => array(
		'name' 			=> 'wpd_ad_link',
		'title' 		=> 'Link for banner image',
		'description' 	=> 'Enter the direct URL for your image advertisement',
		'type'			=> 'text',
		'default'		=> ''
	),
	'wpd_ad_location' => array(
		'name' 			=> 'wpd_ad_loc',
		'title' 		=> 'Location',
		'description' 	=> 'Choose where this ad should appear. Choosing "Widget" makes this advertisement available to add in your widget columns.',
		'type'			=> 'select',
		'default'		=> '',
		'options'		=> array(
			'' 				=> '<em>Choose a location...</em>',
			'site-top' 			=> 'Site top',
			'content-top' 		=> 'Above content',
			'footer'			=> 'Bottom of the site',
			'mobile-top' 		=> 'Mobile top',
			'widget1' 			=> 'Widget - 1',
			'widget2' 			=> 'Widget - 2',
			'widget3' 			=> 'Widget - 3',
			'widget4' 			=> 'Widget - 4',
			'widget5' 			=> 'Widget - 5',
			'widget6' 			=> 'Widget - 6',
			'widget7' 			=> 'Widget - 7',
			'widget8' 			=> 'Widget - 8',
			'widget9' 			=> 'Widget - 9',
			'widget10' 			=> 'Widget - 10',
		)
	),
	
);

function wpd_new_ad_metas() {
	
	global $post, $wpd_ad_metas;
	
	echo '<a class="help-box" href="http://wpdrudge.com/docs/adding-advertising-to-the-site" target="_blank">Help with advertising in WP-Drudge &raquo;</a>';
	
	foreach ($wpd_ad_metas as $meta) :
	
		$curr_value = get_post_meta($post->ID, $meta['name'], true);
		
		if ($curr_value == '') {
			$curr_value = $meta['default'];
		}
		
		echo '
		<div style="margin: 0 0 15px; border-bottom: dashed 2px #eee; padding: 0 0 15px"';
		if ($meta['name'] == 'wpd_ad_code') echo ' id="wpd_ad_code_box"';
		if ($meta['name'] == 'wpd_ad_link') echo ' id="wpd_ad_link_box"';
		echo'>
		<h4 style="margin: 0 0 8px; font-size: 14px; font-weight: bold"><label for="'.$meta['name'].'">'.$meta['title'].'</label></h4>';
		
		echo ' 
		<p>'.$meta['description'].'</p>';
		
		switch ($meta['type']) :
			
			case 'text':
				echo '<input type="text" name="'.$meta['name'].'_value" id="'.$meta['name'].'" value="'.$curr_value.'" style="display: block; margin: 0 0 4px; width: 80%" />';
				break;
			
			case 'textarea':
				echo '<textarea name="'.$meta['name'].'_value" id="'.$meta['name'].'" style="display: block; margin: 0 0 4px; width: 80%" cols="" rows="4">'.$curr_value.'</textarea>';
				break;
				
			case 'select':
				echo '<select name="'.$meta['name'].'_value" id="'.$meta['name'].'" style="display: block; margin: 0 0 4px; width: 50%">';
				
				foreach ($meta['options'] as $opk => $opv) :
					echo '<option value="'.$opk.'"';
					if ($opk == $curr_value) echo ' selected';
					echo '>'.$opv.'</option>';
				endforeach;
				
				break;
			
			case 'checkbox':
				echo '<input type="checkbox" name="'.$meta['name'].'_value" id="'.$meta['name'].'" value="yes"'; 
				echo ($curr_value == 'yes' ? 'checked="checked"' : '' );
				echo '/>';
				break;
				
			case 'radio':
				foreach ($meta['options'] as $opk => $opv) :
					echo '<input type="radio" name="'.$meta['name'].'_value" id="'.$meta['name'].'_'.$opk.'" value="'.$opk.'"'; 
					echo ($opk == $curr_value ? 'checked="checked"' : '' );
					echo '/> <label for="'.$opk.'">'.$opv.'</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
				endforeach;

				break;
		
		endswitch;
		
		echo'
		<input type="hidden" name="'.$meta['name'].'_noncename" id="'.$meta['name'].'_noncename" value="'.wp_create_nonce( 'wpdrudge' ).'" />
		</div>';
	
	endforeach;
	
 
}
 
function wpd_create_ad_metas() {
	
	if ( function_exists('add_meta_box') ) {
		add_meta_box( 'new-meta-boxes', 'Ad Information', 'wpd_new_ad_metas', 'wpdrudge_ad', 'normal', 'high' );
	}
 
}
add_action('admin_menu', 'wpd_create_ad_metas');
 
function wpd_save_ad_metas() {
	
	global $post, $wpd_ad_metas;
	
	if (isset($post->post_type) && $post->post_type == 'wpdrudge_ad') :

		foreach($wpd_ad_metas as $meta) {
			
			if ( !isset($_POST[$meta['name'].'_noncename']) && !wp_verify_nonce( $_POST[$meta['name'].'_noncename'], 'wpdrudge' )) {
				return $post->ID;
			}
			
			if ( 'page' == $_POST['post_type'] ) {
				if ( !current_user_can( 'edit_page', $post->ID ))
					return $post->ID;
			} else {
				if ( !current_user_can( 'edit_post', $post->ID ))
					return $post->ID;
			}
			
			$new_data = $_POST[$meta['name'].'_value'];
			
			$curr_data = get_post_meta($post->ID, $meta['name'], true);
			
			if ( $new_data == '') {
				
				delete_post_meta($post->ID, $meta['name']);
				
			} elseif ($new_data != $curr_data) {
				
				update_post_meta($post->ID, $meta['name'], $new_data);
				
			}
		 
		}
		
	endif;
	
	
	
}
add_action('save_post', 'wpd_save_ad_metas');



function wpd_get_ad($group) {
	
	if(is_page_template('template-page-mobile.php') && ($group == 'site-top' || $group == 'content-top' || $group == 'footer')) return;
	
	$return_html = '';
	
	$args = 'posts_per_page=1&meta_key=wpd_ad_loc&meta_value='.$group.'&post_type=wpdrudge_ad&orderby=rand';
	$newQuery = new WP_Query($args);
		
	if ($newQuery->post_count > 0) {
		$return_html .= '<div class="banner-container">';
		$the_id = $newQuery->posts[0]->ID;
		$wp_ad_type = get_post_meta($the_id, 'wpd_ad_type', true);
		if ($wp_ad_type == 'image') {
			$ad_img = get_the_post_thumbnail($the_id, 'full');
			$ad_link = get_post_meta($the_id, 'wpd_ad_link', true);
			if (empty($ad_img)) {
				$return_html .= '<em style="display: block">No image for this ad!</em>';
			} elseif (empty($ad_link)) {
				$return_html .= '<em style="display: block">No link for this ad!</em>';
			} else {
				$return_html .= '<a href="'.$ad_link.'" target="_blank">'.$ad_img.'</a>';
			}
		} elseif ($wp_ad_type == 'code')  {
			$ad_code = get_post_meta($the_id, 'wpd_ad_code', true);
			if (empty($ad_code)) echo '<em style="display: block">No code for this ad!</em>';
			else $return_html .= $ad_code;
		}
		$return_html .= '</div>';
	} 
	
	echo $return_html;

}
