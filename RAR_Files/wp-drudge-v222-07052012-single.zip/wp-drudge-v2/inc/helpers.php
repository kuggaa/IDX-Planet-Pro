<?php

/*
Helper functions
*/

function validate_hex_color($color) {
	$len = strlen($color);
	if ($len != 3 && $len != 6) {
		return false;
	} elseif (!ctype_xdigit($color)) {
		return false;
	} else {
		return true;
	}
}

function get_key($id, $set = null) {
	if (empty($set)) {
		global $wpd_options;
		return stripslashes($wpd_options[$id]);
	} else {
		global $$set;
		return ${$set}[$id];
	}
}

function wpd_font_stack($font) {
	if ($font == 'Drudge') {
		return "'Courier New', Courier, sans-serif; font-weight: bold";
	} elseif ($font == 'Arial') {
		return "Arial, Helvetica, sans-serif";
	} elseif ($font == 'Helvetica') {
		return "Helvetica, Arial, sans-serif";
	} elseif ($font == 'Times New Roman') {
		return "'Times New Roman', Times, Georgia, serif";
	} elseif ($font == 'Georgia') {
		return "Georgia, 'Times New Roman', Times, sans-serif";
	} elseif ($font == 'Trebuchet MS') {
		return "'Trebuchet MS', Helvetica, Arial, sans-serif";
	} elseif ($font == 'Verdana') {
		return "Verdana, Helvetica, Arial, sans-serif";
	} elseif ($font == 'Tahoma') {
		return "Tahoma, Helvetica, Arial, sans-serif";
	} elseif ($font == 'Impact') {
		return "Impact, Helvetica, Arial, sans-serif";
	} elseif ($font == 'Courier New') {
		return "'Courier New', Courier, Helvetica, Arial, sans-serif";
	} elseif ($font == 'Palatino Linotype') {
		return "'Palatino Linotype', 'Palatino', Georgia, 'Times New Roman', Times, sans-serif";
	}
	
}

// Function to get a darker color. Thanks php.net!
// http://php.net/manual/en/function.hexdec.php#99478

function hex2RGB($hexStr, $returnAsString = false, $seperator = ',') {
    $hexStr = preg_replace("/[^0-9A-Fa-f]/", '', $hexStr); // Gets a proper hex string
    $rgbArray = array();
    if (strlen($hexStr) == 6) { //If a proper hex code, convert using bitwise operation. No overhead... faster
        $colorVal = hexdec($hexStr);
        $rgbArray['red'] = 0xFF & ($colorVal >> 0x10);
        $rgbArray['green'] = 0xFF & ($colorVal >> 0x8);
        $rgbArray['blue'] = 0xFF & $colorVal;
    } elseif (strlen($hexStr) == 3) { //if shorthand notation, need some string manipulations
        $rgbArray['red'] = hexdec(str_repeat(substr($hexStr, 0, 1), 2));
        $rgbArray['green'] = hexdec(str_repeat(substr($hexStr, 1, 1), 2));
        $rgbArray['blue'] = hexdec(str_repeat(substr($hexStr, 2, 1), 2));
    } else {
        return false; //Invalid hex color code
    }
    return $returnAsString ? implode($seperator, $rgbArray) : $rgbArray; // returns the rgb string or the associative array
}

/*
PHP cookie functions
*/

// Takes specially formatted string cookie content and spits back an associative array 
function jch_cookie_bite($content) {
	
	$cookie_crumbs = array();
	
	// Cookie parts are separated by a pipe
	$cookie_arr = explode('|', $content);
	foreach ($cookie_arr as $cookie) :
	
		// Cookie values themselves are key/value separated by an equals sign
		$array = explode('=', $cookie);
		
		// No need to get anything without a name
		if (empty($array[0])) continue;
		
		$cookie_crumbs[$array[0]] = $array[1];
		
	endforeach;
	
	return $cookie_crumbs;
}

// Takes a specially formatted array and makes some cookie content
function jch_cookie_bake($cookies) {
	
	// Return string to build
	$cookie_content = '';
	
	if (!is_array($cookies) || empty($cookies)) return $cookie_content;
	
	$i = 1;
	foreach ($cookies as $key => $val) :

		// Need, at least, a name for this cookie
		if (empty($key)) continue;
		else $cookie_content .= $key . '=' . $val;
		
		if (count($cookies) != $i) $cookie_content .= '|';
		$i++;
		
	endforeach;
	
	return $cookie_content;

}
