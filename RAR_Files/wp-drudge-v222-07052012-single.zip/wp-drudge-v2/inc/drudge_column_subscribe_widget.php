<?php
class drudge_column_subscribe_widget extends WP_Widget {
	
	function drudge_column_subscribe_widget() {
		
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'drudge_column_subscribe', 'description' => 'Shows subscribe options.' );

		/* Create the widget. */
		$this->WP_Widget( 'drudge-column-subscribe', 'WP-Drudge Subscribe', $widget_ops);
	
	}
	 
	function widget($args, $instance) {
		
		global $wpd_options;
		
		// Grab widget settings
		
		extract($args); 
		
		$title = apply_filters('widget_title', $instance['title']);
		
		$subscribe_rss = $instance['subscribe_rss'];
		$subscribe_twitter = $instance['subscribe_twitter'];
		$subscribe_email = $instance['subscribe_email'];
		$subscribe_facebook = $instance['subscribe_facebook'];
		$subscribe_youtube = $instance['subscribe_youtube'];
		$subscribe_linkedin = $instance['subscribe_linkedin'];
		$subscribe_digg = $instance['subscribe_digg'];
		$subscribe_reddit = $instance['subscribe_reddit'];
		$subscribe_stumble = $instance['subscribe_stumble'];
		$subscribe_gplus = $instance['subscribe_gplus'];
		
		$icon_size = $instance['icon_size'];
		
		$link_target = '';
		if ($wpd_options['wpd_display_newtab'] == 'yes') {
			$link_target = ' target="_blank"';
		}
		
		// Display the widget when called
		
		echo $before_widget;
		
		echo '
		<div class="wpd-subscribe">';
		
		if(isset($title) && $title != '') {
			
			echo $before_title . $title . $after_title;
				
		}
		
		if (isset($subscribe_rss) && $subscribe_rss != '') { 
			echo '<a href="' . $subscribe_rss . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_rss.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="RSS" /></a> ';
		}
		if (isset($subscribe_email) && $subscribe_email != '') { 
			echo '<a href="' . $subscribe_email . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_email.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="Email" /></a> ';
		}
		if (isset($subscribe_twitter) && $subscribe_twitter != '') { 
			echo '<a href="' . $subscribe_twitter . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_twitter.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="Twitter" /></a> ';
		}
		if (isset($subscribe_facebook) && $subscribe_facebook != '') { 
			echo '<a href="' . $subscribe_facebook . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_facebook.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="Facebook" /></a> ';
		}
		if (isset($subscribe_youtube) && $subscribe_youtube != '') { 
			echo '<a href="' . $subscribe_youtube . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_youtube.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="LinkedIn" /></a> ';
		}
		if (isset($subscribe_linkedin) && $subscribe_linkedin != '') { 
			echo '<a href="' . $subscribe_linkedin . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_linkedin.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="LinkedIn" /></a> ';
		}
		if (isset($subscribe_digg) && $subscribe_digg != '') { 
			echo '<a href="' . $subscribe_digg . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_digg.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="Digg" /></a> ';
		}
		if (isset($subscribe_reddit) && $subscribe_reddit != '') { 
			echo '<a href="' . $subscribe_reddit . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_reddit.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="Reddit" /></a> ';
		}
		if (isset($subscribe_stumble) && $subscribe_stumble != '') { 
			echo '<a href="' . $subscribe_stumble . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_stumble.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="Stumble" /></a> ';
		}
		if (isset($subscribe_gplus) && $subscribe_gplus != '') { 
			echo '<a href="' . $subscribe_gplus . '"' . $link_target . '><img src="' . get_bloginfo('template_url') . '/images/icons/subscribe_gplus.png" width="' . $icon_size . '" height="' . $icon_size . '" alt="Google Plus" /></a> ';
		}
		
		echo '
		</div>';
	
		echo $after_widget;
			
	}
 
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		
		$instance['icon_size'] = $new_instance['icon_size'];
		
		$instance['subscribe_rss'] = $new_instance['subscribe_rss'];
		$instance['subscribe_email'] = $new_instance['subscribe_email'];
		$instance['subscribe_twitter'] = $new_instance['subscribe_twitter'];
		$instance['subscribe_facebook'] = $new_instance['subscribe_facebook'];
		$instance['subscribe_youtube'] = $new_instance['subscribe_youtube'];
		$instance['subscribe_linkedin'] = $new_instance['subscribe_linkedin'];
		$instance['subscribe_digg'] = $new_instance['subscribe_digg'];
		$instance['subscribe_reddit'] = $new_instance['subscribe_reddit'];
		$instance['subscribe_stumble'] = $new_instance['subscribe_stumble'];
		$instance['subscribe_gplus'] = $new_instance['subscribe_gplus'];

		return $instance;

	}
 
	function form($instance) {
		
		$defaults = array(
			'title' => '',
			'subscribe_rss' => get_bloginfo('rss2_url'),
			'icon_size' => '30'
		);
		
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		?>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><strong>Title</strong> <span style="font-size: 0.9em">(leave blank for none)</span></label>
			<input type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'icon_size' ); ?>"><strong>Icon size</strong> <span style="font-size: 0.9em">(in pixels, up to 60)</span></label>
			<input type="text" id="<?php echo $this->get_field_id( 'icon_size' ); ?>" name="<?php echo $this->get_field_name( 'icon_size' ); ?>" value="<?php echo $instance['icon_size']; ?>" style="display: block; width: 50%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_rss' ); ?>"><strong>RSS URL</strong> <span style="font-size: 0.9em">(leave blank for default feed)</span></label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_rss' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_rss' ); ?>" value="<?php echo $instance['subscribe_rss']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_email' ); ?>" style="font-weight: bold">Email subscribe URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_email' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_email' ); ?>" value="<?php echo $instance['subscribe_email']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_twitter' ); ?>" style="font-weight: bold">Twitter page URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_twitter' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_twitter' ); ?>" value="<?php echo $instance['subscribe_twitter']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_facebook' ); ?>" style="font-weight: bold">Facebook page URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_facebook' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_facebook' ); ?>" value="<?php echo $instance['subscribe_facebook']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_youtube' ); ?>" style="font-weight: bold">YouTube channel URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_youtube' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_youtube' ); ?>" value="<?php echo $instance['subscribe_youtube']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_linkedin' ); ?>" style="font-weight: bold">LinkedIn URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_linkedin' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_linkedin' ); ?>" value="<?php echo $instance['subscribe_linkedin']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_stumble' ); ?>" style="font-weight: bold">StumbleUpon profile URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_stumble' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_stumble' ); ?>" value="<?php echo $instance['subscribe_stumble']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_gplus' ); ?>" style="font-weight: bold">Google Plus profile URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_gplus' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_gplus' ); ?>" value="<?php echo $instance['subscribe_gplus']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_reddit' ); ?>" style="font-weight: bold">Reddit profile URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_reddit' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_reddit' ); ?>" value="<?php echo $instance['subscribe_reddit']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'subscribe_digg' ); ?>" style="font-weight: bold">Digg profile URL</label>
			<input type="text" id="<?php echo $this->get_field_id( 'subscribe_digg' ); ?>" name="<?php echo $this->get_field_name( 'subscribe_digg' ); ?>" value="<?php echo $instance['subscribe_digg']; ?>" style="display: block; width: 100%" />
		</p>
		
		<p style="padding: 6px 0;">
			<a class="help-box" href="http://wpdrudge.com/docs/widgets/subscribe-widget" target="_blank">Help with this widget &raquo;</a>
		</p>
        
        <?php

	}
}

add_action( 'widgets_init', create_function('', 'return register_widget("drudge_column_subscribe_widget");') );