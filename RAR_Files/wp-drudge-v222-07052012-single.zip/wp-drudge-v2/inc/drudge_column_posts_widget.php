<?php 

class drudge_column_posts_widget extends WP_Widget {
	
	function drudge_column_posts_widget() {
		
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'drudge_col_posts', 'description' => 'Displays posts within a particular category.' );

		/* Create the widget. */
		$this->WP_Widget( 'drudge-column-posts', 'WP-Drudge Posted Links', $widget_ops);
	
	}
	 
	function widget($args, $instance) {
	
		global $post, $wpd_options;
		
		// Grab and save the existing $post object
		
		$post_orig = $post; 
		
		// Grab widget settings
		
		extract($args); 
		
		$title = apply_filters('widget_title', $instance['title']);
		$show_header = $instance['show_header'];
		$category = $instance['category'];
		$num_posts = $instance['num_posts'];
		$featured = $instance['featured'];
		
		// A '0' for number if posts on the settings form means show all
		
		if ($num_posts == '0') {
			$num_posts = -1;
		}
		
		$offset = $instance['offset'];
		
		// Display the widget when called
		
		echo $before_widget;
		
		echo '
		<div class="wpd-posted-links">';
		
		do_action('wpd_hook_before_posted_link_widget');
		
		// Formatting and displaying the header
		
		if(isset($title) && $show_header) {
			
			echo $before_title;
			
			// Should the category headers be linked to their category page?
			
			if ($wpd_options['wpd_display_linkcatheads'] == 'yes') {
				echo '<a href="' . get_bloginfo('url') . '/?cat=' . $category . '">' . $title . '</a>';
			} else {
				echo $title;	
			}
			
			echo $after_title;
				
		}
		
		// Args for posts to be displayed, set in the widget form
	
		$list_args = array(
			'posts_per_page' => $num_posts,
			'offset' => $offset,
			'ignore_sticky_posts' => false
		);
		
		if (defined('CURRENT_FEATURED_POST')) $list_args['post__not_in'] = array(constant('CURRENT_FEATURED_POST'));
		
		// Category to display, if not all
		
		if ($category != 'all') {
			$list_args['cat'] = $category;
		}
		
		// Should it be featured posts that are shown?
		
		if ($featured == 'yes') {
			$list_args['meta_key'] = 'featured';
			$list_args['meta_value'] = 'yes';
		}
		
		$showPosts = new WP_Query($list_args);
		
		if ($showPosts->have_posts()) {
			
			// Give it the posted link class and add a border if set in the options
			
			echo '
			<ul class="posts-list posted-links-category-'.$category.'';
			
			if ($wpd_options['wpd_display_postedlink_border'] == 'yes') {
				echo ' border';
			}
			
			echo'">';
			
			while($showPosts->have_posts()) :
			
				$showPosts->the_post();	
				
				$curr_link = get_drudge_metas(get_the_ID(), false, true);
				
				// Now we output the individual link
				echo '
				<li class="the-content'.$curr_link['class_insert'].'">';
				
				if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'top') {	
					echo $curr_link['image_html'];
				}
				
				echo $curr_link['link_html'];
	
				if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'middle') {	
					echo $curr_link['image_html'];
				}
				
				if ($curr_link['blurb'] != '') {
					echo $curr_link['blurb'];
				}
				
				if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'bottom') {	
					echo $curr_link['image_html'];
				}
				
				echo '
				</li>';
		
			endwhile;
			
			echo '
			</ul>';
		}
		
		do_action('wpd_hook_after_posted_link_widget');
		
		echo '
		</div>';

		echo $after_widget;
		
		// Restore original $post object
		
		$post = $post_orig;
			
	}
 
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;

		// Storing widget title as inputted option or category name
		
		$widget_title = strip_tags($new_instance['title']);
		
		$instance['title'] = $widget_title;
		
		if ($widget_title == '') {
			
			$instance['title'] = get_cat_name($new_instance['category']);
			
		}
		
		// Should the header be shown?
		
		$instance['show_header'] = FALSE;
		
		if($new_instance['show_header'] == 'yes') {
		
			$instance['show_header'] = TRUE;
			
		}
		
		// Category to show
		
		$instance['category'] = $new_instance['category'];
		
		// Number of posts to be displayed
	
		$instance['num_posts'] = trim(strip_tags($new_instance['num_posts']));
		
		// Number of posts to offset
		
		$instance['offset'] = trim(strip_tags($new_instance['offset']));
		
		// Should the posts shown be featured?
		
		$instance['featured'] = trim(strip_tags($new_instance['featured']));

		return $instance;

	}
 
	function form($instance) {
		
		$defaults = array(
			'title' => '',
			'show_header' => 'yes',
			'categories' => '',
			'num_posts' => get_option('posts_per_page'),
			'offset' => '0',
			'featured' => ''
		);
		
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		?>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>" style="font-weight: bold">Title </label>
			<input type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="display: block; width: 100%" />
            <span style="font-size: 0.9em; font-weight: normal">(leave blank to use category name)</span>
		</p>
        
        <p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'show_header' ); ?>" name="<?php echo $this->get_field_name( 'show_header' ); ?>" value="yes" <?php if ($instance['show_header'] == 'yes') { echo 'checked="checked"'; } ?>/>
            <label for="<?php echo $this->get_field_id( 'show_header' ); ?>" style="font-weight: bold">Show Title?</label>
		</p>
        
        <p style="padding: 6px 0;">
        	<input type="text" id="<?php echo $this->get_field_id( 'num_posts' ); ?>" name="<?php echo $this->get_field_name( 'num_posts' ); ?>" value="<?php echo $instance['num_posts']; ?>" size="4"/>
			<label for="<?php echo $this->get_field_id( 'num_posts' ); ?>" style="font-weight: bold; margin-left: 10px"># of links to show</label>
		</p>
		
		<p style="padding: 6px 0;">
        	<input type="text" id="<?php echo $this->get_field_id( 'offset' ); ?>" name="<?php echo $this->get_field_name( 'offset' ); ?>" value="<?php echo $instance['offset']; ?>" size="4"/>
			<label for="<?php echo $this->get_field_id( 'offset' ); ?>" style="font-weight: bold; margin-left: 10px"># of links offset</label>
		</p>
        
        <p>
        	
            <label for="<?php echo $this->get_field_id( 'category' ); ?>" style="font-weight: bold; margin: 0 0 10px; display: block">Category to display</label>
            <select id="<?php echo $this->get_field_id( 'categories' ); ?>" name="<?php echo $this->get_field_name( 'category' ); ?>" style="width: 100%">
            <?php 
			$categories = get_categories(array (
			'type' => 'post',
			'hide_empty' => 0
			)); 
			
			foreach($categories as $category) { 
			?> 
            	<option value="<?php echo $category->term_id; ?>" <?php if (isset($instance['category']) && $instance['category'] == $category->term_id) { echo 'selected="selected"';} ?>><?php echo $category->name?></option>
            <?php
			}
			?>
				<option value="all" <?php if (isset($instance['category']) && $instance['category'] == 'all') { echo 'selected="selected"';} ?>>&ndash; All categories &ndash;</option>
            </select>
            <div style="clear: both"></div>
		</p>
		
		<p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'featured' ); ?>" name="<?php echo $this->get_field_name( 'featured' ); ?>" value="yes" <?php if ($instance['featured'] == 'yes') { echo 'checked="checked"'; } ?>/>
            <label for="<?php echo $this->get_field_id( 'featured' ); ?>" style="font-weight: bold">Only featured posts?</label>
		</p>
		
		<p style="padding: 6px 0;">
			<a class="help-box" href="http://wpdrudge.com/docs/widgets/posted-links-widget" target="_blank">Help with this widget &raquo;</a>
		</p>
        
        <?php

	}
}

add_action( 'widgets_init', create_function('', 'return register_widget("drudge_column_posts_widget");') );