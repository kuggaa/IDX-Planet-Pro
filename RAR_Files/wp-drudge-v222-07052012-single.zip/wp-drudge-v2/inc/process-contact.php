<?php

$errors = array();
$submit_type = $_POST['submit_type'];

//Check to see if the honeypot captcha field was filled in, sto pif it is
if (trim($_POST['honeypot']) !== '') :

	$errors[] = 'Try again...';

elseif (! wp_verify_nonce($_POST['nonce'], 'wp-drudge-nonce')) :

	$errors[] = 'Nonce not found';
	
else : 
	
	if ($submit_type == 'page') :
	
		//Check to make sure that the name field is not empty
		if(isset($_POST['from_name']) && $_POST['from_name'] !== '') $from_name = $_POST['from_name'];
		else $errors[] = 'Please enter your name';
		
	endif;
	
	if ($submit_type == 'page' || ($submit_type == 'widget' && $_POST['email_required'] == 'yes')) :
		
		//Check to make sure that the email field is not empty
		if (isset($_POST['from_email']) && $_POST['from_email'] !== '') :
			
			$from_email = $_POST['from_email'];
			
			if (! $from_email = filter_var($from_email, FILTER_VALIDATE_EMAIL)) :
			
				$errors[] = 'Please enter a valid email address';
			
			endif;
		
		else :
		
			$errors[] = 'Please enter an email address';
			
		endif; 
		
	endif;
	
	//Check to make sure comments were entered
	if(isset($_POST['from_message']) && $_POST['from_message'] !== '') $the_message = stripslashes(strip_tags(trim($_POST['from_message'])));
	else $errors[] = 'Please enter a message';
	
	if (isset($_POST['math_gotcha'])) :
	
		if (bindec($_POST['math_gotcha']) != $_POST['math_input']) $errors[] = 'Incorrect math check';
	
	endif;
	
	//If there are no errors, send the email
	if(count ($errors) === 0) {
	
		if(! $to_email = get_post_meta(get_the_ID(), 'Send to', true) ) $to_email = get_bloginfo('admin_email');
		
		$subject = 'Contact form submission (' . $submit_type . ') on ' . get_bloginfo('name');
		
		$body = '** This is a contact submission made from a ' . $submit_type . ' on ' . get_bloginfo('name') . " **\n\n";
		
		if (isset($from_name) && $from_name) 	$body .= "From: $from_name\n";
		
		if (isset($from_email) && $from_email) 	$body .= "Email: $from_email\n";
		else $from_email = get_bloginfo('admin_email');
		
		if ($the_message) 	$body .= "Message: $the_message\n";
		
		$headers = 'From: '.get_bloginfo('name').' Site <' . $from_email . '>' . "\r\n" . 'Reply-To: ' . $from_email;
	
		mail($to_email, $subject, $body, $headers);
		
		$email_sent = true;
	
	}
	
endif;