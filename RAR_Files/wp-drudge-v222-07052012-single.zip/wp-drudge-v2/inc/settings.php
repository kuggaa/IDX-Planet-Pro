<?php 

// Options for WP-Drudge

require_once (TEMPLATEPATH . '/libs/DataSource.php');

$themename = 'WP-Drudge';
$shortname = 'wpdrudge';
$version = WP_DRUDGE_CURRENT_VERSION;

// Using a CSV to store options and their information to make life much easier to keep track of them!
$csv = new WPD_File_CSV_DataSource;
$csv->load(TEMPLATEPATH . '/inc/drudge_options.csv') or die('drudge_options.csv could not be found!');
$options = $csv->getRows();

/* 
0 = name
1 = id
2 = desc
3 = type
4 = default
5 = options
6 = validate
7 = error 
8 = category
*/

function mytheme_add_admin() {
	
	global $themename, $shortname, $options, $wpd_options;
	
	if ( array_key_exists('page', $_GET) && $_GET['page'] == basename(__FILE__) ) {
		
		if (array_key_exists('action', $_REQUEST)) {
			
			if ( 'save' == $_REQUEST['action'] ) {
					
				$i = 0;
		
				foreach ($options as $opt) {
		
					if (isset($_REQUEST[$opt[1]])) :
						
						$new_opt = $_REQUEST[$opt[1]];
						
						// Validate hex colors for certain fields
						if ($options[$i][6] == 'is_hex') :
							
							if ($new_opt[0] == '#') $new_opt = substr($new_opt, 1);
							
							if (! validate_hex_color($new_opt)) $new_opt = $options[$i][4];
							else $new_opt = '#' . $new_opt;
							
						endif;
						
						$wpd_options[$opt[1]] = $new_opt;
						
					else :
					
						$wpd_options[$opt[1]] = '';
						
					endif;
					
					$i++;
		
				}
				
				$wpd_options['last-panel'] = $_REQUEST['panel'];
				
				update_option('wpdrudge_settings_array', $wpd_options);
		
				header("Location: themes.php?page=settings.php&saved=true");
				
				die;
		
			} else if ( 'reset' == $_REQUEST['action'] ) {
		
				foreach ($options as $opt) {
					
					$wpd_options[$opt[1]] = $opt[4];
					
				}
				
				$wpd_options['last-panel'] = $_REQUEST['panel'];
				
				update_option('wpdrudge_settings_array', $wpd_options);
				
				header("Location: themes.php?page=settings.php&reset=true");
				
				die;
			}
		}
	}

	add_theme_page($themename." Options", $themename . " options", 'edit_themes', basename(__FILE__), 'mytheme_admin');

}

add_action('admin_menu' , 'mytheme_add_admin');

function mytheme_admin() {

    global $themename, $shortname, $options, $wpd_options;

	if ( isset($_REQUEST['saved']) && $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' '.__('settings saved.','thematic').'</strong></p></div>';
	
    if ( isset($_REQUEST['reset']) && $_REQUEST['reset'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' '.__('settings reset.','thematic').'</strong></p></div>';
	
	$colorpicker_ids = array();
	?>
		<div class="wrap" id="wpd-options-page">
			<h2><?php echo $themename; ?> Settings</h2>
            
		  	<form method="post">
           
			 <ul id="wpd-options-nav">
            	<?php 
				$last_category = '';
				foreach ($options as $value) {
					$slug = strtolower(str_replace(' ', '-', $value[8]));
					if ($value[8] != $last_category) {
						?><li><a rel="<?php echo $slug ?>"><?php echo $value[8] ?></a></li><?php
					}
					$last_category = $value[8];
				}?>
				<li><a href="http://wpdrudge.com/docs" target="_blank" rel="">Help</a></li>
            </ul>
            
			<?php 
			
			// Resetting previous category name
			
			$last_category = '';
			
			// Set counter for tabbed nav
			
			$i = 1;
			
			
			foreach ($options as $value) :
				
				$slug = strtolower(str_replace(' ', '-', $value[8]));
				
				if ($value[8] != $last_category) {
					
					if ($slug != 'header') echo '</table>';
					
					?>
				<table class="wpd-form-table" id="<?php echo $slug ?>">
					
					<tr>
						<td colspan="2" class="header">
						<h3><?php  echo $value[8] ?></h3>
						<a class="help-box" href="http://wpdrudge.com/docs/configuring-the-theme/<?php echo $slug ?>" target="_blank">Help with <?php  echo $value[8] ?> settings &raquo;</a>
						</td>
					</tr>
					
				<?php
					$last_category = $value[8];
				}
				
				if ($value[5] != '') {
					$value[5] = explode(',', $value[5]);
				}
	
				if (isset($value[4][0]) && $value[4][0] != '#') {
					$value[4] = '#' . $value[4];
				}
		
			
				// Displays correct inputs for "text" type			
				if ($value[3] == 'text') { 
			?>
				<tr>
					<th scope="row">
						<label for="<?php echo $value[1]; ?>"><?php echo $value[0]; ?>:</label>
					</th>
					<td>
						<?php echo $value[2] ?><br >
						<?php 
						// If the field is looking for a HEX code value, it needs to be error checked and displayed differently
						if ($value[6] == 'is_hex') :
							
							$box_id = $value[1] . '_contain';
							$colorpicker_ids[] = $box_id ;
							
							$color_hex = $wpd_options[$value[1]];
							if ($color_hex[0] != '#') $color_hex = '#' . $color_hex;
							
							?><div id="<?php echo $box_id ?>" class="input-append color" data-color-format="hex" data-color="<?php echo $color_hex ?>"><input size="6" name="<?php echo $value[1]; ?>" id="<?php echo $value[1]; ?>" type="text" value="<?php echo $color_hex?>" style="position: relative"> <span class="add-on"><i class="color-sample" style="background-color: <?php echo $color_hex ?>"></i></span> &lArr; Pick a color</div>
							
						<?php 
						elseif ($value[6] == 'is_num') : 
							if (!ctype_digit($wpd_options[$value[1]])) {
									echo '<strong>' . $value[7] . '</strong><br >';
							}
						?>	
						<input size="10" onfocus="this.select();" name="<?php echo $value[1]; ?>" id="<?php echo $value[1]; ?>" type="text" value="<?php 
							if ($wpd_options[$value[1]] != "" && ctype_digit($wpd_options[$value[1]]) ) { 
								echo $wpd_options[$value[1]];
							} else { 
								if ( isset($value[4]) ) {
									echo $value[4];
								}
							} ?>" >
						<?php else: ?>
						<input size="60" onfocus="this.select();" name="<?php echo $value[1]; ?>" id="<?php echo $value[1]; ?>" type="text" value="<?php 
							if ( $wpd_options[$value[1]] != "" ) { 
								echo stripslashes($wpd_options[$value[1]]); 
							} else {
								echo $value[4];
							}
								?>" >
								
						<?php endif; ?>
					</td>
				</tr>
                <?php 
				// Displays correct inputs for "select" type
				} elseif ($value[3] == 'select') {
				?>
                
                <tr>
					<th scope="row">
						<label for="<?php echo $value[1]; ?>"><?php echo $value[0]; ?>:</label>
					</th>
					<td>
						<?php echo $value[2]; ?><br >
						<select name="<?php echo $value[1]; ?>" id="<?php echo $value[1]; ?>">
                        <?php foreach ($value[5] as $val) {?>
                        	<option value="<?php echo $val ?>" <?php 
						if ( array_key_exists($value[1], $wpd_options) && $wpd_options[$value[1]] == $val) { 
							echo 'selected';
						} ?>><?php echo $val ?></option> 
                        <?php } ?>
                        </select>
					</td>
				</tr>
                
                <?php 
				} 
				// Displays correct inputs for "radio" type
				elseif ($value[3] == 'radio') {
				?>
                
                <tr>
					<th scope="row">
						<?php echo $value[0]; ?>:
					</th>
					<td>
						<?php echo $value[2]; ?><br >
                        <?php foreach ($value[5] as $val) {?>
                        
                        <input type="radio" value="<?php echo $val ?>" <?php if ( $wpd_options[$value[1]] == $val || ($wpd_options[$value[1]] == '' && $value[4] == $val )) { echo 'checked';} ?> name="<?php echo $value[1]; ?>" id="<?php echo $value[1] . $val; ?>">
                        <label for="<?php echo $value[1] . $val; ?>"><?php echo $val ?></label><br >
                        <?php } ?>
					</td>
				</tr>
                
                <?php } elseif ($value[3] == 'checkbox') {?>
                
                <tr>
					<th scope="row">
						<?php echo $value[0]; ?>:
					</th>
					<td>	
						<?php echo $value[2] ?><br >
                        <input type="checkbox" value="yes" <?php if ( $wpd_options[$value[1]] == 'yes' ) { echo 'checked';} ?> name="<?php echo $value[1]; ?>" id="<?php echo $value[1]; ?>">
                        <label for="<?php echo $value[1]; ?>">Yes</label><br >

					</td>
				</tr>
                
				<?php } 
				// Displays correct inputs for "textarea" type
				elseif ($value[3] == 'textarea') { ?>
				<tr>
					<th scope="row">
						<?php echo $value[0]; ?>:
					</th>
					<td>
						<textarea onfocus="this.select();" rows="6" cols="60" name="<?php echo $value[1]; ?>" id="<?php echo $value[1]; ?>" type="<?php echo $value[3]; ?>" ><?php if ( $wpd_options[$value[1]] != "") { echo stripslashes($wpd_options[$value[1]]); }?></textarea>
					</td>
				</tr>
				
				<?php } elseif ($value[3] == 'title') {?>
				<tr>
                      <td colspan="2" class="header">
                         <?php  echo $value[0] ?>
                       </td>
				 </tr>
				<?php  }  elseif ($value[3] == "break") { ?>
                <hr style="margin: 10px 0" >
                
			<?php 
				} 
				if ($value[8] != $last_category) {
					echo '</table>';
				}
				$i++;
				
			endforeach; 
			
			?>
			 </table>
			 <p class="submit">
			 <input name="save" type="submit" value="Save changes" class="button-primary">
			 <input type="hidden" name="action" value="save" >
			 <?php if (isset($wpd_options['last-panel'])) : ?>
			 <input type="hidden" id="wpd-show-panel" name="panel" value="<?php echo $wpd_options['last-panel'] ?>" >
			 <?php else : ?>
			 <input type="hidden" id="wpd-show-panel" name="panel" value="header" >
			 <?php endif; ?>
			</p>
		  </form>
		
		  <form method="post">
		   <p class="submit" style="border: 0;">
			<input name="reset" type="submit" value="Restore defaults" onclick="return wpdRestoreConfirm()">
			<input type="hidden" name="action" value="reset" >
		   </p>
		  </form>
		  
		  <script src="<?php echo get_bloginfo('template_url') ?>/js/libs/bootstrap-colorpicker.js"></script>
			<script>
				jQuery('<?php
				$i = 1;
				$c = count($colorpicker_ids);
				foreach ($colorpicker_ids as $cp_id) :
					echo '#' . $cp_id;
					if ($i != $c) echo ',';
				endforeach;
				?>').colorpicker({
					format: 'hex'
				});
			</script>
	
		</div>
		
<?php 

}//end function mytheme_admin() 


function wpdrudge_init() {
	
	global $shortname, $options, $wpd_options, $version;
	
	$activate_option = 'WP-Drudge_activation_check';
	
	$check = get_option($activate_option);
	
	if ( $check == "set" ) {
		
		// AKA, if the theme was activated as version as 1.0.2 or earlier
		// This new version uses different options names stored as an array so we need to get the previous versions, if they exist, and set the new one
		
		$wpd_options['wpd_display_comlink'] = get_option('display_comlink');
		$wpd_options['wpd_display_fimage'] = get_option('display_fimage');
		$wpd_options['wpd_display_footext'] = get_option('display_footext');
		$wpd_options['wpd_display_image'] = get_option('display_image');
		$wpd_options['wpd_display_layout'] = get_option('display_layout');
		$wpd_options['wpd_display_logo'] = get_option('display_logo');
		$wpd_options['wpd_display_newtab'] = get_option('display_newtab');
		$wpd_options['wpd_display_tagline'] = get_option('display_tagline');
		$wpd_options['wpd_style_bgcolor'] = get_option('style_bgcolor');
		$wpd_options['wpd_style_boxborder'] = get_option('style_boxborder');
		$wpd_options['wpd_style_colborder'] = get_option('style_colborder');
		$wpd_options['wpd_style_descsize'] = get_option('style_descsize');
		$wpd_options['wpd_style_headcolor'] = get_option('style_headcolor');
		$wpd_options['wpd_style_headfont'] = get_option('style_headfont');
		$wpd_options['wpd_style_headsize'] = get_option('style_headsize');
		$wpd_options['wpd_style_linkbold'] = get_option('style_linkbold');
		$wpd_options['wpd_style_linkborder'] = get_option('style_linkborder');
		$wpd_options['wpd_style_linkcolor'] = get_option('style_linkcolor');
		$wpd_options['wpd_style_linkfont'] = get_option('style_linkfont');
		$wpd_options['wpd_style_linksize'] = get_option('style_linksize');
		$wpd_options['wpd_style_linkstyle'] = get_option('style_linkstyle');
		$wpd_options['wpd_style_morecss'] = get_option('style_morecss');
		$wpd_options['wpd_style_pagesize'] = get_option('style_pagesize');
		$wpd_options['wpd_style_textcolor'] = get_option('style_textcolor');
		$wpd_options['wpd_style_vlinkcolor'] = get_option('style_vlinkcolor');
		$wpd_options['wpd_style_wrapcolor'] = get_option('style_wrapcolor');
		
		delete_option('display_comlink');
		delete_option('display_fimage');
		delete_option('display_footext');
		delete_option('display_image');
		delete_option('display_layout');
		delete_option('display_logo');
		delete_option('display_newtab');
		delete_option('display_tagline');
		delete_option('style_bgcolor');
		delete_option('style_boxborder');
		delete_option('style_colborder');
		delete_option('style_descsize');
		delete_option('style_headcolor');
		delete_option('style_headfont');
		delete_option('style_headsize');
		delete_option('style_linkbold');
		delete_option('style_linkborder');
		delete_option('style_linkcolor');
		delete_option('style_linkfont');
		delete_option('style_linksize');
		delete_option('style_linkstyle');
		delete_option('style_morecss');
		delete_option('style_pagesize');
		delete_option('style_textcolor');
		delete_option('style_vlinkcolor');
		delete_option('style_wrapcolor');
		
		update_option($activate_option, "activated-$version");
	
		foreach ($options as $opt) {
			
			if (!isset($wpd_options[$opt[1]])) {
				
				$wpd_options[$opt[1]] = $opt[4];
				
			}
			
		}
		
		update_option('wpdrudge_settings_array', $wpd_options);
		
	} elseif (empty($check)) {
		
		foreach ($options as $opt) {
				
			$wpd_options[$opt[1]] = $opt[4];
			
		}
			
		update_option('wpdrudge_settings_array', $wpd_options);
		
		update_option($activate_option, "activated-$version");
	
	} else {
		
		update_option($activate_option, "activated-$version");
	
  	} 
}

add_action('admin_head', 'wpdrudge_init');


