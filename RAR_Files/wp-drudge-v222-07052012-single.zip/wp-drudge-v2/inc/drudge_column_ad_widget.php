<?php



class drudge_column_ad_widget extends WP_Widget {
	
	function drudge_column_ad_widget() {
		
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'drudge_ad', 'description' => 'Displays WP-Drudge advertisements' );

		/* Create the widget. */
		$this->WP_Widget( 'drudge-column-ads', 'WP-Drudge Ads', $widget_ops);
	
	}
	 
	function widget($args, $instance) {
		
		global $wpd_options;
		
		// Grab widget settings
		
		extract($args); 
		
		$wpd_ad_group = $instance['ad_group'];

		// Display the widget when called
		
		echo $before_widget;
		
		echo '
		<div class="wpd-advertisement">';
		
		wpd_get_ad($wpd_ad_group);
		
		echo '
		</div>';
	
		echo $after_widget;
		
		wp_reset_query();
		
	}
 
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['ad_group'] = $new_instance['ad_group'];

		return $instance;

	}
 
	function form($instance) {
		
		$defaults = array(
			'ad_group' => '',
		);
		
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		?>
        
        <p>
        	
            <label for="<?php echo $this->get_field_id( 'ad_group' ); ?>" style="font-weight: bold; margin: 0 0 10px; display: block">Choose the widget ad group:</label>
            <select id="<?php echo $this->get_field_id( 'ad_group' ); ?>" name="<?php echo $this->get_field_name( 'ad_group' ); ?>" style="width: 100%">
            	<option value="widget1" <?php if ($instance['ad_group'] == 'widget1') { echo 'selected="selected"';} ?>>Widget - 1</option>
                <option value="widget2" <?php if ($instance['ad_group'] == 'widget2') { echo 'selected="selected"';} ?>>Widget - 2</option>
                <option value="widget3" <?php if ($instance['ad_group'] == 'widget3') { echo 'selected="selected"';} ?>>Widget - 3</option>
                <option value="widget4" <?php if ($instance['ad_group'] == 'widget4') { echo 'selected="selected"';} ?>>Widget - 4</option>
                <option value="widget5" <?php if ($instance['ad_group'] == 'widget5') { echo 'selected="selected"';} ?>>Widget - 5</option>
                <option value="widget6" <?php if ($instance['ad_group'] == 'widget6') { echo 'selected="selected"';} ?>>Widget - 6</option>
                <option value="widget7" <?php if ($instance['ad_group'] == 'widget7') { echo 'selected="selected"';} ?>>Widget - 7</option>
                <option value="widget8" <?php if ($instance['ad_group'] == 'widget8') { echo 'selected="selected"';} ?>>Widget - 8</option>
                <option value="widget9" <?php if ($instance['ad_group'] == 'widget9') { echo 'selected="selected"';} ?>>Widget - 9</option>
                <option value="widget10" <?php if ($instance['ad_group'] == 'widget10') { echo 'selected="selected"';} ?>>Widget - 10</option>
            </select>
            <div style="clear: both"></div>
		</p>
		
		<p style="padding: 6px 0;">
			<a class="help-box" href="http://wpdrudge.com/docs/widgets/ads-widget" target="_blank">Help with this widget &raquo;</a>
		</p>
        
        
        <?php

	}
}

add_action( 'widgets_init', create_function('', 'return register_widget("drudge_column_ad_widget");') );