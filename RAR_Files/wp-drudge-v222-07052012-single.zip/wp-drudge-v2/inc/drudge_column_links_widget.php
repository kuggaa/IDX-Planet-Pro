<?php



class drudge_column_links_widget extends WP_Widget {
	
	function drudge_column_links_widget() {
		
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'drudge_link_posts', 'description' => 'Displays links within a particular category.' );

		/* Create the widget. */
		$this->WP_Widget( 'drudge-column-links', 'WP-Drudge Static Links', $widget_ops);
	
	}
	 
	function widget($args, $instance) {
		
		global $wpd_options;
		
		// Grab widget settings
		
		extract($args); 
		
		$title = apply_filters('widget_title', $instance['title']);
		
		$show_header = $instance['show_header'];
		
		$show_description = $instance['show_description'];
		
		$category = $instance['category'];
		
		$orderby = $instance['orderby'];
		
		// Display the widget when called
		
		echo $before_widget;
		
		echo '
		<div class="wpd-static-links">';
		
		if(isset($title) && $show_header && $title != '') {
			
			echo $before_title . $title . $after_title;
				
		}
	
		$args['category'] = $category;
		
		$args['orderby'] = $orderby;
		
		$args['title_li'] = 0;
		
		$args['categorize'] = 0;
		
		echo '
		<ul class="links-list static-links-category-'.$category.'';
		
		if ($wpd_options['wpd_display_staticlink_border'] == 'yes') {
			echo ' border';
		}
		
		echo '">';
		
		$link_insert = '';
		if ($wpd_options['wpd_display_newtab'] == 'yes') {
			$link_insert .= ' target="_blank"';
		}
		if ($wpd_options['wpd_display_nofollow'] == 'yes') {
			$link_insert .= ' rel="nofollow"';
		}
	
		$links = get_bookmarks($args);
		foreach ($links as $link) {
			echo '<li>';
			if (!empty($link->link_image)) {
				echo '<a href="' . $link->link_url . '"' . $link_insert . '><img src="' . $link->link_image . '" alt="' . $link->link_name . '" class="alignleft" width="'.$wpd_options['wpd_display_staticimgsize'].'"></a>';
			}
			echo' <a class="headline-link" href="' . $link->link_url . '"' . $link_insert . '>' . $link->link_name . '</a>';
			if (!empty($link->link_description) && $show_description == 'yes') {
				echo '<div class="link-content">' . $link->link_description . '</div>';
			}
			echo '
			</li>';	
		}
		
		echo '
		</ul>
		</div>';
	
		echo $after_widget;
			
	}
 
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;

		$widget_title = strip_tags($new_instance['title']);
		
		$instance['title'] = $widget_title;
		
		if ($widget_title == '') {
			
			global $wpdb;
			
			$query = "
			SELECT name
			FROM $wpdb->terms
			WHERE term_id = " . $new_instance['category'];
			
			$lc_name = $wpdb->get_results($query, 'ARRAY_A');
			
			$instance['title'] = $lc_name[0]['name'];
			
		}
		
		$instance['show_header'] = FALSE;
		
		if($new_instance['show_header'] == 'yes') {
		
			$instance['show_header'] = TRUE;
			
		} 
		
		$instance['show_description'] = $new_instance['show_description'];
	
		$instance['category'] = $new_instance['category'];
		
		$instance['orderby'] = $new_instance['orderby'];

		return $instance;

	}
 
	function form($instance) {
		
		$defaults = array(
			'title' => '',
			'show_header' => TRUE,
			'categories' => '',
			'show_description' => '0',
			'orderby' => 'name'
		);
		
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		?>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>" style="font-weight: bold">Title </label>
			<input type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="display: block; width: 100%" />
		</p>
        
        <p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'show_header' ); ?>" name="<?php echo $this->get_field_name( 'show_header' ); ?>" value="yes" <?php if ($instance['show_header'] == 'yes') { echo 'checked="checked"'; } ?>/>
            <label for="<?php echo $this->get_field_id( 'show_header' ); ?>" style="font-weight: bold">Show Title?</label>
		</p>
        
        <p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'show_description' ); ?>" name="<?php echo $this->get_field_name( 'show_description' ); ?>" value="yes" <?php if ($instance['show_description'] == 'yes') { echo 'checked="checked"'; } ?>/>
            <label for="<?php echo $this->get_field_id( 'show_description' ); ?>" style="font-weight: bold">Show Link Descriptions?</label>
		</p>
        
        <p>
        	
            <label for="<?php echo $this->get_field_id( 'category' ); ?>" style="font-weight: bold; margin: 0 0 10px; display: block">Category to display</label>
            <select id="<?php echo $this->get_field_id( 'category' ); ?>" name="<?php echo $this->get_field_name( 'category' ); ?>" style="width: 100%">
            <?php 
			$categories = get_categories(array (
			'type' => 'link',
			'hide_empty' => 0
			)); 
			
			foreach($categories as $category) { 
			?> 
            	<option value="<?php echo $category->term_id; ?>" <?php if ($instance['category'] == $category->term_id) { echo 'selected="selected"';} ?>><?php echo $category->name?></option>
            <?php
			}
			?>
            </select>
            <div style="clear: both"></div>
		</p>
        
        <p>
        	
            <label for="<?php echo $this->get_field_id( 'orderby' ); ?>" style="font-weight: bold; margin: 0 0 10px; display: block">Order by:</label>
            <select id="<?php echo $this->get_field_id( 'orderby' ); ?>" name="<?php echo $this->get_field_name( 'orderby' ); ?>" style="width: 100%">
            	<option value="name" <?php if ($instance['orderby'] == 'name') { echo 'selected="selected"';} ?>>Alphabetical</option>
                <option value="rating" <?php if ($instance['orderby'] == 'rating') { echo 'selected="selected"';} ?>>Rating</option>
                <option value="random" <?php if ($instance['orderby'] == 'random') { echo 'selected="selected"';} ?>>Random</option>
            </select>
            <div style="clear: both"></div>
		</p>
		
		<p style="padding: 6px 0;">
			<a class="help-box" href="http://wpdrudge.com/docs/widgets/static-links-widget" target="_blank">Help with this widget &raquo;</a>
		</p>
        
        
        <?php

	}
}

add_action( 'widgets_init', create_function('', 'return register_widget("drudge_column_links_widget");') );