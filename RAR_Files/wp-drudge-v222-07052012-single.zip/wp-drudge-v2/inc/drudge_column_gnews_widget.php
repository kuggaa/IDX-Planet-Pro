<?php 

class drudge_column_Gnews_widget extends WP_Widget {
	
	function drudge_column_Gnews_widget () {
		
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'drudge_col_gnews', 'description' => 'Displays a feed from Google News using keywords' );

		/* Create the widget. */
		$this->WP_Widget( 'drudge-column-gnews', 'WP-Drudge Google News Feed', $widget_ops);
	
	}
	 
	function widget($args, $instance) {
		
		global $post, $wpd_options;
		
		// Grab and save the existing $post object
		
		$post_orig = $post; 
		
		// Grab widget settings
		
		extract($args); 
		
		$title = apply_filters('widget_title', $instance['title']);
		$show_header = $instance['show_header'];
		
		$disable_cache = $instance['disable_cache'];
		$keyword = $instance['keyword'];
		$num_posts = $instance['num_posts'];
		$show_date = $instance['show_date'];
		
		// Build argument array for feed fetching function
		
		$feed_args = array(
			'get_date' => false,
			'items' => $num_posts
		);
		
		if ($disable_cache != 'yes') {
			$feed_args['enable_cache'] = true;
			$feed_args['cache_duration'] = (int)$wpd_options['wpd_display_feedcache'];
		}
		
		if ($show_date == 'yes') {
			$feed_args['get_date'] = true;
		}
		 
		// Build the keyword URL and pass the whole thing to the feed fetcher
		
		$gn_query = trim($keyword);
		$gn_query = str_replace(' ', '+', $gn_query);
		$feed_args['url'] = 'http://news.google.com/news?pz=1&cf=all&ned=us&hl=en&q='.$gn_query.'&cf=all&output=rss';
		
		$feed_content = wpd_fetch_rss($feed_args);
		
		$link_insert = '';
		if ($wpd_options['wpd_display_newtab'] == 'yes' && !is_page_template('template-page-mobile.php')) $link_insert .= ' target="_blank"';
		if ($wpd_options['wpd_display_nofollow'] == 'yes') $link_insert .= ' rel="nofollow"';
	
		
		// Display the widget when called
		
		echo $before_widget;
		
		echo '
		<div class="wpd-gnews-links">';
		
		
		
		if(isset($title) && $show_header) {
			
			echo $before_title . $title . $after_title;
				
		}
		
		if (is_array($feed_content) && count($feed_content) > 0) {
			
			echo '
			<ul class="gnews-links posts-list';
			
			if ($wpd_options['wpd_display_postedlink_border'] == 'yes') echo ' border';
		
			echo'">';
			
			foreach($feed_content as $item) :
				
				// Now we output the individual link
				echo '
				<li>
					<a href="' . $item['link'] . '" class="headline-link"' . $link_insert . '>'. $item['title'] . '</a>';
					
				if ($feed_args['get_date']) echo '<div class="link-content">' . $item['date'] . '</div>';
				
				echo '</li>';
		
			endforeach;
			
			echo '
			</ul>';

		} else {
			
			echo '<p><em>No items to show...</em></p>';
				
		}
		
		echo '
		</div>';

		echo $after_widget;
			
	}
 
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		// Formatting and storing the widget title

		$widget_title = strip_tags($new_instance['title']);
		
		if ($widget_title == '') {
			
			$instance['title'] = get_cat_name($new_instance['category']);
			
		} else {
		
			$instance['title'] = $widget_title;
			
		}
		
		// Should the title be displayed?
		
		if($new_instance['show_header'] == 'yes') {
		
			$instance['show_header'] = TRUE;
			
		} else {
			
			$instance['show_header'] = FALSE;
			
		}
		
		// Should the cache be disabled?
		
		$instance['disable_cache'] = $new_instance['disable_cache'];
		
		// Should the date be shown?
		
		$instance['show_date'] = $new_instance['show_date']; 
		
		// Keywords to pull from Google News
		
		$instance['keyword'] = $new_instance['keyword'];
		
		// Validating and storing the number of items to show
		
		$num_posts = trim(strip_tags($new_instance['num_posts']));
		if (!is_numeric($num_posts) || (int)$num_posts < 1 || (int)$num_posts > 20) {
			$instance['num_posts'] = 10;
		} else {
			$instance['num_posts'] = $num_posts;
		}

		return $instance;

	}
 
	function form($instance) {
		
		$defaults = array(
			'title' => 'Google News',
			'keyword' => '',
			'show_header' => 'yes',
			'num_posts' => get_option('posts_per_page'),
			'disable_cache' => '',
			'show_date' => ''
		);
		
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		?>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>" style="font-weight: bold">Title </label>
			<input type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="display: block; width: 100%" />
            <span style="font-size: 0.9em; font-weight: normal">(leave blank to use category name)</span>
		</p>
		
		<p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'show_header' ); ?>" name="<?php echo $this->get_field_name( 'show_header' ); ?>" value="yes" <?php if ($instance['show_header'] == 'yes') { echo 'checked="checked"'; } ?>/>
            <label for="<?php echo $this->get_field_id( 'show_header' ); ?>" style="font-weight: bold">Show Title?</label>
		</p>
        
        <p>
        	<label for="<?php echo $this->get_field_id( 'keyword' ); ?>" style="font-weight: bold;">Keyword or phrase</label>
        	<input type="text" id="<?php echo $this->get_field_id( 'keyword' ); ?>" name="<?php echo $this->get_field_name( 'keyword' ); ?>" value="<?php echo $instance['keyword']; ?>"  style="display: block; width: 100%"/>
            <span style="font-size: 0.9em; font-weight: normal">This phrase will pull stories from Google News.</span>
		</p>
        
        <p style="padding: 6px 0;">
        	<input type="text" id="<?php echo $this->get_field_id( 'num_posts' ); ?>" name="<?php echo $this->get_field_name( 'num_posts' ); ?>" value="<?php echo $instance['num_posts']; ?>" size="4"/>
			<label for="<?php echo $this->get_field_id( 'num_posts' ); ?>" style="font-weight: bold; margin-left: 10px"># of links to show (between 1 and 20)</label>
		</p>
		
		<p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" value="yes" <?php if ($instance['show_date'] == 'yes') { echo 'checked="checked"'; } ?>/>
            <label for="<?php echo $this->get_field_id( 'show_date' ); ?>" ><strong>Show date posted?</strong></label>
		</p>
		
        <p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'disable_cache' ); ?>" name="<?php echo $this->get_field_name( 'disable_cache' ); ?>" value="yes" <?php if ($instance['disable_cache'] == 'yes') { echo 'checked="checked"'; } ?>/>
            <label for="<?php echo $this->get_field_id( 'disable_cache' ); ?>" ><strong>Disable cache?</strong> See <a href="http://wpdrudge.com/docs/widgets/google-news-widget" target="_blank">docs</a> for more info.</label>
		</p>
		
		<p style="padding: 6px 0;">
			<a class="help-box" href="http://wpdrudge.com/docs/widgets/google-news-widget" target="_blank">Help with this widget &raquo;</a>
		</p>
        
        
        
        <?php

	}
}

add_action( 'widgets_init', create_function('', 'return register_widget("drudge_column_Gnews_widget");') );