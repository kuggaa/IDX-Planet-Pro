<?php
/***
Adding post meta fields to the posts
***/

$wpd_metas = array (
	'link' => array(
		'name' 			=> 'link',
		'title' 		=> 'Outbound link',
		'description' 	=> 'Enter a direct URL to a web page (must start with http)',
		'type'			=> 'text',
		'default'		=> isset($_GET['u']) ? esc_url($_GET['u']) : ''
	),
	
	'image' => array (
		'name' 			=> 'image',
		'title' 		=> 'Link image',
		'description' 	=> 'Enter a direct URL to an image (must start with http)',
		'type'			=> 'text',
		'default'		=> ''
	),
	
	'blurb' => array (
		'name' 			=> 'blurb',
		'title' 		=> 'Headline blurb',
		'description' 	=> 'Short blurb to be used on the homepage',
		'type'			=> 'textarea',
		'default'		=> ''
	),
	
	'use_blurb' => array (
		'name' 			=> 'use_blurb',
		'title' 		=> 'Blurb override',
		'description' 	=> 'Use this option to override the standard blurb/body content option. The "blurb" is the Headline Blurb text above and the "Body" is the content you add in the editor window under the title on this page. A "list" page is the homepage or category page, the post page is this items own page. <strong>Default is currently "'.get_key('wpd_display_blurbbody').'"</strong>',
		'type'			=> 'select',
		'options'		=> array(
			'' => 'Use default',
			'body text everywhere' => 'Use the body copy on all pages',
			'blurb text everywhere' => 'Use the blurb text on all pages',
			'blurb on list and body on post pages' => 'Use the blurb on list pages, body on post pages',
			'body on list and blurb on post pages' => 'Use the body on list pages, blurb on post pages',
		),
		'default'		=> ''
	),
	
	'color' => array (
		'name' 			=> 'color',
		'title' 		=> 'Link color',
		'description' 	=> 'New color for this link - current color shown',
		'type'			=> 'color',
		'default'		=> ''
	),
	
	'featured' => array (
		'name' 			=> 'featured',
		'title' 		=> 'Featured link',
		'description' 	=> 'Should this story be featured on the homepage',
		'type'			=> 'checkbox',
		'default'		=> ''
	),
	
	'border' => array (
		'name' 			=> 'border',
		'title' 		=> 'Show border',
		'description' 	=> 'Should this link have a border under it?',
		'type'			=> 'checkbox',
		'default'		=> ''
	),
	
	'no_link_text' => array (
		'name' 			=> 'no_link_text',
		'title' 		=> 'Hide link text',
		'description' 	=> 'Should the link text be hidden?',
		'type'			=> 'checkbox',
		'default'		=> ''
	),
	
);

function wpd_new_metas() {
	
	global $post, $wpd_metas;
	
	foreach ($wpd_metas as $meta) :
	
		$curr_value = get_post_meta($post->ID, $meta['name'], true);
		if ($curr_value == '') $curr_value = $meta['default'];
		
		echo '
		<div class="wpd-post-meta-box">
			<label for="'.$meta['name'].'">'.$meta['title'].'</label>';
		
		switch ($meta['type']) :
			
			case 'text':
				echo '
				<input type="text" class="text-field" name="'.$meta['name'].'_value" id="'.$meta['name'].'" value="'.$curr_value.'" />';
				break;
			
			case 'textarea':
				echo '
				<textarea name="'.$meta['name'].'_value" id="'.$meta['name'].'" cols="50" rows="4">'.$curr_value.'</textarea>';
				break;
			
			case 'select':
				echo '
				<select name="'.$meta['name'].'_value" id="'.$meta['name'].'">';
				
				foreach ($meta['options'] as $opk => $opv) :
					echo '<option value="'.$opk.'"';
					if ($opk == $curr_value) echo ' selected';
					echo '>'.$opv.'</option>';
				endforeach;
				
				echo '
				</select>';
				break;
			
			case 'checkbox':
				echo '<input type="checkbox" name="'.$meta['name'].'_value" id="'.$meta['name'].'" value="yes"'; 
				echo ($curr_value == 'yes' ? ' checked' : '' );
				echo '/>';
				break;
			
			case 'color':
				
				$curr_value_picker = $curr_value;
				if (empty($curr_value_picker)) $curr_value_picker = get_key('wpd_style_linkcolor');
				
				echo '
				<div data-color="'.$curr_value_picker.'" data-color-format="hex" class="input-append color" id="'.$meta['name'].'_contain">
					<input type="text" name="'.$meta['name'].'_value" id="'.$meta['name'].'" value="'.$curr_value.'" size="10" /> 
					<span class="add-on"><i style="background-color: ' . $curr_value_picker . '" class="color-sample"></i></span> &lArr; Pick a color
					<br style="clear: both" /><br />
				</div>
				
				<script src="' . get_bloginfo("template_url") . '/js/libs/bootstrap-colorpicker.js"></script>
				<script>
					jQuery("#'.$meta['name'].'_contain").colorpicker({
						format: "hex"
					});
				</script>
				';
				break;
		
		endswitch;
		
		echo ' 
		<span>'.$meta['description'].'</span>';
		
		echo'
		<input type="hidden" name="'.$meta['name'].'_noncename" id="'.$meta['name'].'_noncename" value="'.wp_create_nonce( 'wpdrudge' ).'" />
		</div>';
	
	endforeach;
	
	echo '<a class="help-box" href="http://wpdrudge.com/docs/adding-posted-links" target="_blank">Help adding posted links &raquo;</a>';
 
}
 
function wpd_create_metas() {
	
	if ( function_exists('add_meta_box') ) {
		add_meta_box( 'new-meta-boxes', 'WP-Drudge Fields', 'wpd_new_metas', 'post', 'normal', 'high' );
	}
 
}
 
function wpd_save_metas() {
	
	global $post, $wpd_metas;
	
	if (!empty($wpd_metas) && isset($post->post_type) && $post->post_type == 'post') :

		foreach($wpd_metas as $meta) {
			
			if ( !wp_verify_nonce( $_POST[$meta['name'].'_noncename'], 'wpdrudge' )) {
				return $post->ID;
			}
			
			if ( 'page' == $_POST['post_type'] ) {
				if ( !current_user_can( 'edit_page', $post->ID ))
					return $post->ID;
			} else {
				if ( !current_user_can( 'edit_post', $post->ID ))
					return $post->ID;
			}
			
			$new_data = isset($_POST[$meta['name'].'_value']) ? $_POST[$meta['name'].'_value'] : '';
			
			$curr_data = get_post_meta($post->ID, $meta['name'], true);
			
			if ( $new_data == '') {
				
				delete_post_meta($post->ID, $meta['name']);
				
			} elseif ($new_data != $curr_data) {
				
				update_post_meta($post->ID, $meta['name'], $new_data);
				
			}
		 
		}
	
	endif; 
	
}



add_action('admin_menu', 'wpd_create_metas');
add_action('save_post', 'wpd_save_metas');

/***
Set up meta information for Drudge posts

This function is used to grab and format all information needed to create posted links . Array options are:

- title: title text from the post
- link: URL for the post, internal or external
- link_insert: adds attributes to external links
- blurb: description post meta tag
- image_html: pre-constructed image HTML, linked and ready to go

***/

function get_drudge_metas($pid, $feat = false, $widget = false) {
	
	global $wpd_options;
	
	$wpdp = get_post($pid, 'OBJECT');
	
	$link['title'] = $wpdp->post_title;
	
	$link['link_insert'] = '';
	
	// Individual link color
	$link_color = get_post_meta($pid, 'color', true);
	if ($link_color != '') :
		if ($link_color[0] != '#') $link_color = '#' . $link_color;
		$link['link_insert'] .= ' style="color: ' . $link_color . '"';
	endif;
	
	// Link to an external page or the post on the site
	$link['link'] = $link['link_out'] = get_post_meta($pid, 'link', true);
	
	if ((!is_single() || $widget) && ($link['link'] == '' || $wpd_options['wpd_display_interrupt'] == 'yes')) :
		// If there is no link field for this post then we want to send users to the post page in the same tab
		$link['link'] = get_permalink($pid); 
	else :
		if ($wpd_options['wpd_display_newtab'] == 'yes' && !is_page_template('template-page-mobile.php')) $link['link_insert'] .= ' target="_blank"';
		if ($wpd_options['wpd_display_nofollow'] == 'yes') $link['link_insert'] .= ' rel="nofollow"';
	endif;
	
	// Should the link text be hidden? Set for each link
	$no_link_text = get_post_meta($pid, 'no_link_text', true);
	
	if ($no_link_text != 'yes') 
		$link['link_html'] = '<a href="' . $link['link'] . '"' . $link['link_insert']. ' class="headline-link">' . $link['title'] . '</a>';
	else 
		$link['link_html'] = '';	
	
	
	/*
	Blurb text/HTML
	*/
	$link['blurb'] = '';
	
	// Grabbing the blurb override option from the post metas
	$use_blurb = get_post_meta($pid, 'use_blurb', true);
	
	// If no override is found, use the current option
	if (empty($use_blurb))
		$use_blurb = $wpd_options['wpd_display_blurbbody'];
	
	$content_body = apply_filters('the_content', $wpdp->post_content);
	$content_meta = wpautop(get_post_meta($pid, 'blurb', true));
	
	switch ($use_blurb) :
		
		case 'blurb text everywhere' :
			$link['blurb_text'] = $content_meta;
			break;
		
		case 'body text everywhere' :
			$link['blurb_text'] = apply_filters('the_content', $wpdp->post_content);
			break;
		
		case 'blurb on list and body on post pages' :
			if (is_single() && !$widget) $link['blurb_text'] = $content_body;
			else $link['blurb_text'] = $content_meta;
			break;
			
		case 'body on list and blurb on post pages' :
			if (is_single() && !$widget) $link['blurb_text'] = $content_meta;
			else $link['blurb_text'] = $content_body;
			break;
		
	endswitch;
	
	if (!empty($link['blurb_text'])) 
		$link['blurb'] = '<div class="the-content link-content">' . $link['blurb_text'] . '</div>';

	if ($wpd_options['wpd_display_comlink'] == 'yes' && $wpdp->comment_status == 'open' && !is_single()) 
		$link['blurb'] .= '<p class="link-content"><a href="' . get_permalink($pid) . '#the-comments" class="comment-link">Comments</a></p>';
	
	
	/*
	Image and HTML
	*/
	
	// If this is a mobile page template, we check the options to see if images should be excluded 
	if (!is_page_template('template-page-mobile.php') || (is_page_template('template-page-mobile.php') && $wpd_options['wpd_mobile_imagegone'] != 'yes') ) :
		
		$link['image'] = get_post_meta($pid, 'image', true);
		
		If (empty($link['image']) && has_post_thumbnail($pid)) {
			$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($pid), 'medium');
			if ($thumb)	$link['image'] = $thumb[0];
		}
		
	endif;
	
	// If we've got an image stored, we need to build the HTML for display
	$link['image_html'] = '';
	if (!empty($link['image']) && (!is_single() || (is_single() && $wpd_options['wpd_display_singleimage'] != 'no'))) :
		
		$img_insert = '';
		
		// If this is a featured link and it's set to display at the top, middle, or bottom, center the image
		if ($feat) :
		
			if ($wpd_options['wpd_display_fimage'] == 'above' || $wpd_options['wpd_display_fimage'] == 'below middle' || $wpd_options['wpd_display_fimage'] == 'bottom') :
				$img_insert = ' class="aligncenter"';
			elseif ( $wpd_options['wpd_display_fimage'] == 'below left' ) :
				$img_insert = ' class="alignleft"';
			elseif ( $wpd_options['wpd_display_fimage'] == 'below right' ) :
				$img_insert = ' class="alignright"';
			endif;
			
		elseif (is_single() && !$widget):
			
			switch ($wpd_options['wpd_display_singleimage']) :
				case 'top middle' : 
					$img_insert = ' class="aligncenter"'; break;
				case 'top left' : 
					$img_insert = ' class="alignleft"'; break;
				case 'top right' : 
					$img_insert = ' class="alignright"'; break;
			endswitch;
		
		endif;
		
		// Set the width based on the theme settings
		$width = $feat ? $wpd_options['wpd_style_featimgsize'] : $wpd_options['wpd_style_postimgsize'];
		$img_insert .= ' width="' . $width . '"';
		
		// This builds the HTML for the image link
		$link['image_html'] = '
		<img src="' . $link['image'] . '" alt="' . $wpdp->post_title . '" ' . $img_insert . '>';
		
		if (is_single() && !$widget && !empty($link['link_out'])) 
			$link['image_html'] = '<a href="' . $link['link_out'] . '"' . $link['link_insert'] . '>' . $link['image_html'] . '</a>';
		else
			$link['image_html'] = '<a href="' . $link['link'] . '"' . $link['link_insert'] . '>' . $link['image_html'] . '</a>';
			
	endif;
	
	// Getting the border preference for this individual link
	$link['class_insert'] = '';
	if ($wpd_options['wpd_display_postedlink_border'] != 'yes') :
		
		$the_border = get_post_meta($pid, 'border', true);
		if (isset($the_border) && $the_border == 'yes') 
			$link['class_insert'] = ' border';
			
	endif;
	
	do_action('wpd_hook_posted_link_process', $link);
	
	return $link;
	
}

function wpdrudge_echo_featured() {
	
	// We need some of the WP-Drudge options to construct this block
	global $wpd_options;
	
	// All pages that don't display the featured link
	if (is_single() || is_404() || is_author() || is_attachment() || is_search() ) return false;
	
	// Mobile template pages need to check the options to determine if a featured image should display
	// if (is_page_template('template-page-mobile.php') && $wpd_options['wpd_mobile_featured'] != 'yes') return false;
	
	// Only show on pages with the WP-Drudge page template active
	if (is_page() && (!is_page_template('template-page-wpdrudge.php') || $wpd_options['wpd_display_featonwpd'] != 'displayed') && (!is_page_template('template-page-mobile.php') || $wpd_options['wpd_mobile_featured'] != 'yes')) return false;
		
	// Only need 1 post and we're only looking for posts that have been set as featured
	$args = array(
		'posts_per_page' => 1,
		'meta_key' => 'featured',
		'meta_value' => 'yes',
		'ignore_sticky_posts' => 1
	);
	
	if (is_date() && $wpd_options['wpd_display_featondate'] != 'yes') :
		 return false;
	endif; 
	
	if (is_category() || is_tag()) {
		
		if ($wpd_options['wpd_display_featoncat'] == 'not displayed') {
			
			return false;
			
		} elseif (is_category() && $wpd_options['wpd_display_featoncat'] == 'display category featured') {
			
			global $wp_query;
			$cat_ID = get_query_var('cat');
			if (!empty($cat_ID)) $args['cat'] = $cat_ID;
			else return false;
			
		} elseif (is_tag() && $wpd_options['wpd_display_featoncat'] == 'display category featured') {
			
			global $wp_query;
			$tag_ID = get_query_var('tag');
			if (!empty($tag_ID)) $args['tag'] = $tag_ID;
			else return false;
			
		}
	}
	
	$feat_query = new WP_Query($args); 
		
	if ($feat_query->have_posts()) : 
		
		$feat_html = '
		<div id="featured">';
    
    	while($feat_query->have_posts()) :
		
			$feat_query->the_post();
			
			$curr_link = get_drudge_metas(get_the_ID(), true);
			
			// This is set so the links below do not display the featured link duplicated
			define('CURRENT_FEATURED_POST', get_the_ID()); 
		
			$display_fimage = $wpd_options['wpd_display_fimage'];
			
			if ($display_fimage == 'above' && $curr_link['image_html']) {
				$feat_html .= $curr_link['image_html'];
			}
			
			$feat_html .= '
			<h2>'.$curr_link['link_html'].'</h2>';
			
			if (($display_fimage == 'below left' || $display_fimage == 'below right' || $display_fimage == 'below middle') && $curr_link['image_html']) {
				$feat_html .= $curr_link['image_html'];
			}
			
			$feat_html .= $curr_link['blurb'];
			
			if ($display_fimage == 'bottom' && $curr_link['image_html']) {
				$feat_html .= $curr_link['image_html'];
			}
			
			
		endwhile;
		
		$feat_html .= '
			<div class="clear"></div>
			</div>';
		
		do_action('wpd_hook_featured_link_process', $feat_html);
		
		echo $feat_html;
		
	endif; 
	
	wp_reset_query();

}


/*
Detecting mobile users and cookie preferences
*/

function wpd_mobile_routing() {
	
	// Setting a global array that contains display info for this user
	global $wpd_mobile_info, $cookie_name;
	
	// This array determines what we're going to do with this visitor, if anything
	$wpd_mobile_info = array(
		// Grabs the current user agent to check below
		'user_agent' => $_SERVER['HTTP_USER_AGENT'],
		// Using the info above, is this a mobile UA?
		'mobile_ua' => 0,
		// This stops the prompt for being displayed at all
		'kill_prompt' => 0,
		// Over-ridden by the above setting, just hides the prompt
		'hide_prompt' => 0,	
		// Should the user be redirected to the mobile site?	
		'mobile_default' => 0,
		// Are we on a mobile template page?
		'mobile_page_tpl' => 0
	);
	
	// Checks the page template to see if we're using the mobile display
	if (is_page_template('template-page-mobile.php')) $wpd_mobile_info['mobile_page_tpl'] = 1;
	
	// No need to show a prompt if there is no mobile site
	if (! get_key('wpd_mobile_uselink')) $wpd_mobile_info['kill_prompt'] = 1;
	
	// No need to show a prompt if mobiles are automatically routed
	
	if (get_key('wpd_mobile_redirect') == 'automatic redirect' && $wpd_mobile_info['mobile_ua']) $wpd_mobile_info['kill_prompt'] = 1;
	
	// Need to set a unique cookie for this site ... the blog name seems like the most likely candidate
	$site_name = strtolower(preg_replace( "/[^a-zA-Z0-9]/i", "", get_bloginfo('name')));
	$cookie_name = $site_name . '_wpdrudge_mobile_settings';
	
	// Checking the WPD mobile site cookie
	if (isset($_COOKIE[$cookie_name])) :
	
		$wpd_mobile_cookie = jch_cookie_bite($_COOKIE[$cookie_name]);
		
		if (isset($wpd_mobile_cookie['no_prompt']) && $wpd_mobile_cookie['no_prompt'] == 1) $wpd_mobile_info['kill_prompt'] = 1;
		if (isset($wpd_mobile_cookie['mobile_default']) && $wpd_mobile_cookie['mobile_default'] == 1) $wpd_mobile_info['mobile_default'] = 1;
	
	endif;
	
	// From http://detectmobilebrowsers.com, set 6/26/2012
	// We're looking for user agents that are associated with mobile devices
	if(
		preg_match('/android.+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $wpd_mobile_info['user_agent']) || 
		preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($wpd_mobile_info['user_agent'],0,4))) :
		$wpd_mobile_info['mobile_ua'] = 1;
	endif;
	
	// If someone wants to hide the banner, this sets the cookie to make sure it goes away
	if (isset($_REQUEST['wpdm'])):
		if ($_REQUEST['wpdm'] == 'no') :
			$wpd_mobile_info['kill_prompt'] = $wpd_mobile_cookie['no_prompt'] = 1;
		elseif ($_REQUEST['wpdm'] == 'yes') :
			$wpd_mobile_info['kill_prompt'] = $wpd_mobile_cookie['no_prompt'] = 0;
		elseif ($_REQUEST['wpdm'] == 'def') :
			$wpd_mobile_info['mobile_default'] = $wpd_mobile_cookie['mobile_default'] = 1;
		elseif ($_REQUEST['wpdm'] == 'nodef') :
			$wpd_mobile_info['mobile_default'] = $wpd_mobile_cookie['mobile_default'] = 0;
		endif;
	endif;
	
	
	// But, if the settings have changed, we want to over-ride the cookie. Settings > cookie here
	
	// Checking the mobile UA redirect settings, the user agent, and whether a redirect link is stored
	// If these all add up, we redirect to the indicated mobile page
	if ( is_home() &&
	// If the user has a cookie to default to mobile, then redirect if we're not already on a mobile page
	($wpd_mobile_info['mobile_default'] || 
	// Otherwise, check if auto-redirect is on and the user has a mobile UA
	(get_key('wpd_mobile_redirect') == 'automatic redirect' && $wpd_mobile_info['mobile_ua']))
	) :
		 $wpd_mobile_cookie['no_prompt'] = 1;
		wp_redirect( get_key('wpd_mobile_uselink') );
		exit;
	endif;
	
	// If there is a "no prompt" cookie, then do not display the prompt
	if (! $wpd_mobile_info['kill_prompt']) :
		
		// If all the settings add up to not displaying the prompt, make sure it doesn't
		if (
		( get_key('wpd_mobile_redirect') == 'do nothing' && $wpd_mobile_info['mobile_ua'] == 1 ) ||
		( get_key('wpd_mobile_allscreen') != 'yes' && $wpd_mobile_info['mobile_ua'] == 0 )
		) :
		
			// If small screens get to see the prompt then we want to hide it rather than killing it altogether
			if (get_key('wpd_mobile_smscreen') == 'yes') $wpd_mobile_info['hide_prompt'] = 1;
			else $wpd_mobile_info['kill_prompt'] = 1;
			
		endif;
		// Otherwise, we need to check screen size
		
	endif;
	
	// If we have cookie values to store, need to rebuild the cookie
	if (!empty($wpd_mobile_cookie)) : 
		$cookie_content = jch_cookie_bake($wpd_mobile_cookie);
		setcookie($cookie_name, $cookie_content, time()+60*60*24*90, '/', '');
	// If the cookie is empty but it was set before, we want to unset it if nothing needs to be stored
	elseif (isset($_COOKIE[$cookie_name])) :
		setcookie($cookie_name, '', time() - 60 * 60 * 24 * 90, '/', '');
	endif;
	
}

add_action('template_redirect', 'wpd_mobile_routing');


function wpd_display_mobile_prompt() {
		
	global $wpd_mobile_info;
	
	$output = '';
	
	// Build the current link to make sure the defaut
	$curr_link =  $_SERVER['REQUEST_URI'];
	if (stripos($curr_link, '?') === false) $curr_link .= '?';
	else $curr_link .= '&amp;';
	
	
	// Get the text to output, depending on where we are
	$banner_text = get_key('wpd_mobile_bannertxt');
	
	// HTML link that will be displayed, depending on current location
	$goto_link = '<a href="' . get_key('wpd_mobile_uselink') . '">&rarr; Go to the mobile site</a>';
	
	// HTML default link and text, only displayed on the mobile site
	$set_default = '';
	
	if (get_key('mobile_page_tpl', 'wpd_mobile_info')) :
	
		$banner_text = 'You are currently viewing our mobile page';
		
		if (get_key('mobile_default', 'wpd_mobile_info')) :
			$goto_link = '';
			$set_default = ' <a href="' . $curr_link . 'wpdm=nodef">[x] Unset as default</a>';
		else :
			$goto_link = ' <a href="' . get_bloginfo('url') . '">&larr; Back home</a>';
			$set_default = ' <a href="' . $curr_link . 'wpdm=def">[&#x2713;] Set as default</a>';
		endif;
		
	endif;
	
	if (! get_key('kill_prompt', 'wpd_mobile_info')) :
	
		$style_insert = '';
		if (get_key('hide_prompt', 'wpd_mobile_info') && !get_key('mobile_page_tpl', 'wpd_mobile_info')) $style_insert = ' style="display: none"';
		
		/*
		"Hide this" link sets a cookie to suppress this prompt in the future
		*/
		$output .= '
		<div id="wpd-mobile-banner"' . $style_insert . '>
			<p>' . $banner_text . ' <br> ' . $goto_link . $set_default . '<a href="' . $curr_link . 'wpdm=no">[x] Hide this</a></p>
		</div>';

	endif;
	
	return $output;
}