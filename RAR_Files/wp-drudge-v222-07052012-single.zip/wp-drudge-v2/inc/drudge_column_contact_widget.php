<?php 

class drudge_column_contact_widget extends WP_Widget {
	
	function drudge_column_contact_widget () {
		
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'drudge_col_contact', 'description' => 'Adds a submission box for quick contacts' );

		/* Create the widget. */
		$this->WP_Widget( 'drudge-column-contact', 'WP-Drudge Contact Box', $widget_ops);
	
	}
	 
	function widget($args, $instance) {
		
		global $post, $wpd_options;
		
		// Grab widget settings and nonce
		extract($args);
		extract($instance); 
		
		// Display the widget when called
		echo $before_widget . '
		<div class="wpd-contact-widget';
		if ($wpd_options['wpd_display_postedlink_border'] == 'yes') echo ' border';
		echo'">';
		
		if (isset($title) && $show_header) echo $before_title . $title . $after_title;		
		
		//If the form is submitted
		if(!empty($_POST['submit_type'])) include(TEMPLATEPATH . '/inc/process-contact.php');
		 
		//If the email was sent, show "thank you"
		if(isset($email_sent) && $email_sent === true) :
		
			echo '<p class="link-content success">' . $text_thanks . '</p>';
		
		//If the email was not sent, show the form
		else :
		
			echo '<p class="link-content">' . $text_prompt . '</p>';
			
			if (isset($errors) && count($errors) !== 0) :
				echo '<ul class="error-box links-list link-content">';
				foreach ($errors as $er) :
					echo '<li>&raquo; ' . $er . '</li>';
				endforeach;
				echo '</ul>';
			endif;
		?>
		
		<form class="wpd-contact" enctype="multipart/form-data" method="post" action="#<?php echo $widget_id ?>">
			<?php if ($request_email == 'yes') : ?>
			<p class="link-content">
				<label for="from_email">Email address <strong>*</strong></label>
				<input type="email" class="text-field"  name="from_email" id="from_email" value="<?php if(isset($_POST['from_email'])) echo $_POST['from_email'];?>">
				<input type="hidden" name="email_required" value="yes">
			</p>
			<?php endif; ?>
			<p class="link-content">
				<label for="from_message">Message <strong>*</strong></label>
				<textarea name="from_message" id="from_message" class="text-field" cols="30" rows="4"><?php if(isset($_POST['from_message'])) echo $_POST['from_message'];?></textarea>
			</p>
			<?php 
			if ($show_math == 'yes') : 
				$math1 = mt_rand(1, 10);
				$math2 = mt_rand(1, 10);
				$math_total_bin = decbin($math1 + $math2);
			?>
			<p class="inline-field link-content">
				<input type="text" value="" id="math_input" name="math_input">
				<label for="math_input">What is <?php echo $math1 ?> + <?php echo $math2 ?>?</label>
				<input type="hidden" name="math_gotcha" value="<?php echo $math_total_bin ?>">
			</p>
			<?php endif; ?>
			<p class="hidden">
				<label for="honeypot">Leave this empty to submit:</label>
				<input type="text" name="honeypot" id="honeypot" value="">
			</p>
			<p>
				<input type="hidden" name="submit_type" value="widget">
				<input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wp-drudge-nonce') ?>">
				<input type="submit" id="form_submit" value="Contact &raquo;">
			</p>
		</form>
		
		<?php
		
		endif;
		
		echo '
		</div>' . $after_widget;
			
	}
 
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		// Formatting and storing the widget title

		$instance['title'] = strip_tags(trim($new_instance['title']));
		$instance['show_header'] = $new_instance['show_header'];
		$instance['show_math'] = $new_instance['show_math']; 
		$instance['contact_email'] = trim($new_instance['contact_email']); 
		$instance['request_email'] = $new_instance['request_email'];	
		$instance['text_prompt'] = trim($new_instance['text_prompt']);	
		$instance['text_thanks'] = trim($new_instance['text_thanks']);	

		return $instance;

	}
 
	function form($instance) {
		
		$defaults = array(
			'title' => 'Contact Us',
			'show_header' => 'yes',
			'show_math' => 'yes',
			'contact_email' => get_bloginfo('admin_email'),
			'request_email' => '',
			'text_prompt' => 'Submit the form below to send us a lead!',
			'text_thanks' => 'Thank you for the contact; we\'ll be in touch soon!'
		);
		
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		?>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>" style="font-weight: bold">Title </label>
			<input type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="display: block; width: 100%">
		</p>
		
		<p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'show_header' ); ?>" name="<?php echo $this->get_field_name( 'show_header' ); ?>" value="yes" <?php if ($instance['show_header'] == 'yes') { echo 'checked="checked"'; } ?>>
            <label for="<?php echo $this->get_field_id( 'show_header' ); ?>" style="font-weight: bold">Show Title?</label>
		</p>
		
		<p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'contact_email' ); ?>" style="display: block; width: 100%">Email to send submissions to</label>
        	<input type="email" id="<?php echo $this->get_field_id( 'contact_email' ); ?>" name="<?php echo $this->get_field_name( 'contact_email' ); ?>" value="<?php echo $instance['contact_email']; ?>" style="display: block; width: 100%">
			
		</p>
		
		<p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'text_prompt' ); ?>" style="display: block; width: 100%">Prompt text above form:</label>
        	<textarea id="<?php echo $this->get_field_id( 'text_prompt' ); ?>" name="<?php echo $this->get_field_name( 'text_prompt' ); ?>" style="display: block; width: 100%"><?php echo $instance['text_prompt']; ?></textarea>
		</p>
		
		<p style="padding: 6px 0;">
			<label for="<?php echo $this->get_field_id( 'text_thanks' ); ?>" style="display: block; width: 100%">"Thank you" text after form is submitted:</label>
        	<textarea id="<?php echo $this->get_field_id( 'text_thanks' ); ?>" name="<?php echo $this->get_field_name( 'text_thanks' ); ?>" style="display: block; width: 100%"><?php echo $instance['text_thanks']; ?></textarea>
		</p>
		
		<p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'show_math' ); ?>" name="<?php echo $this->get_field_name( 'show_math' ); ?>" value="yes" <?php if ($instance['show_math'] == 'yes') { echo 'checked="checked"'; } ?>>
            <label for="<?php echo $this->get_field_id( 'show_math' ); ?>" ><strong>Show math captcha?</strong> This can help to reduce spam</label>
		</p>
		
		<p style="padding: 6px 0;">
			<input type="checkbox" id="<?php echo $this->get_field_id( 'request_email' ); ?>" name="<?php echo $this->get_field_name( 'request_email' ); ?>" value="yes" <?php if ($instance['request_email'] == 'yes') { echo 'checked="checked"'; } ?>>
            <label for="<?php echo $this->get_field_id( 'request_email' ); ?>" ><strong>Should the submittor's email be required?</strong></label>
		</p>
		
		<p style="padding: 6px 0;">
			<a class="help-box" href="http://wpdrudge.com/docs/widgets/contact-widget" target="_blank">Help with this widget &raquo;</a>
		</p>
        
	
        
        <?php

	}
}

add_action( 'widgets_init', create_function('', 'return register_widget("drudge_column_contact_widget");') );