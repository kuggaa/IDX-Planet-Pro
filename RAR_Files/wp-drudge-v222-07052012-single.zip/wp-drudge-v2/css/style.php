<?php 
	
	$all_css = '';
	
	// Setting proper cache-able CSS
	
	$offset = 262800 ;
	
	header('Content-type: text/css');
	header('Cache-Control: public, max-age=' . $offset);
	$ExpStr = "Expires: " . gmdate("D, d M Y H:i:s", time() + $offset) . " GMT";
	header($ExpStr);
	
	// Importing main stylesheet
	
	$cssfile_main = TEMPLATEPATH . '/css/main.css';
	$fh = fopen($cssfile_main, 'r');
	$css_contents_main =  fread($fh, filesize($cssfile_main));
	fclose($fh);
	$all_css .= $css_contents_main;
	
	$wpd_options = get_option('wpdrudge_settings_array');
	
	if ($wpd_options['wpd_style_bgcolor'][0] != '#') $wpd_options['wpd_style_bgcolor'] = '#' . $wpd_options['wpd_style_bgcolor'];
	if ($wpd_options['wpd_style_wrapcolor'][0] != '#') $wpd_options['wpd_style_wrapcolor'] = '#' . $wpd_options['wpd_style_wrapcolor'];
	if ($wpd_options['wpd_style_menubgcolor'][0] != '#') $wpd_options['wpd_style_menubgcolor'] = '#' . $wpd_options['wpd_style_menubgcolor'];
	if ($wpd_options['wpd_style_navlinkcolor'][0] != '#') $wpd_options['wpd_style_navlinkcolor'] = '#' . $wpd_options['wpd_style_navlinkcolor'];
	if ($wpd_options['wpd_style_headcolor'][0] != '#') $wpd_options['wpd_style_headcolor'] = '#' . $wpd_options['wpd_style_headcolor'];
	if ($wpd_options['wpd_style_linkcolor'][0] != '#') $wpd_options['wpd_style_linkcolor'] = '#' . $wpd_options['wpd_style_linkcolor'];
	if ($wpd_options['wpd_style_vlinkcolor'][0] != '#') $wpd_options['wpd_style_vlinkcolor'] = '#' . $wpd_options['wpd_style_vlinkcolor'];
	if ($wpd_options['wpd_style_textcolor'][0] != '#') $wpd_options['wpd_style_textcolor'] = '#' . $wpd_options['wpd_style_textcolor'];

	// Styles from the admin options screen
	
	$all_css .= '
body {font-family: '. wpd_font_stack($wpd_options['wpd_style_linkfont']) . '; background-color: '.$wpd_options['wpd_style_bgcolor'].'; color: '.$wpd_options['wpd_style_textcolor'].'}';
	
	$all_css .= '
	#wrapper, #mobile-wrapper {background-color: '.$wpd_options['wpd_style_wrapcolor'].';}';
	
	$all_css .= '
	#wrapper {';
	
	switch ( $wpd_options['wpd_display_layout'] )  {
		case 'fixed' : 
			$all_css .= 'width: 920px;';
			break;
		case 'fluid (full)' : 
			$all_css .= 'min-width: 500px;';
			break;
		case 'fluid (partial)' : 
			$all_css .= 'width: 80%; min-width: 500px;';
			break;	
	}
	$all_css .= '}';

	
	switch ( $wpd_options['wpd_style_colborder'] )  {
		case 'light' : 
			$all_css .= '
		#column-1, #column-2 {border-right: 1px solid #eee;}';
			break;
			
		case 'medium' : 
			$all_css .= '
		#column-1, #column-2 {border-right: 1px solid #bbb;}';
			break;
			
		case 'dark' : 
			$all_css .= '
		#column-1, #column-2 {border-right: 1px solid #222;}';
			break;	
	}

	$all_css .= '
		a {color: '.$wpd_options['wpd_style_linkcolor'].'}';
	
	$all_css .= '
		a:visited {color: '.$wpd_options['wpd_style_vlinkcolor'].'}';
	
	$all_css .= '
		#header .header-nav a  {color: '.$wpd_options['wpd_style_navlinkcolor'].'}';
	
	$all_css .= '
		.header-nav li, #menu-main-nav {background-color: '.$wpd_options['wpd_style_menubgcolor'].'; font-size: '.$wpd_options['wpd_style_navsize'].'px}';

	$all_css .= '
		#menu-main-nav li {border-right: '.$wpd_options['wpd_style_wrapcolor'].' 2px solid}';
	
	$all_css .= '
		h2.widget-head  {color: '.$wpd_options['wpd_style_headcolor'].'; font-size: '.$wpd_options['wpd_style_headsize'].'px;';
	if ( $wpd_options['wpd_style_headbold'] == 'yes' ) {
		$all_css .= '
		font-weight: bold; ';
	} else {
		$all_css .= '
		font-weight: normal; ';
	}
	$all_css .= '}';
	
	$all_css .= '
		a.headline-link, .link-column .cat-item a {font-size: '.$wpd_options['wpd_style_linksize'].'px;}';	
	if ( $wpd_options['wpd_style_linkstyle'] == 'yes' ) {
			$all_css .= '.link-col a {text-decoration: underline}
		#featured a {text-decoration: underline}
		.link-col a:hover, #featured a:hover {text-decoration: none}';
	} else { 
		$all_css .= '.link-col a, #featured a {text-decoration: none}
		.link-col a:hover, #featured a:hover {text-decoration: underline}';
	}
		
	
	
	if ( $wpd_options['wpd_style_linkbold'] == 'yes' ) {
			$all_css .= "
		a.headline-link {font-weight: bold}
		.links-list a {font-weight: bold}";
	}
	
	
	$all_css .= '
		.the-content, .the-content .link-content, #the-comments {font-size: '.$wpd_options['wpd_style_pagesize'].'px}';
	
	$all_css .= '
		.link-col .link-content, a.comment-link, #featured p, .textwidget {font-size: '.$wpd_options['wpd_style_descsize'].'px}';
	
	$all_css .= '
		#main-content h1, #main-content h2, #main-content h3, #main-content h4, #main-content h5, #main-content h6, .home-link, .post-navigation, #logo-or-name {font-family:'. wpd_font_stack($wpd_options['wpd_style_headfont']) . '}';
	
	$all_css .= '
		#wrapper #featured, #wrapper #featured h2, #wrapper #featured p 
		#mobile-wrapper #featured, #mobile-wrapper #featured h2, #mobile-wrapper #featured p {font-family: '. wpd_font_stack($wpd_options['wpd_style_featfont']) . '}';
	
	
	if ( $wpd_options['wpd_display_fimage'] == 'below left' || $wpd_options['wpd_display_fimage'] == 'below right' ) {
		$all_css .= '
		#wrapper #featured p, #mobile-wrapper #featured p {text-align: left}';
	} elseif ( $wpd_options['wpd_display_fimage'] == 'below middle' || $wpd_options['wpd_display_fimage'] == 'above' || $wpd_options['wpd_display_fimage'] == 'bottom' ) {
		$all_css .= '
		#wrapper #featured .link-content, #mobile-wrapper #featured .link-content {text-align: center}';
	}
	
	$all_css .= '
		#featured a.headline-link {font-size: '.$wpd_options['wpd_style_feat_size'].'px}';
	
	
	switch ($wpd_options['wpd_style_boxborder']) {
		
		case 'light':
			$all_css .= '
	.widget-box {border-bottom: 1px solid #eee;}';
			break;
			
		case 'medium':
			$all_css .= '
	.widget-box {border-bottom: 1px solid #bbb;}';
			break;
		
		case 'dark':
			$all_css .= '
	.widget-box {border-bottom: 1px solid #222;}';
			break;
	}
	
	switch ($wpd_options['wpd_style_linkborder']) {
		
		case 'light':
			$all_css .= '
	.posts-list li.border, ul.border li, .commentlist li {border-bottom: 1px solid #eee;}';
			break;
			
		case 'medium':
			$all_css .= '
	.posts-list li.border, ul.border li, .commentlist li {border-bottom: 1px solid #bbb;}';
			break;
		
		case 'dark':
			$all_css .= '
	.posts-list li.border, ul.border li, .commentlist li {border-bottom: 1px solid #222;}';
			break;
	}
	
	// Creating border lines that are darker enough to be seen against another color background
	// Used for the post pages comments section
	
	$wpd_style_wrapcolor = $wpd_options['wpd_style_wrapcolor'];
	if ($wpd_style_wrapcolor[0] == '#') $wpd_style_wrapcolor = substr($wpd_style_wrapcolor, 1);
	
	$curr_color_rgb = hex2RGB($wpd_style_wrapcolor);
	
	$curr_color_rgb['red'] = $curr_color_rgb['red'] - 20;
	if ($curr_color_rgb['red'] < 0) $curr_color_rgb['red'] = 0;
	$curr_color_rgb['green'] = $curr_color_rgb['green'] - 20;
	if ($curr_color_rgb['green'] < 0) $curr_color_rgb['green'] = 0;
	$curr_color_rgb['blue'] = $curr_color_rgb['blue'] - 20;
	if ($curr_color_rgb['blue'] < 0) $curr_color_rgb['blue'] = 0;
	$form_color_bg = 'rgb('. $curr_color_rgb['red'] . ',' . $curr_color_rgb['green'] . ',' . $curr_color_rgb['blue'] . ')';
	
	$curr_color_rgb['red'] = $curr_color_rgb['red'] - 40;
	if ($curr_color_rgb['red'] < 0) $curr_color_rgb['red'] = 0;
	$curr_color_rgb['green'] = $curr_color_rgb['green'] - 40;
	if ($curr_color_rgb['green'] < 0) $curr_color_rgb['green'] = 0;
	$curr_color_rgb['blue'] = $curr_color_rgb['blue'] - 40;
	if ($curr_color_rgb['blue'] < 0) $curr_color_rgb['blue'] = 0;
	$form_color_border = 'rgb('. $curr_color_rgb['red'] . ',' . $curr_color_rgb['green'] . ',' . $curr_color_rgb['blue'] . ')';
	
	$all_css .= '
	#respond {background-color: ' . $form_color_bg . '; border: 1px solid ' . $form_color_border . '}
	#commentform input[type=text], #commentform textarea {border: 1px solid ' . $form_color_border . '}
	#the-comments {border-top: 1px solid ' . $form_color_border . '}';
	
	// Importing styles for spacious or tight spacing if not mobile
	
	if ($wpd_options['wpd_display_spacing'] != 'medium') {	
		$cssfile_spacing = TEMPLATEPATH . '/css/spacing-' . $wpd_options['wpd_display_spacing'] . '.css';
		$fh = fopen($cssfile_spacing, 'r');
		$css_contents_spacing =  fread($fh, filesize($cssfile_spacing));
		fclose($fh);
		$all_css .= '
		
		' . $css_contents_spacing;
	}
	
	//  Responsive CSS for small screens
	
	if ($wpd_options['wpd_mobile_responsive'] == 'yes') {
		$cssfile_resp = TEMPLATEPATH . '/css/responsive.css';
		$fh = fopen($cssfile_resp, 'r');
		$css_contents_resp =  fread($fh, filesize($cssfile_resp));
		fclose($fh);
		$all_css .= $css_contents_resp;
	}

	// Retrieve and display additional CSS entered on the config page
	$all_css .= '
/** WP-Drudge custom CSS **/

' . stripslashes($wpd_options['wpd_style_morecss']);

	// Compressing CSS
	
	$all_css = str_replace('; ', ';', $all_css);	
	$all_css = str_replace(': ', ':', $all_css);	
	$all_css = str_replace(';}', '}', $all_css);
	$all_css = str_replace("\n", ' ', $all_css);	
	$all_css = str_replace("\r", ' ', $all_css);	
	$all_css = str_replace('	', '', $all_css);	
	
	echo $all_css;