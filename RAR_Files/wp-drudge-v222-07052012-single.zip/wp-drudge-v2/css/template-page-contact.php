<?php
//If the form is submitted
if(isset($_POST['nonce'])) include ('includes/process-contact.php');
?>
<?php 

/*
Template Name: Contact page
*/

get_header(); ?>
    
	<div class="content-full contact-page" id="post-id-<?php the_ID(); ?>">
		
		
	<?php 
	// If the email was sent, show "thank you" text, if any
	if(isset($email_sent) && $email_sent) :
	?>
	
		<h1>Thank you!</h1>
		
		<div class="the-content">
			
			<?php 
			$thanks = get_post_meta(get_the_ID(), 'Thanks text', true);
			if (!empty($thanks)) 
				echo apply_filters('the_content', $thanks);
			else 
				echo '<p>We will be in touch with you soon.</p>'
			?>
			
		</div>
	
	<?php 
	//If the email was not sent, show the form
	else:
	?>
		<?php 
		if (have_posts()) :
			while (have_posts()) : 
				the_post();
				?>
				
			<h1 class="the-title"><?php the_title(); ?></h1>
	
			<div class="the-content">
				<?php the_content(); ?>      
			</div>     
			  
			<?php 
			endwhile; 
		endif; 
		?>
	
		<form id="wpss-page-contact" method="post" enctype="multipart/form-data">
			<?php
			if (count($errors) !== 0) :
				echo '<ul class="error-box links-list link-content">';
				foreach ($errors as $er) :
					echo '<li>&raquo; ' . $er . '</li>';
				endforeach;
				echo '</ul>';
			endif;
			?>
	
			<p>
				<label for="from_name"<?php if (is_array($errors) && array_key_exists('from_name', $errors)) echo ' class="label-error"'; ?>>Name: <strong>*</strong></label>
				<input type="text" name="from_name" id="from_name" class="text-field" value="<?php if(isset($_POST['from_name'])) echo $_POST['from_name'];?>">
			</p>
			<p>
				<label for="from_email"<?php if (is_array($errors) && array_key_exists('from_email', $errors)) echo ' class="label-error"'; ?>>Email address: <strong>*</strong></label>
				<input type="email" name="from_email" id="from_email" class="text-field" value="<?php if(isset($_POST['from_email'])) echo $_POST['from_email'];?>">
			</p>
			<?php 
			$contact_reasons = get_post_meta(get_the_ID(), 'Contact reason', false);
			if (!empty($contact_reasons)) : 
			?>
			<p>
				<label for="from_reason"<?php if (is_array($errors) && array_key_exists('from_reason', $errors)) echo ' class="label-error"'; ?>>Reason for this contact: <strong>*</strong></label>
				<select name="from_reason" id="from_reason">
					<option value="" class="deactivated">Choose...</option>
				<?php
				
				if (count($contact_reasons) > 0) :
					foreach ($contact_reasons as $opt) :
						echo '
						<option value="'.$opt.'"';
						if (isset($_GET['r'])) :
							if (stripos($opt, $_GET['r']) !== false) :
								echo ' selected';
							endif;	
						elseif (isset($from_reason) && $from_reason == $opt) :
							echo ' selected';
						endif;
						
						echo '>'.$opt.'</option>';
					endforeach;
				endif;
				?>
				</select>
			</p>
			<?php endif; ?>
			<p>
				<label for="from_message"<?php if (is_array($errors) && array_key_exists('from_message', $errors)) echo 'class="label-error"'; ?>>Your message <strong>*</strong></label>
				<textarea name="from_message" id="from_message" class="text-field" rows="" cols="" ><?php if(isset($_POST['from_message'])) {
					if(function_exists('stripslashes')) 
						echo stripslashes($_POST['from_message']);
					else 
						echo $_POST['from_message'];
				
				 } ?></textarea>
			</p>
				
			<p class="hidden">
				<label for="honeypot">If you want to submit this form, leave this field blank</label>
				<input type="text" name="honeypot" id="honeypot" value="<?php if(isset($_POST['honeypot']))  echo $_POST['honeypot'];?>">
			</p>
			
			<p>
				<input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wpsoftsell-nonce') ?>">
				<input type="submit" id="wpss-page-contact-submit" value="Contact &raquo;">
			</p>
			
		</form>
	
	<?php endif ; ?>
	
	</div><!-- .content-full -->
    
<?php get_footer(); ?>