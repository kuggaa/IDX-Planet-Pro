<?php 
/*
Template Name: Mobile page
*/

get_header(); ?>

<div id="content-wrap">

	<?php do_action('wpd_hook_before_content'); ?>
  	
    <div id="mobile-column" class="link-col">
    
		<?php dynamic_sidebar('sidebar-mobile-' . get_the_ID()) ?>

	</div>
	
	<?php do_action('wpd_hook_after_content'); ?>
    
</div>

<?php get_footer(); ?>

    
<?php get_footer(); ?>