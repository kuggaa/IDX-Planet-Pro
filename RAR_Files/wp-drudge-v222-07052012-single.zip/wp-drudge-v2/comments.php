<?php // Do not delete these lines
	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

	if (!empty($post->post_password)) { // if there's a password
		if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
			?>

			<p class="nocomments">This post is password protected. Enter the password to view comments.</p>

			<?php
			return;
		}
	}

	/* This variable is for alternating comment background */
	$oddcomment = ' alt';
?>

<?php if ($comments) : ?>
	<p id="comments"><?php comments_number('No responses', 'One response', '% responses' );?> to <em><?php the_title(); ?></em></p>

	<ol class="commentlist">
	<?php foreach ($comments as $comment) : ?>
		<li id="comment-<?php comment_ID() ?>" class="a-comment<?php echo $oddcomment; ?>">
			
			<span class="the-meta">On <?php comment_date('F jS, Y') ?> at <?php comment_time() ?> <?php edit_comment_link('edit','&nbsp;&nbsp;',''); ?>, <?php comment_author_link() ?> said...</span>
			<?php if ($comment->comment_approved == '0') : ?>
			<span class="the-meta">Your comment is awaiting moderation.</span>
			<?php endif; ?>
			<?php echo get_avatar( $comment, 32 ); ?>
			<?php comment_text();?>
			<div class="clear"></div>

		</li>
	<?php endforeach; /* end for each comment */ ?>
	</ol>
	
<?php endif; ?>

<?php comment_form(); ?>