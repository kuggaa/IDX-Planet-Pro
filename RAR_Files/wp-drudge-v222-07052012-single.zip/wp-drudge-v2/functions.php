<?php

define('WP_DRUDGE_CURRENT_VERSION', '2.2.2');

/***
Get WP-Drudge array of options 
***/

$wpd_options = get_option('wpdrudge_settings_array');


/***
Removing public WP version - security measure
***/

remove_action('wp_head', 'wp_generator');


/***
Adding theme support for post thumbnails
***/

add_theme_support('post-thumbnails');


/***
Removing custom fields from posts
***/

if ($wpd_options['wpd_display_cfields'] == 'yes') {
	function wpd_remove_cfields() {
		remove_meta_box('postcustom','post','normal');
	}
	add_action('admin_head', 'wpd_remove_cfields');
}


/***
Removing page and post editor
***/

if ($wpd_options['wpd_display_rmeditor'] == 'yes') {
	function custom_colors() {
	   echo '
	   <style type="text/css">
		   #postdivrich {display: none}
		 </style>';
	}
	add_action('admin_head', 'custom_colors');
}


/***
Create the new custom feed that will use the correct links and add images and blurbs
***/

function create_drudgefeed() {
	load_template( TEMPLATEPATH . '/wp-drudge-feed.php');
}
add_action('do_feed_linkfeed', 'create_drudgefeed', 10, 1);


/***
Registering header and footer menu, respectively
***/

register_nav_menus( array(
	'header' => 'Top navigation',
	'footer' => 'Footer links',
	'mobile' => 'Menu for mobile site'
) );


/***
Registering homepage 
***/

register_sidebar( array(
	'name'=>'Left Column',
	'id' => 'sidebar-1',
	'description'   => 'Left column on the homepage',
	'before_widget' => '<div class="widget-box" id="%1$s">',
	'after_widget' => '</div>',
	'before_title' => '<h2 class="widget-head">',
	'after_title' => '</h2>',
));

register_sidebar( array(
	'name'=>'Middle Column',
	'id' => 'sidebar-2',
	'description'   => 'Middle column on the homepage',
	'before_widget' => '<div class="widget-box" id="%1$s">',
	'after_widget' => '</div>',
	'before_title' => '<h2 class="widget-head">',
	'after_title' => '</h2>',
));

register_sidebar( array(
	'id' => 'sidebar-3',
	'name'=>'Right Column',
	'description'   => 'Right column on the homepage',
	'before_widget' => '<div class="widget-box" id="%1$s">',
	'after_widget' => '</div>',
	'before_title' => '<h2 class="widget-head">',
	'after_title' => '</h2>',
));

if ($wpd_options['wpd_display_rightcol'] != 'yes') {
	
	/***
	Check for category display type and register the sidebar if needed
	***/
	
	if ($wpd_options['wpd_display_catpage'] == '3 columns') {
		
		register_sidebar( array(
			'id' => 'sidebar-archive',
			'name'=>'Category and archive pages',
			'description'   => 'Add widgets here for them to appear on the category and archive pages',
			'before_widget' => '<div class="widget-box" id="%1$s">',
			'after_widget' => '</div>',
			'before_title' => '<h2 class="widget-head">',
			'after_title' => '</h2>',
		));
	}
	
	/***
	Register the post sidebar if needed
	***/
	register_sidebar(
	array(
		'id' => 'sidebar-post',
		'name'=>'Single post page',
		'description' => 'Add widgets here for them to appear on the single post pages',
		'before_widget' => '<div class="widget-box" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget-head">',
		'after_title' => '</h2>',
	));
}


/***
Creating new WP-Drudge page templates 
***/

$page_args = array(
	'post_type' => 'page',
	'numberposts' => -1,
	'meta_key' => '_wp_page_template',
    'meta_value' => 'template-page-wpdrudge.php',
);

$all_pages = get_posts($page_args);

foreach ($all_pages as $a_page) :
	register_sidebar(
	array(
		'id' => 'sidebar-page-' . $a_page->ID . '-col1',
		'name'=>'Column 1 - "' . $a_page->post_title . '"',
		'description' => 'Add widgets here for them to appear on the page title listed above',
		'before_widget' => '<div class="widget-box" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget-head">',
		'after_title' => '</h2>',
	));
	
	register_sidebar(
	array(
		'id' => 'sidebar-page-' . $a_page->ID . '-col2',
		'name'=>'Column 2 - "' . $a_page->post_title . '"',
		'description' => 'Add widgets here for them to appear on the page title listed above',
		'before_widget' => '<div class="widget-box" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget-head">',
		'after_title' => '</h2>',
	));
	
	register_sidebar(
	array(
		'id' => 'sidebar-page-' . $a_page->ID . '-col3',
		'name'=>'Column 3 - "' . $a_page->post_title . '"',
		'description' => 'Add widgets here for them to appear on the page title listed above',
		'before_widget' => '<div class="widget-box" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget-head">',
		'after_title' => '</h2>',
	));
endforeach;


/***
Creating new WP-Drudge mobile templates 
***/

$mobile_args = array(
	'post_type' => 'page',
	'numberposts' => -1,
	'meta_key' => '_wp_page_template',
    'meta_value' => 'template-page-mobile.php',
);

$mob_pages = get_posts($mobile_args);

foreach ($mob_pages as $a_page) :
	register_sidebar(
	array(
		'id' => 'sidebar-mobile-' . $a_page->ID,
		'name'=>'Mobile page - "' . $a_page->post_title . '"',
		'description' => 'Add widgets here for them to appear on the page title listed above',
		'before_widget' => '<div class="widget-box" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="widget-head">',
		'after_title' => '</h2>',
	));
endforeach;


/***
Creating an internal redirect to add the dynamic CSS
***/

add_filter('query_vars', 'add_css_var');
function add_css_var($public_query_vars) {
	$public_query_vars[] = 'wpdrudge_css';
	return $public_query_vars;
}

add_action('template_redirect', 'options_css');
function options_css(){
	$css = get_query_var('wpdrudge_css');
	switch ($css) {
		case 'css' :
			include_once (TEMPLATEPATH . '/css/style.php');
			exit;
	}
}


/***
Adding JS and CSS files to the WP admin
***/
function wpd_admin_css_js () {

	echo '
	<link type="text/css" rel="stylesheet" href="' . get_bloginfo('template_url') . '/css/admin.css?v='.constant('WP_DRUDGE_CURRENT_VERSION').'">
	<script type="text/javascript" src="' . get_bloginfo('template_url') . '/js/admin.js?v='.constant('WP_DRUDGE_CURRENT_VERSION').'"></script>
	';
	

}

add_action('admin_head', 'wpd_admin_css_js');

/***
Inserting header and footer code
***/

function wpd_add_header_code() {
	echo '
	
<!-- WP-Drudge admin header code start -->
<!-- version ' . get_option('WP-Drudge_activation_check') . ' -->
' . stripslashes(get_key('wpd_code_header')) . '
<!-- / WP-Drudge header code -->

';
}

function wpd_add_footer_code() {
	echo '
	
<!-- WP-Drudge admin footer code start -->
' . stripslashes(get_key('wpd_code_footer')) . '
<!-- / WP-Drudge footer code -->

	';
}

add_action('wp_head', 'wpd_add_header_code');
add_action('wp_footer', 'wpd_add_footer_code');



/***
Including all widgets and modular functions
***/

// Settings page
include_once dirname( __FILE__ ) . '/inc/settings.php';

// Functions to build posted links and display the featured post
include_once dirname( __FILE__ ) . '/inc/helpers.php';

// Function to build the posted link widget
include_once dirname( __FILE__ ) . '/inc/drudge_column_posts_widget.php';

// Function to build the static links widget
include_once dirname( __FILE__ ) . '/inc/drudge_column_links_widget.php';

// Function to build the subscribe widget
include_once dirname( __FILE__ ) . '/inc/drudge_column_subscribe_widget.php';

// Function to build the Google News widget
include_once dirname( __FILE__ ) . '/inc/drudge_column_gnews_widget.php';

// Function to build the RSS feed widget
include_once dirname( __FILE__ ) . '/inc/drudge_column_feed_widget.php';

// Function to build the ad widget
include_once dirname( __FILE__ ) . '/inc/drudge_column_ad_widget.php';

// Function to build the contact widget
include_once dirname( __FILE__ ) . '/inc/drudge_column_contact_widget.php';

// Functions to build posted links and display the featured post
include_once dirname( __FILE__ ) . '/inc/drudge_advertising.php';

// Functions to build posted links and display the featured post
include_once dirname( __FILE__ ) . '/inc/essentials.php';