// JavaScript Document

function wpdRestoreConfirm() {
	
	var answer = confirm("Are you sure you want to restore the default values? This will permenantly delete any options you've saved (all site content will not be modified).")
	if (answer){
		return true
	}
	
}


jQuery(document).ready( function() {
	
	// Grabbing current screen to show and adding the class to make that happen
	var initShowScreen = jQuery('#wpd-show-panel').attr('value');
	jQuery('#' + initShowScreen).addClass('show');
	jQuery('#wpd-options-nav a[rel=' + initShowScreen + ']').addClass('active');
	
	// Tabbed navigation on the Options page
	jQuery('#wpd-options-nav a').click( function() {
		
		var showScreen = jQuery(this).attr('rel');
		
		if (showScreen != '') {
		
			// Make the clicked on button active
			jQuery('#wpd-options-nav a').removeClass('active');
			jQuery(this).addClass('active');
			
			// Displaying the right screen and setting the form element to keep it there
			jQuery('table.wpd-form-table').removeClass('show');
			jQuery('#' + showScreen).addClass('show');
			jQuery('#wpd-show-panel').attr('value', showScreen);
		
		}
		
	})
	
	// Adding documentation links in helpful places
	
	jQuery('#addlink #post-body-content').prepend('<a class="help-box" href="http://wpdrudge.com/docs/adding-static-links" target="_blank">Help adding static links &raquo;</a>');
	
	jQuery('#widgets-left').prepend('<a style="margin-top: 10px" class="help-box" href="http://wpdrudge.com/docs/widgets" target="_blank">Help with WP-Drudge widgets &raquo;</a>');
	
	// WP Drudge advertising 
	
	if (pagenow === 'wpdrudge_ad' && (adminpage === 'post-php' || adminpage === 'post-new-php')) {
			
			jQuery("#wpd_ad_code_box, #postimagediv, #wpd_ad_link_box").hide();
	
			if (jQuery("#wpd_ad_type_image").is(':checked')) {
				jQuery("#postimagediv, #wpd_ad_link_box").show();
			}
			if (jQuery("#wpd_ad_type_code").is(':checked')) {
				jQuery("#wpd_ad_code_box").show();
			}
			
			jQuery("#wpd_ad_type_image").click( function() {
				jQuery("#wpd_ad_code_box").hide();
				jQuery("#postimagediv, #wpd_ad_link_box").slideDown();
			})
			jQuery("#wpd_ad_type_code").click( function() {
				jQuery("#postimagediv, #wpd_ad_link_box").hide();
				jQuery("#wpd_ad_code_box").slideDown();
			})
			
			jQuery("#postimagediv h3 span").text("Banner image");
	}

});