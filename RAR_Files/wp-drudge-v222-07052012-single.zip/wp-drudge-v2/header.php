<!DOCTYPE HTML>

<html <?php language_attributes(); ?>>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <meta charset="<?php bloginfo( 'charset' ); ?>" >
	
    <meta name="viewport" content="width=device-width">
    
    <title><?php 
	/*
	Generic function to build a home page title from the stie name and description, in none is given
	This can be overridden by a plugin
	*/
	if (is_front_page()) :
		bloginfo('name');
		$blog_description = get_bloginfo('description');
		if (!empty($blog_description) && $blog_description != 'Just another WordPress site') :
			echo ' | ' . get_bloginfo('description');
		endif;
	else :
		wp_title(''); 
	endif;
	?></title>
    
	
	<link rel="stylesheet" href="<?php bloginfo('url') ?>/?wpdrudge_css=css<?php 
	/*
	Adding the version number to refresh browser caches when a new version is installed
	*/
	echo '&amp;v=' . urlencode(get_option('WP-Drudge_activation_check'));
	?>" type="text/css">
    
    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name') ?> Main RSS Feed" href="<?php bloginfo('url') ?>/?feed=rss2" >
    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name') ?> Links RSS Feed" href="<?php bloginfo('url') ?>/?feed=linkfeed" >
    
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" >
    
    <?php wp_head(); ?>
	
</head>

<body class="<?php if (get_key('mobile_ua', 'wpd_mobile_info')) : ?> wpd-mobile-ua-detected<?php endif; ?>">

<div id="<?php if (get_key('mobile_page_tpl', 'wpd_mobile_info')) : ?>mobile-wrapper<?php else: ?>wrapper<?php endif; ?>" class="spacing-<?php echo get_key('wpd_display_spacing') ?>">

  <?php echo wpd_display_mobile_prompt() ?>

  <div id="header">
    
    <?php 
	wpd_get_ad('site-top'); 
	
	if (is_page_template('template-page-mobile.php')) wpd_get_ad('mobile-top'); 
	?>
	
	<?php if (get_key('wpd_display_featured') == 'above') wpdrudge_echo_featured(); ?>
  
  	<p><a id="logo-or-name" href="<?php bloginfo('url') ?>"><?php 
	/*
	Display the logo image or the site name
	*/
	$logo = get_key('wpd_display_logo');
	if (isset($logo) && !empty($logo)) :
	?>
	<img src="<?php echo $logo ?>" alt="<?php bloginfo('name') ?>" >
	<?php 
	else :
		bloginfo('name');
	endif;
	?></a></p>
	
    <?php 
	/*
	Show the tagline using the correct HTML tag (SEO purposes)
	*/
	$tagline = get_bloginfo('description');
	if (get_key('wpd_display_tagline') ==  'yes' && !empty($tagline)) :
	
		if (is_home()) $tagline_tag = 'h1';
		else $tagline_tag = 'p';
	
		echo '<' . $tagline_tag . ' id="tagline">' . $tagline . '</' . $tagline_tag . '>';
		
	endif; 
	
	
	/*
	If this is not a mobile page template, show regular menu and categories
	*/
	if (! get_key('mobile_page_tpl', 'wpd_mobile_info')) : 
		
		wp_nav_menu( array( 'theme_location' => 'header', 'menu_class' => 'header-nav', 'container' => 'none', 'fallback_cb' => false ) ); 
		
		/*
		Check if the categories should be displayed automatically
		*/
		if (get_key('wpd_display_catlisting') == 'yes') :
		
			echo '
			<ul class="header-nav">
				<li class="clear">Categories: </li>';
			wp_list_categories(array(
				'depth' => '0',
				'hierarchical' => '0',
				'title_li' => ''
			));	
			echo '
			</ul>';
			
		endif;
		
	/*
	If this is a mobile page template, show the mobile menu
	*/
	else : 
		
		wp_nav_menu( array( 'theme_location' => 'mobile', 'menu_class' => 'header-nav', 'container' => 'none', 'fallback_cb' => false ) ); 
		
	endif; 
	?>
	<div class="clear"></div>
  </div>
  
    
    <?php wpd_get_ad('content-top') ?>
    
    <div id="main-content">
	
   		<?php if (get_key('wpd_display_featured') == 'below') wpdrudge_echo_featured(); ?>