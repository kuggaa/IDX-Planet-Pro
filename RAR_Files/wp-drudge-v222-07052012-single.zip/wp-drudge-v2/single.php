<?php get_header(); ?>

	<div id="content-wrap">
    
    	<?php 
		if (get_key('wpd_display_rightcol') == 'yes') $sidebar_id = 'sidebar-3'; 
		else $sidebar_id = 'sidebar-post'; 
		?>
		
		<?php if (is_active_sidebar($sidebar_id)) : ?>
        <div id="single-col">
        <?php else: ?>
        <div id="single-wide">
        <?php endif; ?>
	  
			<?php 
			if (have_posts()) :
				while (have_posts()) : 
					the_post(); 
					$curr_link = get_drudge_metas(get_the_ID(), false);
					?>
				
					<h1 class="the-title"><?php the_title(); ?></h1>
				
				<?php 
				// Checking for a stored external link
				if ( !empty($curr_link['link_out']) ) :
				?><p class="external-link"><a href="<?php echo $curr_link['link_out'] ?>"<?php echo $curr_link['link_insert'] ?>>Go to this article <img src="<?php bloginfo('template_url') ?>/images/link.gif" alt="" width="13" height="13" /></a></p>
				<?php endif; ?>
	
				<div class="the-content">
					
					<?php 
					$show_meta = get_key('wpd_display_postinfo');
					if ($show_meta == 'yes') : 
					?>
					<p class="the-meta">Posted on <?php the_date('n/j/Y') ?> by <?php the_author_posts_link() ?><?php if (comments_open()) { echo ' with <a href="#the-comments">'; comments_number('0 comments', '1 comment', '% comments'); echo '</a>';}?></p>
					<?php endif ; ?>
					
					<?php echo $curr_link['image_html']; ?>  
		
					<?php 
					$use_blurb = get_post_meta(get_the_id(), 'use_blurb', true);
	
					// If no override is found, use the current option
					if (empty($use_blurb))
						$use_blurb = get_key('wpd_display_blurbbody');
						
					if ($use_blurb == 'body text everywhere' || $use_blurb == 'blurb on list and body on post pages' || empty($curr_link['link_out'])) the_content();
					else echo $curr_link['blurb'];
					 
					wp_link_pages(); 
					?>  
					    
				</div>     
				   
				<div id="the-comments">
					<?php if (get_key('wpd_display_fbcomments') == 'yes') : ?>
						<div class="fb-comments-wrap">
							<div class="fb-comments" data-href="<?php echo get_permalink() ?>" data-num-posts="2" data-width="482" style="max-width: 100%"></div>
						</div>
					<?php 
					else: 
						comments_template(); 
					endif; 
					?>
			
				</div>       
	
			<?php endwhile; endif; ?>
			
			<p class="home-link"><a href="<?php bloginfo('url') ?>">&laquo; Back home</a></p>			
		</div>
		
		<?php if (is_active_sidebar($sidebar_id)) : ?>
        <div id="sidebar-col" class="link-col<?php echo ($single ? ' single' : '' ); ?>">
            <?php dynamic_sidebar($sidebar_id) ?>
        </div>
		<div class="clear"></div>
        <?php endif; ?>
		
 </div>

<?php get_footer(); ?>

