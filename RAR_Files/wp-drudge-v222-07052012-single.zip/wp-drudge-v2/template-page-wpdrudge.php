<?php 
/*
Template Name: WP-Drudge page
*/

get_header(); ?>

<div id="content-wrap">
	
	<?php 
	if (have_posts()) :
		while (have_posts()) : 
			the_post();
			?>
	<div class="page-header">
		
		<p class="home-link"><a href="<?php bloginfo('url') ?>">&laquo; Back home</a></p>
		
		<?php if ($title = get_the_title()) : ?>
		<h1><?php echo $title ?></h1>
		<?php endif; ?>
		
		<div class="the-content">
			<?php the_content(); ?>      
		</div>    
	</div> 

	<?php endwhile; endif; ?>

	<?php do_action('wpd_hook_before_content'); ?>
  	
    <div id="column-1" class="link-col">
    
		<?php dynamic_sidebar('sidebar-page-' . get_the_ID() . '-col1') ?>

	</div>
    
    <div id="column-2" class="link-col">
    
		<?php dynamic_sidebar('sidebar-page-' . get_the_ID() . '-col2') ?>

	</div>
    
    <div id="column-3" class="link-col">
    
		<?php dynamic_sidebar('sidebar-page-' . get_the_ID() . '-col3') ?>

	</div>
	
	<div class="clear"></div>	
	
	<?php do_action('wpd_hook_after_content'); ?>
    
</div>

<?php get_footer(); ?>

    
<?php get_footer(); ?>