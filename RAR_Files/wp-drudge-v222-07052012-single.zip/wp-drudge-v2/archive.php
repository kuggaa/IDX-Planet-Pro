<?php get_header(); ?>

<div id="content-wrap">

<?php 
if ($wpd_options['wpd_display_rightcol'] == 'yes') $sidebar_id = 'sidebar-3'; 
else $sidebar_id = 'sidebar-archive'; 

/*
This page displays all the various agregation pages
*/
$archive_disp = get_key('wpd_display_catpage');

if (is_category()) { 
	$page_title = 'Links in &ldquo;' . single_cat_title('',false) . '&rdquo;';
} elseif (is_tag() ) { 
	$page_title = 'Links tagged &ldquo;' . single_tag_title('',false) . '&rdquo;';
} elseif (is_day()) { 
	$page_title = 'Archive for ' . get_the_time('F jS, Y');
} elseif (is_month()) { 
	$page_title = 'Archive for ' . get_the_time('F, Y');
} elseif (is_year()) { 
	$page_title = 'Archive for ' . get_the_time('Y');
} elseif (is_author()) { 
	$thisauthor = get_userdata(intval($author));
	$name = ucfirst($thisauthor->user_nicename);
	$page_title = 'Posts by ' . $name;
}

$single = false;

// If the display is 3-column or 2-column with a sidebar
if ($archive_disp[0] == '3') : 

	if (have_posts()) : 
	
		$x = 1;
		
		// 3 column display
		if (!is_active_sidebar($sidebar_id)) : 
			
			// Create 3 post columns
			$column = array(
				1 => array(),
				2 => array(),
				3 => array()
			);
			
			while (have_posts()) : 
				
				the_post();
				
				if (!defined('CURRENT_FEATURED_POST') || get_the_ID() != constant('CURRENT_FEATURED_POST')) {
					// Shuffle the posts sequentially across the 3 columns, keeping the newest at the top
					if ($x == 1) {
						$column[1][] = $post;
						$x++;	
					} elseif ($x == 2) {
						$column[2][] = $post;	
						$x++;
					} elseif ($x == 3) {
						$column[3][] = $post;	
						$x = 1;
					} 
				}
			
			endwhile;
		
		// 2 column display
		else: 
			
			// Create 2 post columns 
			$column = array(
				1 => array(),
				2 => array()
			);
			
			while (have_posts()) : 
				
				the_post();
				
				if (!defined('CURRENT_FEATURED_POST') || get_the_ID() != constant('CURRENT_FEATURED_POST')) {
					// Shuffle the posts sequentially across the 2 columns, keeping the newest at the top
					if ($x == 1) {
						$column[1][] = $post;
						$x++;	
					} elseif ($x == 2) {
						$column[2][] = $post;	
						$x = 1;
					} 
				}
			
			endwhile;
			
		endif; 
	
	endif ; 
	
// If the display is simple list
else:
	
	$single = true;
	
	while (have_posts()) {
			
		the_post();
		
		if (!defined('CURRENT_FEATURED_POST') || get_the_ID() != constant('CURRENT_FEATURED_POST')) {
			$column[1][] = $post;
		}
	
	}
	
	if (is_active_sidebar($sidebar_id)) {
		echo '
		<div id="single-col">';

	} else {
		echo '
		<div id="single-wide">';
	}

endif; ?>
	<div class="page-header">
		<p class="home-link"><a href="<?php bloginfo('url') ?>">&laquo; Back home</a></p>
		<h1><?php echo $page_title ?></h1>
	</div>

		<?php 
		if (count($column[1]) < 1) :
		
			echo '<h3><em>Nothing to show</em></h3>';
		
		else :
		
			$y = 1;
			
			foreach ($column as $col) :
				echo '
				<div id="column-'.$y.'" class="link-col">';
				
				echo'
					<div class="widget-box" style="border: none">
						<ul class="posts-list';
			
			if (get_key('wpd_display_postedlink_border') == 'yes') {
					echo ' border';
				}
			
			echo'">';
					
					foreach ($col as $one) :
			
						$curr_link = get_drudge_metas($one->ID, false);
						
						// Now we output the individual link
						echo '
						<li class="the-content'.$curr_link['class_insert'].'">';
						
						if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'top') {	
							echo $curr_link['image_html'];
						}
						
						echo $curr_link['link_html'];
			
						if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'middle') {	
							echo $curr_link['image_html'];
						}
						
						if ($curr_link['blurb'] != '') {
							echo $curr_link['blurb'];
						}
						
						if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'bottom') {	
							echo $curr_link['image_html'];
						}
						
						echo '
							</li>'; 
					
					endforeach;
					
				echo '
						</ul>
					</div>
					
				</div>';
				$y++;	
			
			endforeach;
		
		endif;

	if ($single) : 
	?>

	</div>
	
<?php	
endif ;
?>

	<?php if (is_active_sidebar($sidebar_id)) : ?>
    <div id="sidebar-col" class="link-col<?php echo ($single ? ' single' : '' ); ?>">
        <?php dynamic_sidebar($sidebar_id) ?>
    </div>
    <?php endif; ?>
	
	<div class="clear"></div>
	
		<?php if (get_previous_posts_link() || get_next_posts_link()) { ?>
		<div class="post-navigation">
			<div class="alignleft"><?php previous_posts_link('&laquo; Newer Entries') ?></div>
			<div class="alignright"><?php next_posts_link('Older Entries &raquo;') ?></div>
			<div class="clear"></div>
		</div>
		<?php } ?>
		
 </div>

<?php get_footer(); ?>
