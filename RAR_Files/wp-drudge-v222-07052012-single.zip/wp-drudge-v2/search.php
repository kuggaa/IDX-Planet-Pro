<?php get_header(); ?>

<div id="content-wrap">

  <div id="single-wide">
  	
    <p class="home-link"><a href="<?php bloginfo('url') ?>">&laquo; Back home</a></p>
	<h1>Results for: &ldquo;<?php the_search_query(); ?>&rdquo;</h1>

		<?php 
		if (have_posts()) : 
			while (have_posts()) {
				
				the_post();
				$column[1][] = $post;
			
			}
			
			$y = 1;
			
			foreach ($column as $col) :
				echo '
				<div id="column-'.$y.'" class="link-col">';
				
				echo'
					<div class="widget-box" style="border: none">
						<ul class="posts-list">';
					
					foreach ($col as $one) :
			
						$curr_link = get_drudge_metas($one->ID, false);
						
						// Now we output the individual link
						echo '
							<li class="the-content'.$curr_link['class_insert'].'">';
						
						if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'top') {	
							echo $curr_link['image_html'];
						}
						
						echo $curr_link['link_html'];
						
						if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'middle') {	
							echo $curr_link['image_html'];
						}
						
						echo $curr_link['blurb'];
						
						if ($curr_link['image_html'] && $wpd_options['wpd_display_image'] == 'bottom') {	
							echo $$curr_link['image_html'];
						}
						
						echo '
							</li>'; 
					
					endforeach;
					
				echo '
						</ul>
					</div>
					
				</div>';
				$y++;	
			
			endforeach;
		else:
			echo '<h3>No results!</h3>';
		endif;
		?>
	</div>
	
	
	<div class="clear"></div>
	
	<?php if (get_previous_posts_link() || get_next_posts_link()) { ?>
	<div class="post-navigation">
		<div class="alignleft"><?php previous_posts_link('&laquo; Newer Entries') ?></div>
		<div class="alignright"><?php next_posts_link('Older Entries &raquo;') ?></div>
		<div class="clear"></div>
	</div>
	<?php } ?>
		
 </div>

<?php get_footer(); ?>