<?php get_header(); ?>

	<div id="content-wrap">
    
    	<?php 
		if ($wpd_options['wpd_display_rightcol'] == 'yes') $sidebar_id = 'sidebar-3'; 
		else $sidebar_id = 'sidebar-post'; 
		?>
        
        <?php if (is_active_sidebar($sidebar_id)) : ?>
        <div id="single-col">
        <?php else: ?>
        <div id="single-wide">
        <?php endif; ?>
	  
			<?php 
			if (have_posts()) :
				while (have_posts()) : 
					the_post();
					?>
				
				<h1 class="the-title"><?php the_title(); ?></h1>
	
				<div class="the-content">
					<?php the_content(); ?>      
				</div>     
				   
				<div id="the-comments">
				   <?php comments_template(); ?>
				</div>       
	
			<?php endwhile; endif; ?>
			
			<a class="home-link" href="<?php bloginfo('url') ?>">&laquo; Back home</a>
			
		</div>
		
		<?php if (is_active_sidebar($sidebar_id)) : ?>
        <div id="sidebar-col" class="link-col<?php echo ($single ? ' single' : '' ); ?>">
            <?php dynamic_sidebar($sidebar_id) ?>
        </div>
		<div class="clear"></div>	
        <?php endif; ?>

 </div>

<?php get_footer(); ?>

