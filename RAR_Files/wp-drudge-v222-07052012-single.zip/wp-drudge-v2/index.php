<?php get_header(); ?>

<div id="content-wrap">

	<?php do_action('wpd_hook_before_content'); ?>
	
	<div id="column-1" class="link-col">
	
	<?php dynamic_sidebar('Left Column') ?>
	
	</div>
	
	<div id="column-2" class="link-col">
	
	<?php dynamic_sidebar('Middle Column') ?>
	
	</div>
	
	<div id="column-3" class="link-col">
	
	<?php dynamic_sidebar('Right Column') ?>
	
	</div>
	
	<div class="clear"></div>	
	
	<?php do_action('wpd_hook_after_content'); ?>
	
</div>

<?php get_footer(); ?>
